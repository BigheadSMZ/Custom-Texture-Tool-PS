#==========================================================================================================================================
#  Custom Texture Tool PS v0.4 Beta
#  By: Bighead
#==========================================================================================================================================
#  NOTICE TO EXISTING USERS OF THE BATCH VERSION OF THIS SCRIPT!!
#==========================================================================================================================================
#  
#  It is NOT necessary to configure any options through editing this script. You never need to edit it at all!
#
#  It is instead suggested to use the new "Internal Options Menu" that can be found on the Main Menu after running.
#
#  All changes made in the Internal Options Menu update this script itself to permanently store the values you modify!
#
#  Using the new Internal Options Menu is also a lot safer because it prevents entering invalid values.
#
#  If you still wish to configure the options through editing the script you can.
#
#==========================================================================================================================================
#  GLOBAL VARIABLES
#==========================================================================================================================================

# Internal Options
$global:OptiPNGPath        = "C:\Program Files (x86)\optipng-0.7.5-win32"
$global:TempFolder         = "$env:temp\CTT-PS_Temp"
$global:HideOKTextures     = $false
$global:DDSAutoRepair      = $false
$global:ForceNewMipMaps    = $false
$global:ManualRescale      = $false
$global:CopyNonTextures    = $true
$global:ScaleFixThreshold  = "0.65"
$global:AspectFixThreshold = "0.02"

# Paths (Can be changed to format like: "C:\Program Files (x86)\NVIDIA Corporation\DDS Utilities"
$global:ImageMagick        = (Get-ItemProperty -Path "HKLM:\Software\ImageMagick\Current\" -Name BinPath).BinPath
$global:NvidiaTools        = (Get-ItemProperty -Path "HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\{64963F0E-03F2-4B59-8D1B-1806545E7092}\" -Name InstallLocation).InstallLocation

#==========================================================================================================================================
#  CONSTANT VARIABLES
#==========================================================================================================================================

# File extension references.
New-Variable -Name PNG -Value '.png' -Option Constant
New-Variable -Name DDS -Value '.dds' -Option Constant
New-Variable -Name JPG -Value '.jpg' -Option Constant

# Generic variable for returning an empty string.
New-Variable -Name nullstr -Value '' -Option Constant

#==========================================================================================================================================
#  TODO LIST
#
# - Logs
# - Finish OptiPNG Support (logs and shit).
# - ReadMe for main menu options.
#
#==========================================================================================================================================
#  REFERENCE
#==========================================================================================================================================
#
#  Texture Hash Table Values - function CreateTextureInfo($inputimage) 
#
#  When a texture is ran through the main loop, a global hash table is created for the current texture. 
#  Many of the functions rely on this data and are designed around having this data readily available. 
#  Each iteration of the loop creates a new hash table for the current texture so the previous texture data is lost.
#  This is a list of all information that can be retrieved after the texture has been initialized.
#
#  $Texture.Name             -  The name of the texture without the extension.
#  $Texture.FullName         -  The name of the texture with the file extension.
#  $Texture.Extension        -  The file extension of the texture file.
#  $Texture.Path             -  The path to where the texture is currently located.
#  $Texture.FullPath         -  The full path to the texture including the texture + file extension.
#  $Texture.Relative         -  The relative path to the texture, which is the Path minus the BaseFolder (location of the script).
#  $Texture.SplitName[#]     -  Splits the texture name based on the location of underscores, to detect "tex1" or "m" for mipmap.
#  $Texture.Size             -  The file size of the texture in Bytes.
#  $Texture.Width            -  The width of the custom texture.
#  $Texture.Height           -  The height of the custom texture.
#  $Texture.Aspect           -  The aspect of the custom texture (Width/Height)
#  $Texture.Dimensions       -  The full dimensions of the custom texture in the form of (Width x Height).
#  $Texture.OldWidth         -  The width of the original texture.
#  $Texture.OldHeight        -  The height of the original texture.
#  $Texture.OldAspect        -  The aspect of the original texture (OldWidth/OldHeight)
#  $Texture.OldDimensions    -  The full dimensions of the original texture in the form of (OldWidth x OldHeight).
#  $Texture.ScaleWidth       -  The width scale of the custom texture (Width/OldWidth).
#  $Texture.ScaleHeight      -  The height scale of the custom texture (Height/OldHeight).
#  $Texture.Scale            -  The full scale of the texture in the form of  (ScaleWidth x ScaleHeight).
#  $Texture.IsMipMap         -  Stores true or false of whether or not the texture is a mipmap texture.
#  $Texture.AlphaChannel     -  Stores true or false of whether or not the texture has an alpha channel.
#
#==========================================================================================================================================
#
#  MipMap Hash Table Values - function CreateMipMapInfo($inputwidth, $inputheight)
#
#  MipMap data is also stored in the form of a hash table, but is used more dynamically in that it can be created locally during the same 
#  main loop iteration to store/retrieve different data.
#
#  * This data is created based on the current texture hash table. All other information is derived from the input dimensions.
#
#  $MipMap.Name[#]*           -  The name of the MipMap without the extension. 
#  $MipMap.FullName[#]*       -  The name of the MipMap with the file extension.
#  $MipMap.FullPath[#]*       -  The full path to the MipMap including the MipMap + file extension.
#  $MipMap.Width[#]           -  The calculated width of the MipMap based on the input dimensions.
#  $MipMap.Height[#]          -  The calculated height of the MipMap based on the input dimensions.
#  $MipMap.Dimensions[#]      -  The calculated full dimensions of the MipMap in the form of Width x Height.
#  $MipMap.RealWidth[#]*      -  The actual width of the MipMap if it exists.
#  $MipMap.RealHeight[#]*     -  The actual height of the MipMap if it exists.
#  $MipMap.RealDimensions[#]* -  The actual full dimensions of the MipMap in the form of Width x Height.
#  $MipMap.Levels             -  The number of MipMap levels calculated from the input dimensions.
#  $MipMap.LevelsCounted*     -  The number of MipMap levels found based on the name of the current texture.
#  $MipMap.LevelsMissing*     -  The number of MipMap levels that are missing based on the name of the current texture.
#  $MipMap.OddDimensions*     -  The number of MipMap levels where "Dimensions" don't match up with "RealDimensions"
#  $MipMap.Exists[#]*         -  Notifies whether or not the mipmap actually exists. 
#
#  The number of mipmaps [#] in the array is determined by the number of $MipMap.Levels.
#
#==========================================================================================================================================
#
#  Texture issues are stored in array "TextureIssue". This is what each value holds.
#
#  $TextureIssue[0] - NotHD
#  $TextureIssue[1] - Dolphin Duplicate
#  $TextureIssue[2] - Uneven Scale
#  $TextureIssue[3] - Bad Width Scale
#  $TextureIssue[4] - Bad Height Scale
#  $TextureIssue[5] - Aspect Ratio Mismatch
#  $TextureIssue[6] - Missing MipMaps
#  $TextureIssue[7] - MipMaps Bad Scale
#
#==========================================================================================================================================
#  MISC FUNCTIONS
#==========================================================================================================================================
#  Sub-function for DDSMultFour.

function DDSFindDifference([int]$inp_value)
{
	# If the input dimension is 1 or 2 then allow it to pass.
	if (([int]$inp_value -eq 1) -or ([int]$inp_value -eq 2))
	{
		return [int]$inp_value
	}
	# Divide by 4 and use modulus to check for a remainder.
	[int]$temp_value = [int]$inp_value % 4

	# Loop until there is no remainder (loop is skipped if there wasn't).
	[int]$iterations = 0
	while([int]$temp_value -ne 0)
	{
		# Count the number of iterations.
		[int]$iterations += 1

		# Add the iterations to the input value and repeat search for remainder.
		[int]$temp_value = (([int]$inp_value + [int]$iterations) % 4)
	}
	# Add the total number of loop iterations to the input value (which will result in a multiple of four).
	[int]$inp_value += [int]$iterations

	# Return the new value.
	return [int]$inp_value
}

#==========================================================================================================================================
#  To use call "DDSMultFour" and set as a variable. This tests if the input dimensions are a multiple of four, and returns a hash table that
#  supplies the corrected Width and Height and the combined dimensions. Data is retrieved with "DDS.Width" "DDS.Height" or "DDS.Dimensions".

function DDSMultFour([int]$inp_width, [int]$inp_height)
{
	# Create the values using a hash table.
	$dds = @{}
	[int]$dds.Width  = DDSFindDifference $inp_width
	[int]$dds.Height = DDSFindDifference $inp_height
	$dds.Dimensions = $nullstr + $dds.Width + "x" + $dds.Height

	# Return the hash table data.
	return $dds
}

#==========================================================================================================================================
#  Counts the number of characters in a string and extends it with empty spaces to the input amount.

function FormatString ($inp_string, $inp_limit)
{
	# Count the number of characters in the input string.
	$measureObject = $inp_string | Measure-Object -Character
	$count = $measureObject.Characters
	# Check the number characters against the desired amount.
	if ($count -lt $inp_limit)
	{
		# If the string is to be lengthened, find out how much.
		$length = $inp_limit-$count
		# Loop until the string matches the desired number of characters.
		for ($i=1; $i -le $length; $i++) { $inp_string = $inp_string + " " }
	}
	# Return the modified string.
	return $inp_string
}

#==========================================================================================================================================
#  I didn't write this function, but it's freaking amazing! It copies all text currently on the console screen and returns it!
#  Source: http://blogs.msdn.com/b/powershell/archive/2009/01/10/capture-console-screen.aspx

function CopyAllScreenText ()
{
	# Check the host name and return an empty string if the host is not the Windows PowerShell console host.
	if ($host.Name -ne 'ConsoleHost')
	{
	  write-host -ForegroundColor Red "This script runs only in the console host. You cannot run this script in $($host.Name)."
	  return $nullstr
	}

	# Initialize string builder.
	$textBuilder = new-object system.text.stringbuilder

	# Grab the console screen buffer contents using the Host console API.
	$bufferWidth = $host.ui.rawui.BufferSize.Width
	$bufferHeight = $host.ui.rawui.CursorPosition.Y
	$rec = new-object System.Management.Automation.Host.Rectangle 0,0,($bufferWidth - 1),$bufferHeight
	$buffer = $host.ui.rawui.GetBufferContents($rec)

	# Iterate through the lines in the console buffer.
	for($i = 0; $i -lt $bufferHeight; $i++)
	{
	  for($j = 0; $j -lt $bufferWidth; $j++)
	  {
		$cell = $buffer[$i,$j]
		$null = $textBuilder.Append($cell.Character)
	  }
	  $null = $textBuilder.Append("`r")
	}

	return $textBuilder.ToString()
}

#==========================================================================================================================================
#  Tests if an image is valid by generating a temporary 1x1 texture from the image file.

function ValidateTexture ($tex_Name, $tex_FullPath, $tex_Relative)
{
	# Create a temporary path to attempt to generate a test texture.
	$ValidatePath = $TempFolder + "\Validate"
	if (!(Test-Path $ValidatePath)) { New-Item -ItemType directory -Path $ValidatePath | Out-Null }

	# Run ImageMagick.
	&$ImgMagick_EXE -quiet $tex_FullPath -resize 1x1^! $TempFolder"\Validate\"$tex_Name.png

	# Remove the temporary path and generated texture.
	Remove-Item -Recurse -Force $ValidatePath

	# If an image was not generated, lastexitcode set by ImageMagick will be greater than 0.
	if ($lastexitcode -gt 0)
	{
		# Copy corrupt textures to a new folder.
		$CorruptPath = $BaseFolder + "\~CorruptTextures" + $tex_Relative
		if (!(Test-Path $CorruptPath)) { New-Item -ItemType directory -Path $CorruptPath | Out-Null }
		Copy-Item $Texture.FullPath $texoutputpath
		
		# Return that the texture was bad.
		return $false
	}
	# Return that the texture was good.
	return $true
}

#==========================================================================================================================================
#  Calculates how many mipmap levels a texture should have based on input dimensions.

function CalculateMipMapLevels($inp_width, $inp_height)
{
	# Continue to divide the width and height by 2 until 1 or lower is hit on both axis, and count the loop iterations of each.
	while($inp_width -gt 1)  { [Int]$inp_width /= 2  ; $h_iterations += 1 }
	while($inp_height -gt 1) { [Int]$inp_height /= 2 ; $w_iterations += 1 }
	# Compare the amount of loop iterations of width and height and return the greater of the two.
	if ($h_iterations -gt $w_iterations) { return $h_iterations } else { return $w_iterations }
}

#==========================================================================================================================================
#  Loop to calculate a single dimension of a mipmap based on the level.

function CalculateMipMapDimension($level, $inputvalue)
{
	# Continue the loop until it reaches the mipmap level.
	for($i=1; $i -le $level; $i++)
	{
		# Divide the input value in half for each loop iteration.
		if ($inputvalue -ge 1) { $inputvalue /= 2 }
	}
	# Return the calculated dimension.
	return $inputvalue
}

#==========================================================================================================================================
#  TEXTURE HASH TABLE
#==========================================================================================================================================
#  Gets all the necessary information about the texture and stores it into a hash table.

function CreateTextureInfo($inputimage) 
{
	$tex = @{}

	# Create strings referencing texture name/path data.
	[string]$tex.Name      = $inputimage.BaseName 
	[string]$tex.FullName  = $inputimage
	[string]$tex.Extension = $inputimage.Extension
	[string]$tex.Path      = $inputimage.DirectoryName
	[string]$tex.FullPath  = $tex.Path + "\" + $tex.FullName 
	[string]$tex.Relative  = $tex.Path.replace($BaseFolder,'')

	# Splits the texture name into up to 7 parts based on the underscores.
	$tex.SplitName = $tex.Name.split("_",7)

	# Check for "tex1" to verify it's a texture. If it is not found, then exit the function and return null.
	if ($tex.SplitName[0] -ne "tex1") { return $null }

	# Check for "m" extracted from "mip#" to check if it's a lower mipmap level from the 6th and 7th slots. This probably shouldn't be on a 
	# single line, but it's pretty self explanatory. Loops through SplitName [5] and [6] and checks if they are "m". If not, returns null.
	for($loop=5; $loop -lt 7; $loop++) { if ($tex.SplitName[$loop]) { if ($tex.SplitName[$loop].Substring(0,1) -eq "m") { return $null } } }

	# Exit the function with null if the path contains a "~" which usually indicates paths generated by this script.
	if ($tex.Path -like '*~*') { return $null }

	# Test the texture for validity (corruption, errors, not an image, etc). If it fails, return null.
	if (!(ValidateTexture $tex.Name $tex.FullPath $tex.Relative)) { return $null }

	# If it made it past the previous checks, set the texture size.
	[string]$tex.Size = (Measure-Object -InputObject $inputimage -property length -sum).sum

	# Get the width, height, and aspect of the original texture.
	$OldDimensions=$tex.SplitName[1].split("x",2)
	$tex.OldWidth  = $OldDimensions[0]
	$tex.OldHeight = $OldDimensions[1]
	$tex.OldAspect = $tex.OldWidth/$tex.OldHeight
	$tex.OldAspect = $tex.OldAspect.ToString("#.##")
	$tex.OldDimensions = $tex.OldWidth + "x" + $tex.OldHeight

	# If PNG or JPG, get the width and height using native PowerShell because it's faster than ImageMagick.
	if ($tex.Extension -eq $PNG -or $tex.Extension -eq $JPG)
	{
		$image = New-Object -ComObject Wia.ImageFile
		$image.LoadFile($tex.FullPath)
		[string]$tex.Width  = [string]$image.Width
		[string]$tex.Height = [string]$image.Height
	}

	# If DDS, get the width and height of the custom texture using ImageMagick.
	elseif ($tex.Extension -eq $DDS)
	{
		$tex.Width  = &$Identify_EXE -ping -format "%w" $tex.FullPath
		$tex.Height = &$Identify_EXE -ping -format "%h" $tex.FullPath
	}
	$tex.Dimensions = $tex.Width + "x" + $tex.Height

	# Get the aspect of the custom texture.
	$tex.Aspect = $tex.Width/$tex.Height
	$tex.Aspect = $tex.Aspect.ToString("#.##")

	# Calculate the custom texture scaling.
	$tex.ScaleWidth  = ($tex.Width/$tex.OldWidth).ToString("#.##")
	$tex.ScaleHeight = ($tex.Height/$tex.OldHeight).ToString("#.##")
	$tex.Scale       = $($tex.ScaleWidth + "x" + $tex.ScaleHeight)

	# Check for "m" to see if it is a mipmap texture.
	if ($tex.SplitName[2] -eq "m") { $tex.IsMipMap = $true } else { $tex.IsMipMap = $false }

	# Find if the texture has an alpha channel.
	$AlphaChannel = &$Identify_EXE -ping -format %[channels] $tex.FullPath
	if ($AlphaChannel -match "a") { $tex.AlphaChannel = $true } else { $tex.AlphaChannel = $false }

	return $tex
}

#==========================================================================================================================================
#  MIPMAP HASH TABLE
#==========================================================================================================================================
#  Creates MipMap information based on the input dimensions and the texture currently stored in the global hash table.
#  Only the name information is pulled from the texture hash table, the rest of the information is dynamically created from the input dimensions.

function CreateMipMapInfo($inputwidth, $inputheight)
{
	# Don't even create data if the current texture is not a mipmap.
	if (!($Texture.IsMipMap)) { return $null }

	# The important mipmap data.
	$mipmap = @{}
	$mipmap.LevelsCounted = $null
	$mipmap.LevelsMissing = $null
	$mipmap.OddDimensions = $null

	# Store how many mipmap levels the texture should have based on input dimensions.
	$mipmap.Levels = CalculateMipMapLevels $inputwidth $inputheight

	# For some reason PowerShell was designed so that arrays have to be initialized before they can be modified.
	for($i=0; $i -le $mipmap.Levels; $i++) 
	{
		$mipmap.Name += @($i)
		$mipmap.FullName += @($i)
		$mipmap.FullPath += @($i)
		$mipmap.Width += @($i)
		$mipmap.Height += @($i)
		$mipmap.Dimensions += @($i)
		$mipmap.RealWidth += @($i)
		$mipmap.RealHeight += @($i)
		$mipmap.RealDimensions += @($i)
		$mipmap.Exists += @($i)
		$mipmap.Size += @($i)
	}
	# Store information about each mipmap.
	for($i=1; $i -le $mipmap.Levels; $i++)
	{
		# Mipmap name and path stuff.
		$mipmap.Name[$i]       = $nullstr + $Texture.Name + "_mip" + $i
		$mipmap.FullName[$i]   = $nullstr + $Texture.Name + "_mip" + $i + $Texture.Extension
		$mipmap.FullPath[$i]   = $nullstr + $Texture.Path + "\" + $Texture.Name+"_mip" + $i + $Texture.Extension
		$mipmap.Width[$i]      = CalculateMipMapDimension $i $inputwidth
		$mipmap.Height[$i]     = CalculateMipMapDimension $i $inputheight
		$mipmap.Dimensions[$i] = $nullstr + $mipmap.Width[$i] + "x" + $mipmap.Height[$i]

		# Check to see if the mipmap exists.
		if (Test-Path $mipmap.FullPath[$i]) 
		{
			# Get the mipmap as an object file.
			$mipobject = Get-ChildItem $mipmap.FullPath[$i]

			# Set that the mipmap exists.
			$mipmap.Exists[$i] = $true

			# Count the number of mipmaps found
			$mipmap.LevelsCounted++

			# Get the file size of the mipmap.
			$mipmap.Size[$i] = (Measure-Object -InputObject $mipobject -property length -sum).sum

			# If PNG or JPG, get the width and height using native PowerShell because it's faster than ImageMagick.
			if ($Texture.Extension -eq $PNG -or $Texture.Extension -eq $JPG)
			{
				$image = New-Object -ComObject Wia.ImageFile
				$image.LoadFile($mipmap.FullPath[$i])
				[string]$mipmap.RealWidth[$i]  = [string]$image.Width
				[string]$mipmap.RealHeight[$i] = [string]$image.Height
			}

			# If DDS, get the width and height of the mipmap using ImageMagick.
			elseif ($Texture.Extension -eq $DDS)
			{
				$mipmap.RealWidth[$i]  = &$Identify_EXE -ping -format "%w" $mipmap.FullPath[$i]
				$mipmap.RealHeight[$i] = &$Identify_EXE -ping -format "%h" $mipmap.FullPath[$i]
			}
			$mipmap.RealDimensions[$i] = $nullstr + $mipmap.RealWidth[$i] + "x" + $mipmap.RealHeight[$i]

			# Compare the calculated dimensions with the real dimensions and count the number that don't match up.
			if ($mipmap.Dimensions[$i] -ne $mipmap.RealDimensions[$i])
			{
				$mipmap.OddDimensions++
			}
		}
		else # If the mipmap does not exist, count the number of mipmaps missing.
		{
			$mipmap.Exists[$i] = $false
			$mipmap.LevelsMissing++
		}
	}
	return $mipmap
}

#==========================================================================================================================================
#  TEXTURE CREATION
#==========================================================================================================================================
#  Creates a texture at a location using the information of the texture currently stored in the global hash table.
#  The parameters serve as modifiers to the current texture, allowing to alter the format, the width, and the height.

function CreateTexture ($format, $inputwidth, $inputheight, $outputpath)
{
# Return value that states whether or not the texture was created.
$TextureCreated = $false

# Combine the new dimensions into a single value, and add the texture to the output path.
$newDimensions = $nullstr + $inputwidth + "x" + $inputheight
$texoutputpath = $outputpath + "\" + $Texture.Name + $format

#------------------------------------------------------------------------------------------------------------------------
# Create PNG or JPG texture

if ($format -eq $PNG -or $format -eq $JPG)
{
	# Check if the texture dimensions and extensions are the same as the input values.
	if ($newDimensions.Dimensions -eq $Texture.Dimensions -and $format -eq $Texture.Extension)
	{
		# Rather than create it just copy it since the output would be identical anyway.
		Copy-Item $Texture.FullPath $texoutputpath ; $TextureCreated = $true 
	}
	# Texture didn't pass the checks so it must be created.
	else 
	{
		# If the texture is rescaled with ForcedIntScaling, apply a slight sharpening filter.
		if ($ForceIntScaling) {	$Strength="0x0.50" } else {	$Strength="0x0.00" }
		&$ImgMagick_EXE $Texture.FullPath -resize $newDimensions! -sharpen $Strength $texoutputpath ; $TextureCreated = $true
	}

#------------------------------------------------------------------------------------------------------------------------
# Create PNG or JPG MipMaps

	# Generate MipMaps.
	if ($Texture.IsMipMap)
	{
		# Create a hash table with mipmap information.
		$MipMap = CreateMipMapInfo $inputwidth $inputheight

		# Loop through all levels.
		for($i=1; $i -le $MipMap.Levels; $i++)
		{
			# Set where to create the new mipmap.
			$MipOutPutPath = $outputpath + "\" + $MipMap.Name[$i] + $format

			# Force creating new mipmaps if the user wants. If it is false, check if the mipmap exists.
			if ($ForceNewMipMaps -eq $false -and $MipMap.Exists[$i])
			{
				# Check to see if the calculated dimensions match the real dimensions.
				if ($MipMap.Dimensions[$i] -eq $MipMap.RealDimensions[$i])
				{
					# If the dimensions matched up and the file extensions are the same then simply copy it.
					if ($format -eq $Texture.Extension)
					{ Copy-Item $MipMap.FullPath[$i] $MipOutPutPath | Out-Null }

					# If the dimensions matched up but only the extension is changed then create the texture without sharpening.
					else { &$ImgMagick_EXE $MipMap.FullPath[$i] -resize $($MipMap.Dimensions[$i] + "!") $MipOutPutPath }
				}
				# If the mipmap exists, but the dimensions changed, then create the mipmap with sharpening strength.
				else { $ImageMagick ; &$ImgMagick_EXE $MipMap.FullPath[$i] -resize $($MipMap.Dimensions[$i] + "!") -sharpen 0x0.75 $MipOutPutPath }
			}
			else # If the mipmap did not exist or the user forced new mipmaps, create it from the top layer.
			{ $ImageMagick ; &$ImgMagick_EXE $Texture.FullPath -resize $($MipMap.Dimensions[$i] + "!") -sharpen 0x0.75 $MipOutPutPath }
		}
	}
}

#------------------------------------------------------------------------------------------------------------------------
# Create DDS texture

elseif ($format -eq $DDS)
{
	# Check whether or not the texture has an alpha channel.
	if ($Texture.AlphaChannel) 
	{ $DDSCompression = "-dxt5" ; $DDSQualityLevel = "-quality_highest" }
	else  # If it does not have an Alpha channel, set the compression type to DXT1c and force normal quality or it can generate artifacts.
	{ $DDSCompression = "-dxt1c" ; $DDSQualityLevel = "-quality_normal" }

	# Get a multiple of 4 version of the input dimensions.
	$NewDDS = DDSMultFour $inputwidth $inputheight

	# Set the input path for nvidia tools to the texture location. This gets overwritten with a generated texture if the next step fails.
	$NvidiaInputPath = $Texture.FullPath

	# If the DDS dimensions do not match the custom texture dimensions, create a temporary texture with the new dimensions.
	if ($NewDDS.Dimensions -ne $Texture.Dimensions)
	{
		# Set up the path for the temporary texture and create it.
		$TempTexturePath = $TempFolder + "\TempTexture\"
		if (!(Test-Path $TempTexturePath)) { New-Item -ItemType directory -Path $TempTexturePath | Out-Null }
		$NvidiaInputPath = $TempTexturePath + $Texture.FullName

		# Generate the new image.
		&$ImgMagick_EXE $Texture.FullPath -resize $($NewDDS.Dimensions + "!") -sharpen 0x0.50 $NvidiaInputPath
	}
	# If it's not a mipmap texture, simply generate it.
	if (!($Texture.IsMipMap))
	{
		# Navigate to the nvidia tools path and generate the texture.
		&$DDSUtil_EXE -file $NvidiaInputPath $DDSQualityLevel -nomipmap $DDSCompression -output $texoutputpath
		$TextureCreated = $true
	}

#------------------------------------------------------------------------------------------------------------------------
# Create DDS MipMaps

	# If it is a mipmap texture, do (a LOT) more stuff.
	else 
	{
		# Create a temporary version of the very top layer (base image) of the mipmap texture.
		$TempDDSPath = $TempFolder + "\TempDDSMipMaps"
		if (!(Test-Path $TempDDSPath)) { New-Item -ItemType directory -Path $TempDDSPath | Out-Null }
		&$DDSUtil_EXE -file $NvidiaInputPath $DDSQualityLevel -nomipmap $DDSCompression -output $($TempDDSPath + "\TempDDS_00" + $DDS)

		# Create a hash table with mipmap information.
		$MipMap = CreateMipMapInfo $NewDDS.Width $NewDDS.Height

		# Loop through all levels.
		for($i=1; $i -le $MipMap.Levels; $i++)
		{
			# Get a multiple of 4 version of the mipmap dimensions (just in case).
			$MipMapDDS = DDSMultFour $MipMap.Width[$i] $MipMap.Height[$i]

			# If it exists and the dimensions line up, then use the current mipmap as a base.
			if ($mipmap.Exists[$i] -and ($MipMapDDS.Dimensions -eq $MipMap.RealDimensions[$i]))
			{ $NvidiaPath = $MipMap.FullPath[$i] }

			# If it exists but the dimensions didn't line up, and if ForceNewMipMaps is disabled, create a temporary texture from the existing mipmap.
			elseif ($mipmap.Exists[$i] -and ($ForceNewMipMaps -eq $false))
			{ $MipMapPath = $MipMap.FullPath[$i] }

			# If it doesn't exist, the dimensions didn't line up, and/or ForceNewMaps was true, then create a temporary texture from the base texture.
			else
			{ $MipMapPath = $Texture.FullPath }

			# Check if MipMapPath was set, which means a temporary texture must be generated.
			if ($MipMapPath)
			{
				# Create the temporary MipMap folder if it does not exist.
				$TempMipMapPath = $TempFolder + "\TempMipMaps"
				if (!(Test-Path $TempMipMapPath)) { New-Item -ItemType directory -Path $TempMipMapPath | Out-Null }

				# Store the path to the temporary mipmap for DDS Utilities.
				$NvidiaPath = $TempMipMapPath + "\" + $MipMap.FullName[$i]

				# If the calculated dimensions match the real dimensions, disable sharpening. If they don't, enable sharpening.
				if ($MipMapDDS.Dimensions -eq $MipMap.RealDimensions[$i]) { $Strength = "0x0.00"} else { $Strength = "0x0.75" }

				# Create the temporary MipMap.
				&$ImgMagick_EXE $MipMapPath -resize $($MipMapDDS.Dimensions + "!") -sharpen $Strength $NvidiaPath
			}

			# Nvidia tools need texture names to be in ## format (01, 02, etc..), so correct the current level.
			if ($i -lt 10) { $Level = "0" + $i } else { $Level = $nullstr + $i }

			# Create the mipmap from the base texture (if it existed) or a temporary texture (if it did not exist).
			$NvidiaOutputPath = $nullstr + $TempDDSPath+"\TempDDS_" + $Level + $DDS
			&$DDSUtil_EXE -file $NvidiaPath $DDSQualityLevel -nomipmap $DDSCompression -output $NvidiaOutputPath

			# If the user wants to generate External mipmaps
			if ($DDSExternal)
			{
				$MipOutPutPath = $outputpath + "\"+$MipMap.Name[$i] + $format
				Copy-Item -Force $NvidiaOutputPath $MipOutPutPath | Out-Null
			}
		}

		# If the user wants to generate Internal mipmaps.
		if ($DDSInternal)
		{
			&$NSTITCH_EXE $($TempDDSPath + "\TempDDS")
			Move-Item -Force -Path $($TempDDSPath + "\TempDDS" + $DDS) -destination $texoutputpath ; $TextureCreated = $true
		}
		else # If the user does not want internal mipmaps, simply use the top layer generated earlier.
		{ Move-Item -Force -Path $($TempDDSPath + "\TempDDS_00" + $DDS) -destination $texoutputpath ; $TextureCreated = $true }
	}

	# Clean up the temporary files.
	if ($TempDDSPath) { if (Test-Path $TempDDSPath) { Remove-Item -Recurse -Force $TempDDSPath } }
	if ($TempMipMapPath) { if (Test-Path $TempMipMapPath) { Remove-Item -Recurse -Force $TempMipMapPath } }
	if ($TempTexturePath) { if (Test-Path $TempTexturePath) { Remove-Item -Recurse -Force $TempTexturePath } }
}
return $TextureCreated
}

#==========================================================================================================================================
#  A menu that is displayed when Rescaling textures and ManualRescale is enabled.

function ManualRescalePrompt()
{
	# If the user wants to default to skipping textures with 0, set it as the message. Otherwise display the stored integer as default.
	if ($StoredScale -eq "0") {	$MenuMsg = "Skip Texture" } else { $MenuMsg = $StoredScale }

	# Display the menu.
	Clear-Host
	Write-Host "-----------------------------------------------------------------------------------------------------------------------"
	Write-Host "Enter a new scale ( 1-100 , 0 = Skip Texture , Default = $MenuMsg )"
	Write-Host ""
	Write-Host "[Texture]  " $Texture.Name
	Write-Host "[Original] " $Texture.OldDimensions":"$OldAspect
	Write-Host "[Custom]   " $Texture.Dimensions":"$Aspect
	Write-Host "[FullScale]" $Texture.Scale
	Write-Host ""
	$MenuInput = Read-Host "> "

	# If the user inputs nothing, then set the input to the stored scale.
	if ($MenuInput -eq $nullstr) { $MenuInput = $StoredScale }

	# If the user wants to skip the texture then allow it.
	if ($MenuInput -eq "0") { return $true }

	# If the user wants to rescale the texture, then umm.. rescale the texture.
	elseif ([int]$MenuInput -gt 0 -and [int]$MenuInput -le 100) { $global:ForcedScale = $MenuInput ; return $false }

	# If there is no or invalid input, then use the stored scale.
	else { $global:ForcedScale = $StoredScale ; return $false }
}

#==========================================================================================================================================
#  This is called if the user forces the script to convert textures to an integer scale.

function RescaleTextureInteger()
{
	# Check to see if the user did not want to convert.
	if (!($ConvertExtension -eq $null))
	{
		#Skip if it is a JPG texture, and it has an alpha channel.
		if ($ConvertExtension -eq $JPG -and $Texture.AlphaChannel)
		{
			Write-Host " Message    : Textures with an alpha channel are not converted to (.jpg)!"
			Write-Host "-----------------------------------------------------------------------------------------------------------------------"
			return
		}
		# Use the convert extension if it is valid.
		 $RescaleExtension = $ConvertExtension

	# Use the texture extension if the user did not wist to convert.
	} else { $RescaleExtension = $Texture.Extension }

	# If the user wants to rescale textures individually, display a prompt and texture information.
	if ($ManualRescale -eq $true) {	$SkipTexture = ManualRescalePrompt } else { $SkipTexture = $false }

	# Skip the texture if the user wanted to. This can only become true with ManualRescale.
	if ($SkipTexture) { return }

	# Make sure the directory to create scaled textures exists.
	$RescaledPath = $BaseFolder + "\~RescaledTextures" + $Texture.Relative
	if (!(Test-Path $RescaledPath)) { New-Item -ItemType directory -Path $RescaledPath | Out-Null }

	# Calculate the new dimensions of the texture based on the original dimensions * the forced integer.
	[int]$NewWidth  = [int]$Texture.OldWidth * [int]$ForcedScale
	[int]$NewHeight = [int]$Texture.OldHeight * [int]$ForcedScale

	# Create a rescaled texture.
	$RescaledTexture = CreateTexture $RescaleExtension $NewWidth $NewHeight $RescaledPath

	# Report that the texture has been created.
	if ($RescaledTexture) 
	{
		Write-Host " Message    : Successfully rescaled the texture!"
		Write-Host "-----------------------------------------------------------------------------------------------------------------------"
	}
	# If the texture was not created, report an error.
	else
	{
		Write-Host " ERROR      : Texture was not created!" -ForegroundColor Red
		Write-Host "-----------------------------------------------------------------------------------------------------------------------"
	}
	return
}

#==========================================================================================================================================
#  Checks the input decimal against ScaleFixThreshold, and increments the integer if the decimal is greater than ScaleFixThreshold.

function ScaleFixThresholdCorrection ($inp_int, $inp_dec)
{
	$inp_dec /= 100
	if ([Int]$inp_dec -ge [Int]$ScaleFixThreshold) 
	{ 
		[Int]$inp_int += 1	
	}
	return $inp_int
}

#==========================================================================================================================================
#  This is called if the user forces the script to convert textures to DDS.

function ConvertTextureFormat ()
{
	# Check to see if it is already in the correct format.
	if ($ConvertExtension -eq $Texture.Extension)
	{
		Write-Host $(" Message    : Texture already in (" + $ConvertExtension + ") format!")
		Write-Host "-----------------------------------------------------------------------------------------------------------------------"
		return
	}
	# Check to see if it is a JPG texture and if it has an alpha channel, skip the texture.
	if ($ConvertExtension -eq $JPG -and $Texture.AlphaChannel)
	{
		Write-Host " Message    : Textures with an alpha channel are not converted to (.jpg)!"
		Write-Host "-----------------------------------------------------------------------------------------------------------------------"
		return
	}
	# If it's a DDS texture and auto correction is enabled, find new dimensions based on the nearest low integer scale.
	if ($DDSAutoRepair -and $ConvertExtension -eq $DDS)
	{
		# Use the smaller of the two scales (width vs. height) and store the decimals.
		if ([Int]$Texture.ScaleWidth -gt [Int]$Texture.ScaleHeight) 
		{ $NewScale = $Texture.ScaleHeight.split(".",2) } 
		else 
		{ $NewScale = $Texture.ScaleWidth.split(".",2) }

		# Send the decimal in the form of a whole number to ScaleFixThresholdCorrection (which can increment the integer if it passes).
		if ($NewScale[1]) {	$NewScale[0] = ScaleFixThresholdCorrection $NewScale[0] $NewScale[1] }

		# Use the new scaling value to determine the new dimensions.
		[Int]$NewWidth  = ([Int]$Texture.OldWidth * $NewScale[0])
		[Int]$NewHeight = ([Int]$Texture.OldHeight * $NewScale[0])
	}
	# If all that noise up there isn't true, just use the custom texture dimensions.
	else
	{
		[Int]$NewWidth  = [Int]$Texture.Width
		[Int]$NewHeight = [Int]$Texture.Height
	}
	# Store converted textures in their own unique directory.
	$ConvertedPath = $BaseFolder + "\~ConvertedTextures" + $Texture.Relative
	if (!(Test-Path $ConvertedPath)) { New-Item -ItemType directory -Path $ConvertedPath | Out-Null }

	# Create the texture in the converted directory.
	$ConvertedTexture = CreateTexture $ConvertExtension $NewWidth $NewHeight $ConvertedPath

	# Report that the texture has been created.
	if ($ConvertedTexture) 
	{
		Write-Host $(" Message    : Successfully converted to (" + $ConvertExtension + ") format!")
		Write-Host "-----------------------------------------------------------------------------------------------------------------------"
	}
	# If the texture was not created, report an error.
	else
	{
		Write-Host " ERROR      : Texture was not created!" -ForegroundColor Red
		Write-Host "-----------------------------------------------------------------------------------------------------------------------"
	}
	return
}

#==========================================================================================================================================
#  ISSUE TRACKING AND REPAIR
#==========================================================================================================================================
#  Try to fix the texture and/or copy the broken texture to a new directory.

function RepairAndCopy()
{
	# A flag that tells that the texture is currently broken.
	$FixedTexture = $false

	# Test if the texture aspect difference is within the aspect fix threshold.
	$AspectDif = $Texture.Aspect - $Texture.OldAspect
	if ($AspectDif -lt 0) { $AspectDif *= -1 }
	$ApectPass = ($AspectDif -le [int]$AspectFixThreshold)

	# Attempt to repair the bad texture.
	if ($AutoFixTextures -and $ApectPass)
	{
		# Use the smaller of the two scales (width vs. height) and store the decimals.
		if ([Int]$Texture.ScaleWidth -gt [Int]$Texture.ScaleHeight) 
		{ $NewScale = $Texture.ScaleHeight.split(".",2) } 
		else 
		{ $NewScale = $Texture.ScaleWidth.split(".",2) }

		# Send the decimal in the form of a whole number to ScaleFixThresholdCorrection (which can increment the integer if it pases).
		if ($NewScale[1]) {	$NewScale[0] = ScaleFixThresholdCorrection $NewScale[0] $NewScale[1] }

		# Use the new scaling value to determine the new dimensions.
		[Int]$NewWidth  = ([Int]$Texture.OldWidth * $NewScale[0])
		[Int]$NewHeight = ([Int]$Texture.OldHeight * $NewScale[0])

		# Create the repaired folder location if it does not exist.
		$OutputPath = $BaseFolder + "\~RepairedTextures" + $Texture.Relative
		if (!(Test-Path $OutputPath)) {	New-Item -ItemType directory -Path $OutputPath | Out-Null }

		# Create the repaired texture and store if it was created or not.
		$FixedTexture = CreateTexture $Texture.Extension $NewWidth $NewHeight $OutputPath

		# If the texture was repaired, report it.
		if ($FixedTexture)
		{
			Write-Host " Message    : Texture successfully repaired to " -NoNewline
			Write-Host $("~RepairedTextures" + $Texture.Relative) -ForegroundColor Green
		}
	}

	# Check if the user wants to copy bad textures, but only copy them if they weren't fixed.
	if ($CopyBadTextures -and $FixedTexture -eq $false)
	{
		# Create the broken textures folder if it does not exist and copy the broken texture.
		$OutputPath = $BaseFolder + "\~BrokenTextures" + $Texture.Relative
		if (!(Test-Path $OutputPath)) {	New-Item -ItemType directory -Path $OutputPath | Out-Null }
		Copy-Item $Texture.FullPath $OutputPath

		# If the texture was copied, report it.
		Write-Host " Message    : Texture has been copied to " -NoNewline
		Write-Host $("~BrokenTextures" + $Texture.Relative) -ForegroundColor Green
	}
}

#==========================================================================================================================================
#  Checks a texture for issues and reports to logs.

function CheckTextureForIssues()
{
	# For ease of adding new issues, store how many issues are currently detected.
	$Issues = 8

	# Initialize the issues array so it can be modified.
	for($i=0; $i -le $Issues; $i++) { $TextureIssue += @(0) }
	
	# --------------------------------------------------
	#  Issue 0: Check to see if it's actually an HD texture.
	# --------------------------------------------------
	if ($Texture.Scale -eq "1x1")	
	{ 
		# Copy NotHD textures to their own folder.
		$OutputPath = $BaseFolder + "\~NotHDTextures" + $Texture.Relative
		if (!(Test-Path $OutputPath)) {	New-Item -ItemType directory -Path $OutputPath | Out-Null }
		Copy-Item $Texture.FullPath $OutputPath

		# Set the texture issue.
		$TextureIssue[0] = "NotHD"
	}
	# --------------------------------------------------
	#  Issue 1: Check for Dolphin identified duplicates (ones that end with .1, .2, .3, etc.)
	# --------------------------------------------------
	$DolphinDupe = $Texture.Name.split(".",2)
	if ($DolphinDupe[1]) 
	{ 
		# Copy DolphinDupes to their own folder.
		$OutputPath = $BaseFolder + "\~DolphinDuplicates" + $Texture.Relative
		if (!(Test-Path $OutputPath)) {	New-Item -ItemType directory -Path $OutputPath | Out-Null }
		Copy-Item $Texture.FullPath $OutputPath

		# Set the texture issue.
		$TextureIssue[1] = "DolphinDupe"
	}
	# ----------------------------------------------------------------------------------------------------
	#  Issue 2: Duplicate Texture
	# ----------------------------------------------------------------------------------------------------
	# Check if the texture has already been added to the "Duplicates" hash table.
	if ($Duplicates.ContainsKey($Texture.Name))
	{
		# Get the value of that texture from the hash table (the size of the texture when added).
		$Check = $Duplicates.Get_Item($Texture.Name)

		# If the sizes match, then it's an exact duplicate.
		if ($Check -eq $Texture.Size) 
		{ 
			$TextureIssue[2] = "Duplicate" 
		}
		else
		{
			$TextureIssue[2] = "Duplicate (Different Size)" 
		}
		if ($TextureIssue[2] -ne 0)
		{
			# Copy Duplicates to their own folder.
			$OutputPath = $BaseFolder + "\~DuplicateTextures" + $Texture.Relative
			if (!(Test-Path $OutputPath)) {	New-Item -ItemType directory -Path $OutputPath | Out-Null }
			Copy-Item $Texture.FullPath $OutputPath
		}
	}

	# If the texture was not in the Duplicates hash table then add it.
	else { $Duplicates.Add($Texture.Name, $Texture.Size) }
	# ---------------------------------------------------------------------------

	# Certain checks will only work in PNG or JPG.
	if ($Texture.Extension -eq $PNG -or $Texture.Extension -eq $JPG)
	{
		# Create information about the texture if it is a mipmap texture (info is null if it is not).
		$global:MipMapInfo = CreateMipMapInfo $Texture.Width $Texture.Height

		# ----------------------------------------------------------------------------------------------------
		#  Issue 3: Check to see if the integer variables match between scales.
		# ----------------------------------------------------------------------------------------------------
		if ($Texture.ScaleWidth -ne $Texture.ScaleHeight)	{ $TextureIssue[3] = "UnevenScale" }

		# ----------------------------------------------------------------------------------------------------
		#  Issue 4: Check to see if the width has a decimal value.
		# ----------------------------------------------------------------------------------------------------
		if ($Texture.ScaleWidth -match '..') {	$TextureIssue[4] = "BadWidth" }

		# ----------------------------------------------------------------------------------------------------
		#  Issue 5: Check to see if the height has a decimal value.
		# ----------------------------------------------------------------------------------------------------
		if ($Texture.ScaleHeight -match '..') { $TextureIssue[5] = "BadHeight" }

		# ----------------------------------------------------------------------------------------------------
		#  Issue 6: Check to see if the aspects match between original and custom.
		# ----------------------------------------------------------------------------------------------------
		if (!($Texture.OldAspect -eq $Texture.Aspect))	{ $TextureIssue[6] = "BadAspect" }

		# ----------------------------------------------------------------------------------------------------
		#  Issue 7: Check to see if there are any missing mipmaps.
		# ----------------------------------------------------------------------------------------------------
		if ($MipMapInfo.LevelsMissing) { $TextureIssue[7] = "MipMapsMissing(x" + $MipMapInfo.LevelsMissing + ")" }

		# ----------------------------------------------------------------------------------------------------
		#  Issue 8: Check to see if there are any mipmaps with bad scaling values.
		# ----------------------------------------------------------------------------------------------------
		if ($MipMapInfo.OddDimensions) { $TextureIssue[8] = "MipMapsBadScale(x" + $MipMapInfo.OddDimensions + ")" }
	}

	# Combine all issues into a single string.
	for($i=0; $i -le $Issues; $i++) { if ($TextureIssue[$i] -ne "0")	{ $LogIssues = $LogIssues+$TextureIssue[$i] + " " } }

	# ----------------------------------------------------------------------------------------------------
	#  Log File and Console Window
	# ----------------------------------------------------------------------------------------------------
	# Format text for log files using the custom "FormatString" function.
	$LogName    = FormatString $Texture.Name 53
	$LogOldDim  = FormatString $($Texture.OldWidth + "x" + $Texture.OldHeight + ":" + $Texture.OldAspect) 14
	$LogNewDim  = FormatString $($Texture.Width + "x" + $Texture.Height + ":" + $Texture.Aspect) 14
	$LogScale   = FormatString $Texture.Scale 12
	if ($LogIssues)	{ $LogIssues = FormatString $LogIssues 60 }	else { $LogIssues = FormatString "OK" 60 }

	# Ouput formatted text to the log file.
	$LogOutput  = "| $LogName | $LogOldDim | $LogNewDim | $LogScale | $LogIssues |"
	Add-Content -path "$LogFile" -value "$LogOutput"

	# Output issues to the console.
	Write-Host " Status     :"$LogIssues

	# If it was a NotHD texture, output that it copied the file.
	if ($TextureIssue[0] -eq "NotHD") 
	{
		Write-Host " Message    : Texture has been copied to " -NoNewline
		Write-Host $("~NotHDTextures" + $Texture.Relative) -ForegroundColor Green
	}

	# If it was a DolphinDupe, output that it copied the file.
	if ($TextureIssue[1] -eq "DolphinDupe") 
	{
		Write-Host " Message    : Texture has been copied to " -NoNewline
		Write-Host $("~DolphinDuplicates" + $Texture.Relative) -ForegroundColor Green
	}

	# If it was a Duplicate, output that it copied the file.
	if ($TextureIssue[2] -eq "Duplicate (Different Size)" -or $TextureIssue[2] -eq "Duplicate (Different Size)") 
	{
		Write-Host " Message    : Texture has been copied to " -NoNewline
		Write-Host $("~DuplicateTextures" + $Texture.Relative) -ForegroundColor Green
	}
	# ----------------------------------------------------------------------------------------------------
	#  Initiate Auto-Repair and Copy Broken Textures.
	# ----------------------------------------------------------------------------------------------------
	# If the texture has issues, then attempt to repair and copy it.
	for($i=3; $i -lt $Issues; $i++) { if ($TextureIssue[$i] -ne "0") { $RunAutoFix = $true } }

	# On second thought, cancel the fix if it is a DolphinDuplicate or NotHD texture (Ugly Logic).
	for($i=0; $i -lt 3; $i++) { if ($TextureIssue[$i] -ne "0") { $RunAutoFix = $false } }

	# Try to repair the texture if it has issues and its not a DolphinDupe or NotHD texture.
	if ($RunAutoFix) { RepairAndCopy }
	Write-Host "-----------------------------------------------------------------------------------------------------------------------"
}

#==========================================================================================================================================
#  OPTIPNG
#==========================================================================================================================================
# Calculate/store stuff for OptiPNG.

function OptiData($InputPath) 
{
	$opti = @{}
	$OptiObject  = Get-ChildItem $InputPath
	$opti.Name   = $OptiObject.Name
	$opti.SizeB  = (Measure-Object -InputObject $OptiObject -property length -sum).sum
	$opti.SizeKB = ($opti.SizeB/1024).ToString("#.##")
	$opti.SizeMB = ($opti.SizeB/1024/1024).ToString("#.##")
	return $opti
}

#==========================================================================================================================================
#  Textures that pass the OptiPNG checks get passed through here. Input parameter takes a full path to the texture + file extension.

function OptimizeTexture($InputPath)
{
	# Create information of the image before optimization.
	$OldImage = OptiData $InputPath

	# Create a path to the exe file and create a usable format for the parameter.
	$OptiArg = "-o" + $OptiTests

	# Method 1: Optimize the files in-place.
	if ($OptiMethod -eq "1")
	{
		# Run OptiPNG.
		&$OptiPNG_EXE $OptiArg $InputPath

		# Set the path to check the ByteSize to the current location of the texture.
		$OptiCheckPath = $InputPath
	}

	# Method 2: Output the optimized texture to a new folder.
	elseif ($OptiMethod -eq "2")
	{
		# Create the directory to output files from OptiPNG.
		$OptimizePath = $BaseFolder + '\~OptimizedTextures' + $Texture.Relative
		if (!(Test-Path $OptimizePath)) { New-Item -ItemType directory -Path $OptimizePath | Out-Null }

		# Run OptiPNG.
		&$OptiPNG_EXE $OptiArg $InputPath -dir $OptimizePath

		# Set the path to check the ByteSize to the current location of the texture.
		$OptiCheckPath = $OptimizePath + "\" + $OldImage.Name
	}

	# Create information of the image after optimization.
	$NewImage = OptiData $OptiCheckPath

	# Check if there was actually any reduction in file size.
	if ($OldImage.SizeB -ne $NewImage.SizeB)
	{
		# Calculate the size difference in Bytes.
		$Diff_B = $OldImage.SizeB - $NewImage.SizeB
		if ($Diff_B -lt 0) { $Diff_B = $Diff_B * -1 }

		# Store the total reduction in Bytes
		$TotalReduction += $Diff_B
	}

	# If there was no reduction, perform some clean-up.
	else
	{
		# Remove the new image if there was no reduction in size.
		if ($OptiCheckPath -ne $InputPath -and (Test-Path $OptiCheckPath)) 
		{ Remove-Item -Recurse -Force $OptiCheckPath }

		# Check if the folder is empty. If it is, remove it.
		if((Get-ChildItem $OptimizePath -force | Select-Object -First 1 | Measure-Object).Count -eq 0)
		{ Remove-Item -Recurse -Force $OptimizePath	}
	}
}

#==========================================================================================================================================
# The master function to start optimizing textures.

function InitiateOptiPNG()
{
	# Make sure to only run this on PNG files.
	if (!($Texture.Extension -eq $PNG)) { return }

	# Optimize the current texture.
	OptimizeTexture $Texture.FullPath

	# If the texture is a mipmap, look for mipmap levels and optimize them too.
	if ($Texture.IsMipMap)
	{
		# Create a mipmap hash table.
		$MipMap = CreateMipMapInfo $Texture.Width $Texture.Height

		# Loop through all levels.
		for($i=1; $i -le $MipMap.Levels; $i++)
		{
			# If the mipmap level exists, optimize it.
			if ($MipMap.Exists[$i]) { OptimizeTexture $MipMap[$i].FullPath }
		}
	}
}

#==========================================================================================================================================
#  LOG FILE
#==========================================================================================================================================
#  Creates the log file type based on the parameter.
function InitLogFile($option)
{
	$global:LogFile="$BaseFolder\Custom.Texture.Tool.PS.Log_0.log"
	while(Test-Path $LogFile)
	{
		$i++
		$global:LogFile="$BaseFolder\Custom.Texture.Tool.PS.Log_$i.log"
	}
	Add-Content -path "$LogFile" -value "Custom Texture Tool PS - Operation Log"
	Add-Content -path "$LogFile" -value "--------------------------------------------------------------------------------------------------------------"
	Add-Content -path "$LogFile" -value "             tex1_hash_#.ext       -  The identified texture name with ext:png/dds/jpg."
	Add-Content -path "$LogFile" -value "[Original]   dimensions:aspect     -  The original texture dimensions and aspect ratio"
	Add-Content -path "$LogFile" -value "[Custom]     dimensions:aspect     -  The custom texture dimensions and aspect ratio"
	Add-Content -path "$LogFile" -value "[New]        dimensions            -  Dimensions of new texture created with forced integer scale."
	Add-Content -path "$LogFile" -value "[Scale]      x/y scaling factor    -  The width and height scales of the custom texture"
	Add-Content -path "$LogFile" -value "[Forced]     forced scaling factor -  Integer scale that a texture was forced to convert to."
	Add-Content -path "$LogFile" -value "[Status]     OK / ISSUES           -  NotHD, DolphinDuplicate, Uneven Scale, Bad Width ^(X^), Bad Height ^(Y^),"
	Add-Content -path "$LogFile" -value "                                      Aspect Ratio Mismatch, Bad MipMapScale, Missing MipMap, Bad DDS Scaling"
	Add-Content -path "$LogFile" -value ""
	Add-Content -path "$LogFile" -value "+-------------------------------------------------------+----------------+----------------+--------------+--------------------------------------------------------------+"
	Add-Content -path "$LogFile" -value "| Texture File                                          | Original       | Custom         | Scale        | Status                                                       |"
	Add-Content -path "$LogFile" -value "+-------------------------------------------------------+----------------+----------------+--------------+--------------------------------------------------------------+"
}

#==========================================================================================================================================
#  MASTER LOOP
#==========================================================================================================================================
#  All external functions are ran through this loop in some form.

function MasterLoop()
{
	# Output that the loop is about to start to the PS window.
	Clear-Host
	Write-Host "-----------------------------------------------------------------------------------------------------------------------"
	Write-Host " Processing textures ..."
	Write-Host "-----------------------------------------------------------------------------------------------------------------------"

	# Create the log file.
	InitLogFile

	# Create an empty hash table to store files that may be duplicates.
	$Duplicates = @{}

	# Loop through all folders and sub-folders to attempt to find texture files.
	foreach($file in Get-ChildItem -Recurse)
	{
		# Creates texture data in the form of a hash table and returns null if it is not a texture file.
		$global:Texture = CreateTextureInfo $file

		# Check to see if there is valid texture data.
		if ($Texture -ne $null)
		{
			# Show information about the texture.
			Write-Host " Texture    : " -NoNewline
			Write-Host $Texture.FullName -ForegroundColor Cyan
			Write-Host " Path       :"$Texture.Path
			Write-Host " Dimensions :"$Texture.Dimensions":"$Texture.Aspect
			Write-Host " Scale      :"$Texture.Scale

			# If options 1-4 are ticked, scan all textures for errors.
			if ($ScanAllTextures) {	CheckTextureForIssues }

			# If the script is forced to convert textures to an integer scale.
			if ($ForceIntScaling) {	RescaleTextureInteger }

			# If the script is forced to convert to another format.
			if ($ConvertTextures) {	ConvertTextureFormat }

			# If the script is forced to optimize PNG textures with OptiPNG.
			if ($OptiPNGTextures) {	InitiateOptiPNG }
		}

		# The file is not a texture, so try to copy it instead if the user wanted and a conversion method was enabled.
		elseif ($CopyNonTextures -and $Texture -eq $null -and ($ForceIntScaling -or $ConvertTextures))
		{
			$Fext   = $file.Extension                          # - Extract the file extension.
			$FSplit = $file.BaseName.split("_",2)              # - Split the file name to check for "tex1".
			$FPath  = $file.DirectoryName                      # - Get the name of the folder to check for ~
			$CheckA = (!($file.PSIsContainer))                 # - Make sure it's a file and not a folder.
			$CheckB = (!($FPath -like '*~*'))                  # - Make sure the file is not in a generated directory.
			$CheckC = ($Fext -ne ".log")                       # - Do not copy log files (txt files can pass).
			$CheckD = ($Fext -ne ".ps1")                       # - Block finding this (or any) powershell script.
			$CheckE = ($Fext -ne ".bat")                       # - Block batch scripts in case I package them together.
			$CheckF = ($FSplit[0] -ne "tex1")                  # - Catch lower mipmap levels that sneak through.

			# Perform all checks.
			if ($CheckA -and $CheckB -and $CheckC -and $CheckD -and $CheckE -and $CheckF) 
			{
				# Recreate the complex folder structure of where the file should go.
				if ($ForceIntScaling) { $ConvertPath = "\~RescaledTextures"	} else { $ConvertPath = "\~ConvertedTextures" }
				$Relative = $FPath.replace($BaseFolder,'')
				$FullPath = $nullstr + $file.Directory + "\" + $file
				$CopyPath = $BaseFolder + $ConvertPath + $Relative
	
				# Create the folder if it doesn't exist and copy the file.
				if (!(Test-Path $CopyPath)) {	New-Item -ItemType directory -Path $CopyPath | Out-Null }
				Copy-Item $FullPath $CopyPath

				# Display that the file has been copied.
				Write-Host " File       : " -NoNewline
				Write-Host $file -ForegroundColor Red
				Write-Host " Message    : Non-texture file copied to " -NoNewline
				Write-Host $ConvertPath$Relative -ForegroundColor Green
				Write-Host "-----------------------------------------------------------------------------------------------------------------------"
			}
		}
	}

	# All files have been processed so wrap it up.
	Add-Content -path "$LogFile" -value "+-------------------------------------------------------+----------------+----------------+--------------+--------------------------------------------------------------+"
	Write-Host ""
	Write-Host " Finished! Press any key to continue."
	[void][System.Console]::ReadKey($true)
	
	# Completely remove the Temp folder.
	if (Test-Path $TempFolder) { Remove-Item -Recurse -Force $TempFolder }
}

#==========================================================================================================================================
#  UPDATE SCRIPT FUNCTION
#==========================================================================================================================================
# Updates the script file itself when new values are entered.

function UpdateScript($FindText, $ReplaceWith)
{
	# Find text that matches the Replace text and replace it.
	$UpdateContent = [System.IO.File]::ReadAllText($ScriptPath).Replace($FindText, $ReplaceWith)
	# Write the changes to the script file.
	[System.IO.File]::WriteAllText($ScriptPath, $UpdateContent)
}

#==========================================================================================================================================
#  INVALID INPUT FUNCTION FOR MENUS
#==========================================================================================================================================
#  Ended up using this small chunk enough times that it deserved its own function.

function InvalidInput($inputtype)
{
	# If an input option is incorrect.
	if ($inputtype -eq "option")
	{
		Write-Host ""
		Write-Host " Invalid input. Please enter a valid option. Press any key to continue."
	}
	# If a typed path is incorrect.
	elseif ($inputtype -eq "path")
	{
		Write-Host ""
		Write-Host " Invalid path. Please make sure the entered path is correct."
	}
	# If a typed value is incorrect.
	elseif ($inputtype -eq "value")
	{
		Write-Host ""
		Write-Host " Invalid input value. Please make sure the entered value is correct."
	}
	# If the ImageMagick path does not contain the executables.
	elseif ($inputtype -eq "imagemagick")
	{
		Write-Host ""
		Write-Host ' The entered path does not contain "convert.exe" or "magick.exe". Please check the spelling and try again.'
	}
	[void][System.Console]::ReadKey($true)
}

#==========================================================================================================================================
#  INTERNAL OPTIONS MENU HELP
#==========================================================================================================================================

# Displays what each option does by entering a value plus a ? (such as "1?").
function OptionsHelp($InputValue)
{
	# OptiPNG Path
	if ($InputValue -eq "1?") 
	{
		Write-Host "-----------------------------------------------------------------------------------------------------------------------"
		Write-Host ""
		Write-Host " Path to OptiPNG - Used with Option 8 - Optimize Textures with OptiPNG" -ForegroundColor Yellow
		Write-Host ""
		Write-Host " This is the path to OptiPNG which is completely optional. OptiPNG attempts to recompresses PNG files in order to"
		Write-Host ' shrink their file size by running a number of different "tests" and going with the best results. When this option'
		Write-Host " is selected, you can select how many tests to run per texture from 1-20. Above 5-7 tests is not suggested. Each"
		Write-Host " test will significantly increase how long it takes to optimize a texture."
		Write-Host ""
		Write-Host " This process can take hours depending on the number of tests, the number of textures in the pack, and how large the" 
		Write-Host " texture dimensions are. The location of optimized textures can also be configured; this menu is presented when the "
		Write-Host " option is selected. In-Place will overwrite the old textures, and Copy to Folder creates them in" -NoNewLine
		Write-Host " ~OptimizedTextures" -ForegroundColor Cyan -NoNewLine
		Write-Host "."
		Write-Host ""
		Write-Host " Press any key to continue..."
		Write-Host ""
		Write-Host "-----------------------------------------------------------------------------------------------------------------------"
		[void][System.Console]::ReadKey($true)
	}
	elseif ($InputValue -eq "2?") 
	{
		Write-Host "-----------------------------------------------------------------------------------------------------------------------"
		Write-Host ""
		Write-Host " Temporary Folder - Used when generating temporary textures." -ForegroundColor Yellow
		Write-Host ""
		Write-Host " When temporary textures need to be generated, this is the folder they will be created. Temporary files will always" 
		Write-Host " be deleted when they are no longer needed, and are wiped out on every execution/completion of one of the script's" 
		Write-Host ' options. The default location is "\AppData\Local\Temp\CTT_Temp", but can be changed to anywhere. This could be useful' 
		Write-Host " if a user has trouble creating content in the AppData folder, or just simply wants to relocate the Temp folder."
		Write-Host ""
		Write-Host " Press any key to continue..."
		Write-Host ""
		Write-Host "-----------------------------------------------------------------------------------------------------------------------"
		[void][System.Console]::ReadKey($true)
	}
	elseif ($InputValue -eq "3?") 
	{
		Write-Host "-----------------------------------------------------------------------------------------------------------------------"
		Write-Host ""
		Write-Host " Hide OK Textures - Used with Options 1-4" -ForegroundColor Yellow
		Write-Host ""
		Write-Host " Textures are checked for issues when using Options 1-4. By default, all textures that are processed are printed in a" 
		Write-Host ' log file. If a texture does not have any issues, it is flagged "OK". If this variable is true, then OK textures will'
		Write-Host ' not be printed in the log file. This is useful if you only want to see which textures have issues that need fixed.'
		Write-Host ""
		Write-Host " Press any key to continue..."
		Write-Host ""
		Write-Host "-----------------------------------------------------------------------------------------------------------------------"
		[void][System.Console]::ReadKey($true)
	}
	elseif ($InputValue -eq "4?") 
	{
		Write-Host "-----------------------------------------------------------------------------------------------------------------------"
		Write-Host ""
		Write-Host " DDS Auto-Repair - Used with Option 6 - Convert Textures to Another Format" -ForegroundColor Yellow
		Write-Host ""
		Write-Host " If true, dimensions will be calculated by multiplying the " -NoNewLine
		Write-Host "original dimensions * lowest integer scale" -ForegroundColor Cyan -NoNewLine
		Write-Host " between width" 
		Write-Host " and height. This means if a texture is scaled to 5.97x6.02, the lowest integer scale between width and height is 5 so"
		Write-Host " dimensions end up as original dimensions * 5. The value set in Scale-Fix Threshold affects if the scaling integer is"
		Write-Host " rounded up based on the decimal value. Using the same example, ScaleFixThreshold<=0.97, 5.97 becomes 6, so the DDS" 
		Write-Host " dimensions end up as original dimensions * 6." 
		Write-Host ""
		Write-Host " If false, generated DDS texture dimensions will instead be scaled up to the " -NoNewLine
		Write-Host "nearest multiple of 4" -ForegroundColor Cyan -NoNewLine
		Write-Host ", meaning a texture"
		Write-Host " with dimensions 123x125 becomes 124x128 although 124x124 may be correct. This matches the behavior of other programs"
		Write-Host " such as Aorta and The Compressonator, but this script can still generate 1x1 and 2x2 mipmaps (which they can't)."
		Write-Host ""
		Write-Host " Example: DDSAutoRepair=true  original=24x24 custom=75x75 (scale 3.12) dds=72x72" -ForegroundColor Green
		Write-Host " Example: DDSAutoRepair=false original=24x24 custom=75x75 (scale 3.12) dds=76x76" -ForegroundColor Green
		Write-Host ""
		Write-Host " Setting this option to true is useful when trying to get the most accurate dimensions." -ForegroundColor Green
		Write-Host " Setting this option to false is useful when textures have very low scaling values or mismatched aspect ratios." -ForegroundColor Green
		Write-Host ""
		Write-Host " Press any key to continue..."
		Write-Host ""
		Write-Host "-----------------------------------------------------------------------------------------------------------------------"
		[void][System.Console]::ReadKey($true)
	}
	elseif ($InputValue -eq "5?") 
	{
		Write-Host "-----------------------------------------------------------------------------------------------------------------------"
		Write-Host ""
		Write-Host " Force New MipMaps - Used whenever the script generates MipMaps" -ForegroundColor Yellow
		Write-Host ""
		Write-Host " When the script generates mipmaps when (converting, repairing, rescaling), it will scan for external mipmaps included" 
		Write-Host " with the pack (_mip1, _mip2, _mip3, etc) to use as a base for the newly generated mipmaps. When this option is set to"
		Write-Host ' true the script will ignore included mipmaps and generate new mipmaps from the top level (base texture with "m" flag'
		Write-Host " minus the mip# suffix). Setting this option to true is useful when rescaling a pack with a fixed integer scale and the" 
		Write-Host " pack contains textures with scales that exceed or dip below the integer set. Setting this option to false is useful" 
		Write-Host " when a pack includes mipmaps with correct scaling values, and/or uses dynamic mipmaps (mipmaps with different images)."
		Write-Host ""
		Write-Host " Example: Pack contains [m] textures - 2048x2048 (16x scale) and 512x512 (2x scale)." -ForegroundColor Green
		Write-Host ""
		Write-Host " Rescaling at 4x using included mipmaps will create nice mipmaps for 2048x2048 texture because they are scaled down but" -ForegroundColor Green
		Write-Host " very blurry mipmaps for 512x512 texture because they are scaled up. Setting this option to true will instead generate" -ForegroundColor Green
		Write-Host " new mipmaps using the 2048x2048 texture and 512x512 textures as a base which will still force the 512x512 to scale the" -ForegroundColor Green
		Write-Host " first few layers of its mipmaps up, but with significantly greater quality." -ForegroundColor Green
		Write-Host ""
		Write-Host " Press any key to continue..."
		Write-Host ""
		Write-Host "-----------------------------------------------------------------------------------------------------------------------"
		[void][System.Console]::ReadKey($true)
	}
	elseif ($InputValue -eq "6?") 
	{
		Write-Host "-----------------------------------------------------------------------------------------------------------------------"
		Write-Host ""
		Write-Host " Manual Rescale - Used with Option 5 - Rescale Textures at Fixed Integer (1-16)" -ForegroundColor Yellow
		Write-Host ""
		Write-Host " Changes the behavior of rescaling textures with Option 5. This option allows rescaling each texture individually with" 
		Write-Host " a different integer scale chosen by the user. A prompt will appear to enter a default scale, followed by additional" 
		Write-Host " prompts to enter a scaling value for each texture. Very large scaling values from 1-100 are allowed to be set in this" 
		Write-Host " mode, so choose the values reasonably. If a scale is not entered for the current texture, it will scale the texture" 
		Write-Host " using the default value that was entered when selecting Option 5. The default value chosen is always visible."
		Write-Host ""
		Write-Host " Press any key to continue..."
		Write-Host ""
		Write-Host "-----------------------------------------------------------------------------------------------------------------------"
		[void][System.Console]::ReadKey($true)
	}
	elseif ($InputValue -eq "7?") 
	{
		Write-Host "-----------------------------------------------------------------------------------------------------------------------"
		Write-Host ""
		Write-Host " Copy Non-Textures - Used with Option 6 - Convert Textures to Another Format" -ForegroundColor Yellow
		Write-Host ""
		Write-Host " If true, files that are not textures are copied to the newly created pack in " -NoNewLine
		Write-Host "~ConvertedTextures" -ForegroundColor Cyan -NoNewLine
		Write-Host "."
		Write-Host " If a pack has only texture files, this option should be set to false."
		Write-Host ""
		Write-Host " Example: A directory such as C:\Pack\Environment\Area01 contains textures and contains ReadMe.txt." -ForegroundColor Green
		Write-Host " When the pack is converted to DDS, ReadMe.txt will be copied to C:\Pack\~ConvertedTextures\Environment\Area01." -ForegroundColor Green
		Write-Host ""
		Write-Host " Press any key to continue..."
		Write-Host ""
		Write-Host "-----------------------------------------------------------------------------------------------------------------------"
		[void][System.Console]::ReadKey($true)
	}
	elseif ($InputValue -eq "8?") 
	{
		Write-Host "-----------------------------------------------------------------------------------------------------------------------"
		Write-Host ""
		Write-Host " Scale-Fix Threshold - Used with Options 3, 4, and 6" -ForegroundColor Yellow
		Write-Host ""
		Write-Host " This value applies when attempting to repair texture scaling, or when converting textures to DDS with Option 6 when"
		Write-Host " DDS Auto-Repair is enabled. This sets a minimum decimal value to auto-fix textures to the next highest integer scale."
		Write-Host " The value that is entered takes an integer from 0-99, but it is read internally as 0.00-0.99."
		Write-Host ""
		Write-Host " Example: Scale-Fix Threshold = 0.45 would up-scale 4.45-4.99 to 5x scale, but downscale 4.44 to 4x scale." -ForegroundColor Green
		Write-Host " Example: Scale-Fix Threshold = 0.98 would up-scale 6.98-6.99 to 7x scale, but downscale 6.98 to 6x scale." -ForegroundColor Green
		Write-Host ""
		Write-Host " Press any key to continue..."
		Write-Host ""
		Write-Host "-----------------------------------------------------------------------------------------------------------------------"
		[void][System.Console]::ReadKey($true)
	}
	elseif ($InputValue -eq "9?") 
	{
		Write-Host "-----------------------------------------------------------------------------------------------------------------------"
		Write-Host ""
		Write-Host " Aspect-Fix Threshold - Used with Options 3 and 4" -ForegroundColor Yellow
		Write-Host ""
		Write-Host " Sets a minimum limit of aspect difference between the original and custom texture. This option takes an integer value"
		Write-Host " from 0-100, but is read internally as 0.00-1.00. Aspect is calculated from dividing the width by the height, and both"
		Write-Host " the original and custom texture should have identical aspects. The value of Aspect-Fix Threshold is compared against" 
		Write-Host " the original texture aspect minus the custom texture aspect, and it is not suggested to use a value above 0.10."
		Write-Host ""
		Write-Host " Example: original=240x64=3.75 custom=752x200=3.76, 3.76-3.75=0.01, Minimum Aspect-Fix Threshold=0.01 to Auto-Repair" -ForegroundColor Green
		Write-Host " Example: original=200x32=6.25 custom=800x130=6.15, 6.25-6.15=0.10, Minimum Aspect-Fix Threshold=0.10 to Auto-Repair" -ForegroundColor Green
		Write-Host ""
		Write-Host " Press any key to continue..."
		Write-Host ""
		Write-Host "-----------------------------------------------------------------------------------------------------------------------"
		[void][System.Console]::ReadKey($true)
	}
	elseif ($InputValue -eq "0?")
	{
		Write-Host "-----------------------------------------------------------------------------------------------------------------------"
		Write-Host ""
		Write-Host " Uh, this option exits this menu and returns to the main menu."
		Write-Host ""
		Write-Host " Press any key to continue..."
		Write-Host ""
		Write-Host "-----------------------------------------------------------------------------------------------------------------------"
		[void][System.Console]::ReadKey($true)
	}
	elseif ($InputValue -eq "??") 
	{
		Write-Host "-----------------------------------------------------------------------------------------------------------------------"
		Write-Host ""
		Write-Host "                                     OMFG YOU JUST FOUND AN EASTER EGG!" -ForegroundColor Green
		Write-Host ""
		Write-Host ""
		Write-Host '                                                  _,,gg,,_              ' -ForegroundColor Cyan
		Write-Host '                                               ,a888P88Y888a,           ' -ForegroundColor Magenta
		Write-Host '                                             ,d"8"8",YY,"8"8"b,         ' -ForegroundColor Yellow
		Write-Host '                                           d",P"d" d" `b `b`Y,"b,       ' -ForegroundColor Green
		Write-Host '                                         ,P",P",P  8   8  Y,`Y,"Y,      ' -ForegroundColor Red
 		Write-Host '                                        ,P ,P` d`  8   8  `b `Y, Y,     ' -ForegroundColor Magenta
		Write-Host '                                       ,P ,P_,,8gg8gg8ggg8g8,,_Y, Y,    ' -ForegroundColor Cyan
		Write-Host '                                       ,8P"""""""``      ``"""""""Y8,   ' -ForegroundColor Cyan
		Write-Host '                                       d`/~\    /~\    /~\    /~\  `b   ' -ForegroundColor Green
		Write-Host '                                       8/   \  /   \  /   \  /   \  8   ' -ForegroundColor Yellow
		Write-Host '                                       8 ,8, \/ ,8, \/ ,8, \/ ,8, \/8   ' -ForegroundColor Green
		Write-Host '                                       8 "Y" /\ "Y" /\ "Y" /\ "Y" /\8   ' -ForegroundColor Yellow
		Write-Host '                                       8\   /  \   /  \   /  \   /  8   ' -ForegroundColor Green
		Write-Host '                                       8 \_/    \_/    \_/    \_/   8   ' -ForegroundColor Yellow
		Write-Host '                                       8                            8   ' -ForegroundColor Green
		Write-Host '                                       Y""""YYYaaaa,,,,,,aaaaPPP""""P   ' -ForegroundColor Cyan
		Write-Host '                                       `b ag,   ``""""""""``   ,ga d`   ' -ForegroundColor Cyan
		Write-Host '                                        `YP "b,  ,aa,  ,aa,  ,d" YP`    ' -ForegroundColor Magenta
		Write-Host '                                          "Y,_"Ya,_)8  8(_,aP"_,P"      ' -ForegroundColor Yellow
		Write-Host '                                            `"Ya_"""    """_aP"`        ' -ForegroundColor Red
		Write-Host '                                               `""YYbbddPP""`           ' -ForegroundColor Cyan
		Write-Host ""
		Write-Host ""
		Write-Host "                                 PRESS ANY KEY TO GET THE HELL OUT OF HERE!"-ForegroundColor Red
		Write-Host ""
		Write-Host "                        The secret code is: Up Up Down Down Left Right Left Right B A"
		Write-Host ""
		Write-Host "-----------------------------------------------------------------------------------------------------------------------"
		[void][System.Console]::ReadKey($true)
	}
	else { InvalidInput "option" }
}

#==========================================================================================================================================
#  INTERNAL OPTIONS MENU
#==========================================================================================================================================
#  Allows configuring internal options instead of having to edit the script like the old batch version.

function OptionsMenu()
{
	Clear-Host
	Write-Host "-----------------------------------------------------------------------------------------------------------------------"
	Write-Host " Internal Options Menu"
	Write-Host "-----------------------------------------------------------------------------------------------------------------------"
	Write-Host ""
	Write-Host " Allows configuration of the scripts options through command input."
	Write-Host " To learn more about an option, enter a ? after the input value (Example: " -NoNewLine
	Write-Host "1?" -ForegroundColor Green -NoNewLine
	Write-Host ")"
	Write-Host ""
	Write-Host "-----------------------------------------------------------------------------------------------------------------------"
	Write-Host ""
	Write-Host " (1:) Path to OptiPNG       =  "$OptiPNGPath  
	Write-Host " (2:) Temp Folder           =  "$TempFolder
	Write-Host " (3:) Hide OK Textures      =  "$HideOKTextures
	Write-Host " (4:) DDS Auto-Repair       =  "$DDSAutoRepair
	Write-Host " (5:) Force New MipMaps     =  "$ForceNewMipMaps
	Write-Host " (6:) Manual Rescale        =  "$ManualRescale
	Write-Host " (7:) Copy Non-Textures     =  "$CopyNonTextures
	Write-Host " (8:) Scale-Fix Threshold   =  "$ScaleFixThreshold
	Write-Host " (9:) Aspect-Fix Threshold  =  "$AspectFixThreshold
	Write-Host " (0:) Return to Main Menu"
	Write-Host ""
	$MenuInput = Read-Host "> "
	Write-Host ""

	#--------------------------------------------------------------------------------------------------------
	# Internal Option 1: Allow changing the path to OptiPNG.
	#--------------------------------------------------------------------------------------------------------
	if ($MenuInput -eq "1")
	{
		# Prompt the user for a new input path.
		Write-Host "-----------------------------------------------------------------------------------------------------------------------"
		Write-Host " Enter a new path for OptiPNG. The path must point to (but not contain) " -NoNewLine
		Write-Host "optipng.exe" -ForegroundColor Yellow
		Write-Host ""
		Write-Host " Example: C:\Users\Username\Desktop\optipng-0.7.5-win32" -ForegroundColor Green
		Write-Host ""
		Write-Host " PowerShell should allow you to right click the window to quickly paste a path."
		Write-Host ""
		$SecondInput = Read-Host "> "

		# Create a location to OptiPNG using the input path.
		$OptiCheckPath = $SecondInput + "\optipng.exe"

		# Test if that path exists.
		if (Test-Path $OptiCheckPath) {

			# Store the old path so the script can be updated.
			$OldOptiPNGPath = $OptiPNGPath

			# Update the global variables with the new path.
			$global:OptiPNGPath = $SecondInput
			$global:OptiPNG_EXE = $OptiPNGPath + "\optipng.exe"

			# Permanently save the changes to the script.
			$ReplaceText = '$global:OptiPNGPath        = ' + '"' + $OldOptiPNGPath+'"'
			$ReplaceWith = '$global:OptiPNGPath        = ' + '"' + $OptiPNGPath+'"'
			UpdateScript $ReplaceText $ReplaceWith
		}
		else { InvalidInput "path" }
	}

	#--------------------------------------------------------------------------------------------------------
	# Internal Option 2: Allow changing the Temporary folder.
	#--------------------------------------------------------------------------------------------------------
	elseif ($MenuInput -eq "2")
	{
		# Prompt the user for a new input path.
		Write-Host "-----------------------------------------------------------------------------------------------------------------------"
		Write-Host ' Enter a new temporary folder path. The entered path must be valid to succeed.'
		Write-Host " PowerShell should allow you to right click the window to quickly paste a path."
		Write-Host ""
		$SecondInput = Read-Host "> "

		# Test if that path exists.
		if ($SecondInput -and (Test-Path $SecondInput)) {

			# Store the old path so the script can be updated.
			$OldTempFolder = $TempFolder

			# Update the global variable with the new path.
			$global:TempFolder = $SecondInput

			# Permanently save the changes to the script.
			$ReplaceText = '$global:TempFolder         = ' + '"' + $OldTempFolder + '"'
			$ReplaceWith = '$global:TempFolder         = ' + '"' + $TempFolder + '"'
			UpdateScript $ReplaceText $ReplaceWith

			# An ugly work-around to replace the default value for the first time. This is only done once and becomes redundant after it has been changed.
			# TODO: Come up with a better method than this. Every time this option is changed the script is updated twice for no reason.
			$ReplaceOnce = '$global:TempFolder         = ' + '"$env:temp\CTT-PS_Temp"'
			UpdateScript $ReplaceOnce $ReplaceWith
		}
		else { InvalidInput "path" }
	}

	#--------------------------------------------------------------------------------------------------------
	# Internal Option 3: Configuring Hide OK Textures.
	#--------------------------------------------------------------------------------------------------------
	elseif ($MenuInput -eq "3")
	{
		if ($HideOKTextures) {
			$global:HideOKTextures = $false
			$ReplaceText = '$global:HideOKTextures     = ' + '$true'
			$ReplaceWith = '$global:HideOKTextures     = ' + '$false'
		}
		else 
		{
			$global:HideOKTextures = $true
			$ReplaceText = '$global:HideOKTextures     = ' + '$false'
			$ReplaceWith = '$global:HideOKTextures     = ' + '$true'
		}
		UpdateScript $ReplaceText $ReplaceWith
	}

	#--------------------------------------------------------------------------------------------------------
	# Internal Option 4: Configuring DDS Auto Repair.
	#--------------------------------------------------------------------------------------------------------
	elseif ($MenuInput -eq "4")
	{
		if ($DDSAutoRepair) {
			$global:DDSAutoRepair = $false
			$ReplaceText = '$global:DDSAutoRepair      = ' + '$true'
			$ReplaceWith = '$global:DDSAutoRepair      = ' + '$false'
		}
		else
		{
			$global:DDSAutoRepair = $true
			$ReplaceText = '$global:DDSAutoRepair      = ' + '$false'
			$ReplaceWith = '$global:DDSAutoRepair      = ' + '$true'
		}
		UpdateScript $ReplaceText $ReplaceWith
	}

	#--------------------------------------------------------------------------------------------------------
	# Internal Option 5: Configuring Force New MipMaps.
	#--------------------------------------------------------------------------------------------------------
	elseif ($MenuInput -eq "5")
	{
		if ($ForceNewMipMaps)
		{
			$global:ForceNewMipMaps = $false
			$ReplaceText = '$global:ForceNewMipMaps    = ' + '$true'
			$ReplaceWith = '$global:ForceNewMipMaps    = ' + '$false'
		}
		else
		{
			$global:ForceNewMipMaps = $true
			$ReplaceText = '$global:ForceNewMipMaps    = ' + '$false'
			$ReplaceWith = '$global:ForceNewMipMaps    = ' + '$true'
		}
		UpdateScript $ReplaceText $ReplaceWith
	}

	#--------------------------------------------------------------------------------------------------------
	# Internal Option 6: Configuring Manual Rescale.
	#--------------------------------------------------------------------------------------------------------
	elseif ($MenuInput -eq "6") 
	{
		if ($ManualRescale) {
			$global:ManualRescale = $false
			$ReplaceText = '$global:ManualRescale      = ' + '$true'
			$ReplaceWith = '$global:ManualRescale      = ' + '$false'
		}
		else 
		{
			$global:ManualRescale = $true
			$ReplaceText = '$global:ManualRescale      = ' + '$false'
			$ReplaceWith = '$global:ManualRescale      = ' + '$true'
		}
		UpdateScript $ReplaceText $ReplaceWith
	}

	#--------------------------------------------------------------------------------------------------------
	# Internal Option 7: Configuring Copy Non-Textures.
	#--------------------------------------------------------------------------------------------------------
	elseif ($MenuInput -eq "7") 
	{
		if ($CopyNonTextures)
		{
			$global:CopyNonTextures = $false
			$ReplaceText = '$global:CopyNonTextures    = ' + '$true'
			$ReplaceWith = '$global:CopyNonTextures    = ' + '$false'
		}
		else
		{
			$global:CopyNonTextures = $true
			$ReplaceText = '$global:CopyNonTextures    = ' + '$false'
			$ReplaceWith = '$global:CopyNonTextures    = ' + '$true'
		}
		UpdateScript $ReplaceText $ReplaceWith
	}

	#--------------------------------------------------------------------------------------------------------
	# Internal Option 8: Allows changing the scale fix threshold.
	#--------------------------------------------------------------------------------------------------------
	elseif ($MenuInput -eq "8")
	{
		# Prompt the user for a new scale fix treshold.
		Write-Host "-----------------------------------------------------------------------------------------------------------------------"
		Write-Host ' Enter a new value for ScaleFixThreshold. Valid values are (0-99).'
		Write-Host ""
		$SecondInput = Read-Host "> "
		
		# Text if the input value is an integer.
		if ($SecondInput -and $SecondInput -as [int] -is [int])
		{
			# If the input value is between 0 and 9, then fix the input for single digits.
			if ([int]$SecondInput -ge 0 -and [int]$SecondInput -lt 10)
			{
				# Update the value.
				$OldScaleFixThreshold = $ScaleFixThreshold
				$global:ScaleFixThreshold = $("0.0"+$SecondInput)

				# Permanently save the changes to the script.
				$ReplaceText = '$global:ScaleFixThreshold  = ' + '"' + $OldScaleFixThreshold+'"'
				$ReplaceWith = '$global:ScaleFixThreshold  = ' + '"' + $ScaleFixThreshold+'"'
				UpdateScript $ReplaceText $ReplaceWith
			}
			# If the input value is between 10 and 99, just convert to decimal.
			elseif ([int]$SecondInput -gt 9 -and [int]$SecondInput -lt 100)
			{
				# Update the value.
				$OldScaleFixThreshold = $ScaleFixThreshold
				$global:ScaleFixThreshold = $("0."+$SecondInput)

				# Permanently save the changes to the script.
				$ReplaceText = '$global:ScaleFixThreshold  = ' + '"' + $OldScaleFixThreshold+'"'
				$ReplaceWith = '$global:ScaleFixThreshold  = ' + '"' + $ScaleFixThreshold+'"'
				UpdateScript $ReplaceText $ReplaceWith
			}
			else { InvalidInput "value" }
		}
		else { InvalidInput "value" }
	}

	#--------------------------------------------------------------------------------------------------------
	# Internal Option 9: Allows changing the aspect fix threshold.
	#--------------------------------------------------------------------------------------------------------
	elseif ($MenuInput -eq "9")
	{
		# Prompt the user for a new aspect-fix threshold.
		Write-Host "-----------------------------------------------------------------------------------------------------------------------"
		Write-Host ' Enter a new value for AspectFixThreshold. Valid values are (0-100).'
		Write-Host ""
		$SecondInput = Read-Host "> "

		# Text if the input value is an integer.
		if ($SecondInput -and $SecondInput -as [int] -is [int])
		{
			# If the input value is between 0 and 9, then fix the input for single digits.
			if ([int]$SecondInput -ge 0 -and [int]$SecondInput -lt 10)
			{
				# Update the value.
				$OldAspectFixThreshold = $AspectFixThreshold
				$global:AspectFixThreshold = $("0.0"+$SecondInput)

				# Permanently save the changes to the script.
				$ReplaceText = '$global:AspectFixThreshold = ' + '"' + $OldAspectFixThreshold+'"'
				$ReplaceWith = '$global:AspectFixThreshold = ' + '"' + $AspectFixThreshold+'"'
				UpdateScript $ReplaceText $ReplaceWith
			}
			# If the input value is between 10 and 99, just convert to decimal.
			elseif ([int]$SecondInput -gt 9 -and [int]$SecondInput -lt 100)
			{
				# Update the value.
				$OldAspectFixThreshold = $AspectFixThreshold
				$global:AspectFixThreshold = $("0."+$SecondInput)

				# Permanently save the changes to the script.
				$ReplaceText = '$global:AspectFixThreshold = ' + '"' + $OldAspectFixThreshold+'"'
				$ReplaceWith = '$global:AspectFixThreshold = ' + '"' + $AspectFixThreshold+'"'
				UpdateScript $ReplaceText $ReplaceWith
			}
			# Allow a full 1.00 for aspect difference.
			elseif ([int]$SecondInput -eq 100)
			{
				# Update the value.
				$OldAspectFixThreshold = $AspectFixThreshold
				$global:AspectFixThreshold = "0.02"

				# Permanently save the changes to the script.
				$ReplaceText = '$global:AspectFixThreshold = ' + '"' + $OldAspectFixThreshold+'"'
				$ReplaceWith = '$global:AspectFixThreshold = ' + '"' + $AspectFixThreshold+'"'
				UpdateScript $ReplaceText $ReplaceWith
			}
			else { InvalidInput "value" }
		}
		else { InvalidInput "value" }
	}

	#--------------------------------------------------------------------------------------------------------
	# Exit this menu.
	elseif ($MenuInput -eq "0") { return $true }

	# Show further information about each option.
	elseif ($MenuInput -like "*?") { OptionsHelp $MenuInput }

	# Invalid input so show an error.
	else { InvalidInput "option" }

	return $false
}
#==========================================================================================================================================
#  OPTIPNG MENUS
#==========================================================================================================================================
# Allows configuration of where OptiPNG outputs files.

function OptiPNGMenuA ($ScreenText)
{
	Clear-Host
	Write-Host $ScreenText
	Write-Host "-----------------------------------------------------------------------------------------------------------------------"
	Write-Host "Define how textures will be optimized with OptiPNG."
	Write-Host ""
	Write-Host "(1:) In-Place: Replace old texture with optimized texture directly."
	Write-Host "(2:) Create Copy: Copy optimized texture to ~OptimizedTextures folder."
	Write-Host ""
	$MenuInput = Read-Host "> "

	# Optimize the textures in-place.
	if ($MenuInput -eq "1") { $global:OptiMethod = "1" ; return $true}

	# Create a new folder.
	elseif ($MenuInput -eq "2") { $global:OptiMethod = "2" ; return $true }

	# Invalid input so show an error.
	else { InvalidInput "option" }

	return $false
}

#==========================================================================================================================================
# Allows configuration of how many tests OptiPNG performs.

function OptiPNGMenuB ($ScreenText)
{
	Clear-Host
	Write-Host $ScreenText
	Write-Host "-----------------------------------------------------------------------------------------------------------------------"
	Write-Host 'Set the number of optimization tests for OptiPNG. (Max:20)'
	Write-Host ""
	Write-Host "The more tests performed, the longer it will take. More tests than 5 may result"
	Write-Host "in a smaller texture, but it's not likely and is usually overkill."
	Write-Host ""
	$MenuInput = Read-Host "> "

	# Optimize the textures in-place.
	if ($MenuInput -as [int] -is [int])
	{
		# Prevent more than 20 tests to protect users from themselves.
		if ([int]$MenuInput -gt 0 -and [int]$MenuInput -le 20)
		{
			$global:OptiTests = $MenuInput
			return $true
		}

		# Invalid input so show an error.
		else { InvalidInput "value" }
	}

	# Invalid input so show an error.
	else { InvalidInput "value" }

	return $false
}

#==========================================================================================================================================
#  FORCE SCALE MENU
#==========================================================================================================================================
#  The Force Scale Menu when called with Option 5.

function ForceScaleMenu($ScreenText)
{
	Clear-Host
	Write-Host $ScreenText
	Write-Host "-----------------------------------------------------------------------------------------------------------------------"
	if ($ManualRescale)
	{
		Write-Host "Enter a default integer scale from 1-16 to rescale textures."
		Write-Host "Or, enter 0 to set the default setting to skip the current texture:"
	}
	else
	{
		Write-Host "Enter an integer scale from 1-16 to rescale all textures:"
	}
	Write-Host ""
	$MenuInput = Read-Host "> "

	# Allows it to pass with value 0 if manual rescale is true.
	if ($MenuInput -eq "0" -and $ManualRescale) { $ExitFunction = $true }

	# Detects selecting value of 1-16.
	elseif ([int]$MenuInput -gt 0 -and [int]$MenuInput -le 16) { $ExitFunction = $true }

	# Invalid input so show an error.
	else { InvalidInput "option" }

	# If valid input was detected, then store the input and exit the function.
	if ($ExitFunction)
	{
		$global:StoredScale = $MenuInput
		$global:ForcedScale = $MenuInput
		return $true
	}
	return $false
}

#==========================================================================================================================================
#  CONVERT TEXTURES / GENERATION TYPE MENU
#==========================================================================================================================================
# The menu to choose the type of DDS Mipmaps to generate.

function DDSMipMapMenu($ScreenText)
{
	Clear-Host
	Write-Host $ScreenText
	# Show a sub-menu to choose which types of MipMaps to generate.
	Write-Host "-----------------------------------------------------------------------------------------------------------------------"
	Write-Host "Choose what types of mipmaps to generate:"
	Write-Host ""
	Write-Host " (1:) Both"
	Write-Host " (2:) Internal Only"
	Write-Host " (3:) External Only"
	Write-Host ""
	$MenuInput = Read-Host "> "

	# Make both Types.
	if ($MenuInput -eq "1")
	{
		$global:DDSInternal = $true
		$global:DDSExternal = $true
		return $true
	}

	# Make Internal only.
	elseif ($MenuInput -eq "2")
	{
		$global:DDSInternal = $true
		$global:DDSExternal = $false
		return $true
	}

	#Make External only.
	elseif ($MenuInput -eq "3")
	{
		$global:DDSInternal = $false
		$global:DDSExternal = $true
		return $true
	}
	else 
	{
		InvalidInput "option" 
	}
	return $false
}

#==========================================================================================================================================
# The menu to choose the format of textures to generate generate.

function FileTypeMenu($ScreenText)
{
	Clear-Host
	Write-Host $ScreenText
	Write-Host "-----------------------------------------------------------------------------------------------------------------------"
	Write-Host "Choose a format to generate textures:"
	Write-Host ""
	Write-Host " (1:) PNG"
	Write-Host " (2:) DDS"
	Write-Host " (3:) JPG"
	if ($ForceIntScaling) 
	{
		Write-Host " (4:) Use Texture File Extension"
	}
	Write-Host ""
	$MenuInput = Read-Host "> "

	# Convert files to PNG.
	if ($MenuInput -eq "1")	{ $global:ConvertExtension = $PNG ; return $true }

	# Convert files to DDS.
	elseif ($MenuInput -eq "2")	
	{
		$global:ConvertExtension = $DDS
		# Capture the current screen text.
		$ScreenCapture = CopyAllScreenText
		# Show the DDS MipMaps Menu
		while (!(DDSMipMapMenu $ScreenCapture)) { }
		return $true
	}

	# Convert files to JPG.
	elseif ($MenuInput -eq "3")	{ $global:ConvertExtension = $JPG ; return $true }

	# If accessed from the set scale menu, allow using the base file extension.
	elseif ($ForceIntScaling -and $MenuInput -eq "4") { $global:ConvertExtension = $null ; return $true }

	# Invalid input, show an error.
	else { InvalidInput "option" }

	return $false
}

#==========================================================================================================================================
#  INTRODUCTION MENU
#==========================================================================================================================================
# The Main Menu to select all options.

function InitMainMenu()
{
	Clear-Host
	Write-Host "-----------------------------------------------------------------------------------------------------------------------"
	Write-Host " "$ScriptName
	Write-Host "-----------------------------------------------------------------------------------------------------------------------"
	Write-Host ""
	Write-Host " Choices:"
	Write-Host ""
	Write-Host " (0:) Internal Options"
	Write-Host " (1:) Check Textures For Issues"
	Write-Host " (2:) Copy Textures With Issues"
	Write-Host " (3:) Repair Textures With Issues"
	Write-Host " (4:) Repair/Copy Textures With Issues"
	Write-Host " (5:) Rescale Textures at Fixed Integer (1-16)"
	Write-Host " (6:) Convert Textures to Another Format"
	Write-Host " (7:) Optimize Textures with OptiPNG (PNG Only)"
	Write-Host " (8:) Exit"
	Write-Host ""
	$MenuInput = Read-Host "> "

	# Run the menu inputs.
	$MainCapture = CopyAllScreenText
	switch ($MenuInput)
	{
			# The Internal Options menu.
		"0"	{
				while (!(OptionsMenu)) {}
			}

			# Check textures for issues.
		"1"	{ 
				$ScanAllTextures = $true
				MasterLoop 
			}

			# Copy bad textures.
		"2"	{
				$ScanAllTextures = $true
				$CopyBadTextures = $true
				MasterLoop
			}

			# Auto-fix bad textures.
		"3"	{
				$ScanAllTextures = $true
				$AutoFixTextures = $true
				MasterLoop 
			}

			# Auto-fix and copy bad textures.
		"4"	{ 
				$ScanAllTextures = $true
				$CopyBadTextures = $true
				$AutoFixTextures = $true
				MasterLoop 
			}

			# Rescale textures at a fixed integer.
		"5"	{
				$ForceIntScaling = $true
				while (!(ForceScaleMenu $MainCapture)) {}
				$MainCaptureB = CopyAllScreenText
				while (!(FileTypeMenu $MainCaptureB)) {}
				MasterLoop
			}

			# Convert textures to another format.
		"6"	{
				$ConvertTextures = $true
				while (!(FileTypeMenu $MainCapture)) {}
				MasterLoop
			}

			# Run OptiPNG on textures.
		"7"	{
				if (!(Test-Path $OptiPNG_EXE))
				{
					Write-Host ""
					Write-Host "-----------------------------------------------------------------------------------------------------------------------"
					Write-Host ""
					Write-Host "ERROR: " -Foreground Red -NoNewLine
					Write-Host "OptiPNG not found. Configure the Internal Options to set the path and try again."
					Write-Host ""
					Write-Host "Press any key to continue."
					[void][System.Console]::ReadKey($true)
					return $false
				}
				$OptiPNGTextures = $true
				while (!(OptiPNGMenuA $MainCapture)) {}
				$MainCaptureB = CopyAllScreenText
				while (!(OptiPNGMenuB $MainCaptureB)) {}
				MasterLoop
			}

			# Close the menu.
		"8"	{ 
				return $true
			}

			# Default to invalid input.
		default
			{
				InvalidInput "option"
			}
	}
	return $false 
}
#==========================================================================================================================================
# Pretty self explanatory.

function ResetAllVars()
{
	$global:TotalReduction  = 0
	$global:ScanAllTextures = $false
	$global:CopyBadTextures = $false
	$global:AutoFixTextures = $false
	$global:ForceIntScaling = $false
	$global:ConvertTextures = $false
	$global:OptiPNGTextures = $false
}
#==========================================================================================================================================
#  IMAGEMAGICK - FIND AND/OR RELOCATE
#==========================================================================================================================================
# Find up to Imagemagick v7.

# Searches for convert.exe and magick.exe in the inputpath.
function FindImageMagick ($inputpath)
{
	# Find up to ImageMagick v6.
	if (Test-Path $inputpath\convert.exe)
	{
		return "$inputpath\convert.exe"
	}
	# Find ImageMagick v7 and beyond?
	elseif (Test-Path $inputpath\magick.exe)
	{
		return "$inputpath\magick.exe"
	}
	# Return a null value if neither were found.
	return $null
}

#==========================================================================================================================================
# Error to display if ImageMagick was not found.

function NoImageMagick()
{
	Clear-Host
	Write-Host "-----------------------------------------------------------------------------------------------------------------------"
	Write-Host " ERROR: IMAGEMAGICK WAS NOT FOUND!"
	Write-Host ""
	Write-Host " Windows does not have native support for writing images in PowerShell, so it is required that you install ImageMagick "
	Write-Host " in order to use this Texture Tool. If you already have ImageMagick installed, but the script failed to find the path" 
	Write-Host " to where it was installed, you can attempt to input the path here or edit the script to manually add the path."
	Write-Host ""
	Write-Host " Get ImageMagick at http://www.imagemagick.org/"
	Write-Host ""
	Write-Host "-----------------------------------------------------------------------------------------------------------------------"
	Write-Host ""
	Write-Host ' Enter a path to ImageMagick below. The path must contain "convert.exe" or "magick.exe" to succeed.'
	Write-Host ""
	Write-Host ' Type the letter "x" and hit Enter if you wish to close this window.'
	Write-Host ""
	$InputPath = Read-Host "> "
	Write-Host ""

	# Test if the input path exists.
	if (Test-Path $InputPath) 
	{
		# Find the ImageMagick executable in the new path.
		$global:ImgMagick_EXE = FindImageMagick $InputPath
	
		# If it exists, permanently store the new path.
		if ($ImgMagick_EXE -ne $null)
		{
			# Store the old path so the script can be updated.
			$OldImageMagick = $ImageMagick

			# Update the global variable with the new path.
			$global:ImageMagick = $InputPath

			# Permanently save the changes to the script.
			$ReplaceText = '$global:ImageMagick        = ' + '"' + $OldImageMagick + '"'
			$ReplaceWith = '$global:ImageMagick        = ' + '"' + $ImageMagick + '"'
			UpdateScript $ReplaceText $ReplaceWith

			# An ugly work-around to replace the default value for the first time. This is only done once and becomes redundant after it has been changed.
			# TODO: Come up with a better method than this. Every time this option is changed the script is updated twice for no reason.
			$ReplaceOnce = '$global:ImageMagick        = ' + '(Get-ItemProperty -Path "HKLM:\Software\ImageMagick\Current\" -Name BinPath).BinPath'
			UpdateScript $ReplaceOnce $ReplaceWith

			# Alert that it worked.
			Write-Host " New path to ImageMagick succeeded!"
			[void][System.Console]::ReadKey($true)
			return $true

		}
		# Special error just for ImageMagick.
		else { InvalidInput "imagemagick" }
	}
	# Allow a forced exit.
	elseif ($InputPath -eq "x")	{ return $true }
	
	# The input was invalid.
	else { InvalidInput "path" } 
	
	return $false
}

#==========================================================================================================================================
#  SCRIPT START
#==========================================================================================================================================
# Clean out the old Temp folder if it is found.
if (Test-Path $TempFolder) { Remove-Item -Recurse -Force $TempFolder }

# Important Stuff
$global:BaseFolder    = "$pwd"
$global:ScriptName    = "Custom Texture Tool PS v0.4 Beta"
$global:ScriptPath    = $MyInvocation.MyCommand.path

# Change the title of the window to the name of the script.
$host.UI.RawUI.WindowTitle=$ScriptName

# Find ImageMagick converter. v6="convert.exe" v7="magick.exe"
$global:ImgMagick_EXE = FindImageMagick $ImageMagick

# If ImageMagick was not found, display an error and prompt the user to manually enter a path.
if ($ImgMagick_EXE -eq $null) { while (!(NoImageMagick)) {} }

# Set the location of identify.exe only after the ImageMagick path has been verified.
$global:Identify_EXE = $ImageMagick+"\identify.exe"

# Set the path to optipng.exe, nvdxt.exe, and stitch.exe based on the default path.
$global:OptiPNG_EXE   = $OptiPNGPath+"\optipng.exe"
$global:DDSUtil_EXE   = $NvidiaTools+"\nvDXT.exe"
$global:NSTITCH_EXE   = $NvidiaTools+"\stitch.exe"

# If ImageMagick is found, run the script.
if ($ImgMagick_EXE -ne $null) { while (!(InitMainMenu)) { ResetAllVars } }