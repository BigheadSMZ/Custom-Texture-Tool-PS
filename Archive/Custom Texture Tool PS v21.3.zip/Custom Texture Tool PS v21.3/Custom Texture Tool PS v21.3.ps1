#==============================================================================================================================================================================================
#  Custom Texture Tool PS v21.3
#  By: Bighead
#==============================================================================================================================================================================================
#  Windows 7/Powershell v2 Fix
#==============================================================================================================================================================================================
# A long standing issue with this script was that PowerShell v2 would run in "Multi-Thread Apartment" mode, which bugs out .NET Open File dialogs and Open Folder dialogs.
# Before a work-around was used if PowerShell v2 was found that involved setting the dialog property "ShowHelp" to $false, but this only worked with "Open File" dialogs, so
# when dealing with entering folder paths such as the "Temp Folder", PowerShell v2 users would have to manually type the path. Since the script now has a GUI, a proper fix
# had to be found. The fix is simple: if MTA is found, force STA and restart the script. After this new instance of the script is closed, then exit the PowerShell console.
#==============================================================================================================================================================================================
if ([Threading.Thread]::CurrentThread.GetApartmentState() -eq 'MTA')
{
  $ScriptPath = ($MyInvocation.MyCommand.Definition).ToString()
  PowerShell -STA -File $ScriptPath
  Exit
}
#==============================================================================================================================================================================================
#  LOAD MICROSOFT .NET FRAMEWORK ASSEMBLIES
#==============================================================================================================================================================================================
Add-Type -AssemblyName 'System.Windows.Forms'
Add-Type -AssemblyName 'System.Drawing'
#==============================================================================================================================================================================================
#  CONSTANT VARIABLES: IMAGE FILE EXTENSIONS
#==============================================================================================================================================================================================
New-Variable -Name 'PNG' -Value '.png' -Option Constant
New-Variable -Name 'DDS' -Value '.dds' -Option Constant
New-Variable -Name 'JPG' -Value '.jpg' -Option Constant
#==============================================================================================================================================================================================
#  GLOBAL VARIABLES - THEY MUST BEGIN ON LINE 32 AND REMAIN IN THIS ORDER OR THE SCRIPT WILL FAIL TO UPDATE THEM WHEN IT IS CLOSED! (Reference: See function "StoreAllOptions")
#==============================================================================================================================================================================================
$global:CurrentOptions     = "Standard"
$global:StoredStandard     = "0"
$global:StoredAdvanced     = "0"
$global:StoreInputFolder   = $false
$global:StoreOutputFolder  = $false
$global:SavedInputFolder   = ""
$global:SavedOutputFolder  = ""
$global:IshiirukaTool      = "C:\Program Files (x86)\Ishiiruka-TextureEncoder.0.9.7\TextureEncoder.exe"
$global:OptiPNGPath        = "C:\Program Files (x86)\optipng-0.7.6-win32\optipng.exe"
$global:ScalerTestPath     = "C:\Program Files (x86)\ScalerTest\ScalerTest.exe"
$global:Waifu2xPath        = "C:\Program Files (x86)\waifu2x-caffe\waifu2x-caffe-cui.exe"
$global:TempFolder         = "$env:temp\CTT-PS_Temp"
$global:AllowAllImages     = $false
$global:DisableLogFile     = $false
$global:DDSForceDXT5       = $false
$global:EnableStoring      = $true
$global:MaterialMapFormat  = "Ishiiruka"
$global:AutoCenterConsole  = $true
$global:DisableTopMost     = $true
$global:AlwaysShowConsole  = $true
$global:RepairTextures     = $false
$global:CopyBadTextures    = $false
$global:HideOKTextures     = $false
$global:IgnoreDuplicates   = $false
$global:AllowNotHD         = $true
$global:ScaleThreshold     = "0.65"
$global:AspectThreshold    = "0.05"
$global:DDSMipMapType      = "External"
$global:ForceNewMipMaps    = $false
$global:CopyNonTextures    = $true
$global:RescaleFactor      = "4"
$global:RescaleFormat      = $PNG
$global:RescaleScaling     = "All"
$global:ManualRescale      = $false
$global:ConvertFormat      = $PNG
$global:ConvertRepair      = $false
$global:IshiirukaFormat    = $PNG
$global:InPlaceMaterial    = $false
$global:WM_Length          = "0"
$global:WM_FontFace        = "Courier-New-Bold"
$global:WM_FontSize        = "8"
$global:WM_FontColor       = "#FF0000"
$global:WM_BGColor         = "#00FF00"
$global:WM_WordWrap        = $true
$global:OptiPNGTests       = "3"
$global:InPlaceOptiPNG     = $false
$global:FilterSelected     = "Point"
$global:FilterNewScale     = "4"
$global:SeamlessMethod     = "Opaque"
$global:SeamlessFactor     = "0.85"
$global:Waifu2xCMode       = "Noise_Scale"
$global:Waifu2xNoise       = "3"
$global:Waifu2xOpenCL      = $false
$global:Waifu2xModel       = "anime_style_art_rgb"
$global:Waifu2xNoGPU       = $false
$global:TextureRows        = "2"
$global:TextureColumns     = "2"
$global:CombinedName       = "CombinedTexture"
$global:ConsoleColors      = $true
$global:ImageMagick        = (Get-ItemProperty -LiteralPath "HKLM:\Software\ImageMagick\Current\" -Name BinPath -ErrorAction SilentlyContinue).BinPath
$global:NvidiaTools        = (Get-ItemProperty -LiteralPath "HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\{64963F0E-03F2-4B59-8D1B-1806545E7092}\" -Name InstallLocation -ErrorAction SilentlyContinue).InstallLocation
$global:DisablePSXButton   = $true
$global:SelectionPath      = ($pwd).path
$global:UpdateTempFolder   = $false
$global:UpdateImageMagick  = $false
$global:UpdateNvidiaTools  = $false
#==============================================================================================================================================================================================
#  DOCUMENTATION: ALL GLOBAL VARIABLES
#==============================================================================================================================================================================================
#  * Note that all variables in this section that are listed as "integer" or "decimal" are actually stored as strings!
#  * The same goes for "extension". These are also strings, but specifically refers to the constant variables that define image file extensions.
#  
#  $global:CurrentOptions        - string    - Stores the most recently used options, either "Standard" or "Advanced", and displays them on startup.
#  $global:StoredStandard        - integer   - Stores the most recently used Standard option and displays it on startup.
#  $global:StoredAdvanced        - integer   - Stores the most recently used Advanced option and displays it on startup.
#  $global:StoreInputFolder      - boolean   - Flags whether or not to store the most recently used Texture Path on exit.
#  $global:StoreOutputFolder     - boolean   - Flags whether or not to store the most recently used Output Path on exit. 
#  $global:SavedInputFolder      - string    - If "StoreInputFolder" was flagged, stores the most recent path and overrides "$MasterInputPath" on startup.
#  $global:SavedOutputFolder     - string    - If "SavedOutputFolder" was flagged, stores the most recent path and overrides "$MasterOutputPath" on startup.
#  $global:IshiirukaTool         - string    - The path to Ishiiruka Tool.
#  $global:OptiPNGPath           - string    - The path to OptiPNG.
#  $global:ScalerTestPath        - string    - The path to xBRZ ScalerTest.
#  $global:Waifu2xPath           - string    - The path to waifu2x, caffe or CPP.
#  $global:TempFolder            - string    - The path to create temporary folders.
#  $global:AllowAllImages        - boolean   - Forces the script to validate all images instead of only Dolphin "tex1" images.
#  $global:DisableLogFile        - boolean   - Disables the log file.
#  $global:EnableStoring         - boolean   - Enables updating any of these variables on exit.
#  $global:MaterialMapFormat     - string    - If set to Ishiiruka, generates material maps normally. If set to Dolphin, converts material maps to standard DDS.
#  $global:AutoCenterConsole     - boolean   - Hidden option, not on GUI. Toggles the method to auto-center the console on startup.
#  $global:DisableTopMost        - boolean   - Disables CTT-PS from showing over all other open windows.
#  $global:AlwaysShowConsole     - boolean   - Toggles the visibility of the PowerShell console.
#  $global:RepairTextures        - boolean   - Flags whether or not to repair textures using "Scan Textures For Issues".
#  $global:CopyBadTextures       - boolean   - Flags whether or not to copy bad textures if they were not repaired using "Scan Textures For Issues".
#  $global:HideOKTextures        - boolean   - Flags whether or not to hide textures without issues from the log when using "Scan Textures For Issues".
#  $global:IgnoreDuplicates      - boolean   - Flags whether or not to ignore duplicate file names when using "Scan Textures For Issues".
#  $global:AllowNotHD            - boolean   - Flags whether or not to allow textures with the original resolution to pass error checking using "Scan Textures For Issues".
#  $global:ScaleThreshold        - decimal   - Value which controls when to upscale a texture to the next highest integer scale when repairing using the decimal value.
#  $global:AspectThreshold       - decimal   - Value which controls the amount of aspect difference between the original and custom texture before repairing.
#  $global:DDSMipMapType         - string    - The type of DDS mipmaps to generate and the type that are checked for issues.
#  $global:ForceNewMipMaps       - boolean   - Flags whether or not to generate new mipmaps from the top layer rather than use included mipmaps as a base.
#  $global:CopyNonTextures       - boolean   - Flags whether or not to create copies of non-texture files in the newly generated pack.
#  $global:RescaleFactor         - integer   - The value to upscale the texture when using "Rescale Textures at Fixed Integer".
#  $global:RescaleFormat         - extension - The output format of the rescaled texture. PNG, DDS, or JPG.
#  $global:RescaleScaling        - string    - Defines which textures will be rescaled, allowing only upscaling, downscaling, or both.
#  $global:ManualRescale         - boolean   - Toggles "Manual Rescale Mode" which allows scaling each texture individually with insane values.
#  $global:ConvertFormat         - extension - The output format of the rescaled texture. PNG, DDS, or JPG when using "Convert Textures to Another Format." Can also hold $null to use existing extension.
#  $global:ConvertRepair         - boolean   - Enables a method to auto-repair textures when converting to get the most accurate dimensions.
#  $global:IshiirukaFormat       - extension - The output format when creating material maps with "Create Material Maps WIth Ishiiruka Tool". PNG or DDS.
#  $global:InPlaceMaterial       - boolean   - Create material maps in-place instead of the output folder.
#  $global:WM_Length             - integer   - The number of characters to use in a watermark. Entering 0 means "use the whole name". Minimum of 6 is forced.
#  $global:WM_FontFace           - string    - The font used for the watermark. Naming scheme must match what ImageMagick expects.
#  $global:WM_FontSize           - integer   - The relative size of the font expanded across the texture.
#  $global:WM_FontColor          - string    - The color of the font using HTML notation. 
#  $global:WM_BGColor            - string    - The color displayed behind the font using HTML notation. 
#  $global:WM_WordWrap           - boolean   - Forces the name to wrap to the next line. This feature is broken in several versions of ImageMagick v7.0.3+.
#  $global:OptiPNGTests          - integer   - The number of tests OptiPNG performs in attempts to reduce texture size.
#  $global:InPlaceOptiPNG        - boolean   - Create optimized textures in-place instead of the output folder.
#  $global:FilterSelected        - string    - The selected upscaling filter that is used in "Apply Upscaling Filter to All Textures".
#  $global:FilterNewScale        - integer   - The value to upscale the texture using the selected filter.
#  $global:SeamlessMethod        - string    - Controls which textures get the seamless method: opaque, all, or none.
#  $global:SeamlessFactor        - decimal   - The amount of the image to crop when using the seamless method.
#  $global:Waifu2xCMode          - string    - The conversion mode when using waifu2x. Can be noise, scale, or noise_scale.
#  $global:Waifu2xNoise          - integer   - The amount of noise reduction to apply if "noise" is selected in the conversion mode.
#  $global:Waifu2xOpenCL         - boolean   - Enables OpenCL with waifu2x-CPP. Can not be used with "Waifu2xNoGPU".
#  $global:Waifu2xModel          - string    - Stores the selected waifu2x model that is used for upscaling.
#  $global:Waifu2xNoGPU          - boolean   - Disables the GPU using any version of waifu2x. Can not be used with "Waifu2xOpenCL".
#  $global:TextureRows           - integer   - Stores the default number of rows when using "Combine Multiple Textures" or "Split Combine Multi-Texture".
#  $global:TextureColumns        - integer   - Stores the default number of columns when using "Combine Multiple Textures" or "Split Combine Multi-Texture".
#  $global:CombinedName          - string    - The output name of the combined texture when using "Combine Multiple Textures".
#  $global:ConsoleColors         - boolean   - Show additional colors in the console window when processing textures.
#  $global:ImageMagick           - string    - The path to ImageMagick. Script by default pulls this value from the registry, but can be set to any path.
#  $global:NvidiaTools           - string    - The path to DDS Utilities. Script by default pulls this value from the registry, but can be set to any path.
#  $global:DisablePSXButton      - boolean   - Hidden option, not on GUI. Toggles the PowerShell "X" button.
#  $global:SelectionPath         - string    - Stores the path to where textures are selected from when using Combine Multiple Textures.
#  $global:UpdateTempFolder      - boolean   - NOT to be manually edited. If the TempFolder path was changed, this variable allows the new value to be written to the script when closed.
#  $global:UpdateImageMagick     - boolean   - NOT to be manually edited. If the ImageMagick path was changed, this variable allows the new value to be written to the script when closed.
#  $global:UpdateNvidiaTools     - boolean   - NOT to be manually edited. If the NvidiaTools path was changed, this variable allows the new value to be written to the script when closed.
#==============================================================================================================================================================================================
#  * An attempt to gather all globals scattered throughout the script into a single location with explanations of their functionality.
#
#  $global:Texture               - hashtable - The most important variable, this stores all information about the texture.
#  $global:ScriptName            - string    - Stores the name of the script.
#  $global:ScriptPath            - string    - Stores the full path to the script + the script.
#  $global:TitleBarMessage       - string    - Stores the current operation to display on the scripts title bar.
#  $global:PSVersion             - integer   - Stores the running version of PowerShell.
#  $global:MasterInputPath       - string    - The path where the script looks for textures.
#  $global:MasterOutputPath      - string    - The path where the script outputs generated textures.
#  $global:PreviousPath          - string    - Used only when updating the log file to check if the path has changed.
#  $global:BaseFolder            - string    - The path to the base location of the script.
#  $global:LogFile               - string    - The full path to the log file.
#  $global:IMVersion             - string    - Displays the ImageMagick version. Currently only the branch, meaning v6 or v7 and not the specific version.
#  $global:IMConvert             - string    - ImageMagick path to convert.exe/magick.exe.
#  $global:IMIdentify            - string    - ImageMagick path to identify.exe for ImageMagick v6. Will hold magick.exe for v7.
#  $global:IM7Identify           - string    - ImageMagick symbolic link to identify for ImageMagick v7. Empty string if v6 is found.
#  $global:IMMontage             - string    - ImageMagick path to montage.exe for ImageMagick v6. Will hold magick.exe for v7.
#  $global:IM7Montage            - string    - ImageMagick symbolic link to montage for ImageMagick v7. Empty string if v6 is found.
#  $global:NVDXT                 - string    - DDS Utilities path to "nvdxt.exe".
#  $global:NSTITCH               - string    - DDS Utilities path to "stitch.exe".
#  $global:NDETACH               - string    - DDS Utilities path to "detach.exe".
#  $global:NVDXT_Exists          - boolean   - Stores whether or not "nvdxt.exe" was found on the first initialization.
#  $global:MasterOperation       - string    - Stores the "Standard" or "Advanced" option that was selected from the main menu.
#  $global:RescaleAutoText       - string    - Renames "RescaledTextures" to the value specified by the user from the GUI.
#  $global:ConvertAutoText       - string    - Renames "ConvertedTextures" to the value specified by the user from the GUI.
#  $global:TotalReductionB       - integer   - Stores the total amount of hard drive space recovered from OptiPNG.
#  $global:FilterSelected        - string    - Stores the filter that was selected when upscaling textures.
#  $global:IshiirukaFormat       - string    - Stores the file extension the user chose when creating material maps.
#  $global:Duplicates            - hashtable - All textures names are added during a "Scan Textures" loop. Each loop the hash table is checked to see if it already exists.  
#  $global:CountProcessed        - integer   - Stores the total number of textures processed by the main loop.
#  $global:CountIssues           - integer   - Stores the number of textures that had issues.
#  $global:CountCopied           - integer   - Stores the number of textures that were copied.
#  $global:CountRepaired         - integer   - Stores the number of textures that were repaired.
#  $global:CountRepairOptiPNG    - integer   - Stores the number of textures repaired that were potentially broken by OptiPNG.
#  $global:CountOptimized        - integer   - Stores the number of textures optimized with OptiPNG.
#  $global:CountMipMapped        - integer   - Stores the number of textures that had mipmaps created for them using "Generate New MipMaps".
#  $global:CountInvalidMips      - integer   - Stores the number of textures that had invalid mipmaps removed.
#  $global:CountSlicedAlpha      - integer   - Stores the number of textures that had their alpha channel removed.
#  $global:ConsoleType           - integer   - The type of message to display in ConsoleUpdateLoopEnd. 0: Error, 1: One Part Message, 2: Two Part Message
#  $global:ConsoleMsgA           - string    - The first part of the console message. Displayed in red if ConsoleType is an error.
#  $global:ConsoleMsgB           - string    - The second part of the console message, displayed in green.
#  $global:LogMessage            - string    - Appended to the end of the line in the log file.
#  $global:TextureArray          - string    - A 2 dimensional array that stores the texture in the row/column when using split or combine textures.
#  $global:CombinedTexture       - string    - The path to the texture to when using Split Combined Multi-Texture.
#  $global:CTTDataFile           - string    - The path to a CTT file when using Split Combined Multi-Texture.
#  $global:YesNoChoice           - boolean   - If the user hits escape to cancel the main loop, a confirm dialog pops up. This is the answer the user chose.
#==============================================================================================================================================================================================
#  GLOBAL VARIABLES: RESET GLOBAL VARIABLES
#==============================================================================================================================================================================================
#  When the main loop is finished, these variables are reset to their default values. This is also executed once on init.

function ResetGlobalVars()
{
  $global:MasterOperation     = ''      # The current operation that is taking place in the main loop.
  $global:LogMessage          = ''      # What to display in the log after a loop iteration is complete.
  $global:PreviousPath        = ''      # Stores the path of the previous loop iteration so it can be accessed in the current iteration. Used for logging.
  $global:Duplicates          = @{}     # Hash table which stores file names that may be duplicate textures during a Scan Textures loop.
  $global:CountIssues         = 0       # The total number of textures that had issues after a Scan Textures loop is complete.
  $global:CountProcessed      = 0       # The total number of textures processed when the main loop finishes.
  $global:CountCopied         = 0       # The total number of bad textures copied when a Scan Textures loop is complete.
  $global:CountRepaired       = 0       # The total number of bad textures repaired when a Scan Textures loop is complete.
  $global:CountMipMapped      = 0       # The total number of textures that had mipmaps generated with Generate New MipMaps.
  $global:CountInvalidMips    = 0       # The total number of textures that had invalid mipmaps with Remove Invalid MipMaps.
  $global:CountSlicedAlpha    = 0       # The total number of textures that had their alpha channel removed with Remove Alpha Channel From Opaque Textures.
  $global:CountRepairOptiPNG  = 0       # The total number of textures fixed that were potentially broken by OptiPNG.
  $global:CountOptimized      = 0       # The total number of textures that were optimized with OptiPNG.
  $global:TotalReductionB     = 0       # The total amount of hard drive space recovered using OptiPNG in Bytes.
  $global:TitleBarMessage     = ''      # Message that is displayed on the title bar.
}
#==============================================================================================================================================================================================
#  IMPORTED CODE: SET POWERSHELL CONSOLE POSITION
#==============================================================================================================================================================================================
#  Like all amazing code, I didn't write it but it's awesome. It lets you position the window for a running process, in this case I use it for the PS window.
#  Source: https://gallery.technet.microsoft.com/scriptcenter/Set-the-position-and-size-54853527

function Set-Window {
  [OutputType('System.Automation.WindowInfo')]
  [cmdletbinding()]
  Param (
    [parameter(ValueFromPipelineByPropertyName=$True)]
    $ProcessName,
    [int]$X,
    [int]$Y,
    [int]$Width,
    [int]$Height,
    [switch]$Passthru
  )
  Begin {
    Try {
      [void][Window]
    } Catch {
      Add-Type @"
      using System;
      using System.Runtime.InteropServices;
      public class Window {
        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
        [DllImport("User32.dll")]
        public extern static bool MoveWindow(IntPtr handle, int x, int y, int width, int height, bool redraw);
      }
      public struct RECT
      {
        public int Left;        // x position of upper-left corner
        public int Top;         // y position of upper-left corner
        public int Right;       // x position of lower-right corner
        public int Bottom;      // y position of lower-right corner
      }
"@
    }
  }
  Process {
    $Rectangle = New-Object RECT
    $Handle = (Get-Process -Name $ProcessName).MainWindowHandle
    $Return = [Window]::GetWindowRect($Handle,[ref]$Rectangle)
    if (-NOT $PSBoundParameters.ContainsKey('Width')) {            
      $Width = $Rectangle.Right - $Rectangle.Left            
    }
    if (-NOT $PSBoundParameters.ContainsKey('Height')) {
      $Height = $Rectangle.Bottom - $Rectangle.Top
    }
    if ($Return) {
      $Return = [Window]::MoveWindow($Handle, $x, $y, $Width, $Height,$True)
    }
    if ($PSBoundParameters.ContainsKey('Passthru')) {
      $Rectangle = New-Object RECT
      $Return = [Window]::GetWindowRect($Handle,[ref]$Rectangle)
      if ($Return) {
        $Height = $Rectangle.Bottom - $Rectangle.Top
        $Width = $Rectangle.Right - $Rectangle.Left
        $Size = New-Object System.Management.Automation.Host.Size -ArgumentList $Width, $Height
        $TopLeft = New-Object System.Management.Automation.Host.Coordinates -ArgumentList $Rectangle.Left, $Rectangle.Top
        $BottomRight = New-Object System.Management.Automation.Host.Coordinates -ArgumentList $Rectangle.Right, $Rectangle.Bottom
        if ($Rectangle.Top -lt 0 -AND $Rectangle.LEft -lt 0) {
          Write-Warning "Window is minimized! Coordinates will not be accurate."
        }
        $Object = [pscustomobject]@{
          ProcessName = $ProcessName
          Size = $Size
          TopLeft = $TopLeft
          BottomRight = $BottomRight
        }
        $Object.PSTypeNames.insert(0,'System.Automation.WindowInfo')
        $Object            
      }
    }
  }
}
#==============================================================================================================================================================================================
#  IMPORTED CODE: DISABLE POWERSHELL "X" BUTTON
#==============================================================================================================================================================================================
# Disables the PowerShell "X" button which forces users to close the script with the GUI.
# Source: http://poshcode.org/4059

$DisableX = @"
using System;
using System.Runtime.InteropServices;
     
namespace CloseButtonToggle {
  internal static class WinAPI {
    [DllImport("kernel32.dll")]
    internal static extern IntPtr GetConsoleWindow();
     
    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    internal static extern bool DeleteMenu(IntPtr hMenu, uint uPosition, uint uFlags);

    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    internal static extern bool DrawMenuBar(IntPtr hWnd);
     
    [DllImport("user32.dll")]
    internal static extern IntPtr GetSystemMenu(IntPtr hWnd, [MarshalAs(UnmanagedType.Bool)]bool bRevert);

    const uint SC_CLOSE     = 0xf060;
    const uint MF_BYCOMMAND = 0;
     
    internal static void ChangeCurrentState(bool state) {
      IntPtr hMenu = GetSystemMenu(GetConsoleWindow(), state);
      DeleteMenu(hMenu, SC_CLOSE, MF_BYCOMMAND);
      DrawMenuBar(GetConsoleWindow());
    }
  }
  public static class Status {
    public static void Disable() {
      WinAPI.ChangeCurrentState(false); //its 'true' if need to enable
    }
  }
}
"@
# The hidden option in the script's header can easily control if this function is ran or not.
if ($DisablePSXButton)
{
  Add-Type -TypeDefinition $DisableX -Language CSharp
  [CloseButtonToggle.Status]::Disable()
}
#==============================================================================================================================================================================================
#  IMPORTED CODE: SHOW / HIDE POWERSHELL CONSOLE
#==============================================================================================================================================================================================
# Awesome function that can show or hide the PowerShell console window.
# Source: http://powershell.cz/2013/04/04/hide-and-show-console-window-from-gui/

$HideConsole = @"
[DllImport("Kernel32.dll")]
public static extern IntPtr GetConsoleWindow();
[DllImport("user32.dll")]
public static extern bool ShowWindow(IntPtr hWnd, Int32 nCmdShow);
"@
Add-Type -Namespace Console -Name Window -MemberDefinition $HideConsole

# Function to call that shows or hides the console window.
function ShowPowerShellConsole([bool]$ShowConsole)
{
  $consolePtr = [Console.Window]::GetConsoleWindow()
  if ($ShowConsole)
  {
    [Console.Window]::ShowWindow($consolePtr, 5) | Out-Null
  }
  else
  {
    [Console.Window]::ShowWindow($consolePtr, 0) | Out-Null
  }
}
#==============================================================================================================================================================================================
#  MISCELLANEOUS: PATH/FILE MANIPULATION FUNCTIONS
#==============================================================================================================================================================================================
#  Creates a folder if it does not already exist. Returns the parameter so it can be set to a variable when called.

function CreatePath([string]$inputpath)
{
  # Make sure the path isn't null to avoid errors.
  if ($inputpath -ne '')
  {
    # Check to see if the path does not exist.
    if (!(Test-Path -LiteralPath $inputpath))
    {
      # Create the path.
      New-Item -Path $inputpath -ItemType Directory | Out-Null
    }
  }
  # Return the path so it can be set to a variable when creating.
  return $inputpath
}
#==============================================================================================================================================================================================
#  Removes a file or folder if it exists.

function RemovePath([string]$inputpath)
{
  # Make sure the path isn't null to avoid errors.
  if ($inputpath -ne '')
  {
    # Check to see if the path exists.
    if (Test-Path -LiteralPath $inputpath)
    {
      # Remove the path.
      Remove-Item -LiteralPath $inputpath -Recurse -Force | Out-Null
    }
  }
}
#==============================================================================================================================================================================================
#  Checks if a path exists. Avoids use of "Test-Path" directly which can generate an error if the tested path is null.

function TestPath([string]$inputpath)
{
  # Make sure the path isn't null to avoid errors.
  if ($inputpath -ne '')
  {
    # Check to see if the path exists.
    if (Test-Path -LiteralPath $inputpath)
    {
      # Remove the path.
      return $true
    }
  }
  return $false
}
#==============================================================================================================================================================================================
#  MISCELLANEOUS: STRING MANIPULATION FUNCTIONS
#==============================================================================================================================================================================================
#  Counts the number of characters in a string and extends it with empty spaces to the input amount.

function ExtendString([string]$inputstring, [int]$stringlength)
{
  # Count the number of characters in the input string.
  $Count = ($inputstring | Measure-Object -Character).Characters

  # Check the number of characters against the desired amount.
  if ($Count -lt $stringlength)
  {
    # If the string is to be lengthened, find out by how much.
    $AddLength = $stringlength - $Count

    # Loop until the string matches the desired number of characters.
    for ($i=1; $i -le $AddLength; $i++)
    {
      $inputstring += ' '
    }
  }
  # Return the modified string.
  return $inputstring
}
#==============================================================================================================================================================================================
#  Takes an integer and converts it to a string and also appends a 0 to the front of the string if the integer is less than 10.

function IntToStringDoubleDigit([int]$inputint)
{
  # Check if the input number is less than 10.
  if ($inputint -lt 10)
  {
    # If it is, append a 0 and return as a string.
    return ('0' + $inputint.ToString())
  }
  # Otherwise just return the integer as a string.
  return $inputint.ToString()
}
#==============================================================================================================================================================================================
#  Forces a value into a string with 2 decimal places.

function FormatDecimal([string]$inputvalue)
{
  # Some countries use commas instead of periods for decimals.
  if ($inputvalue -like '*,*')
  {
    # If a comma is found, replace it with a period.
    $inputvalue = $inputvalue.Replace(',','.')
  }
  # Now split on the period. This will be used to fix any values with a leading 0 (such as 01.25) or a missing 0 (such as .25).
  $PeriodSplit = $inputvalue.Split('.', 2)

  # Convert the integer part of the string into an actual integer, then back into a string. This will fix any leading 0s, or make it 0 if a number was not found.
  $IntValue = ([int]$PeriodSplit[0]).ToString()

  # Fixing the decimal value depends on the number of characters available in the value.
  $DecimalPlaces = (($PeriodSplit[1] | Measure-Object -Character).Characters).ToString()

  # A switch works well here because the range is 0-2, anything beyond, and nothing negative.
  switch ($DecimalPlaces)
  {
    '0'     { $FixedValue = $IntValue + ".00" }                                 # If a decimal value was not provided, append two 0s.
    '1'     { $FixedValue = $IntValue + '.' + $PeriodSplit[1] + "0" }           # If there is only a single digit, then append a single zero.
    '2'     { $FixedValue = $IntValue + '.' + $PeriodSplit[1] }                 # If there are exactly 2 characters, just use the current value.
    default { $FixedValue = $IntValue + '.' + $PeriodSplit[1].Substring(0,2) }  # If the decimal has more than 2 characters, keep only the first 2 characters.
  }
  # Return the new value.
  return $FixedValue
}
#==============================================================================================================================================================================================
#  Takes a file extension (.png/.dds/.jpg) and returns it as a 3 letter word (PNG/DDS/JPG).

function ExtensionToText([string]$inputstring)
{
  # Allow returning "null" as text if string is empty. Only used in "OverwriteOption" function.
  if ($inputstring -eq '')
  {
    return 'null'
  }
  # Trim the period and force the string to uppercase.
  return $inputstring.TrimStart('.').ToUpper()
}
#==============================================================================================================================================================================================
#  POWERSHELL CONSOLE FUNCTIONS: MORE CONSOLE COLORS
#==============================================================================================================================================================================================
#  Alternative Write-Host that can conditionally add color rather than being forced like regular Write-Host. Mostly used with $ConsoleColors (a.k.a. "More Console Colors" option).

function Write_Host([string]$Message, [bool]$AddColor, [string]$Color, [bool]$NoNewLine)
{
  # If color was specified and color is enabled.
  if (($Color -ne '') -and ($AddColor))
  {
    # Merge the next line of text written to console with this one.
    if ($NoNewLine)
    {
      Write-Host $Message -ForegroundColor $Color -NoNewLine
    }
    # Keep it to a single line only.
    else
    {
      Write-Host $Message -ForegroundColor $Color
    }
  }
  # If color was disabled or no color was provided.
  else
  {
    # Merge the next line of text written to console with this one.
    if ($NoNewLine)
    {
      Write-Host $Message -NoNewLine
    }
    # Keep it to a single line only.
    else
    {
      Write-Host $Message
    }
  }
}
#==============================================================================================================================================================================================
#  POWERSHELL CONSOLE FUNCTIONS: UPDATE THE POWERSHELL WINDOW WITH INFORMATION
#==============================================================================================================================================================================================
#  Console: Updates the console with texture information before processing the texture in the Main Loop.

function ConsoleUpdateLoopStart()
{
  # Manual Rescale has its own information to display, so don't display this if it's enabled.
  if (!$ManualRescale)
  {
    # Writes information about the texture to the console window.
    Write_Host ' Texture    : ' $ConsoleColors Yellow $true
    Write-Host $Texture.FullName -ForegroundColor Cyan
    Write_Host ' Path       : ' $ConsoleColors Yellow $true
    Write-Host ($Texture.Folder + $Texture.Relative)
    Write_Host ' Dimensions : ' $ConsoleColors Yellow $true
    Write-Host ($Texture.Dimensions + ' : ' + $Texture.Aspect.ToString())
    Write_Host ' Scale      : ' $ConsoleColors Yellow $true
    Write-Host $Texture.Scale
  }
}
#==============================================================================================================================================================================================
#  Console: Set up the message to display in "ConsoleUpdateLoopEnd" which shows after the main loop processes a texture.

function SetConsoleMessage([string]$msgtype, [string]$msgstart, [string]$msgend)
{
  $global:ConsoleType = $msgtype
  $global:ConsoleMsgA = $msgstart
  $global:ConsoleMsgB = $msgend
}
#==============================================================================================================================================================================================
#  Console: Updates the console with texture information after processing the texture in the Main Loop. 

function ConsoleUpdateLoopEnd()
{
  # There are four types of messages that can be displayed. If "ConsoleType" is empty none of them will display.
  switch ($ConsoleType)
  {
    # Error Message - All red "error" with red text.
    '0' { Write-Host (' ERROR      : ' + $ConsoleMsgA) -ForegroundColor Red }
    # Normal Message - Yellow "message", white text.
    '1' { Write_Host ' Message    : ' $ConsoleColors Yellow $true ; Write-host $ConsoleMsgA }
    # 2-Part Message - Yellow "message", half white/half green text.
    '2' { Write_Host ' Message    : ' $ConsoleColors Yellow $true ; Write-Host $ConsoleMsgA -NoNewLine ; Write-Host $ConsoleMsgB -ForegroundColor Green }
    # Notice Message - Magenta "notice", white text.
    '3' { Write_Host ' Notice     : ' $ConsoleColors Magenta $true ; Write-Host $ConsoleMsgA }
  }
  # Reset the message variables to a null value to prevent text popping up when it's not wanted.
  $global:ConsoleType = $null
  $global:ConsoleMsgA = $null
  $global:ConsoleMsgB = $null

  # Create a text bar to separate individual texture information.
  Write_Host '-----------------------------------------------------------------------------------------------------------------------' $ConsoleColors Gray $false
}
#==============================================================================================================================================================================================
#  LOG FILE FUNCTIONS: CREATE AND WRITE TO THE LOG FILE
#==============================================================================================================================================================================================
#  Log: Creates the log file.

function AttemptCreateLogFile()
{
  # If the user disabled creating the log file then do not create it.
  if (!$DisableLogFile)
  {
    # Set the base log path.
    $global:LogFile = $BaseFolder + '\' + $ScriptName + '.log'

    # If a log file already exists, remove it before starting to add data to it.
    RemovePath $LogFile

    # Log the intro stuff.
    Add-Content -LiteralPath $LogFile -value '---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------'
    Add-Content -LiteralPath $LogFile -value 'Custom Texture Tool PS - Operation Log '
    Add-Content -LiteralPath $LogFile -value '---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------'

    # Log the operation and all enabled sub-options.
    $OptionSelected = ''
    $EnabledOptions = ''

    # Log the master option that was selected.
    switch ($MasterOperation)
    {
      'ScanAllTextures' { $OptionSelected = 'Scan Textures For Issues' }
      'ForceIntScaling' { $OptionSelected = 'Rescale Textures at Fixed Integer (' + $RescaleFactor + 'x)' }
      'ConvertTextures' { $OptionSelected = 'Convert Textures to Another Format (' + (ExtensionToText $ConvertFormat) + ')' }
      'CreateMaterials' { $OptionSelected = 'Create Material Maps With Ishiiruka Tool' }
      'MaterialInPlace' { $OptionSelected = 'Create Material Maps With Ishiiruka Tool (In-Place)' }
      'CreateWatermark' { $OptionSelected = 'Add Identifying Watermark to All Textures' }
      'OptiPNGTextures' { $OptionSelected = 'Optimize PNG Textures With OptiPNG' }
      'OptimizeInPlace' { $OptionSelected = 'Optimize PNG Textures With OptiPNG (In-Place)' }
      'UpscaleTextures' { $OptionSelected = 'Apply Upscaling Filter to All Textures (' + $UpscaleFilter + ')' }
      'GenerateMipMaps' { $OptionSelected = 'Generate New MipMaps' }
      'RemoveBadMipMap' { $OptionSelected = 'Remove Invalid MipMaps' }
      'AlphaChannelFix' { $OptionSelected = 'Remove Alpha Channel From Opaque Textures' }
      'FixBrokeOptiPNG' { $OptionSelected = 'Fix Textures Potentially Broken by OptiPNG' }
    }
    # Log all enabled sub-options.
    if ($RepairTextures)   { $EnabledOptions += 'Attempt Repairs, ' }
    if ($CopyBadTextures)  { $EnabledOptions += 'Copy Bad Textures, ' }
    if ($HideOKTextures)   { $EnabledOptions += 'Hide OK Textures, ' }
    if ($IgnoreDuplicates) { $EnabledOptions += 'Ignore Duplicates, ' }
    if ($AllowNotHD)       { $EnabledOptions += 'Allow NotHD Textures, ' }
    if ($CopyNonTextures)  { $EnabledOptions += 'Copy Non-Textures, ' }
    if ($ForceNewMipMaps)  { $EnabledOptions += 'Force New MipMaps, ' }
    if ($ManualRescale)    { $EnabledOptions += 'Manual Rescale, ' }
    if ($ConvertRepair)    { $EnabledOptions += 'Auto-Repair Dimensions, ' }
    if ($AllowAllImages)   { $EnabledOptions += 'Allow All Images, ' }

    # The last logged option will leave behind a trailing comma so trim it.
    $EnabledOptions = $EnabledOptions.TrimEnd(', ')

    # Print all enabled options in the log file.
    Add-Content -LiteralPath $LogFile -value ('Operation Selected : ' + $OptionSelected)
    Add-Content -LiteralPath $LogFile -value ('Enabled Sub-Options: ' + $EnabledOptions)
  }
}
#==============================================================================================================================================================================================
#  Log: Updates the log with texture information after processing the texture in the Main Loop.

function AttemptUpdateLogFile()
{
  # Log the texture if the user did not disable the log, and it holds a message other than 'OK'. Only log 'OK' textures when the user chooses not to hide them.
  if ((!$DisableLogFile) -and (($LogMessage -ne 'OK') -or (!$HideOKTextures)))
  {
    # If the path has changed since the last texture, then log the new path for the next texture.
    if ($Texture.Path -ne $PreviousPath)
    {
      Add-Content -LiteralPath $LogFile -value '---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------'
      Add-Content -LiteralPath $LogFile -value ('Path: ' + $Texture.Path)
      Add-Content -LiteralPath $LogFile -value ''
    }
    # Format text for log files using the custom "ExtendString" function.
    $LogName    = ExtendString $Texture.FullName 52
    $LogOldDim  = ExtendString ($Texture.OldWidth.ToString() + 'x' + $Texture.OldHeight.ToString() + ':' + $Texture.OldAspect.ToString()) 14
    $LogNewDim  = ExtendString ($Texture.Width.ToString() + 'x' + $Texture.Height.ToString() + ':' + $Texture.Aspect.ToString()) 14
    $LogScale   = ExtendString $Texture.Scale 11

    # Output formatted text to the log file. Uses the global $LogMessage variable to display additional info.
    $LogOutput  = $LogName + ' [Original] ' + $LogOldDim + ' [Custom] ' + $LogNewDim + ' [Scale] ' + $LogScale + ' [Status] ' + $LogMessage
    Add-Content -LiteralPath $LogFile -value $LogOutput

    # After the log message has been used, wipe it out so it doesn't display again unless set.
    $global:LogMessage = $null

    # Store the current path so when the next texture is analyzed, it is known whether or not the path changed so the log can be updated accordingly.
    $global:PreviousPath = $Texture.Path
  }
}
#==============================================================================================================================================================================================
#  POWERSHELL CONSOLE + LOG FILE FINAL UPDATE: FIRES WHEN THE MASTER LOOP ENDS
#==============================================================================================================================================================================================
#  Sub-function of "ConsoleAndLogFinalUpdate". Appends a line of text to the log file if it's not disabled.

function TryUpdateLog([string]$message)
{
  # Do not append text if the log file is disabled. 
  if (!$DisableLogFile)
  {
    # Uh, add the line of text to the log file?
    Add-Content -LiteralPath $LogFile -value $message
  }
}
#==============================================================================================================================================================================================
#  Sub-function of "ConsoleAndLogFinalUpdate" to show additional information if the selected option is "Scan All Textures".

function ConsoleAndLogFinal_ScanTextures()
{
  # Report the number of issues.
  if ($CountIssues -gt 0)
  {
    Write_Host ' Total Textures w/ Issues : ' $ConsoleColors Cyan $true
    Write-Host $CountIssues.ToString()
    TryUpdateLog ('Total Texture Issues   : ' + $CountIssues)
  }
  #  Report a special message if there were no issues.
  else
  {
    Write-Host ' No texture issues were detected!'
    TryUpdateLog ('No texture issues were detected!')
  }
  # If the user attempted to repair textures.
  if ($RepairTextures)
  {
    # Report the number of copied textures.
    if ($CountCopied -gt 0)
    {
      Write_Host ' Total Textures Copied    : ' $ConsoleColors Cyan $true
      Write-Host $CountCopied.ToString()
      TryUpdateLog ('Total Textures Copied  : ' + $CountCopied)
    }
    # Report the number of repaired textures.
    if ($CountRepaired -gt 0)
    {
      Write_Host ' Total Textures Repaired  : ' $ConsoleColors Cyan $true
      Write-Host $CountRepaired.ToString()
      TryUpdateLog ('Total Textures Repaired: ' + $CountRepaired)
    }
  }
  # Create one last dividing bar.
  Write_Host '-----------------------------------------------------------------------------------------------------------------------' $ConsoleColors Gray $false
  TryUpdateLog '---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------'
}
#==============================================================================================================================================================================================
#  Sub-function of "ConsoleAndLogFinalUpdate" to show additional information if the selected option is "Optimize Textures With OptiPNG".

function ConsoleAndLogFinal_OptiPNGTextures()
{
  # Report the total number of textures optimized.
  Write_Host ' Total Textures Optimized     : ' $ConsoleColors Cyan $true
  Write-Host $CountOptimized.ToString()
  TryUpdateLog ('Total Textures Optimized     : ' + $CountOptimized)

  # If the Total Reduction is greater than 1 MB.
  if ($TotalReductionB -ge 1048576)
  {
    $TotalReductionMB = FormatDecimal ([decimal]($TotalReductionB/1024/1024))
    Write_Host ' Total Reduction With OptiPNG : ' $ConsoleColors Cyan $true
    Write-Host ($TotalReductionMB + ' MB')
    TryUpdateLog ('Total Reduction With OptiPNG : ' + $TotalReductionMB + ' MB')
  }
  # If the Total Reduction is greater than 1 KB.
  elseif ($TotalReductionB -ge 1024)
  {
    $TotalReductionKB = FormatDecimal ([decimal]($TotalReductionB/1024))
    Write_Host ' Total Reduction With OptiPNG : ' $ConsoleColors Cyan $true
    Write-Host ($TotalReductionKB + ' KB')
    TryUpdateLog ('Total Reduction With OptiPNG : ' + $TotalReductionKB + ' KB')
  }
  # Display in Bytes.
  else
  {
    Write_Host ' Total Reduction With OptiPNG : ' $ConsoleColors Cyan $true
    Write-Host ($TotalReductionB.ToString() + ' Bytes')
    TryUpdateLog ('Total Reduction With OptiPNG : ' + $TotalReductionB.ToString() + ' Bytes')
  }
  # Create one last dividing bar.
  Write_Host '-----------------------------------------------------------------------------------------------------------------------' $ConsoleColors Gray $false
  TryUpdateLog '---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------'
}
#==============================================================================================================================================================================================
#  Sub-function of "ConsoleAndLogFinalUpdate". Generic function that displays either the number of textures in the count, or a message indicating the count was zero.

function ConsoleAndLogFinal_Universal([int]$texcount, [string]$message_A, [string]$message_B)
{
  # Check to see if the corresponding count is greater than 0.
  if ($texcount -gt 0)
  {
    # If it is, display the count in both the console and the log.
    Write_Host (' Total Textures ' + $message_A + ' : ') $ConsoleColors Cyan $true
    Write-Host ' ' + $texcount.ToString()
    TryUpdateLog ('Total Textures ' + $message_A + ' : ' + $texcount)
  }
  else
  {
    # If not, display the alternate message that states the count was 0.
    Write-Host (' ' + $message_B)
    TryUpdateLog ($message_B)
  }
  # Create a bar between texture information in both console and log.
  Write_Host '-----------------------------------------------------------------------------------------------------------------------' $ConsoleColors Gray $false
  TryUpdateLog '---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------'
}
#==============================================================================================================================================================================================
function ConsoleAndLogFinalUpdate()
{
  # Log a bar for the hell of it.
  TryUpdateLog '---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------'

  # If any of the below options are enabled, display additional information.
  switch ($MasterOperation)
  {
    'ScanAllTextures' { ConsoleAndLogFinal_ScanTextures }
    'OptiPNGTextures' { ConsoleAndLogFinal_OptiPNGTextures }
    'OptimizeInPlace' { ConsoleAndLogFinal_OptiPNGTextures }
    'GenerateMipMaps' { ConsoleAndLogFinal_Universal $CountMipMapped 'MipMapped' 'No textures required mipmaps!' }
    'RemoveBadMipMap' { ConsoleAndLogFinal_Universal $CountInvalidMips 'With Invalid MipMaps' 'No mipmap textures with invalid mipmaps were found!' }
    'AlphaChannelFix' { ConsoleAndLogFinal_Universal $CountSlicedAlpha 'With Removed Alpha Channel' 'No textures with an unnecessary alpha channel were found!' }
    'FixBrokeOptiPNG' { ConsoleAndLogFinal_Universal $CountRepairOptiPNG 'With Attempted Repairs' 'No textures found that could be potentially broken!' }
  }
  # Create one last empty space.
  Write-Host ''
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: TEXTURE VALIDATION
#==============================================================================================================================================================================================
#  Sub function of ValidateTexture. Copies a corrupt texture to a location and outputs information to the console.

function CopyCorruptTexture([hashtable]$texdata)
{
  # Output that the texture is corrupt.
  Write_Host ' Texture    : ' $ConsoleColors Yellow $true
  Write-Host ($texdata.FullName + ' is corrupt.') -ForegroundColor Red
  Write_Host ' Path       : ' $ConsoleColors Yellow $true
  Write-Host ($texdata.Folder + $texdata.Relative)
  Write_Host ' Message    : ' $ConsoleColors Yellow $true
  Write-Host 'Texture copied to ' -NoNewLine
  Write-Host ('CorruptTextures' + $texdata.Relative) -ForegroundColor Green
  Write_Host '-----------------------------------------------------------------------------------------------------------------------' $ConsoleColors Gray $false

  # Copy corrupt textures to a new folder.
  $CorruptPath = CreatePath ($MasterOutputPath + '\CorruptTextures' + $texdata.Relative)
  Copy-Item -LiteralPath $texdata.FullPath -Destination $CorruptPath -Force
}
#==============================================================================================================================================================================================
#  Sub function of ValidateTexture. Checks/repairs an Ishiiruka color texture with a missing material if it was detected as "corrupt".

function MaterialMapTextureRepaired([hashtable]$texdata)
{
  # Default the return state to false. It only becomes true if a texture is created.
  $IshiiRepaired = $false

  # It might actually be an Ishiiruka color texture with a missing material. Attempt to repair it to a standard DDS. 
  if (TestPath $IshiirukaTool)
  {
    # Alert the user that additional testing is being done.
    Write_Host ' Notice     : ' $ConsoleColors Magenta $true
    Write-Host 'Testing ' -NoNewLine
    Write-Host $texdata.FullName -ForegroundColor Cyan -NoNewLine
    Write-Host ' for Ishiiruka Texture with missing Material Map...'

    # Create a fake (.mat) texture from the current texture.
    $FakeMaterial = $texdata.PathName + '.mat' + $DDS
    Copy-Item -LiteralPath $texdata.FullPath -Destination $FakeMaterial -Force

    # Create a temporary path to attempt to generate a PNG texture from Ishiiruka Tool.
    $TempIshiiFolder  = CreatePath ($TempFolder + '\TempIshiiruka\')
    $TempIshiiTexture = $TempIshiiFolder + $texdata.Name + $PNG

    # Try to create a texture using Ishiiruka Tool.
    & $IshiirukaTool $texdata.FullPath $TempIshiiFolder '-nomipmaps' '-savecolor' | Out-Null

	# Remove the fake material because it's no longer needed.
    RemovePath $FakeMaterial

    # Check to see if the texture was created.
    if (TestPath $TempIshiiTexture)
    {
      # Create more paths to create a texture to replace the bunk Ishiiruka Texture with the missing material.
      $TempGenFolder  = CreatePath ($TempFolder + '\TempGenerate\')
      $TempGenTexture = $TempGenFolder + $texdata.Name + $DDS

      # Recreate the texture with ImageMagick.
      & $IMConvert -quiet $TempIshiiTexture -define 'dds:compression=dxt5' -define 'dds:mipmaps=0' $TempGenTexture

      # Check to see if the generated texture exists.
      if (TestPath $TempGenTexture)
      {
        # If it does then replace the original texture with the fixed texture.
        Move-Item -LiteralPath $TempGenTexture -Destination $texdata.FullPath -Force

        # Alert the texture was repaired.
        Write_Host ' Message    : ' $ConsoleColors Yellow $true
        Write-Host 'Successfully repaired ' -NoNewLine
        Write-Host ($texdata.Name + '.dds') -ForegroundColor Cyan -NoNewLine
        Write-Host '.'

        # Now that we have a working texture, pass the validation.
        $IshiiRepaired = $true
      }
      # If it doesn't exist.
      else
      {
        # Alert the texture is still bad.
        Write_Host ' Message    : ' $ConsoleColors Red $true
        Write-Host 'Texture failed Ishiiruka Test and is corrupt!'
      }
    }
    # Some shit got output to the console so another bar will be needed for separation.
    Write_Host '-----------------------------------------------------------------------------------------------------------------------' $ConsoleColors Gray $false

    # Cleanup all the junk.
    RemovePath $TempIshiiFolder
    RemovePath $TempGenFolder
  }
  # If it failed to be an Ishiiruka color texture.
  return $IshiiRepaired
}
#==============================================================================================================================================================================================
#  Sub function of ValidateTexture. Tests the extension of the texture to see if it is PNG, DDS, or JPG.

function ValidExtension([hashtable]$texdata)
{
  # Create an array with valid extensions.
  $ExtCheck = $PNG,$DDS,$JPG

  # Make sure the texture has a valid extension.
  if ($ExtCheck -contains $texdata.Extension)
  {
    # Yay a valid image file.
    return $true
  }
  # It's not an image or it has no extension.
  return $false
}
#==============================================================================================================================================================================================
#  Sub function of ValidateTexture. Tests an image for validity by reading its header.

function ValidImageHeader([hashtable]$texdata)
{
  # Get the image as a byte array.
  $ByteArray = [System.IO.File]::ReadAllBytes($texdata.FullPath)

  # Each file type will have a different header to compare to.
  if ($texdata.Extension -eq $PNG)
  {
    $HexHeader  = [System.BitConverter]::ToString($ByteArray[0..7])
    $HexCompare = '89-50-4E-47-0D-0A-1A-0A'
  }
  # I could eat fried chicken any day of the week.
  elseif ($texdata.Extension -eq $DDS)
  {
    $HexHeader  = [System.BitConverter]::ToString($ByteArray[0..7])
    $HexCompare = '44-44-53-20-7C-00-00-00'
  }
  # TODO: For now just force JPG to true until I come up with a solution.
  elseif ($texdata.Extension -eq $JPG)
  {
    return $true
  }
  # See if the header found matches the one to compare to.
  if ($HexHeader -eq $HexCompare)
  {
    # If it matches the texture is valid.
    return $true
  }
  # If the header is not valid, the texture is corrupt.
  CopyCorruptTexture $texdata
  return $false
}
#==============================================================================================================================================================================================
#  Sub function of ValidateTexture. Checks to see if the texture has a valid file name + extension. 

function ValidTextureName([hashtable]$texdata)
{
  # Check to see if it is a Dolphin texture.
  if ($texdata.DolphinFormat)
  {
    # Create an array with every type of material.
    $MatCheck = 'nrm','mat','bump','spec','lum'

    # See if the name contains material or mipmap identifiers.
    if (($MatCheck -contains $texdata.SplitPeriod[1]) -or ($texdata.Name -like '*_mip*'))
    {
      # The texture is a material or mipmap.
      return $false
    }
  }
  # It's not a Dolphin texture.
  else
  {
    # If AllowAllImages is enabled then force the texture to pass validation.
    return $AllowAllImages
  }
  # The file name and extension passes all validity checks.
  return $true
}
#==============================================================================================================================================================================================
#  Tests if a path/file is a valid texture when creating the Texture Hash Table, using partial data from the Texture Hash Table.
#  I don't really like multiple of the same returns, I'd rather check all conditions at once with a single return. But this way allows it to fail early so it's faster.

function ValidateTexture([hashtable]$texdata)
{
  # Make sure the texture has a valid extension.
  if (!(ValidExtension $texdata)) { return $false }

  # Validate the image header.
  if (!(ValidImageHeader $texdata)) { return $false }

  # Validate the name of the texture.
  if (!(ValidTextureName $texdata)) { return $false }

  # If the texture is DDS but does not have a material map.
  if (($texdata.Extension -eq $DDS) -and (!$texdata.HasMaterialMap))
  {
    # Perform a hidden "identify" check to check if it's an Ishiiruka color texture with a missing material map.
    & $IMIdentify $IM7Identify -format %[channels] $TexData.FullPath >$null 2>&1

    # If identify fails, $lastexitcode set by ImageMagick will be greater than 0.
    if ($lastexitcode -gt 0)
    {
      # Try to repair the DDS texture.
      if (!(MaterialMapTextureRepaired $texdata))
      {
        # If it failed it most likely really is corrupt.
        CopyCorruptTexture $texdata
        return $false
      }
    }
  }
  # If we made it this far it's a valid texture.
  return $true
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: IMAGE INFORMATION HASH TABLE
#==============================================================================================================================================================================================
#  Based on a function I found online to test an image for transparency. Discussion of my PowerShell conversion below: 
#  http://stackoverflow.com/questions/42153408/interopservices-marshal-copy-always-zero-in-powershell-script-converted-from-c-s

function IsAlphaBitMap([string]$imagepath)
{
  # Get the image as a Bitmap.
  $BitMap = [System.Drawing.BitMap]$imagepath

  # Check PixelFormat as a bit mask flag. 
  if (($BitMap.PixelFormat.value__ -band [System.Drawing.Imaging.PixelFormat]::Alpha) -eq 0) 
  {
    # If there is no alpha then leave now.
    return $false
  }
  # Get the pixel length so this can work on multiple types of images.
  # Only works on PS3+ >> $pixelBytes = [Drawing.Image]::GetPixelFormatSize($BitMap.PixelFormat) -shr 3
  $pixelBytes = [math]::Floor([System.Drawing.Image]::GetPixelFormatSize($BitMap.PixelFormat) * [math]::Pow(2,-3))

  # Do not support paletted images with less than 8bpp.
  if (!$pixelBytes) { return $false }

  # Convert the bitmap into BitmapData.
  $Rect    = New-Object Drawing.Rectangle(0, 0, $BitMap.Width, $BitMap.Height)
  $BmpData = [System.Drawing.Imaging.BitmapData]$BitMap.LockBits($Rect, [System.Drawing.Imaging.ImageLockMode]::ReadWrite, $BitMap.PixelFormat)

  # Create a Byte array to hold the image info.
  $Bytes = New-Object Byte[] ($BmpData.Height * $BmpData.Stride)

  # Copy all Bytes from the image into the Byte array.
  [System.Runtime.InteropServices.Marshal]::Copy($BmpData.Scan0, $Bytes, 0, $Bytes.Length)

  # Now that we're done with the image, dispose of the Bitmap so it doesn't get locked.
  $BitMap.Dispose()

  # Loop through each alpha Byte to see if there is transparency.
  for($p = $pixelBytes - 1 ; $p -lt $Bytes.Length ; $p += $pixelBytes)
  {
    # If the alpha Byte is not 255 the pixel contains transparency.
    if ($Bytes[$p] -ne 255)
    {
      # Return that the image has transparency.
      return $true
    }
  }
  # The image did not have any transparent pixels.
  return $false
}
#==============================================================================================================================================================================================
#  Gets various properties of an image file. (Width, Height, Gray, Alpha, Transparent)

function GetImageInfo([string]$imagepath, [bool]$ishiirukaDDS)
{
  # Create a hash table to store the dimensions.
  $ImageData = @{}

  # Extract the extension from the end of the image path.
  $Extension = $imagepath.Substring($imagepath.Length - 4, 4)

  # Read the image as a byte array.
  $ByteArray = [System.IO.File]::ReadAllBytes($imagepath)

  # Get the width/height of PNG images.
  if ($Extension -eq $PNG)
  {
    # Also convert the byte array into a readable string.
    $ArrayText = [System.Text.Encoding]::ASCII.GetString($ByteArray)

    # Read value 17-20 for width and 21-24 for height.
    $HexWidth  = ([System.BitConverter]::ToString($ByteArray[16..19])).Replace('-','')
    $HexHeight = ([System.BitConverter]::ToString($ByteArray[20..23])).Replace('-','')

    # Convert the hex value to decimal.
    $ImageData.Width  = [Convert]::ToInt32($HexWidth,16)
    $ImageData.Height = [Convert]::ToInt32($HexHeight,16)   

    # Read the color type from the header.
    $ColorType = [System.BitConverter]::ToString($ByteArray[25])

    # See if the texture has an alpha channel.
    switch($ColorType)
    {
      # If the color type is Gray or RGB, check for the tRNS chunk to see if it has 1-Bit Alpha.
      '00'  { $ImageData.Gray  = $true
              $ImageData.Alpha = ($ArrayText -like '*tRNS*')
            }
      '02'  { $ImageData.Gray  = $false
              $ImageData.Alpha = ($ArrayText -like '*tRNS*')
            }
      # If it's an indexed texture, search for the "tRNS" chunk to know if it has 1-Bit Alpha.
      '03'  { $ImageData.Gray  = $false
              $ImageData.Alpha = ($ArrayText -like '*tRNS*')
            }
      # If the color type is GrayA or RGBA, we don't know if there's transparency or not so test for it.
      '04'  { $ImageData.Gray  = $true
              $ImageData.Alpha = IsAlphaBitMap $imagepath
            }
      '06'  { $ImageData.Gray  = $false
              $ImageData.Alpha = IsAlphaBitMap $imagepath
            }
    }
  }
  # Get the width/height of DDS images.
  elseif ($Extension -eq $DDS)
  {
    # DDS headers are little endian they must be read backwards.
    $HexWidth  = ([System.BitConverter]::ToString($ByteArray[19..16])).Replace('-','')
    $HexHeight = ([System.BitConverter]::ToString($ByteArray[15..12])).Replace('-','')

    # Convert the hex value to decimal.
    $ImageData.Width  = [Convert]::ToInt32($HexWidth,16)
    $ImageData.Height = [Convert]::ToInt32($HexHeight,16)

    # Ishiiruka DDS color textures cannot be analyzed with ImageMagick.
    if (!$ishiirukaDDS)
    {
      # Determine whether or not there is transparency using ImageMagick.
      $ImageData.Gray  = $false
      $ImageData.Alpha = ((& $IMIdentify $IM7Identify -format %[opaque] $imagepath) -eq 'False')
    }
    # DDS Ishiiruka textures cannot be analyzed with ImageMagick.
    else
    {
      # Force these values to avoid errors. Ishiiruka textures do not make use of them (yet?).
      $ImageData.Gray  = $false
      $ImageData.Alpha = $true
    }
  }
  # For JPEG use .NET Framework since JPEG format is a fucking mess.
  elseif ($Extension -eq $JPG)
  {
    # Get the image as an object.
    $ImageObject = New-Object System.Drawing.Bitmap $imagepath

    # Get the dimensions.
    $ImageData.Width  = $ImageObject.Width
    $ImageData.Height = $ImageObject.Height

    # Force these values since they won't change (except maybe gray but I don't care enough).
    $ImageData.Gray  = $false
    $ImageData.Alpha = $false

    # Remove hook to the image.
    $ImageObject.Dispose()
  }
  # Return the image data.
  return $ImageData
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: MATERIAL MAP HASH TABLE
#==============================================================================================================================================================================================
#  Get various information about material maps.

function GetMaterialMapInfo([hashtable]$texdata)
{
  # Create and store the values using a hash table.
  $MatMapData = @{}

  # Store whether or not the color texture is one of those Ishiiruka textures.
  $MatMapData.ColorIsLum = ($texdata.Name -like '*_lum')

  # Whether or not it's a (_lum) texture decides on the base name to use.
  if ($MatMapData.ColorIsLum)
  {
    # Remove the '_lum' because material maps will not have it.
    $MatMapBase = $texdata.PathName.Substring(0, $texdata.PathName.Length - 4)
  }
  else
  {
    # Use just the base color texture path and name.
    $MatMapBase = $texdata.PathName
  }
  # Test to see if any combined material maps or materials exist.
  $mat_Exists  = (TestPath ($MatMapBase + '.mat' + $texdata.Extension))
  $nrm_Exists  = (TestPath ($MatMapBase + '.nrm' + $texdata.Extension))
  $bump_Exists = (TestPath ($MatMapBase + '.bump' + $PNG))
  $spec_Exists = (TestPath ($MatMapBase + '.spec' + $PNG))
  $lum_Exists  = (TestPath ($MatMapBase + '.lum' + $PNG))

  # Try to find a material map with ".mat" extension.
  if ($mat_Exists)
  {
    $MatMapData.HasMaterialMap = $true
    $MatMapData.MaterialMapType = '.mat'
  }
  # Test for the old "nrm" material map. It must exist alone without a bump, spec, and lum texture. 
  elseif (($nrm_Exists) -and (!$bump_Exists) -and (!$spec_Exists) -and (!$lum_Exists))
  {
    # This does not verify that it is not a "normal map", but it is a good approximation if other materials are not present.
    $MatMapData.HasMaterialMap = $true
    $MatMapData.MaterialMapType = '.nrm'
  }
  # Undefined variables read as "false".
  else
  {
    # But I like to define them anyway.
    $MatMapData.HasMaterialMap = $false
    $MatMapData.MaterialMapType = ''
  }
  # Set the path to the material map.
  $MatMapData.MaterialMapPath = ($MatMapBase + $MatMapData.MaterialMapType + $texdata.Extension)

  # Only build material maps from PNG. Fail if color texture is "_lum" type. Since "nrm" and "lum" textures are optional, only check for bump/spec.
  $MatMapData.HasMaterials = (($texdata.Extension -eq $PNG) -and (!$MatMapData.ColorIsLum) -and ($bump_Exists) -and ($spec_Exists))

  # Return the material map data.
  return $MatMapData
}
#==============================================================================================================================================================================================
#  DOCUMENTATION: TEXTURE HASH TABLE
#==============================================================================================================================================================================================
#  When a texture is ran through the main loop, a global hash table is created for the current texture. 
#  Many of this script's functions rely on this data and are designed around having this data readily available. 
#  Each iteration of the loop creates a new hash table for the current texture and discards the data from the last one.
#  Below is a list of all information that can be retrieved when a hash table for the current texture has been created.
#
#  $Texture.Name                 - string    -  The name of the texture without the extension.
#  $Texture.FullName             - string    -  The name of the texture with the file extension.
#  $Texture.Extension            - string    -  The file extension of the texture file.
#  $Texture.Folder               - string    -  The name of the folder that the current texture is located in.
#  $Texture.Path                 - string    -  The path to where the texture is currently located, minus the texture name.
#  $Texture.PathName             - string    -  The full path to the texture including the texture name without the file extension.
#  $Texture.FullPath             - string    -  The full path to the texture including the texture name with the file extension.
#  $Texture.Relative             - string    -  The relative path to the texture, which is the Path minus the MasterInputPath (location of the script).
#  $Texture.SplitName[#]*        - string    -  Splits the texture name using the locations of underscores to detect "tex1", dimensions, "m" for MipMap, or "mip_#" for MipMap level.
#  $Texture.SplitPeriod[#]       - string    -  Splits the texture name using the locations of periods to test for Dolphin dupes or Ishiiruka bump/spec/lum/nrm textures.
#  $Texture.DolphinFormat        - boolean   -  Stores true or false whether or not the texture is in Dolphin's texture format (starts with "tex1").
#  $Texture.Size                 - integer   -  The file size of the texture in Bytes.
#  $Texture.Width                - integer   -  The width of the custom texture.
#  $Texture.Height               - integer   -  The height of the custom texture.
#  $Texture.Aspect               - decimal   -  The aspect of the custom texture (Width/Height)
#  $Texture.Dimensions           - string    -  The full dimensions of the custom texture in the form of (Width x Height).
#  $Texture.OldWidth             - integer   -  The width of the original texture.
#  $Texture.OldHeight            - integer   -  The height of the original texture.
#  $Texture.OldAspect            - decimal   -  The aspect of the original texture (OldWidth/OldHeight)
#  $Texture.OldDimensions        - string    -  The full dimensions of the original texture in the form of (OldWidth x OldHeight).
#  $Texture.ScaleWidth           - decimal   -  The width scale of the custom texture (Width/OldWidth).
#  $Texture.ScaleHeight          - decimal   -  The height scale of the custom texture (Height/OldHeight).
#  $Texture.Scale                - string    -  The full scale of the texture in the form of (ScaleWidth x ScaleHeight).
#  $Texture.IsMipMap             - boolean   -  Stores true or false of whether or not the texture is a MipMap texture.
#  $Texture.IsGrayScale          - boolean   -  Stores true or false of whether or not the texture is a grayscale texture.
#  $Texture.HasTransparency      - boolean   -  Stores true or false of whether or not the texture has any transparent pixels.
#  $Texture.HasMaterialMap       - boolean   -  Stores true or false of whether or not the texture has a supplied material map (nrm) texture.
#  $Texture.ColorIsLum           - boolean   -  Stores whether or not the color texture has the Ishiiruka (_lum) suffix.
#  $Texture.MaterialMapPath      - string    -  The full path to the texture's supplied material map.
#  $Texture.HasMaterials         - boolean   -  Stores true or false of whether or not the texture has supplied materials (bump/spec/lum/nrm) textures.
#  $Texture.MaterialMapType      - string    -  If the texture has a material map store the file extension.
#  $Texture.DDSCompression       - string    -  If the texture is to be converted to DDS, stores the compression type. DXT1-Opaque, DXT5-Transparency
#  $Texture.DDSQualityLevel      - string    -  If the texture is to be converted to DDS, stores which quality level to feed DDS Utilities.
#
#  * SplitName[0-6] is the texture name broken up into 7 sections to pull data from based on the location of underscores. A list of this data can be found below. 
#
#  SplitName[0]
#  - [tex1]       - Useful. Used for texture validation to check if the file is in the correct texture format. Ignored with "AllowAllImages".
#  SplitName[1]
#  - [dimensions] - Useful. Allows pulling the width and height of the original texture from the texture name.
#  SplitName[2]
#  - [m]          - Useful. Allows checking if it is a MipMap texture.
#  - [hash]       - Useless. Will hold the texture hash value if the texture is not a MipMap. This script does not need to know anything about the hash.
#  SplitName[3]
#  - [format]     - Useless. If it is a standard texture, it will hold the texture format which this script does not need to know.
#  - [hash]       - Useless. Will hold the texture hash value if the texture is a MipMap texture. This script does not need to know anything about the hash.
#  - [2nd hash]   - Useless. If the texture is a paletted texture, this value will hold the second hash.
#  SplitName[4]
#  - [format]     - Useless. If it is a MipMap or paletted texture, it will hold the texture format which this script does not need to know.
#  - [2nd hash]   - Useless/Rare. If the texture is a paletted MipMap texture, this value will hold the second hash.
#  SplitName[5]
#  - [mip_#]      - Useful. If it is a MipMap texture and a lower MipMap level, this value will hold the level.
#  - [format]     - Useless/Rare. If it is a paletted MipMap texture, it will hold the texture format.
#  SplitName[6]
#  - [mip_#]      - Useful/Rare. If it is a paletted MipMap texture, this value will hold the level.
#
#  SplitName[3/4] are completely useless to this script, as those sections of the texture name will never hold data that the script needs.
#==============================================================================================================================================================================================
#  TEXTURE CREATION: TEXTURE HASH TABLE
#==============================================================================================================================================================================================
# The global texture hash table that is created every iteration of the main loop.

function CreateTextureInfo($file)
{
  # Initialize the texture hash table.
  $TexData = @{}

  # Get the path to the texture.
  $TexData.Path = [string]$file.Directory

  # To greatly speed up skipping generated folders with lots of files, immediately fail if a ~ is found.
  if ($TexData.Path -like '*~*') {return $null}

  # Create strings referencing texture name/path data.
  $TexData.Name      = $file.BaseName
  $TexData.FullName  = $file.Name
  $TexData.Extension = $file.Extension
  $TexData.Folder    = (Get-Item -LiteralPath $MasterInputPath).Name
  $TexData.PathName  = $TexData.Path + '\' + $TexData.Name
  $TexData.FullPath  = $TexData.Path + '\' + $TexData.FullName
  $TexData.Relative  = $TexData.Path.Replace($MasterInputPath,'')

  # Splits the texture name into up to 7 parts based on the underscores. This allows pulling individual information from the texture name.
  $TexData.SplitName = $TexData.Name.Split('_',7)

  # Splits the texture name into 2 parts based on any periods found to identify bump/spec/lum/nrm or Dolphin dupes.
  $TexData.SplitPeriod = $TexData.Name.Split('.',2)

  # Stores if the current texture is in the format Dolphin uses.
  $TexData.DolphinFormat = ($TexData.SplitName[0] -eq 'tex1')

  # Get all the various material map information from a hash table.
  $MatMapInfo = GetMaterialMapInfo $TexData

  # Copy all data from the MatMapInfo hash table into the TexData hash table.
  $TexData.HasMaterials    = $MatMapInfo.HasMaterials
  $TexData.HasMaterialMap  = $MatMapInfo.HasMaterialMap
  $TexData.MaterialMapPath = $MatMapInfo.MaterialMapPath
  $TexData.MaterialMapType = $MatMapInfo.MaterialMapType
  $TexData.ColorIsLum      = $MatMapInfo.ColorIsLum

  # Test the texture for validity (corruption, errors, not an image, etc). If it fails, return null.
  if (!(ValidateTexture $TexData)) {return $null}

  # If the texture was successfully validated, set the texture size in Bytes.
  $TexData.Size = ($file | Measure-Object -Property 'length' -Sum).Sum

  # Check for "m" to see if it is a MipMap texture.
  $TexData.IsMipMap = ($TexData.SplitName[2] -eq 'm')

  # Get the details of the texture as a hash table that contains stuff like dimensions, alpha, transparency, and grayscale.
  $ImageInfo = GetImageInfo $TexData.FullPath $TexData.HasMaterialMap

  # Get the custom texture width, height, combined dimensions, and aspect.
  $TexData.Width      = $ImageInfo.Width
  $TexData.Height     = $ImageInfo.Height
  $TexData.Dimensions = $TexData.Width.ToString() + 'x' + $TexData.Height.ToString()
  $TexData.Aspect     = [decimal](FormatDecimal ($TexData.Width/$TexData.Height))

  # Get whether or not the custom texture is grayscale, has an alpha channel, and actually contains transparent pixels.
  $TexData.IsGrayScale     = $ImageInfo.Gray
  $TexData.HasTransparency = $ImageInfo.Alpha

  # If it's a Dolphin texture (meaning the name starts with "tex1"), the original dimensions can be retrieved from the name.
  if ($TexData.DolphinFormat)
  {
    # Get the original texture width/height by further splitting SplitName[1] by the "x".
    $OldDimensions         = $TexData.SplitName[1].Split('x',2)
    $TexData.OldWidth      = [int]$OldDimensions[0]
    $TexData.OldHeight     = [int]$OldDimensions[1]
    $TexData.OldDimensions = $TexData.OldWidth.ToString() + 'x' + $TexData.OldHeight.ToString()
    $TexData.OldAspect     = [decimal](FormatDecimal ($TexData.OldWidth/$TexData.OldHeight))
  }
  # If not a Dolphin texture (meaning "AllowAllImages" is enabled), the original dimensions can't be retrieved.
  else
  {
    # Set the "original" dimensions to the texture's "current" dimensions.
    $TexData.OldWidth      = $TexData.Width
    $TexData.OldHeight     = $TexData.Height
    $TexData.OldDimensions = $TexData.Dimensions
    $TexData.OldAspect     = $TexData.Aspect
  }
  # Calculate the custom texture scaling compared to the original texture.
  $TexData.ScaleWidth  = [decimal](FormatDecimal ($TexData.Width/$TexData.OldWidth))
  $TexData.ScaleHeight = [decimal](FormatDecimal ($TexData.Height/$TexData.OldHeight))
  $TexData.Scale       = ($TexData.ScaleWidth.ToString() + 'x' + $TexData.ScaleHeight.ToString())

  # If the texture has transparency or the user forced DXT5, set the compression type to DXT5.
  if (($TexData.HasTransparency) -or ($DDSForceDXT5))
  {
    # These values are fed into DDS Utilities. Highest quality works fine for DXT5.
    $TexData.DDSCompression  = 'DXT5'
    $TexData.DDSQualityLevel = '-quality_highest'
  }
  # If texture does not have transparency, set the compression type to DXT1.
  else
  {
    # If we're using DXT1, normal quality must be forced to avoid pixel corruption.
    $TexData.DDSCompression  = 'DXT1'
    $TexData.DDSQualityLevel = '-quality_normal'
  }
  # Return the texture data so it can be set to a global and used basically everywhere in the script.
  return $TexData
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: DDS DIMENSION CALCULATIONS
#==============================================================================================================================================================================================
#  Sub-function for DDSMultFour to find the nearest multiple of four for a dimension. Also used in MipMap calculations when finding levels and calculating dimensions.

function FindMultFour([int]$inputvalue)
{
  # If the input dimension is 1 or 2 then return that value (allows 1x1,1x2,2x1,2x2 DDS mipmaps).
  if (($inputvalue -eq 1) -or ($inputvalue -eq 2))
  {
    # For some reason DDS Utilities can create textures 1-2 pixels tall or wide which is nice because it allows flooring mipmaps properly to 1x1.
    return $inputvalue
  }
  # Use a modulus of 4 to check for a remainder. A remainder means it was not a multiple of four.
  $tempvalue = $inputvalue % 4

  # We shall count the number of loop iterations. This value will be the amount to add to find a multiple of four.
  $iterations = 0

  # Loop until there is no remainder. Loop is skipped if there wasn't.
  while($tempvalue -ne 0)
  {
    # Add to the number of iterations.
    $iterations ++

    # Add the iterations to the input value and repeat search for remainder.
    $tempvalue = (($inputvalue + $iterations) % 4)
  }
  # Add the total number of loop iterations to the input value which will result in a multiple of four!
  $inputvalue += $iterations

  # Return the new value.
  return $inputvalue
}
#==============================================================================================================================================================================================
#  To use, set "DDSMultFour" as a hashtable variable. This tests if the input dimensions are a multiple of four, and returns a hash table that
#  supplies the corrected Width and Height and the combined dimensions. Data is retrieved with "Var.Width" "Var.Height" or "Var.Dimensions".

function DDSMultFour([int]$inputwidth, [int]$inputheight)
{
  # Create and store the values using a hash table.
  $DDSData = @{}
  $DDSData.Width  = FindMultFour $inputwidth
  $DDSData.Height = FindMultFour $inputheight
  $DDSData.Dimensions = $DDSData.Width.ToString() + 'x' + $DDSData.Height.ToString()

  # Return the hash table data.
  return $DDSData
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: MIPMAP FUNCTIONS
#==============================================================================================================================================================================================
#  Calculates how many MipMap levels a texture should have based on the input dimension.

function CalculateMipMapLevels([int]$dimension, [string]$format)
{
  # Continue to divide the width or height by 2 until 1 (or lower) is hit.
  while($dimension -gt 1)
  {
    # Check if we're doing calculations for a DDS texture.
    if ($format -eq $DDS)
    {
      # Find the nearest multiple of 4 of the current dimension.
      $dimension = FindMultFour $dimension
    }
    # Perform the calculation as a decimal to remain as accurate as possible.
    $HalvedDimension = [decimal]($dimension / 2)

    # Divide the dimension in half, and fix the decimal for other regions.
    $NewDimension = FormatDecimal $HalvedDimension

    # Split the value so the decimal can be dropped (and not rounded).
    $NewDimensionSplit = $NewDimension.Split('.',2)

    # Keep only the integer value for the next iteration.
    $dimension = [int]$NewDimensionSplit[0]

    # Increment the number of levels.
    $Levels ++
  }
  # Return the number of levels calculated.
  return $Levels
}
#==============================================================================================================================================================================================
#  Loop to calculate a single dimension of a MipMap based on the MipMap's current level.

function CalculateMipMapDimension([int]$level, [int]$dimension, [string]$format)
{
  # Continue the loop until the loop iteration reaches the MipMap level.
  for($i=1; $i -le $level; $i++)
  {
    # Make sure the dimension is not less than or equal to 1. Less than 1 shouldn't ever happen, but just in case.
    if ($dimension -gt 1)
    {
      # Check if we're doing calculations for a DDS texture.
      if ($format -eq $DDS)
      {
        # Find the nearest multiple of 4 of the current dimension.
        $dimension = FindMultFour $dimension
      }
      # Perform the calculation as a decimal to remain as accurate as possible.
      $HalvedDimension = [decimal]($dimension / 2)

      # Divide the dimension in half, and fix the decimal for other regions.
      $NewDimension = FormatDecimal $HalvedDimension

      # Split the value so the decimal can be dropped (and not rounded).
      $NewDimensionSplit = $NewDimension.Split('.',2)

      # Keep only the integer value for the next iteration.
      $dimension = [int]$NewDimensionSplit[0]
    }
  }
  # Return the calculated dimension.
  return $dimension
}
#==============================================================================================================================================================================================
#  Extracts all internal mipmaps from a DDS texture into the output path. Also works on Ishiiruka DDS textures and material maps.

function ExtractInternalDDSMipMaps([string]$texturepath, [string]$outputpath)
{
  # Set up data for the texture.
  $TextureObject     = Get-ChildItem -LiteralPath $texturepath
  $TextureName       = $TextureObject.BaseName
  $TextureFullName   = $TextureObject.Name
  $TextureSplit      = $TextureName.Split('.',2)
  $TextureIsMaterial = (($TextureSplit[1] -eq 'nrm') -or ($TextureSplit[1] -eq 'mat'))
  $DetachPathBase    = CreatePath ($TempFolder + '\DetachedTextures')
  $DetachTexture     = $DetachPathBase + '\' + $TextureName

  # Create a copy of the texture to extract mipmaps from.
  Copy-Item -LiteralPath $texturepath -Destination $DetachPathBase -Force

  # Extract Internal MipMaps from the texture.
  & $NDETACH $DetachTexture

  # Remove the generated "log.wri" created by nvidia detach and the copied texture.
  RemovePath ($BaseFolder + '\log.wri')
  RemovePath ($DetachTexture + $DDS)

  # Count the number of files that remain in the folder.
  $CountTextures = (Get-ChildItem -LiteralPath $DetachPathBase | Where-Object {!$_.PSIsContainer} | Measure-Object).Count

  # Check to see if mipmaps were extracted. The top level will always be present, so at least 2 textures must exist.
  if ($CountTextures -gt 1)
  {
    # Loop through all files within the folder.
    for($i=0; $i -lt $CountTextures; $i++)
    {
      # Get the current level as a string and in double digits.
      $Level = IntToStringDoubleDigit $i

      # Create a variable to reference the current mipmap in the loop.
      $CurrentMipMap = $DetachPathBase + '\' + $TextureName + '_' + $Level + $DDS

      # If were on the top level, a name without the "mip" suffix must be used.
      if ($i -eq 0)
      {
        # Note that nothing special needs to be done for a material map. The (.mat/.nrm) part of it will be included in $TextureFullName.
        $NewMipMapName = $DetachPathBase + '\' + $TextureFullName
      }
      # If were on a lower mipmap level.
      else
      {
        # If it's a material map lower mipmap level, add the appropriate suffix.
        if ($TextureIsMaterial)
        {
          # Use the split texture name. [0] will contain the name only, [1] will contain (.mat/.nrm). 
          $NewMipMapName = $DetachPathBase + '\' + $TextureSplit[0] + '_mip' + $i + '.' + $TextureSplit[1] + $DDS
        }
        # It's just a regular lower mipmap level and not a material map.
        else
        {
          # Simply add the mip suffix + the level.
          $NewMipMapName = $DetachPathBase + '\' + $TextureName + '_mip' + $i + $DDS
        }
      }
      # Rename the current mipmap to the new name.
      Move-Item -LiteralPath $CurrentMipMap -Destination $NewMipMapName -Force
    }
  }
  # Loop through all mipmaps in the temporary path.
  foreach($MipMapFile in Get-ChildItem -LiteralPath $DetachPathBase)
  {
    # Move all mipmaps to the current texture path.
    $MovePath = [string]$MipMapFile.Directory + '\' + $MipMapFile.Name
    Move-Item -LiteralPath $MovePath -Destination $outputpath -Force
  }
  # Cleanup the temp folder.
  RemovePath $DetachPathBase
}
#==============================================================================================================================================================================================
#  DOCUMENTATION: MIPMAP HASH TABLE
#==============================================================================================================================================================================================
#  Creates MipMap information based on the input dimensions and the texture currently stored in the global hash table.
#  Only the name/path information is pulled from the texture hash table, the rest of the information is dynamically created from the input dimensions.
#
#  The number of mipmaps [#] in the array is determined by the number of $MipMap.Levels.
#
#  $MipMap.Levels             - integer -  The number of levels calculated from the input dimensions. Also defines the size of the MipMap array.
#  $MipMap.Name[#]*           - string  -  The name of the MipMap without the extension. 
#  $MipMap.FullName[#]*       - string  -  The name of the MipMap with the file extension.
#  $MipMap.FullPath[#]*       - string  -  The full path to the MipMap including the MipMap + file extension.
#  $MipMap.Size[#]*           - integer -  The file size of the MipMap in Bytes. Currently unused in any functions.
#  $MipMap.Width[#]           - string  -  The calculated width of the MipMap based on the input dimensions.
#  $MipMap.Height[#]          - string  -  The calculated height of the MipMap based on the input dimensions.
#  $MipMap.Dimensions[#]      - string  -  The calculated full dimensions of the MipMap in the form of Width x Height.
#  $MipMap.Exists[#]*         - boolean -  Notifies whether or not the mipmap actually exists. 
#  $MipMap.RealWidth[#]*      - string  -  The actual width of the MipMap if it exists.
#  $MipMap.RealHeight[#]*     - string  -  The actual height of the MipMap if it exists.
#  $MipMap.RealDimensions[#]* - string  -  The actual full dimensions of the MipMap in the form of Width x Height.
#  $MipMap.LevelsCounted*     - integer -  The number of MipMap levels found based on the name of the current texture.
#  $MipMap.LevelsMissing*     - integer -  The number of MipMap levels that are missing based on the name of the current texture.
#  $MipMap.BadDimensions*     - integer -  The number of MipMap levels where "Dimensions" don't match up with "RealDimensions"
#
#  * This data is created based on the current texture hash table. All other information is derived from the input dimensions.
#==============================================================================================================================================================================================
#  TEXTURE CREATION: MIPMAP HASH TABLE
#==============================================================================================================================================================================================
#  Unlike the texture hash table, the MipMap hash table is not global. This allows it to be much more dynamic, in that it can be 
#  created multiple times during a single loop iteration. This allows multiple hash tables to contain separate data from each other.

function CreateMipMapInfo([hashtable]$texdata, [int]$inputwidth, [int]$inputheight, [string]$format)
{
  # Initialize the MipMap hash table.
  $MipMapData = @{}

  # Find the largest dimension between the width and height.
  $LargestDimension = [math]::max($inputwidth, $inputheight)

  # Store how many MipMap levels the texture should have based on the largest dimension.
  $MipMapData.Levels = CalculateMipMapLevels $LargestDimension $format

  # For now assume there are no mipmaps present, and none are missing (sounds like a catch 22).
  $MipMapData.LevelsCounted = 0
  $MipMapData.LevelsMissing = 0

  # Initialize an array to store information about each individual MipMap. ArraySize must be (+1) to start with index[1] instead of [0].
  $ArraySize = ($MipMapData.Levels + 1)
  $MipMapData.Name           = New-Object string[] $ArraySize
  $MipMapData.FullName       = New-Object string[] $ArraySize
  $MipMapData.FullPath       = New-Object string[] $ArraySize
  $MipMapData.Width          = New-Object int[]    $ArraySize
  $MipMapData.Height         = New-Object int[]    $ArraySize
  $MipMapData.Dimensions     = New-Object string[] $ArraySize
  $MipMapData.Exists         = New-Object bool[]   $ArraySize
  $MipMapData.RealWidth      = New-Object int[]    $ArraySize
  $MipMapData.RealHeight     = New-Object int[]    $ArraySize
  $MipMapData.RealDimensions = New-Object string[] $ArraySize
  $MipMapData.Size           = New-Object int[]    $ArraySize

  # Store information about each MipMap. Start with index [1] instead of [0] for simplicity.
  # Example: "mipmap.Variable[3]" will reference "tex1_128x128_m_e3487d3b2a9d3e11_14_mip3"
  for($i=1; $i -le $MipMapData.Levels; $i++)
  {
    # Set up basic information about MipMap.
    $MipMapData.Name[$i]       = $texdata.Name + '_mip' + $i
    $MipMapData.FullName[$i]   = $texdata.Name + '_mip' + $i + $texdata.Extension
    $MipMapData.FullPath[$i]   = $texdata.PathName + '_mip' + $i + $texdata.Extension
    $MipMapData.Width[$i]      = CalculateMipMapDimension $i $inputwidth $format
    $MipMapData.Height[$i]     = CalculateMipMapDimension $i $inputheight $format
    $MipMapData.Dimensions[$i] = [string]$MipMapData.Width[$i] + 'x' + [string]$MipMapData.Height[$i]

    # Check to see if the MipMap exists.
    if (TestPath $MipMapData.FullPath[$i]) 
    {
      # Store that the MipMap exists.
      $MipMapData.Exists[$i] = $true

      # Add the current MipMap to the number of mipmaps found.
      $MipMapData.LevelsCounted ++

      # Get the MipMap as an object file to set the file size of the MipMap in Bytes.
      $mipobject = Get-ChildItem -LiteralPath $MipMapData.FullPath[$i]
      $MipMapData.Size[$i] = ($mipobject | Measure-Object -Property 'length' -Sum).Sum

      # Get the dimensions of the texture as a hash table.
      $MipDimensions = GetImageInfo $MipMapData.FullPath[$i] $false

      # Get the dimensions of the MipMap file.
      $MipMapData.RealWidth[$i]      = $MipDimensions.Width
      $MipMapData.RealHeight[$i]     = $MipDimensions.Height
      $MipMapData.RealDimensions[$i] = [string]$MipMapData.RealWidth[$i] + 'x' + [string]$MipMapData.RealHeight[$i]

      # Compare the calculated dimensions with the real dimensions and count the number that don't match up.
      if ($MipMapData.Dimensions[$i] -ne $MipMapData.RealDimensions[$i])
      {
        # This is only used when scanning textures for issues in function "CheckMipMapsScale".
        $MipMapData.BadDimensions ++
      }
    }
    # If the mipmap does not exist, count the number of mipmaps missing.
    else
    {
      # The number of missing levels is only used when scanning textures for issues in function "CheckMissingMipMaps".
      $MipMapData.Exists[$i] = $false
      $MipMapData.LevelsMissing ++
    }
  }
  # Return the MipMap data so it can be set to a variable.
  return $MipMapData
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: MIPMAP HASH TABLE - GETTING THE PROPER MIPMAP HASH TABLE
#==============================================================================================================================================================================================
#  Extends the functionality of "CreateMipMapInfo". The priority for the created hash table goes to a DDS texture with internal mipmaps. The internal mipmaps are extracted and stored in a 
#  temporary folder. These mipmaps must be manually cleaned when no longer needed (below function)! If no internal mipmaps exist, then create mipmap info from the base texture. This method 
#  rarely needs to be done, only when internals must be referenced for whatever reason. As of now there are only 2 places in the script that use it, and that is when textures are created.

function CreateMipMapInfoPlus([hashtable]$texdata, [int]$inputwidth, [int]$inputheight, [string]$format)
{
  # If the custom texture is a DDS texture with internal mipmaps, prefer these over all other mipmaps as a base.
  if ((TestPath $NDETACH) -and ($texdata.Extension -eq $DDS))
  {
    # Create a folder to extract internal MipMaps to.
    $DDSExtractedMipMapPath = CreatePath ($TempFolder + '\ExternalDDSMipMaps\')

    # Extract MipMaps from the texture to see if it has internal MipMaps.
    ExtractInternalDDSMipMaps $texdata.FullPath $DDSExtractedMipMapPath

    # Count the number of files that remain in the folder, and subtract 1 to compensate for the top level.
    $DDSLevelsCounted = ((Get-ChildItem -LiteralPath $DDSExtractedMipMapPath | Where-Object {!$_.PSIsContainer} | Measure-Object).Count) - 1

    # Check to see if there are actually any internal mipmaps to be found.
    if ($DDSLevelsCounted -gt 0)
    {
      # Mipmaps were found so create an entirely new texture hash table based on the temporary texture + mipmaps.
      $NewDDSTextureFile = $DDSExtractedMipMapPath + $texdata.FullName
      $NewDDSTextureInfo = CreateTextureInfo (Get-ChildItem -LiteralPath $NewDDSTextureFile)

      # Create a mipmap hash table based on the temporary texture.
      return (CreateMipMapInfo $NewDDSTextureInfo $inputwidth $inputheight $format)
    }
  }
  # If it's not a DDS texture or DDS Utilities was not found, simply create a hash table from the current texture.
  return (CreateMipMapInfo $texdata $inputwidth $inputheight $format)
}
#==============================================================================================================================================================================================
#  Cleans out any temporary DDS mipmaps that were extracted with the above function.

function DestroyMipMapInfoPlus()
{
  RemovePath ($TempFolder + '\ExternalDDSMipMaps\')
}
#==============================================================================================================================================================================================
#  DOCUMENTATION: TEXTURE CREATION FUNCTIONS
#==============================================================================================================================================================================================
#  There are a lot of texture creation functions, and all of them link back to a single function. The master function is "CreateTexture". The texture hash table it takes is created from the
#  function "CreateTextureInfo". This allows it to take any texture hash table created with "CreateTextureInfo" rather than confine it to the global hash table "$Texture" which is created in
#  the "MasterLoop" function. Input Width/Height serve as modifiers to the output dimensions. The Format parameter overrides the output format. The Output Path basically explains itself.
#
#  * CreateTexture [hashtable]Texture [int]InputWidth [int]InputHeight [string]Format [string]OutputPath
#
#  Contained within "CreateTexture" is a function that has a common specific use. This function is "CreateStandardTexture", and it can be used when all attributes of the input texture and
#  and resulting texture have nothing to do with Ishiiruka Textures. It ignores material maps, so material map textures will be skipped. It cannot handle DDS color textures created by
#  by Ishiiruka Tool. There are specific functions for handling Ishiiruka Textures, in those cases "CreateTexture" will automatically handle when to use them.
#
#  * CreateStandardTexture [hashtable]Texture [int]InputWidth [int]InputHeight [string]Format [string]OutputPath
#  
#  There are three Material Map functions that can be called in "CreateTexture". Any of these can be called externally from CreateTexture to fit a specific situation relating to materials. 
#  Function "CreateMaterialMap_FromMaterial" creates a new material map from an existing material map. Dimensions and Format serve as modifiers to the resulting texture.
#  Function "CreateMaterialMap_FromTextures" creates a new material map from bump/spec/nrm/lum textures. Dimensions and Format serve as modifiers to the resulting texture.
#  Function "ConvertMaterialMap_DolphinFormat" converts textures created with Ishiiruka Tool, into a texture created from ImageMagick. Material maps are not created.
#  
#  * CreateMaterialMap_FromMaterial   [hashtable]Texture [int]InputWidth [int]InputHeight [string]Format [string]OutputPath
#  * CreateMaterialMap_FromTextures   [hashtable]Texture [int]InputWidth [int]InputHeight [string]Format [string]OutputPath
#  * ConvertMaterialMap_DolphinFormat [hashtable]Texture [int]InputWidth [int]InputHeight [string]Format [string]OutputPath
#  
#  All other texture creation functions from this section of the script should probably not be called directly as their purpose is to directly support the above functions.
#==============================================================================================================================================================================================
#  TEXTURE CREATION: PNG INFO HASH TABLE
#==============================================================================================================================================================================================
#  Returns the color type based on the input image so ImageMagick knows what kind of image to create.

function CreatePNGData([hashtable]$texdata)
{
  # I do love me some hash tables.
  $PNGData = @{}

  # Check to see if it is a grayscale texture.
  if ($texdata.IsGrayScale)
  {
    # Check to see if the texture has transparency.
    if ($texdata.HasTransparency)
    {
      $PNGData.ColorType  = '4'
      $PNGData.ColorSpace = 'GrayA'
      $PNGData.BitDepth   = '16'
    }
    # Texture does not have transparency.
    else
    {
      $PNGData.ColorType  = '0'
      $PNGData.ColorSpace = 'Gray'
      $PNGData.BitDepth   = '8'
    }
  }
  # It actually has color info.
  else
  {
    # Check to see if the texture has transparency.
    if ($texdata.HasTransparency)
    {
      $PNGData.ColorType  = '6'
      $PNGData.ColorSpace = 'RGBA'
      $PNGData.BitDepth   = '32'
    }
    # Texture does not have transparency.
    else
    {
      $PNGData.ColorType  = '2'
      $PNGData.ColorSpace = 'RGB'
      $PNGData.BitDepth   = '24'
    }
  }
  return $PNGData
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: PNG/JPG
#==============================================================================================================================================================================================
#  Sub-function of "CreateStandardTexture" to create mipmaps for PNG or JPG textures.

function CreatePNGMipMaps([hashtable]$texdata, [int]$inputwidth, [int]$inputheight, [string]$format, [string]$outputpath)
{
  # Create a mipmap hash table.
  $MipMap = CreateMipMapInfoPlus $texdata $inputwidth $inputheight $format

  # Loop through all levels.
  for($i=1; $i -le $MipMap.Levels; $i++)
  {
    # Set where to create the new MipMap.
    $MipMapOutputPath = $outputpath + '\' + $MipMap.Name[$i] + $format

    # Check if the user forced new MipMaps through the internal options, chose the advanced function to force new mipmaps from the main menu, or if the MipMap does not exist.
    if ((!$MipMap.Exists[$i]) -or ($ForceNewMipMaps))
    {
      # If the MipMap did not exist or the user forced new mipmaps, create it from the top layer with sharpening.
      & $IMConvert -quiet $texdata.FullPath -resize ($MipMap.Dimensions[$i] + '!') $Define $ColorType -sharpen '0x0.50' $MipMapOutputPath
    }
    # Check to see if the calculated dimensions match the real dimensions.
    elseif ($MipMap.Dimensions[$i] -eq $MipMap.RealDimensions[$i])
    {
      # Create the MipMap from the existing MipMap without sharpening.
      & $IMConvert -quiet $MipMap.FullPath[$i] -resize ($MipMap.Dimensions[$i] + '!') $Define $ColorType $MipMapOutputPath
    }
    # If the MipMap exists, but the dimensions changed.
    else
    {
      # Create the MipMap from the existing MipMap with slight sharpening.
      & $IMConvert -quiet $MipMap.FullPath[$i] -resize ($MipMap.Dimensions[$i] + '!') $Define $ColorType -sharpen '0x0.25' $MipMapOutputPath
    }
  }
  # Destroy the folder with internal mipmaps if it exists.
  DestroyMipMapInfoPlus
}
#==============================================================================================================================================================================================
#  Sub-function of "CreateStandardTexture" to create a PNG or JPG texture.

function CreatePNGTexture([hashtable]$texdata, [int]$inputwidth, [int]$inputheight, [string]$format, [string]$outputpath)
{
  # The full path to where the new texture will be created.
  $OutputTexture = $outputpath + '\' + $texdata.Name + $format

  # Combine the new dimensions into a single value.
  $NewDimensions = $inputwidth.ToString() + 'x' + $inputheight.ToString()

  # Enable sharpening for texture only if 'ForceIntScaling' is true.
  if ($MasterOperation -eq 'ForceIntScaling')
  {
    $SharpenStrength = '0x0.50'
  }
  else
  {
    $SharpenStrength = '0x0.00'
  }
  # If creating a PNG, force the PNG type and color depth.
  if ($format -eq $PNG)
  {
    $PNGData   = CreatePNGData $texdata
    $Define    = '-define'
    $ColorType = 'png:color-type=' + $PNGData.ColorType
  }
  # If creating JPG (which nobody cares about) then do not send extra parameters to ImageMagick.
  else
  {
    $Define = $ColorType = ''
  }
  # Create the new image by feeding ImageMagick all the crap that's needed.
  & $IMConvert -quiet $texdata.FullPath -resize ($NewDimensions + '!') $Define $ColorType -sharpen $SharpenStrength $OutputTexture

  # Check if it is a MipMap texture.
  if ($texdata.IsMipMap)
  {
    # If it is, then generate MipMaps.
    CreatePNGMipMaps $texdata $inputwidth $inputheight $format $outputpath
  }
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: DDS - These functions are not meant to be called directly, instead use CreateStandardTexture which is what links to these functions.
#==============================================================================================================================================================================================
#  Sub-function of "CreateDDSTexture" functions which creates an image using either DDS Utilities or ImageMagick depending on what the script selects.

function CreateDDSWithOptimalTool([hashtable]$texdata, [bool]$nvidia, [string]$inputimage, [string]$inputdimensions, [string]$mipmaplevels, [string]$outputimage)
{
  # Convert the compression type to a usable format (dxt1/dxt5). I don't know if ImageMagick or DDS Utilities is case sensitive, but just in case.
  $DXT = $texdata.DDSCompression.ToLower()

  # This method uses nvidia tools "nvdxt.exe" to create the image.
  if ($nvidia)
  {
    # I can't think of a good way to not make mipmap detection a conditional situation so fuck it.
    if ($mipmaplevels -ne '0')
    {
      # DDS considers the top level (base texture) a mipmap so add +1 to the number of mipmaps.
      & $NVDXT -file $inputimage $texdata.DDSQualityLevel -nmips ([int]$mipmaplevels + 1) ('-' + $DXT) -output $outputimage | Out-Null
    }
    else
    {
      # If it's not a mipmap texture force disable mipmaps.
      & $NVDXT -file $inputimage $texdata.DDSQualityLevel -nomipmap ('-' + $DXT) -output $outputimage | Out-Null
    }
  }
  # This method uses ImageMagick "convert.exe" or "magick.exe" to create the image.
  else
  {
    # Luckily entering 'dds:mipmaps=0' disables mipmap levels altogether, so just feed it the $mipmaplevels parameter.
    & $IMConvert -quiet $inputimage -define ('dds:compression=' + $DXT) -define ('dds:mipmaps=' + $mipmaplevels) -resize ($inputdimensions + '!') $outputimage
  }
}
#==============================================================================================================================================================================================
#  Sub-function of "CreateDDSTexture" to create DDS mipmaps if no mipmaps are provided.

function CreateDDSMipMapsFast([hashtable]$texdata, [int]$inputwidth, [int]$inputheight, [string]$format, [string]$outputpath)
{
  # The full path to where the new texture will be created.
  $OutputTexture = $outputpath + '\' + $texdata.Name + $format

  # Create the texture with internal mipmaps.
  CreateDDSWithOptimalTool $texdata $UseNvidiaTools $DDSInputPath $NewDDS.Dimensions $DDSMipMap.Levels $OutputTexture
}
#==============================================================================================================================================================================================
#  Sub-function of "CreateDDSTexture" to create DDS mipmaps if mipmaps are provided.

function CreateDDSCustomMipMaps([hashtable]$texdata, [int]$inputwidth, [int]$inputheight, [string]$format, [string]$outputpath)
{
  # Create a temporary path to create the mipmaps.
  $NewDDSMipMapPath = CreatePath ($TempFolder + '\NewDDSMipMaps\')

  # Set up the output path to where the top level will be created.
  $NewDDSTopLevel = $NewDDSMipMapPath + 'TempDDS_00' + $DDS

  # The top level must be generated first.
  CreateDDSWithOptimalTool $texdata $UseNvidiaTools $DDSInputPath $NewDDS.Dimensions '0' $NewDDSTopLevel

  # Loop through all levels. $DDSMipMap (which is the mipmap hash table), is inherited from "CreateDDSTexture".
  for($i=1; $i -le $DDSMipMap.Levels; $i++)
  {
    # Get the mipmap dimensions as the nearest multiple of four (7 becomes 8, 22 becomes 24, etc..)
    $MipMapDDS = DDSMultFour $DDSMipMap.Width[$i] $DDSMipMap.Height[$i]

    # Check to see if the mipmap exists which is used to create the new mipmap. Force new mipmaps if the script calls for it.
    if (($DDSMipMap.Exists[$i]) -and (!$ForceNewMipMaps))
    {
      # If using nvidia tools and the dimensions don't line up, a temporary mipmap must be created.
      if (($UseNvidiaTools) -and ($MipMapDDS.Dimensions -ne $DDSMipMap.RealDimensions[$i]))
      {
        # Because the mipmap exists, create the temporary mipmap from the top layer.
        $TempMipMapTexture = $DDSMipMap.FullPath[$i]
      }
      # ImageMagick doesn't care about dimensions so a temporary mipmap does not need to be created.
      else
      {
        # Link directly to the mipmap file rather than create a clone.
        $GenerateMipMapPath = $DDSMipMap.FullPath[$i]
      }
    }
    # The mipmap did not exist or new ones were forced, so the base texture is used for the new mipmap.
    else
    {
      # The texture needs to be resized for nvidia tools so a temporary mipmap must be created.
      if ($UseNvidiaTools)
      {
        # Since the mipmap does not exist, create the temporary mipmap from the base texture.
        $TempMipMapTexture = $texdata.FullPath
      }
      # ImageMagick doesn't care about dimensions so a temporary mipmap does not need to be created.
      else
      {
        # Link directly to the base texture file rather than create a clone.
        $GenerateMipMapPath = $texdata.FullPath
      }
    }
    # Check if "TempMipMapTexture" was set, which means a temporary texture must be generated.
    if ($TempMipMapTexture)
    {
      # Create a temporary folder for the temporary mipmap.
      $TempMipMapPath = CreatePath ($TempFolder + '\TempMipMap\')

      # Store the path to the temporary mipmap for DDS Utilities.
      $GenerateMipMapPath = $TempMipMapPath + $DDSMipMap.FullName[$i]

      # If the calculated dimensions match the real dimensions, disable sharpening. 
      if ($MipMapDDS.Dimensions -eq $DDSMipMap.RealDimensions[$i])
      {
        $SharpenStrength = '0x0.00'
      }
      # Default enable sharpening the texture.
      else
      {
        $SharpenStrength = '0x0.25'
      }
      # Create the temporary mipmap.
      & $IMConvert -quiet $TempMipMapTexture -resize ($MipMapDDS.Dimensions + '!') -sharpen $SharpenStrength $GenerateMipMapPath
    }
    # Get the current level as a string and in double digits.
    $Level = IntToStringDoubleDigit $i

    # Set up the output path to where the mipmap will be created.
    $MipMapOutputPath = $NewDDSMipMapPath + 'TempDDS_' + $Level + $DDS

    # Create the mipmap from wherever GenerateMipMapPath was set to.
    CreateDDSWithOptimalTool $texdata $UseNvidiaTools $GenerateMipMapPath $MipMapDDS.Dimensions '0' $MipMapOutputPath

    # If the user wants external mipmaps, copy the generated mipmap to the texture output path rather than move it, as it may be needed later for internal mipmaps.
    if ($DDSMipMapType -ne 'Internal')
    {
      $MovePath = $outputpath + '\' + $DDSMipMap.Name[$i] + $DDS
      Copy-Item -LiteralPath $MipMapOutputPath -Destination $MovePath -Force
    }
  }
  # Set up where to create the final texture.
  $DDSOutPutPath = $outputpath + '\' + $texdata.Name + $DDS

  # If the user also wants internal mipmaps, stitch them together into a single texture.
  if ($DDSMipMapType -ne 'External')
  {
    # Combine all mipmap levels into a single texture (all textures generated with the name TempDDS_##) using nvidia stitch.
    & $NSTITCH ($NewDDSMipMapPath + 'TempDDS')

    # Move the newly created texture with all mipmap levels to the texture path.
    Move-Item -LiteralPath ($NewDDSMipMapPath + 'TempDDS' + $DDS) -Destination $DDSOutPutPath -Force
  }
  # If only external mipmaps were desired, then copy over the top level without mipmaps.
  else
  {
    Move-Item -LiteralPath $NewDDSTopLevel -Destination $DDSOutPutPath -Force
  }
  # Clean up generated folders.
  RemovePath $TempMipMapPath
  RemovePath $NewDDSMipMapPath
}
#==============================================================================================================================================================================================
#  Sub-function of "CreateStandardTexture" to create DDS Textures.

function CreateDDSTexture([hashtable]$texdata, [int]$inputwidth, [int]$inputheight, [string]$format, [string]$outputpath)
{
  # The full path to where the new texture will be created.
  $OutputTexture = $outputpath + '\' + $texdata.Name + $format

  # Create a hash table with a multiple of 4 version of the input dimensions.
  $NewDDS = DDSMultFour $inputwidth $inputheight

  # Calculate the total number of pixels of both the initial image and the result to find out which generation method to use.
  $TotalPixelsDDS = $NewDDS.Width * $NewDDS.Height
  $TotalPixelsOld = $texdata.Width * $texdata.Height
  $UseNvidiaTools = (($TotalPixelsDDS -lt 16777216) -and ($TotalPixelsOld -lt 16777216)) # 16777216 is the product of 4096*4096.

  # NVDXT does not accept images with non-multiple 4 dimensions, so a temporary texture must be created before using DDS Utilities.
  if (($UseNvidiaTools) -and ($NewDDS.Dimensions -ne $texdata.Dimensions))
  {
    # Set up the path for the temporary texture.
    $TempTexturePath = CreatePath ($TempFolder + '\TempTextures\')

    # Change Nvidia input path to where the temporary texture will be created.
    $DDSInputPath = $TempTexturePath + $texdata.FullName

    # Generate the temporary image using ImageMagick.
    & $IMConvert -quiet $texdata.FullPath -resize ($NewDDS.Dimensions + '!') $DDSInputPath
  }
  # If a texture does not need to be generated then simply use the custom texture.
  else
  {
    # Hello there, I'm a comment! There are far too many of me in this script. If you don't like it, you can eat shit!
    $DDSInputPath = $texdata.FullPath
  }
  # Check if the texture is a mipmap texture.
  if ($texdata.IsMipMap)
  {
    # Get a mipmap hash table. It will automatically carry over into the below two MipMap functions.
    $DDSMipMap = CreateMipMapInfoPlus $texdata $NewDDS.Width $NewDDS.Height $DDS

    # We only want to use this method if the DDS Mipmap type is set to Internal and no levels already exist or new ones were forced.
    if (($DDSMipMapType -eq 'Internal') -and (($DDSMipMap.LevelsCounted -eq 0) -or ($ForceNewMipMaps)))
    {
      CreateDDSMipMapsFast $texdata $inputwidth $inputheight $format $outputpath
    }
    # If mipmaps are provided then use them to create the new mipmaps, and stitch them together if internal mipmaps were wanted.
    else
    {
      CreateDDSCustomMipMaps $texdata $inputwidth $inputheight $format $outputpath
    }
    # Destroy the folder with internal mipmaps if it exists.
    DestroyMipMapInfoPlus
  }
  # Since it's not a mipmap texture, just create the texture normally without mipmaps.
  else
  {
    CreateDDSWithOptimalTool $texdata $UseNvidiaTools $DDSInputPath $NewDDS.Dimensions '0' $OutputTexture
  }
  # Clean up any generated folders/textures.
  RemovePath $TempTexturePath
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: STANDARD CREATION METHOD
#==============================================================================================================================================================================================
#  Creates a texture and all MipMap levels at a location using the "TextureInfo" of a texture fed into the hash table parameter.
#  Parameters serve as modifiers to the texture, allowing to alter the format, width, height, and output path to create the texture.

function CreateStandardTexture([hashtable]$texdata, [int]$inputwidth, [int]$inputheight, [string]$format, [string]$outputpath)
{
  # The full path to where the new texture will be created.
  $NewTexturePath = $outputpath + '\' + $texdata.Name + $format

  # Create PNG or JPG texture.
  if ($format -ne $DDS)
  {
    CreatePNGTexture $texdata $inputwidth $inputheight $format $outputpath
  }
  # Create DDS texture.
  else
  {
    # Make sure DDS Utilities exists before attempting to create the texture.
    if ($NVDXT_Exists)
    {
      CreateDDSTexture $texdata $inputwidth $inputheight $format $outputpath
    }
    # If it's not found notify the user.
    else
    {
      Write_Host ' Notice     : ' $ConsoleColors Magenta $true
      Write-Host 'Nvidia DDS Utilities was not found! It must be installed to create DDS textures.'
    }
  }
  # Return whether or not the texture was created.
  return (TestPath $NewTexturePath)
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: MATERIAL MAPS - FUNCTIONS FOR CREATING MATERIAL MAPS WITH ISHIIRUKA TOOL
#==============================================================================================================================================================================================
#  Creates an Ishiiruka material map from an already existing material map. Unlike the other material map function found below, this one 
#  will return whether or not the function ran. This is so both functions do not run and waste precious time...

function CreateMaterialMap_FromMaterial([hashtable]$texdata, [int]$inputwidth, [int]$inputheight, [string]$format, [string]$outputpath)
{
  # Check for a valid path to Ishiiruka Tool.
  if (!(TestPath $IshiirukaTool))
  {
    # Report that Ishiiruka Tool was not found so nothing can be done.
    Write_Host ' Notice     : ' $ConsoleColors Magenta $true
    Write-Host 'Material map exists, but path to Ishiiruka Tool not found!'

    # If the path failed, then exit this function.
    return $false
  }
  # Get the current dimensions of the material map.
  $MaterialWidth  = [int](& $IMIdentify $IM7Identify -quiet -format '%w' $texdata.MaterialMapPath)
  $MaterialHeight = [int](& $IMIdentify $IM7Identify -quiet -format '%h' $texdata.MaterialMapPath)

  # Check if the texture is a mipmap texture or not.
  if (!$texdata.IsMipMap)
  {
    # Check if the format and dimensions line up so the texture can just be copied instead of recreated.
    if (($texdata.Extension -eq $format) -and ($MaterialWidth -eq $inputwidth) -and ($MaterialHeight -eq $inputheight))
    {
      # If so, simply copy it. We only copy non-mipmaps because of the whole internal vs. external shit that gets old.
      Copy-Item -LiteralPath $texdata.FullPath -Destination $outputpath -Force
      Copy-Item -LiteralPath $texdata.MaterialMapPath -Destination $outputpath -Force

      # Report to the console that the textures were copied.
      Write_Host ' Notice     : ' $ConsoleColors Green $true
      Write-Host 'Material map copied from existing material map.'

      # Exit the function now that the work is already done.
      return $true
    }
    # If the above check failed, tell Ishiiruka Tool this is not a mipmap texture.
    $nomipmaps = '-nomipmaps'
  }
  # Check if the user wanted to convert textures to DDS.
  if ($format -eq $DDS)
  {
    # Send the "compress" command to Ishiiruka Tool to create DDS material maps.
    $compress = '-compress'
  }
  # Check the dimensions to see if rescaling is necessary.
  if (($MaterialWidth -ne $inputwidth) -or ($MaterialHeight -ne $inputheight))
  {
    # Send the new dimensions to Ishiiruka Tool.
    $IshiirukaWidth  = '-w' + $inputwidth
    $IshiirukaHeight = '-h' + $inputheight
  }
  # WORKAROUND: Ishiiruka Tool will not take (_lum) textures directly so work-around this by creating a copy without the (_lum).
  # Affects 0.9.6, 0.9.7 (most recent)
  if ($texdata.ColorIsLum)
  {
    # Derive a lumless name from the texture.
    $LumlessName = $texdata.Name.TrimEnd('_lum')

    # Paths to check and see if the textures were created.
    $FinalTexture  = $outputpath + '\' + $texdata.Name + $format
    $FinalMaterial = $outputpath + '\' + $LumlessName + '.mat' + $format

    # Set up the path for the temporary texture.
    $TempPathCop = CreatePath ($TempFolder + '\TempCopied\')
    $TempTexture = $TempPathCop + $LumlessName + $texdata.Extension
    $TempPathGen = CreatePath ($TempFolder + '\TempGenerated\')

    # Create a copy of the texture without the (_lum).
    Copy-Item -LiteralPath $texdata.FullPath -Destination $TempTexture -Force

    # Run this copy through Ishiiruka Tool.
    & $IshiirukaTool $TempTexture $TempPathGen $nomipmaps $compress $IshiirukaWidth $IshiirukaHeight '-savecolor' '-frommaterial' | Out-Null

    # Find the number of badly named mipmaps of both the color texture and the material map.
    foreach($CurrentTexture in Get-ChildItem -LiteralPath $TempPathGen)
    {
      # Get the name of the texture in string format.
      $TextureLoopName = $CurrentTexture.ToString()

      # Find any textures that are similar to the texture's name.
      if ($TextureLoopName -like ($TextureName + '*'))
      {
        # Set up variables and rename the textures. 
        $BadName = $TempPathGen + '\' + $TextureLoopName
        $NewName = $TempPathGen + '\' + $TextureLoopName.TrimEnd($format) + '_lum' + $format
        Move-Item -LiteralPath $BadName -Destination $NewName -Force
      }
    }
    # Loop through all textures in the temporary path.
    foreach($MipMapFile in Get-ChildItem -LiteralPath $TempPathGen)
    {
      # Move all textures to the current texture output path.
      $MovePath = [string]$MipMapFile.Directory + '\' + $MipMapFile.Name
      Move-Item -LiteralPath $MovePath -Destination $outputpath -Force
    }
    # Clean up any leftovers in the temp folders.
    RemovePath $TempPathCop
    RemovePath $TempPathGen
  }
  # If it's not a (_lum) texture then simply send the color texture.
  else
  {
    # Paths to check and see if the textures were created.
    $FinalTexture  = $outputpath + '\' + $texdata.Name + $format
    $FinalMaterial = $outputpath + '\' + $texdata.Name + '.mat' + $format

    # Generate the color textures.
    & $IshiirukaTool $texdata.FullPath $outputpath $nomipmaps $compress $IshiirukaWidth $IshiirukaHeight '-savecolor' '-frommaterial' | Out-Null
  }
  # Generate the material map textures.
  & $IshiirukaTool $texdata.MaterialMapPath $outputpath $nomipmaps $compress $IshiirukaWidth $IshiirukaHeight '-frommaterial' | Out-Null

  # Test if the textures were created.
  if ((TestPath $FinalTexture) -and (TestPath $FinalMaterial))
  {
    # Report to the console that the texture was created.
    Write_Host ' Notice     : ' $ConsoleColors Green $true
    Write-Host 'Material map created from existing material map.'
    return $true
  }
  # The texture was not created.
  return $false
}
#==============================================================================================================================================================================================
#  Creates an Ishiiruka material map from bump/spec/lum/nrm textures.

function CreateMaterialMap_FromTextures([hashtable]$texdata, [int]$inputwidth, [int]$inputheight, [string]$format, [string]$outputpath)
{
  # Check for a valid path to Ishiiruka Tool.
  if (!(TestPath $IshiirukaTool))
  {
    # Report that Ishiiruka Tool was not found so nothing can be done.
    Write_Host ' Notice     : ' $ConsoleColors Magenta $true
    Write-Host 'Material textures exist, but path to Ishiiruka Tool not found!'

    # If path failed, then exit this function.
    return $false
  }
  # Set the possible material types into an array so they can easily be looped through.
  $MaterialSuffix = 'nrm','bump','spec','lum'

  # If new dimensions are specified (with rescale textures option), new materials must be created with these dimensions.
  if (($inputwidth -ne $texdata.Width) -or ($inputheight -ne $texdata.Height))
  {
    # Store the new dimensions in a format needed by ImageMagick.
    $NewDimensions = $inputwidth.ToString() + 'x' + $inputheight.ToString() + '!'

    # Set the path for all of the temporary rescaled textures.
    $TempScaledMaterials = CreatePath ($TempFolder + '\TempScaledMaterials')

    # Set the path to the temporary color map. 
    $TinoTexturePath = $TempScaledMaterials + "\" + $texdata.Name + $PNG

    # Create the temporary rescaled color map.
    & $IMConvert -quiet ($texdata.PathName + $PNG) -resize $NewDimensions -sharpen '0x0.50' $TinoTexturePath

    # Loop through each material.
    foreach($Suffix in $MaterialSuffix)
    {
      # Create the paths to the original and created materials.
      $OldMaterial = $texdata.PathName + '.' + $Suffix + $PNG
      $NewMaterial = $TempScaledMaterials + '\' + $texdata.Name + '.' + $Suffix + $PNG

      # Check to see if the original material exists.
      if (TestPath $OldMaterial)
      {
        # If it does, then create a rescaled version of the material.
        & $IMConvert -quiet $OldMaterial -resize $NewDimensions -sharpen '0x0.50' $NewMaterial

        # Console: Add to the string of types used to create the material (so it appears as "nrm/bump/spec/lum/").
        $MaterialsUsed += $Suffix + '/'
      }
    }
    # Console: Trim the last forward slash from the string.
    $MaterialsUsed = $MaterialsUsed.TrimEnd('/')
  }
  # In any other case, the base textures can be used.
  else
  {
    # Set the path to the current texture in the main loop.
    $TinoTexturePath = $texdata.FullPath

    # Console: Loop through each material to find which materials are actually being used to report to the console.
    foreach($Suffix in $MaterialSuffix)
    {
      # Console: Check if the material type exists.
      if (TestPath ($texdata.PathName + '.' + $Suffix + $PNG))
      {
        # Console: Add to the string of types used to create the material.
        $MaterialsUsed += $Suffix + '/'
      }
    }
    # Console: Trim the last forward slash from the string.
    $MaterialsUsed = $MaterialsUsed.TrimEnd('/')
  }
  # Check if the texture is a mipmap texture or not.
  if (!$texdata.IsMipMap)
  {
    $nomipmaps = '-nomipmaps'
  }
  # Check if the user wanted to convert textures to DDS.
  if ($format -eq $DDS)
  {
    # If they did, then add the compress argument to Ishiiruka Tool. Otherwise this value will be empty.
    $compress = '-compress'
  }
  # Create the material map and all mipmaps in the temporary folder.
  & $IshiirukaTool $TinoTexturePath $outputpath $nomipmaps $compress '-savecolor' | Out-Null

  # Cleanup temporary materials if they exist now that they are no longer needed.
  RemovePath $TempScaledMaterials

  # Test if a material (.lum) exists. If it does, the color texture will come out with the suffix (_lum).
  if (TestPath ($texdata.PathName + '.lum' + $PNG))
  {
    # Add the (_lum) suffix to the texture path that will be tested.
    $FinalTexture = $outputpath + '\' + $texdata.Name + '_lum' + $format
  }
  # The texture did not have a (.lum) material file included.
  else
  {
    # In this case do not append any suffix to the texture path that is to be tested.
    $FinalTexture = $outputpath + '\' + $texdata.Name + $format
  }
  # The generated material map will never have (_lum) so just use the texture name +(.mat) for the material test path.
  $FinalMaterial = $outputpath + '\' + $texdata.Name + '.mat' + $format

  # Test if the textures were created using the previously two defined paths.
  if ((TestPath $FinalTexture) -and (TestPath $FinalMaterial))
  {
    # Console: Report to the console that the texture was created.
    Write_Host ' Notice     : ' $ConsoleColors Green $true
    Write-Host ('Material map created from material (' + $MaterialsUsed + ') textures.')
    return $true
  }
  return $false
}
#==============================================================================================================================================================================================
#  Converts an Ishiiruka color texture into a format that is compatible with standard Dolphin.

function ConvertMaterialMap_DolphinFormat([hashtable]$texdata, [int]$inputwidth, [int]$inputheight, [string]$format, [string]$outputpath)
{
  # Check for a valid path to Ishiiruka Tool.
  if (!(TestPath $IshiirukaTool))
  {
    # Report that Ishiiruka Tool was not found so nothing can be done.
    Write_Host ' Notice     : ' $ConsoleColors Magenta $true
    Write-Host 'Material map exists, but path to Ishiiruka Tool not found!'
    
    # If the path failed, then exit this function.
    return $false
  }
  # Return value that states whether or not the texture was created.
  $TextureConverted = $false

  # If the material is in DDS format, then it must first be converted to PNG using Ishiiruka Tool.
  if ($texdata.Extension -eq $DDS)
  {
    # Create a temporary folder and path to the temporary file.
    $TempIshiiruka = CreatePath ($TempFolder + '\TempIshiiruka\')
    $TempIshiiFile = $TempIshiiruka + $texdata.Name + $PNG

    # Create a temporary color texture that is in PNG format.
    & $IshiirukaTool $texdata.MaterialMapPath $TempIshiiruka '-nomipmaps' '-savecolor' '-frommaterial' | Out-Null
  }
  # If the material is in PNG format, then simply just use the base texture.
  else
  {
    $TempIshiiFile = $texdata.FullPath
  }
  # Recreate the image using ImageMagick.
  $IshiiTextureData = CreateTextureInfo (Get-ChildItem -LiteralPath $TempIshiiFile)
  $IshiirukaTexture = CreateStandardTexture $IshiiTextureData $inputwidth $inputheight $format $outputpath

  # Cleanup the junk.
  RemovePath $TempIshiiruka

  # Test if the textures were created.
  if (TestPath ($outputpath + '\' + $texdata.Name + $format))
  {
    # Report to the console that the texture was created.
    Write_Host ' Notice     : ' $ConsoleColors Green $true
    Write-Host 'Material map color texture converted to Dolphin compatible format!'

    # Flag that the texture was created.
    $TextureConverted = $true
  }
  # Return whether or not the texture was created.
  return $TextureConverted
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: MASTER FUNCTION
#==============================================================================================================================================================================================
#  The master function that links together all the different "CreateTexture" functions and automatically chooses the appropriate one.
#  It is not uncommon for many places in the script to call "CreateStandardTexture" directly, in the case material maps are to be ignored.

function CreateTexture([hashtable]$texdata, [int]$inputwidth, [int]$inputheight, [string]$format, [string]$outputpath)
{
  # Check if the texture has an already combined material map.
  if ($texdata.HasMaterialMap)
  {
    # If the script is set to Ishiiruka format, then generate a material map from the material.
    if ($MaterialMapFormat -eq 'Ishiiruka')
    {
      $TextureCreated = CreateMaterialMap_FromMaterial $texdata $inputwidth $inputheight $format $outputpath
    }
    # If the script is set to Dolphin format, then generate a normal texture from the material.
    else
    {
      $TextureCreated = ConvertMaterialMap_DolphinFormat $texdata $inputwidth $inputheight $format $outputpath
    }
  }
  # If the texture has a bump/spec/lum/nrm textures, then create a material map from them.
  elseif (($texdata.HasMaterials) -and ($MaterialMapFormat -eq 'Ishiiruka'))
  {
    $TextureCreated = CreateMaterialMap_FromTextures $texdata $inputwidth $inputheight $format $outputpath
  }
  # Otherwise create the texture normally.
  else
  {
    $TextureCreated = CreateStandardTexture $texdata $inputwidth $inputheight $format $outputpath
  }
  # Return if the texture was created or not.
  return $TextureCreated
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: MISCELLANEOUS TEXTURE FUNCTIONS
#==============================================================================================================================================================================================
#  Used to copy the current texture, its MipMaps, and Material Map from the current texture path in the hash table to a destination path.

function CopyTexture([string]$copypath)
{
  # Copy the texture if no conversion is necessary.
  Copy-Item -LiteralPath $Texture.FullPath -Destination $copypath -Force

  # If the texture has a material map, copy it as well.
  if ($Texture.HasMaterialMap)
  {
    Copy-Item -LiteralPath $Texture.MaterialMapPath -Destination $copypath -Force
  }
  # If the texture is a MipMap, look for lower MipMap levels and copy them too.
  if ($Texture.IsMipMap)
  {
    # Attempt to create a MipMap hash table.
    $MipMap = CreateMipMapInfo $Texture $Texture.Width $Texture.Height $Texture.Extension

    # Loop through all lower levels.
    for($i=1; $i -le $MipMap.Levels; $i++) 
    {
      # If the MipMap level exists, copy it.
      if ($MipMap.Exists[$i])
      {
        Copy-Item -LiteralPath $MipMap.FullPath[$i] -Destination $copypath -Force
      }
    }
  }
}
#==============================================================================================================================================================================================
#  Checks the decimal value of the input against ScaleThreshold, and increments the integer if the decimal is greater than ScaleThreshold.

function ScaleThresholdCorrection([string]$inputvalue)
{
  # Split the integer from the decimal value.
  $ScaleSplit = (FormatDecimal $inputvalue).Split('.', 2)

  # Store the integer value as an actual integer.
  $intvalue = [int]$ScaleSplit[0]

  # Store the decimal value separately without the integer.
  $decvalue = [decimal]('0.' + $ScaleSplit[1])

  # See if the decimal value is greater than or equal to Scale-Fix Threshold.
  if ($decvalue -ge [decimal]$ScaleThreshold)
  {
    # If it is, increment the scaling integer.
    $intvalue++
  }
  # Return the new integer scale.
  return $intvalue
}
#==============================================================================================================================================================================================
#  Function exists to reduce duplicate code. When rescaling or converting textures, JPG textures require special attention. 

function CheckCopyJPG([string]$CheckExtension, [string]$OutPutPath)
{
  # We only want to run this on JPG textures.
  if ($CheckExtension -eq $JPG)
  {
    # Do not even try to convert textures with Material Maps to JPG.
    if (($Texture.HasMaterialMap) -or ($Texture.HasMaterials))
    {
      # Log/Console: Add the logging events.
      SetConsoleMessage 3 'Textures with a Material Map are not converted to JPG!' ''
      $global:LogMessage = 'Not Converted (Has Material)'

      # Copy the texture since no conversion is necessary.
      CopyTexture $OutPutPath
      return $true
    }
    # Check if the original texture has any transparent pixels.
    elseif ($Texture.HasTransparency)
    {
      # Log/Console: Add the logging events.
      SetConsoleMessage 3 'Textures with transparency are not converted to JPG!' ''
      $global:LogMessage = 'Not Converted (Transparency)'

      # Copy the texture since no conversion is necessary.
      CopyTexture $OutPutPath
      return $true
    }
  }
  return $false
}
#==============================================================================================================================================================================================
#  STANDARD OPTION 1: SCAN TEXTURES - ISSUE DETECTION
#==============================================================================================================================================================================================
#  Issue Detection 0: Check to see if it's actually an HD texture.

function Issue_00_NotHDTexture()
{
  # See if the user wants to detect NotHD textures.
  if (!$AllowNotHD)
  {
    # Test both the width and height.
    if (($Texture.ScaleWidth -le 1) -or ($Texture.ScaleHeight -le 1))
    {
      # Copy NotHD textures to their own folder.
      $OutputPath = CreatePath ($MasterOutputPath + '\NotHDTextures' + $Texture.Relative)
      CopyTexture $OutputPath

      # Log/Console: Output that it copied the file.
      SetConsoleMessage 2 'Texture copied to ' ('NotHDTextures' + $Texture.Relative)
      $global:LogMessage = 'NotHD, '

      # Return that the texture had this issue.
      return $true
    }
  }
  # Return that the texture does not have this issue.
  return $false
}
#==============================================================================================================================================================================================
#  Issue Detection 1: Check for Dolphin identified duplicates (ones that end with .1, .2, .3, etc.)

function Issue_01_DolphinDupe()
{
  # Check to see something exists after the period, and that it is an integer (so it doesn't catch "material map" textures).
  if (($Texture.SplitPeriod[1]) -and ($Texture.SplitPeriod[1] -as [int] -is [int]))
  {
    # Copy DolphinDupes to their own folder.
    $OutputPath = CreatePath ($MasterOutputPath + '\DolphinDuplicates' + $Texture.Relative)
    CopyTexture $OutputPath

    # Log/Console: Output that it copied the file.
    SetConsoleMessage 2 'Texture copied to ' ('DolphinDuplicates' + $Texture.Relative)
    $global:LogMessage += 'Dolphin Duplicate, '

    # Return that the texture had this issue.
    return $true
  }
  # Return that the texture does not have this issue.
  return $false
}
#==============================================================================================================================================================================================
#  Issue Detection 2: Test for Duplicate Texture.

function Issue_02_DuplicateTexture()
{
  # Only run if the user does not want to hide duplicates.
  if (!$IgnoreDuplicates)
  {
    # Find the texture in the "Duplicates" hash table if it exists.
    if ($Duplicates.ContainsKey($Texture.Name))
    {
      # Copy Duplicates to their own folder.
      $OutputPath = CreatePath ($MasterOutputPath + '\DuplicateTextures' + $Texture.Relative)
      CopyTexture $OutputPath

      # Console: Output that it copied the file.
      SetConsoleMessage 2 'Texture copied to ' ('DuplicateTextures' + $Texture.Relative)

      # Get the value of that texture from the hash table (the size of the texture when added).
      $CheckSize = $Duplicates.Get_Item($Texture.Name)

      # If the sizes match, then it's an exact duplicate.
      if ($CheckSize -eq $Texture.Size)
      {
        # Log: Add the issue to the global issues variable.
        $global:LogMessage += 'Duplicate Texture, '
      }
      # If they don't match report that it is different.
      else
      {
        # Log: Add the issue to the global issues variable.
        $global:LogMessage += 'Duplicate Texture (Different), '
      }
      # Return that the texture had this issue.
      return $true
    }
    # If the texture was not in the Duplicates hash table.
    else
    {
      # Add it to the Duplicates hash table by texture name and store the size as its value.
      $Duplicates.Add($Texture.Name, $Texture.Size)
    }
  }
  # Return that the texture does not have this issue.
  return $false
}
#==============================================================================================================================================================================================
#  Issue Detection 3: Check to see if there are any missing external MipMaps.

function Issue_03_ExternalMipMaps([hashtable]$mipmap)
{
  # Skip this check if the texture is not a mipmap.
  if ($mipmap -ne $null)
  {
    # For PNG and JPG. Check if there are any mipmaps missing (which is stored in the MipMap hash table).
    if (($Texture.Extension -ne $DDS) -and ($mipmap.LevelsMissing -gt 0))
    {
      # Log/Console: Add the issue to the global issues variable.
      $global:LogMessage += 'MipMaps Missing (x' + $mipmap.LevelsMissing + '), '

      # Return that the texture had this issue.
      return $true
    }
    # The DDS version of mipmap checking. The script's mipmap type must be set to "External" or "Both". Do not attempt to create external mipmaps for material maps.
    elseif (($Texture.Extension -eq $DDS) -and ($mipmap.LevelsMissing -gt 0) -and ($DDSMipMapType -ne 'Internal') -and (!$Texture.HasMaterialMap))
    {
      # Log/Console: Add the issue to the global issues variable.
      $global:LogMessage += 'External MipMaps Missing (x' + $mipmap.LevelsMissing + '), '

      # Return that the texture had this issue.
      return $true
    }
  }
  # Return that the texture does not have this issue.
  return $false
}
#==============================================================================================================================================================================================
#  Issue Detection 4: Check to see if the texture has material textures.

function Issue_04_MaterialTextures()
{
  # Reference the "HasMaterials" variable.
  if ($Texture.HasMaterials)
  {
    # Log/Console: Add the issue to the global issues variable.
    $global:LogMessage += 'Material Textures, '

    # Return that the texture had this issue.
    return $true
  }
  # Return that the texture does not have this issue.
  return $false
}
#==============================================================================================================================================================================================
#  Issue Detection 5: PNG/JPG only. Check to see if there are any MipMaps with bad scaling values.

function Issue_05_BadMipMapsScale([hashtable]$mipmap)
{
  # Texture must be a PNG/JPG mipmap texture.
  if (($Texture.Extension -ne $DDS) -and ($mipmap -ne $null))
  {
    # See if the mipmaps have bad dimensions.
    if ($mipmap.BadDimensions)
    {
      # Log/Console: Add the issue to the global issues variable.
      $global:LogMessage += 'MipMaps Bad Scale (x' + $mipmap.BadDimensions + '), '

      # Return that the texture had this issue.
      return $true
    }
  }
  # Return that the texture does not have this issue.
  return $false
}
#==============================================================================================================================================================================================
#  Issue Detection 6: PNG/JPG only. Check to see if the integer variables match between scales.

function Issue_06_TextureUnevenScale()
{
  # Texture must be PNG/JPG and scaling values must not be identical for both width and height.
  if (($Texture.Extension -ne $DDS) -and ($Texture.ScaleWidth -ne $Texture.ScaleHeight))
  {
    # Log/Console: Add the issue to the global issues variable.
    $global:LogMessage += 'Uneven Scale, '

    # Return that the texture had this issue.
    return $true
  }
  # Return that the texture does not have this issue.
  return $false
}
#==============================================================================================================================================================================================
#  Issue Detection 7: PNG/JPG only. Check to see if the scale is an integer scale.

function Issue_07_BadIntegerScale()
{
  # Texture must be in PNG/JPG format.
  if ($Texture.Extension -ne $DDS)
  {
    # Split the value for both width and height to grab a decimal value if it exists.
    $WidthCheck  = $Texture.ScaleWidth.ToString().Split('.',2)
    $HeightCheck = $Texture.ScaleHeight.ToString().Split('.',2)

    # The value should store double zeros if there is no decimal value.
    if ($WidthCheck[1] -ne '00' -or $HeightCheck[1] -ne '00')
    {
      # Log/Console: Add the issue to the global issues variable.
      $global:LogMessage += 'Non-Integer Scale, '

      # Return that the texture had this issue.
      return $true
    }
    # Return that the texture does not have this issue.
    return $false
  }
}
#==============================================================================================================================================================================================
#  Issue Detection 8: PNG/JPG only. Check to see if the aspects match between original and custom.

function Issue_08_TextureAspect()
{
  # Texture must be PNG/JPG and aspect ratios must not be identical between the original and custom texture.
  if (($Texture.Extension -ne $DDS) -and ($Texture.OldAspect -ne $Texture.Aspect))
  {
    # Log/Console: Add the issue to the global issues variable.
    $global:LogMessage += 'Bad Aspect Ratio, '

    # Return that the texture had this issue.
    return $true
  }
  # Return that the texture does not have this issue.
  return $false
}
#==============================================================================================================================================================================================
#  Issue Detection 9: DDS only. Check DDS dimensions against calculated dimensions to see if they are at the nearest multiple of 4.

function Issue_09_DDSBadDimensions()
{
  # Make sure the textures is in DDS format.
  if ($Texture.Extension -eq $DDS)
  {
    # Set an annoying amount of variables to get the "DDS version" of the dimensions.
    $SplitScaleWidth = $Texture.ScaleWidth.ToString().Split('.',2)

    # Calculate the dimensions using the original texture and the current width scale.
    $CheckWidth = [int]$Texture.OldWidth * [int]$SplitScaleWidth[0]

    # Height scale is not used because if the scales are uneven it would throw off the calculation.
    $CheckHeight = [int]$Texture.OldHeight * [int]$SplitScaleWidth[0]

    # Run the new dimensions through the DDS dimension algorithm to get a hashtable with the "nearest multiple of 4" dimensions.
    $CheckDDS = DDSMultFour $CheckWidth $CheckHeight

    # If the dimensions end up different than the custom texture, then the custom texture is wrong.
    if ($Texture.Dimensions -ne $CheckDDS.Dimensions)
    {
      # Log/Console: Add the issue to the global issues variable.
      $global:LogMessage += 'Bad DDS Dimensions, '

      # Return that the texture had this issue.
      return $true
    }
    # Return that the texture does not have this issue.
    return $false
  }
}
#==============================================================================================================================================================================================
#  Issue Detection 10: DDS only. Check DDS for missing internal mipmaps.

function Issue_10_DDSInternalMipMaps([hashtable]$mipmap)
{
  # Texture must be a DDS mipmap texture, and the mipmap type must be set to "Internal" or "Both" in the script.
  if (($Texture.Extension -eq $DDS) -and ($mipmap -ne $null) -and ($DDSMipMapType -ne 'External') -and (!$Texture.HasMaterialMap))
  {
    # Make sure DDS Utilities exists.
    if (!$NVDXT_Exists)
    {
      # If it doesn't then display to the console that mipmaps cannot be checked.
      Write_Host ' Notice     : ' $ConsoleColors Magenta $true
      Write-Host 'Nvidia DDS Utilities was not found! It must be installed to check "Internal MipMaps".'
      return $false
    }
    # Create a folder to extract MipMaps to.
    $ExtractedPath = CreatePath ($TempFolder + '\Extracted')

    # Extract MipMaps from the texture to see if it has internal MipMaps.
    ExtractInternalDDSMipMaps $Texture.FullPath $ExtractedPath

    # Count the number of files that remain in the folder, and subtract 1 to compensate for the top level.
    $MipMapsFound = ((Get-ChildItem -LiteralPath $ExtractedPath | Where-Object {!$_.PSIsContainer} | Measure-Object).Count) - 1

    # Find how many mipmap levels are missing.
    $CountMissing = $mipmap.Levels - $MipMapsFound

    # Remove the temporary directory and all extracted mipmaps.
    RemovePath $ExtractedPath

    # The log stuff to report missing mipmaps.
    if ($CountMissing -gt 4)
    {
      # Log/Console: Add the issue to the global issues variable.
      $global:LogMessage += 'Internal MipMaps Missing (x' + ($CountMissing - 4) + '), '

      # Return that the texture had this issue.
      return $true
    }
  }
  # Return that the texture does not have this issue.
  return $false
}
#==============================================================================================================================================================================================
#  STANDARD OPTION 1: SCAN TEXTURES - TEXTURE REPAIR AND COPY
#==============================================================================================================================================================================================
#  Try to fix the texture and/or copy the broken texture to a new directory.

function AttemptRepairAndCopy()
{
  # Find the difference in aspect between the original and custom textures.
  $AspectDifference = [math]::abs($Texture.Aspect - $Texture.OldAspect)

  # Attempt to repair the bad texture if the user wanted to, and the aspect difference is within the aspect fix threshold.
  if (($RepairTextures) -and ($AspectDifference -le [decimal]$AspectThreshold))
  {
    # Find the smallest scale between width and height and see if the integer should be incremented.
    $NewScale = ScaleThresholdCorrection ([math]::min($Texture.ScaleWidth, $Texture.ScaleHeight))

    # Use the new scaling value to determine the new dimensions.
    $NewWidth  = ([int]$Texture.OldWidth * $NewScale)
    $NewHeight = ([int]$Texture.OldHeight * $NewScale)

    # Create the repaired folder location if it does not exist.
    $OutputPath = CreatePath ($MasterOutputPath + '\RepairedTextures' + $Texture.Relative)

    # Create the texture in the repaired folder.
    $RepairedTexture = CreateTexture $Texture $NewWidth $NewHeight $Texture.Extension $OutputPath

    # If the texture was repaired, report it.
    if ($RepairedTexture)
    {
      # Add to the total number of repaired textures.
      $global:CountRepaired += 1

      # Console: Add the logging events.
      SetConsoleMessage 2 'Texture successfully repaired to ' ('RepairedTextures' + $Texture.Relative)
      
      # Log: Update the log message to say that the texture was repaired.
      $global:LogMessage = 'REPAIRED: ' + $LogMessage
    }
    # This should never happen, but if the texture failed to be repaired report it.
    else
    {
      # Console: Add the logging events.
      SetConsoleMessage 0 'Texture failed creation and was not repaired!' ''
    }
  }
  # Check if the user wants to copy bad textures, but only copy them if they weren't fixed.
  if (($CopyBadTextures) -and (!$RepairedTexture))
  {
    # Count the number of textures that were copied.
    $global:CountCopied += 1

    # Create the broken textures folder if it does not exist and copy the broken texture.
    $OutputPath = CreatePath ($MasterOutputPath + '\BrokenTextures' + $Texture.Relative)
    CopyTexture $OutputPath

    # Console: Add the logging events.
    SetConsoleMessage 2 'Texture copied to ' ('BrokenTextures' + $Texture.Relative)

    # Log: Update the log message to say that the texture was copied.
    $global:LogMessage = 'COPIED: ' + $LogMessage
  }
}
#==============================================================================================================================================================================================
#  STANDARD OPTION 1: SCAN TEXTURES - MASTER FUNCTION
#==============================================================================================================================================================================================
#  Checks a texture for all issues and reports to logs.

function ScanTextureForIssues()
{
  # If the texture is a MipMap, create a hashtable to pass to issue functions.
  if ($Texture.IsMipMap)
  {
    $MipMap = CreateMipMapInfo $Texture $Texture.Width $Texture.Height $Texture.Extension
  }
  # A compilation of all issues in a single string. Default as an empty string.
  $global:LogMessage = ''

  # Create an array to store the state of all texture issues.
  $TextureIssue = New-Object bool[] 11
  $TextureIssue[0]  = Issue_00_NotHDTexture
  $TextureIssue[1]  = Issue_01_DolphinDupe
  $TextureIssue[2]  = Issue_02_DuplicateTexture
  $TextureIssue[3]  = Issue_03_ExternalMipMaps $MipMap
  $TextureIssue[4]  = Issue_04_MaterialTextures
  $TextureIssue[5]  = Issue_05_BadMipMapsScale $MipMap
  $TextureIssue[6]  = Issue_06_TextureUnevenScale
  $TextureIssue[7]  = Issue_07_BadIntegerScale
  $TextureIssue[8]  = Issue_08_TextureAspect
  $TextureIssue[9]  = Issue_09_DDSBadDimensions
  $TextureIssue[10] = Issue_10_DDSInternalMipMaps $MipMap

  # The texture did not have issues so the string should be empty.
  if ($LogMessage -eq '')
  {
    # Log that the texture is OK.
    $global:LogMessage = 'OK'
  }
  # The string was not empty so there were issues.
  else
  {
    # Trim the comma from the final issue set.
    $global:LogMessage = $LogMessage.TrimEnd(', ')

    # Count the total number of textures with issues.
    $global:CountIssues += 1
  }
  # Force output of the issues to the console.
  Write_Host ' Status     : ' $ConsoleColors Yellow $true
  Write-Host $LogMessage

  # Start a loop to check issues 0-2.
  for($i=0; $i -lt 3; $i++)
  {
    # Check if the following issues are present: NotHD, Duplicate, or DolphinDupe.
    if ($TextureIssue[$i])
    {
      # If any of these issues are present, the texture does not need to be repaired or copied so leave now.
      return
    }
  }
  # One last check to see if the texture has issues.
  if ($LogMessage -ne 'OK')
  {
    # If it does have issues, attempt to repair or copy the broken texture.
    AttemptRepairAndCopy
  }
}
#==============================================================================================================================================================================================
#  STANDARD OPTION 2: RESCALE TEXTURES AT FIXED INTEGER
#==============================================================================================================================================================================================
#  A menu that is displayed when Rescaling textures and "ManualRescale" is enabled.

function ManualRescaleMenu()
{
  # Write information about the texture to the console window.
  Write_Host ' Texture    : ' $ConsoleColors Yellow $true
  Write-Host $Texture.FullName -ForegroundColor Cyan
  Write_Host ' Path       : ' $ConsoleColors Yellow $true
  Write-Host ($Texture.Folder + $Texture.Relative)
  Write_Host ' Original   : ' $ConsoleColors Yellow $true
  Write-Host ($Texture.OldDimensions + ' : ' + $Texture.OldAspect.ToString())
  Write_Host ' Custom     : ' $ConsoleColors Yellow $true
  Write-Host ($Texture.Dimensions + ' : ' + $Texture.Aspect.ToString() + ' : (' + $Texture.Scale + ' Scale)')
  Write-Host ''
  Write-Host ' Enter a new scaling value for the texture.'
  Write-Host (' Range: ') -ForegroundColor Yellow -NoNewLine
  Write-Host ('1-100 , ') -NoNewLine
  Write-Host ('Skip Texture: ') -ForegroundColor Yellow -NoNewLine
  Write-Host ('0 , ') -NoNewLine
  Write-Host ('Default: ') -ForegroundColor Yellow -NoNewLine
  Write-Host $RescaleFactor
  Write-Host ''
  $MenuInput = Read-Host '> '
  Write-Host ''
  # Check that the entered scale is 0-100.
  if ($MenuInput -match '^(?:100|[1-9]?[0-9])$')
  {
    return $MenuInput
  }
  # If there is invalid input or the user wishes to use the default value, then return the stored scale.
  return $RescaleFactor
}
#==============================================================================================================================================================================================
#  This is called if the user forces the script to convert textures to an integer scale.

function RescaleTextureInteger()
{
  # The user preferred to use the texture's file extension rather than convert.
  if ($RescaleFormat -eq $null)
  {
    # Get the extension as text.
    $FileType = ExtensionToText $Texture.Extension

    # Do not convert the texture when rescaling.
    $RescaleExtension = $Texture.Extension

    # Make sure the directory to create rescaled textures exists.
    $RescaledPath = CreatePath ($MasterOutputPath + '\RescaledTextures' + $Texture.Relative)
  }
  # The user  wanted to convert to a specific format.
  else
  {
    # Get the extension as text.
    $FileType = ExtensionToText $RescaleFormat

    # Set the type of texture to convert to when rescaling.
    $RescaleExtension = $RescaleFormat

    # Make sure the directory to create rescaled textures exists.
    $RescaledPath = CreatePath ($MasterOutputPath + '\RescaledTextures (' + $FileType + ')' + $Texture.Relative)
  }
  # Check to see if the user wants to convert to JPG.
  if (CheckCopyJPG $RescaleExtension $RescaledPath)
  {
    return
  }
  # Check to see if manual rescale is disabled.
  if (!$ManualRescale)
  {
    # Set up conditions for when a texture should be rescaled based on user selection.
    $RescaleConditionA = $RescaleScaling -eq 'All'
    $RescaleConditionB = (($RescaleScaling -eq 'Upscale') -and ($Texture.ScaleWidth -le [decimal]$RescaleFactor) -and ($Texture.ScaleHeight -le [decimal]$RescaleFactor))
    $RescaleConditionC = (($RescaleScaling -eq 'Downscale') -and ($Texture.ScaleWidth -ge [decimal]$RescaleFactor) -and ($Texture.ScaleHeight -ge [decimal]$RescaleFactor))

    # If any of the above conditions pass then rescale the texture using the chosen rescaling factor.
    if (($RescaleConditionA) -or ($RescaleConditionB) -or ($RescaleConditionC))
    {
      $NewScale = $RescaleFactor
    }
    # If none of the conditions pass then use the texture's current scale.
    else
    {
      # Choose the greater of the two to find the new scaling value.
      $NewScale = ([math]::max($Texture.ScaleWidth, $Texture.ScaleHeight)).ToString().SubString(0,1)
    }
  }
  # If the user wants to rescale textures individually, display a prompt and texture information.
  else
  {
    # Show the manual rescale menu and grab the returned value.
    $NewScale = ManualRescaleMenu

    # Check if the texture was skipped by the user.
    if ($NewScale -eq '0')
    {
      # Skip the texture if the user wanted to.
      Write_Host ' Notice     : ' $ConsoleColors Yellow $true
      Write-Host 'Skipping this texture.'
      return
    }
    # Display to the host that the texture is being rescaled.
    Write_Host ' Notice     : ' $ConsoleColors Yellow $true
    Write-Host 'Rescaling texture with custom scale...'
  }
  # Calculate the new dimensions based on the new scaling value.
  $NewWidth  = $Texture.OldWidth * [int]$NewScale
  $NewHeight = $Texture.OldHeight * [int]$NewScale

  # Create the rescaled texture.
  if (CreateTexture $Texture $NewWidth $NewHeight $RescaleExtension $RescaledPath)
  {
    # Log/Console: If the texture was converted to PNG, log the format and color space.
    if ($RescaleExtension -eq $PNG)
    {
      $PNGData = CreatePNGData $Texture
      SetConsoleMessage 1 ('Successfully rescaled to ' + $NewWidth + 'x' + $NewHeight + ' (' + $NewScale + 'x) ' + $FileType + ' format! (' + $PNGData.BitDepth + '-Bit ' + $PNGData.ColorSpace + ')') ''
      $global:LogMessage = ('Rescaled to ' + $NewWidth + 'x' + $NewHeight + ' (' + $NewScale + 'x) ' + $FileType + ' Format' + ' (' + $PNGData.BitDepth + '-Bit ' + $PNGData.ColorSpace + ')')
    }
    # Log/Console: If the texture was converted to DDS, log the compression type.
    elseif ($RescaleExtension -eq $DDS)
    {
      SetConsoleMessage 1 ('Successfully rescaled to ' + $NewWidth + 'x' + $NewHeight + ' (' + $NewScale + 'x) ' + $FileType + ' format! (' + $Texture.DDSCompression + ')') ''
      $global:LogMessage = ('Rescaled to ' + $NewWidth + 'x' + $NewHeight + ' (' + $NewScale + 'x) ' + $FileType + ' Format' + ' (' + $Texture.DDSCompression + ')')
    }
    # Log/Console: If the texture was converted to JPG, just log the format.
    else
    {
      SetConsoleMessage 1 ('Successfully rescaled to ' + $NewWidth + 'x' + $NewHeight + ' (' + $NewScale + 'x) ' + $FileType + ' format!') ''
      $global:LogMessage = ('Rescaled to ' + $NewWidth + 'x' + $NewHeight + ' (' + $NewScale + 'x) ' + $FileType + ' Format')
    }
  }
  # Log/Console: If the texture was not created, report an error.
  else
  {
    # Log/Console: Add the logging events.
    SetConsoleMessage 0 'Texture failed creation and was not rescaled!' ''
    $global:LogMessage = 'Failed Creation'
  }
}
#==============================================================================================================================================================================================
#  STANDARD OPTION 3: CONVERT TEXTURES TO ANOTHER FORMAT
#==============================================================================================================================================================================================
#  This is called if the user forces the script to convert textures to a specific format.

function ConvertTextureFormat()
{
  # Store converted textures in their own unique directory.
  $FileType       = ExtensionToText $ConvertFormat
  $ConvertedPath  = CreatePath ($MasterOutputPath + '\ConvertedTextures (' + $FileType + ')' + $Texture.Relative)
  $AutoRepairText = ''

  # Check to see if the user wants to convert to JPG.
  if (CheckCopyJPG $ConvertFormat $ConvertedPath)
  {
    return
  }
  # If the user wishes to auto-repair Dolphin textures, find new dimensions based on the nearest low integer scale.
  if (($ConvertRepair) -and ($Texture.DolphinFormat))
  {
    # Find the smallest scale between width and height and see if the integer should be incremented.
    $NewScale = ScaleThresholdCorrection ([math]::min($Texture.ScaleWidth, $Texture.ScaleHeight))

    # Use the new scaling value to determine the new dimensions.
    $NewWidth  = $Texture.OldWidth * $NewScale
    $NewHeight = $Texture.OldHeight * $NewScale

    # Alert the user that repairs are being done if the calculated dimensions are different than the texture's current dimensions.
    if ((!$Texture.HasMaterialMap) -and (($NewWidth -ne $Texture.Width) -or ($NewHeight -ne $Texture.Height)))
    {
      $AutoRepairText = (', Repaired to (' + $NewWidth + 'x' + $NewHeight + ') Using (' + $NewScale + 'x) Scale')
      Write_Host ' Notice     : ' $ConsoleColors Green $true
      Write-Host 'Dimensions will be repaired to (' + $NewWidth + 'x' + $NewHeight + ') using (' + $NewScale.ToString() + 'x) scale.'
    }
  }
  # If the user does not wish to auto-repair, just use the custom texture dimensions.
  else
  {
    $NewWidth  = $Texture.Width
    $NewHeight = $Texture.Height
  }
  # Create the converted texture.
  if (CreateTexture $Texture $NewWidth $NewHeight $ConvertFormat $ConvertedPath)
  {
    # Log/Console: If the texture was converted to PNG, log the format and color space.
    if ($ConvertFormat -eq $PNG)
    {
      $PNGData = CreatePNGData $Texture
      SetConsoleMessage 1 ('Successfully converted to ' + $FileType + ' format! (' + $PNGData.BitDepth + '-Bit ' + $PNGData.ColorSpace + ')') ''
      $global:LogMessage = ('Converted to ' + $FileType + ' Format (' + $PNGData.BitDepth + '-Bit ' + $PNGData.ColorSpace + ')' + $AutoRepairText)
    }
    # Log/Console: If the texture was converted to DDS, log the compression type.
    elseif ($ConvertFormat -eq $DDS)
    {
      SetConsoleMessage 1 ('Successfully converted to ' + $FileType + ' format! (' + $Texture.DDSCompression + ')') ''
      $global:LogMessage = ('Converted to ' + $FileType + ' Format (' + $Texture.DDSCompression + ')' + $AutoRepairText)
    }
    # Log/Console: If the texture was converted to JPG, just log the format.
    else
    {
      SetConsoleMessage 1 ('Successfully converted to ' + $FileType + ' format!') ''
      $global:LogMessage = ('Converted to ' + $FileType + ' Format' + $AutoRepairText)
    }
  }
  # If the texture was not created, report an error.
  else
  {
    SetConsoleMessage 0 'Texture failed creation and was not converted!' ''
    $global:LogMessage = 'Failed Creation'
  }
}
#==============================================================================================================================================================================================
#  STANDARD OPTION 4: CREATE MATERIAL MAPS WITH ISHIIRUKA TOOL
#==============================================================================================================================================================================================
#  Creates material maps from bump/spec/lum/nrm textures. Parameter "$ishiimethod" defines where to create the texture. 1 - Output Folder, 2 - Overwrite the Textures/Destroy Materials

function CreateMaterialMaps($ishiimethod)
{
  # Check to see if the texture actually has supplied material maps.
  if (!$Texture.HasMaterials)
  {
    # Log/Console: Add the logging events.
    SetConsoleMessage 1 'No material textures (bump/spec/lum/nrm) exist for this texture.' ''
    $global:LogMessage = 'No Materials'
    return
  }
  # Get the extension as text for the output folder.
  $FileType = ExtensionToText $IshiirukaFormat

  # This method creates the material map in the output path.
  if ($ishiimethod -eq 1)
  {
    # Set up the path to create material map to a new folder.
    $MaterialOutputPath = CreatePath ($MasterOutputPath + '\MaterialMaps ' + '(' + $FileType + ')' + $Texture.Relative)

    # Attempt to create the material map.
    if (!(CreateMaterialMap_FromTextures $Texture $Texture.Width $Texture.Height $IshiirukaFormat $MaterialOutputPath))
    {
      # Report if the material map failed creation
      Write-Host ' ERROR      : Material map failed creation!' -ForegroundColor Red
    }
  }
  # This method creates the material map in-place.
  else
  {
    # Set up the path to create material maps to a new folder.
    $TempMaterialPath = CreatePath ($TempFolder + '\TempMaterials')

    # Attempt to create the material map.
    if (CreateMaterialMap_FromTextures $Texture $Texture.Width $Texture.Height $IshiirukaFormat $TempMaterialPath)
    {
      # Remove the old material textures.
      RemovePath $Texture.FullPath
      RemovePath ($Texture.Path + '\' + $Texture.Name + '.nrm' + $PNG)
      RemovePath ($Texture.Path + '\' + $Texture.Name + '.bump' + $PNG)
      RemovePath ($Texture.Path + '\' + $Texture.Name + '.spec' + $PNG)
      RemovePath ($Texture.Path + '\' + $Texture.Name + '.lum' + $PNG)

      # Log/Console: Add the logging events.
      $global:LogMessage = 'Material Map Created'

      # Loop through all Material Maps in the temp materials directory.
      foreach($subfile in Get-ChildItem -LiteralPath $TempMaterialPath)
      {
        # Move all Material Maps to the current texture path.
        $MovePath = [string]$subfile.Directory + '\' + $subfile.Name
        Move-Item -LiteralPath $MovePath -Destination $Texture.Path -Force
      }
    }
    # It was not created.
    else
    {
      # Report if the material map failed creation
      Write-Host ' ERROR      : Material map failed creation!' -ForegroundColor Red
    }
    # Clean up on aisle four.
    RemovePath $TempMaterialPath
  }
}
#==============================================================================================================================================================================================
#  STANDARD OPTION 5: ADD IDENTIFYING WATERMARK TO ALL TEXTURES
#==============================================================================================================================================================================================
#  Creates textures with a watermark using the end of the texture name so they can be more easily identified in-game.

function AddTextureWatermark()
{
  # Create the output path if it doesn't exist.
  $OutputPath = CreatePath ($MasterOutputPath + '\WatermarkTextures' + $Texture.Relative)

  # Set the full path to output texture.
  $TexOutputPath = $OutputPath + '\' + $Texture.Name + $PNG

  # Check if the user wanted a specific number of characters in the watermark.
  if ([int]$WM_Length -gt 0)
  {
    # Less than 6 characters is pretty useless, so force 6 if its less than 6.
    if ([int]$WM_Length -lt 6)
    {
      # Extract characters from the end of the texture name to use as a watermark.
      $Watermark = $Texture.Name.Substring($Texture.Name.Length - 6, 6)
    }
    # Otherwise, use the value the user input.
    else
    {
      # Extract characters from the end of the texture name to use as a watermark.
      $Watermark = $Texture.Name.Substring($Texture.Name.Length - $WM_Length, $WM_Length)
    }
  }
  # If the value was 0, the user wanted to use the full name.
  else
  {
    # Use the full texture name as the watermark.
    $Watermark = $Texture.Name
  }
  # Store the width and height before checks so it can be used if the checks immediately pass.
  $NewWidth  = $Texture.Width
  $NewHeight = $Texture.Height

  # Check to see if the texture width is less than 256 pixels.
  if ($NewWidth -lt 256)
  {
    # If it failed to be at least 256 pixels, calculate a new width and height that equals/exceeds 256 using the lowest possible integer scale.
    $ScaleFactor = 2
    while($NewWidth -lt 256)
    {
      # Each iteration increments the scale by 1x. Loop exits when greater than or equal to 256 is reached.
      $NewWidth  = $Texture.Width * $ScaleFactor
      $NewHeight = $Texture.Height * $ScaleFactor
      $ScaleFactor ++
    }
  }
  # Store the dimensions in a format needed by ImageMagick when creating images.
  $NewDimensions = $NewWidth.ToString() + 'x' + $NewHeight.ToString()

  # Scale the font to the texture. Use the user selected font size as a multiplier.
  $FontSize = ([int](($NewWidth / 128) * $WM_FontSize)).ToString()

  # If word wrap is disabled, simply create a watermark over the texture.
  if (!$WM_WordWrap)
  {
    # Create the texture with a watermark.
    & $IMConvert -quiet $Texture.FullPath -resize ($NewDimensions + '!') -gravity center -font $WM_FontFace -pointsize $FontSize -fill $WM_FontColor -undercolor $WM_BGColor -draw "text 0,0 `'$Watermark`'" $TexOutputPath
  }
  # Word wrapping requires a more complex method of applying the watermark. An external caption image file must be created and applied to the texture file.
  else
  {
    # Create a folder for temporary textures.
    $TempWatermarkPath = CreatePath ($TempFolder + '\TempWatermark\')

    # Set the path for the temporary texture and caption.
    $TexturePath = $TempWatermarkPath + 'tex.png'
    $CaptionPath = $TempWatermarkPath + 'cap.png'

    # Set the width of the caption using 80% of the texture width.
    $FindNewWidth = $NewWidth * 0.80
    $CaptionWidth = $FindNewWidth.ToString() + 'x'

    # Check if the texture is a DDS texture generated with Ishiiruka Tool.
    if (($Texture.HasMaterialMap) -and ($Texture.Extension -eq $DDS))
    {
      # I don't even want to fuck with trying to convert a (_lum) texture.
      if ((TestPath $IshiirukaTool) -and ($Texture.ColorIsLum))
      {
        # Instead just create a black texture.
        & $IMConvert -quiet -size $NewDimensions 'xc:#000000' $TexturePath
        Write_Host ' Notice     : ' $ConsoleColors Magenta $true
        Write-Host 'Ishiiruka (_lum) color texures cannot be converted. Generated texture will be a black image!'
      }
      # If it's not a (_lum) texture attempt to convert it.
      elseif ((TestPath $IshiirukaTool) -and (!$Texture.ColorIsLum))
      {
        # Create a link to the temporary generated texture.
        $IshiirukaFile = $TempWatermarkPath + $Texture.Name + $PNG

        # Create a temporary color texture that is in PNG format.
        & $IshiirukaTool $Texture.MaterialMapPath $TempWatermarkPath '-nomipmaps' '-savecolor' '-frommaterial' | Out-Null

        # Rename the file to 'tex.png' for the combination step.
        Move-Item -LiteralPath $IshiirukaFile -Destination $TexturePath -Force
      }
      # Ishiiruka Tool was not found.
      else
      {
        # Instead just create a black texture.
        & $IMConvert -quiet -size $NewDimensions 'xc:#000000' $TexturePath
        Write_Host ' Notice     : ' $ConsoleColors Magenta $true
        Write-Host 'Ishiiruka Tool not found. Generated texture will be a black image!'
      }
    }
    # In every other case, generate the temporary texture from the custom texture.
    else
    {
      # Create the temporary texture.
      & $IMConvert -quiet $Texture.FullPath -resize ($NewDimensions + '!') $TexturePath
    }
    # Create the caption that will overlay the texture.
    & $IMConvert -quiet -background transparent -fill $WM_FontColor -undercolor $WM_BGColor -font $WM_FontFace -pointsize $FontSize -size $CaptionWidth -gravity Center caption:$Watermark $CaptionPath

    # Test if the texture and caption were created. DDS textures created by Ishiiruka Tool will most likely fail here.
    if ((TestPath $TexturePath) -and (TestPath $CaptionPath))
    {
      # Apply the caption to the texture using the -composite command.
      & $IMConvert -quiet $TexturePath $CaptionPath -gravity center -composite $TexOutputPath
    }
    # Clean up the temporary files and folders.
    RemovePath $TempWatermarkPath
  }
  # LOG/Console: Report to the user that the texture was created.
  if (TestPath $TexOutputPath)
  {
    SetConsoleMessage 1 'Texture with watermark created successfully.' ''
    $global:LogMessage = 'Watermark Created'
  }
  # LOG/Console: Report to the user that the texture was not created.
  else
  {
    SetConsoleMessage 0 'Texture with watermark failed creation.' ''
    $global:LogMessage = 'Watermark Failed'
  }
}
#==============================================================================================================================================================================================
#  STANDARD OPTION 6: OPTIMIZE PNG TEXTURES WITH OPTIPNG
#==============================================================================================================================================================================================
#  Calculate/store stuff for OptiPNG using a hash table. Also used in function "FixBadOptiPNGTexture".

function CreateOptiPNGData([string]$inputpath) 
{
  # Initialize a hash table.
  $OptiData = @{}

  # Get the texture as an object so it can be analyzed.
  $OptiObject = Get-ChildItem -LiteralPath $inputpath

  # Store the name of the texture.
  $OptiData.Name     = $OptiObject.BaseName
  $OptiData.FullName = $OptiObject.Name

  # Store the size of the texture in Bytes.
  $OptiData.Size = ($OptiObject | Measure-Object -property length -sum).sum

  # This function will generate ass-loads of errors if a channel is not in the string, so silence them all.
  $ErrorActionPreference = 'silentlycontinue'

  # Run the "-verbose" command on the texture to find the channel information. Verbose is stored as an array of strings.
  $Verbose = (& $IMIdentify $IM7Identify -quiet -verbose $inputpath)

  # Search the array of strings for color data. Find the numeric value of the bit depth stored in the string.
  $R_String = (($Verbose | Select-String -Pattern 'Red.*bit') -Split 'Red: ') -Split '-bit'
  $G_String = (($Verbose | Select-String -Pattern 'Green.*bit') -Split 'Green: ') -Split '-bit'
  $B_String = (($Verbose | Select-String -Pattern 'Blue.*bit') -Split 'Blue: ') -Split '-bit'
  $A_String = (($Verbose | Select-String -Pattern 'Alpha.*bit') -Split 'Alpha: ') -Split '-bit'

  # Initialize an array to store the depth in each channel.
  $Channel = New-Object int[] 4

  # Search for the channel depth and convert it to an integer. If the channel is not found, set depth to zero.
  if ($R_String[1]) { $Channel[0] = [int]$R_String[1] } else { $Channel[0] = 0 }
  if ($G_String[1]) { $Channel[1] = [int]$G_String[1] } else { $Channel[1] = 0 } # Heh. G-String.
  if ($B_String[1]) { $Channel[2] = [int]$B_String[1] } else { $Channel[2] = 0 }
  if ($A_String[1]) { $Channel[3] = [int]$A_String[1] } else { $Channel[3] = 0 }

  # Default the depth fail to false.
  $OptiData.DepthFail = $false

  # Loop through all the channels.
  for($i=0; $i -lt $Channel.Length; $i++)
  {
    # See if the bit depth falls between 0 and 8, meaning it must be 1-7 to fail.
    if (($Channel[$i] -gt 0) -and ($Channel[$i] -lt 8))
    {
      # If any of the channels failed to be greater than 8 bit set the depth fail.
      $OptiData.DepthFail = $true

      # Track which channel failed.
      switch ($i)
      {
        '0' { $OptiData.ChannelFailed = 'Red' }
        '1' { $OptiData.ChannelFailed = 'Green' }
        '2' { $OptiData.ChannelFailed = 'Blue' }
        '3' { $OptiData.ChannelFailed = 'Alpha' }
      }
      # Exit the loop so it isn't overwritten if another channel passes.
      break
    }
  }
  # Store if the image has indexed color space.
  $OptiData.Indexed = ([string]$Verbose -match 'Indexed')

  # Return the hash table.
  return $OptiData
}
#==============================================================================================================================================================================================
#  Optimizes a texture with OptiPNG and returns the reduction in Bytes. Input parameter takes a full path to the texture + file extension.

function OptimizeTexture([string]$inputpath, [int]$optimethod)
{
  # Initialize a hash table so multiple values can be returned.
  $OptiResults = @{}

  # Create information of the image before optimization.
  $OldImage = CreateOptiPNGData $inputpath

  # Set up temporary paths to the optimized texture.
  $OptiTempPath    = CreatePath ($TempFolder + '\OptiTemp\')
  $OptiTempTexture = $OptiTempPath + $OldImage.FullName

  # Run OptiPNG and create a new texture in the temp path.
  & $OptiPNGPath ('-o' + $OptiPNGTests) $inputpath -dir $OptiTempPath 2>&1>$null

  # Create information of the image after optimization.
  $NewImage = CreateOptiPNGData $OptiTempTexture

  # -------------------------------------------------------
  # Track whether or not any tests are failed.
  $OptiResults.FailTests = $false

  # Check if the image failed in both indexed color and the depth check.
  if (($OldImage.Indexed) -and ($OldImage.DepthFail))
  {
    Write_Host ' Message    : ' $ConsoleColors Magenta $true
    Write-Host ('Skipped ' + $OldImage.Name + ' (' + $OldImage.ChannelFailed + ' channel less than 8bpp + Indexed)')
    $global:LogMessage = 'Skipped  : ' + $OldImage.ChannelFailed + ' Channel Less Than 8bpp + Indexed'
    $OptiResults.FailTests = $true
  }
  # Check if the image only failed as indexed color space.
  elseif ($OldImage.Indexed)
  {
    Write_Host ' Message    : ' $ConsoleColors Magenta $true
    Write-Host ('Skipped ' + $OldImage.Name + ' (Indexed color space)')
    $global:LogMessage = 'Skipped (Indexed Color Space)'
    $OptiResults.FailTests = $true
  }
  # Check if the image only failed the depth check.
  elseif ($OldImage.DepthFail)
  {
    Write_Host ' Message    : ' $ConsoleColors Magenta $true
    Write-Host ('Skipped ' + $OldImage.Name + ' (' + $OldImage.ChannelFailed + ' channel less than 8bpp)')
    $global:LogMessage = 'Skipped (' + $OldImage.ChannelFailed + ' Channel Less Than 8bpp)'
    $OptiResults.FailTests = $true
  }
  # Check if the new image failed in both indexed color and the depth check.
  elseif (($NewImage.Indexed) -and ($NewImage.DepthFail))
  {
    Write_Host ' Message    : ' $ConsoleColors Magenta $true
    Write-Host ('Skipped ' + $NewImage.Name + ' (Resulting ' + $NewImage.ChannelFailed + ' channel less than 8bpp + Indexed)')
    $global:LogMessage = 'Skipped (Result ' + $OldImage.ChannelFailed + ' Channel Less Than 8bpp + Indexed)'
    $OptiResults.FailTests = $true
  }
  # Check if the new image only failed as indexed color space.
  elseif ($NewImage.Indexed)
  {
    Write_Host ' Message    : ' $ConsoleColors Magenta $true
    Write-Host ('Skipped ' + $NewImage.Name + ' (Result has Indexed color space)')
    $global:LogMessage = 'Skipped (Result Indexed Color Space)'
    $OptiResults.FailTests = $true
  }
  # Check if the new image only failed the depth check.
  elseif ($NewImage.DepthFail)
  {
    Write_Host ' Message    : ' $ConsoleColors Magenta $true
    Write-Host ('Skipped ' + $NewImage.Name + ' (Resulting ' + $NewImage.ChannelFailed + ' channel less than 8bpp)')
    $global:LogMessage = 'Skipped (Result ' + $OldImage.ChannelFailed + ' Channel Less Than 8bpp)'
    $OptiResults.FailTests = $true
  }
  # If any of the above checks failed then fail the texture.
  if ($OptiResults.FailTests)
  {
    # Remove the temp path and send data back to the host function.
    RemovePath $OptiTempPath
    $OptiResults.Reduction = 0
    return $OptiResults
  }
  # -------------------------------------------------------
  # Method 1: Output the optimized texture to a new folder.
  if ($optimethod -eq 1)
  {
    # Create the path to the output texture.
    $OutputPath    = CreatePath ($MasterOutputPath + '\OptimizedTextures' + $Texture.Relative)
    $OutputTexture = $OutputPath + '\' + $NewImage.FullName
  }
  # Method 2: Optimize the files in-place if the user wished it.
  elseif ($optimethod -eq 2)
  {
    # Create the path to the output texture.
    $OutputTexture = $inputpath
  }
  # -------------------------------------------------------
  # Check if there was actually any reduction in file size.
  if ($NewImage.Size -lt $OldImage.Size)
  {
    # Calculate the size difference in Bytes.
    $OptiResults.Reduction = $OldImage.Size - $NewImage.Size

    # Move the optimized texture to the new path.
    Move-Item -LiteralPath $OptiTempTexture -Destination $OutputTexture -Force
  }
  # If there was no reduction....
  else
  {
    # Store that the amount of reduction is zero so it can be returned as 0.
    $OptiResults.Reduction = 0

    # Perform some clean-up if Method 1 was used.
    if ($optimethod -eq 1)
    {
      # Check to see if the folder that the texture was to be copied to is empty.
      if ((Get-ChildItem -LiteralPath $OutputPath | Select-Object -First 1 | Measure-Object).Count -eq 0)
      {
        # If no files are found in the folder then remove it.
        RemovePath $OutputPath
      }
    }
  }
  # -------------------------------------------------------
  # Cleanup the temp texture path.
  RemovePath $OptiTempPath

  # Return the reduction.
  return $OptiResults
}
#==============================================================================================================================================================================================
#  The master function to start optimizing textures. Parameter "$optimethod" defines where to create the texture. 1 - Output Folder, 2 - Overwrite the Texture

function OptimizeWithOptiPNG([int]$optimethod)
{
  # -------------------------------------------------------
  # Make sure to only run this on PNG files.
  if ($Texture.Extension -ne $PNG)
  {
    # Log/Console: Add the logging events.
    SetConsoleMessage 1 'Texture not in PNG format' ''
    $global:LogMessage = 'Skipped (Not PNG)'
    return
  }
  # Do not run this on textures with material maps.
  if ($Texture.HasMaterialMap)
  {
    # Log/Console: Add the logging events.
    SetConsoleMessage 1 'Textures with Material Maps are skipped.' ''
    $global:LogMessage = 'Skipped (Material Map)'
    return
  }
  # -------------------------------------------------------
  Write_Host ' Notice     : ' $ConsoleColors Yellow $true
  Write-Host 'Running texture through OptiPNG. This may take some time....'

  # Optimize the base texture and get the results in a hash table.
  $BaseOptiData = OptimizeTexture $Texture.FullPath $optimethod

  # Store the amount of reduction so far.
  $TotalReduction = $BaseOptiData.Reduction

  # Keep track of the number of mipmaps that may fail the tests.
  $MipMapsFailedTests = 0

  # If the texture is a MipMap, look for MipMap levels and optimize them too.
  if ($Texture.IsMipMap)
  {
    # Create a MipMap hash table.
    $MipMap = CreateMipMapInfo $Texture $Texture.Width $Texture.Height $Texture.Extension

    # Loop through all lower levels.
    for($i=1; $i -le $MipMap.Levels; $i++)
    {
      # If the MipMap level exists, optimize it and store any reduction to the total texture reduction.
      if ($MipMap.Exists[$i])
      {
        # Optimize the mipmap and get the results.
        $MipMapOptiData = OptimizeTexture $MipMap.FullPath[$i] $optimethod

        # Add to the amount of reduction.
        $TotalReduction += $MipMapOptiData.Reduction

        # Store the total number of mipmaps that failed tests.
        if ($MipMapOptiData.FailTests)
        {
          $MipMapsFailedTests += 1
        }
      }
    }
  }
  # -------------------------------------------------------
  # Check to see if the base texture failed the tests.
  if ($BaseOptiData.FailTests)
  {
    # Check if the texture was a mipmap.
    if ($Texture.IsMipMap)
    {
      # See if all mipmaps failed the tests.
      if ($MipMapsFailedTests -eq $MipMap.Levels)
      {
        # If they did, leave now so nothing is logged.
        return
      }
    }
    # It's not a mipmap.
    else
    {
      # If the base texture failed tests then log nothing.
      return
    }
  }
  # -------------------------------------------------------
  # Check to see if there was actually any reduction between the original and custom textures. 
  if ($TotalReduction -gt 0)
  {
    # Log/Console: Increment the total number of optimized textures.
    $global:CountOptimized += 1

    # Log/Console: Display the reduced size in Bytes if it's less than 1 KB.
    if ($TotalReduction -lt 1024)
    {
      SetConsoleMessage 2 'Texture successfully optimized (reduced by ' ($TotalReduction.ToString() + ' Bytes)')
      $global:LogMessage = ('Optimized (' + $TotalReduction.ToString() + ' Bytes)')
    }
    # Log/Console: Display the size in KB if its over or equal to 1 KB.
    else
    {
      $TotalReductionKB = FormatDecimal ($TotalReduction/1024)
      SetConsoleMessage 2 'Texture successfully optimized (reduced by ' ($TotalReductionKB.ToString() + ' KB)')
      $global:LogMessage = ('Optimized (' + $TotalReductionKB.ToString() + ' KB)')
    }
  }
  # Log/Console: If there was no reduction then the texture was already optimized.
  else
  {
    SetConsoleMessage 1 'Texture already optimized.' ''
    $global:LogMessage = 'Already Optimized'
  }
  # Store the total reduction so far in Bytes.
  $global:TotalReductionB += $TotalReduction
}
#==============================================================================================================================================================================================
#  STANDARD OPTION 7: APPLY UPSCALING FILTER TO ALL TEXTURES
#==============================================================================================================================================================================================
#  Applies an upscaling filter to a texture.

function StandardUpscalingFilter([string]$UpscaleFactor, [string]$UpscaledTexture)
{
  # If creating a DDS texture then first generate the texture in a temporary directory.
  if ($Texture.Extension -eq $DDS)
  {
    # Create a temporary path for temporary textures temporarily.
    $TempFilteredPath = CreatePath ($TempFolder + '\TempFiltered')
    $CreatedTexture = $TempFilteredPath + '\' + $Texture.Name + $PNG
  }
  # Otherwise just set the final path to the output path.
  else
  {
    $CreatedTexture = $UpscaledTexture
  }
  # xBRZ was chosen as the filter.
  if ($UpscaleFilter -match 'xBRZ')
  {
    # Store the scaler strength as a parameter for ScalerTest.
    $ScalerStrength = '-' + $UpscaleFilter

    # Rescale the texture with xBRZ.
    & $ScalerTestPath $ScalerStrength $UpscaleBase $CreatedTexture | Out-Null
  }
  # Waifu2x was chosen as the filter.
  elseif ($UpscaleFilter -match 'waifu')
  {
    # Get the Waifu2x directory because CPP needs to run from here.
    $WaifuDir = [string](Get-ChildItem -LiteralPath $Waifu2xPath).Directory

    # Use Waifu2x on the new tiled image. Waifu2x-CPP only wants to run from its current location so push to the containing folder.
    Push-Location -LiteralPath $WaifuDir
    & $Waifu2xPath -i $UpscaleBase -m $Waifu2xCMode.ToLower() --scale_ratio $UpscaleFactor --noise_level $Waifu2xNoise $wf2xModelA $wf2xModelB $wf2xOpenCL $wf2xNoGpuA $wf2xNoGpuB -o $CreatedTexture | Out-Null
    Pop-Location
  }
  # All other filtering techniques are handled with ImageMagick.
  else
  {
    # ImageMagick takes the size in the form of a percentage so calculate that now.
    $NewScale = ([int]$UpscaleFactor * 100).ToString() + '%'

    # Rescale the texture and apply the filter set by the user.
    & $IMConvert -quiet $UpscaleBase -filter $UpscaleFilter -resize $NewScale $CreatedTexture
  }
  # If creating a DDS texture more stuff needs to be done...
  if ($Texture.Extension -eq $DDS)
  {
    # Create a texture hash table from the result so it can easily be converted to DDS.
    $DDSTexture = CreateTextureInfo (Get-ChildItem -LiteralPath $CreatedTexture)

    # Create the DDS texture.
    $TextureCreated = CreateStandardTexture $DDSTexture $DDSTexture.Width $DDSTexture.Height $DDS $UpscaledPath
  }
  # If filtering PNG or DDS, simply test the path to the filtered texture and generate mipmaps for the texture if its a MipMap texture.
  elseif (TestPath $CreatedTexture)
  {
    # The texture exists so it has been created.
    $TextureCreated = $true

    # No point in doing any of the below if its not a mipmap texture.
    if ($Texture.IsMipMap)
    {
      # Create a temporary path to copy the result to.
      $TempFilteredPath = CreatePath ($TempFolder + '\TempFiltered')
      $TemporaryTexture = $TempFilteredPath + '\' + $Texture.FullName

      # Copy the texture a temporary folder to create mipmaps from.
      Copy-Item -LiteralPath $CreatedTexture -Destination $TemporaryTexture -Force

      # Create a texture hash table from the result so mipmaps can be generated.
      $PNGTexture = CreateTextureInfo (Get-ChildItem -LiteralPath $TemporaryTexture)

      # Create the mipmaps.
      CreatePNGMipMaps $PNGTexture $PNGTexture.Width $PNGTexture.Height $PNG $UpscaledPath
    }
  }
  # Clean up the temporary files and folders.
  RemovePath $TempFilteredPath

  # Return that the texture was actually created.
  return $TextureCreated
}
#==============================================================================================================================================================================================
#  Applies an upscaling filter to a texture using a special method to preserve the edges of seamless textures.

function SeamlessUpscalingFilter([string]$UpscaleFactor, [string]$NewWidth, [string]$NewHeight, [string]$UpscaledTexture)
{
  # Tracks whether or not the final texture was created.
  $TextureCreated = $false

  # Create a temporary path for temporary textures temporarily.
  $TempFilteredPath = CreatePath ($TempFolder + '\TempFiltered')

  # Set the paths to temporary files and the final result.
  $MontyPath  = $TempFilteredPath + '\montage.png'
  $SlicePath  = $TempFilteredPath + '\sliced.png'
  $FilterPath = $TempFilteredPath + '\filtered.png'
  $ResultPath = $TempFilteredPath + '\result.png'

  # Get the width and height of the image after using montage.
  $MontageWidth  = [int]$Texture.Width * 3
  $MontageHeight = [int]$Texture.Height * 3

  # Get the % of the amount of pixels to crop by multiplying by the seamless factor and removing the last digit.
  $WidthCropMontage  = (FormatDecimal ($Texture.Width * [decimal]$SeamlessFactor)).Split('.',2)
  $HeightCropMontage = (FormatDecimal ($Texture.Height * [decimal]$SeamlessFactor)).Split('.',2)

  # Get the amount of the image to keep from the montage at normal size.
  $WidthKeepTotal  = [string]($MontageWidth - ([int]$WidthCropMontage[0] * 2))
  $HeightKeepTotal = [string]($MontageHeight - ([int]$HeightCropMontage[0] * 2))

  # Get the amount left over after cropping.
  $WidthLeftover  = $Texture.Width - $WidthCropMontage[0]
  $HeightLeftover = $Texture.Height - $HeightCropMontage[0]

  # Get the remaining % to crop, but it is now upscaled to multiply by the new scale.
  $WidthLeftoverFiltered  = $WidthLeftover * [int]$UpscaleFactor
  $HeightLeftoverFiltered = $HeightLeftover * [int]$UpscaleFactor

  # Create an image using the same image 9 times with ImageMagick.
  & $IMMontage $IM7Montage -geometry '+0+0' -background none $UpscaleBase $UpscaleBase $UpscaleBase $UpscaleBase $UpscaleBase $UpscaleBase $UpscaleBase $UpscaleBase $UpscaleBase $MontyPath

  # Set the geometry parameter for ImageMagick to crop the image with offsets.
  $CropGeometry = $WidthKeepTotal + 'x' + $HeightKeepTotal + '+' + $WidthCropMontage[0] + '+' + $HeightCropMontage[0]

  # Crop the center image with some overhang from the tiled image.
  & $IMConvert -quiet $MontyPath -crop $CropGeometry '+repage' $SlicePath

  # xBRZ was chosen as the filter.
  if ($UpscaleFilter -match 'xBRZ')
  {
    # Store the scaler strength as a parameter for ScalerTest.
    $ScalerStrength = '-' + $UpscaleFilter

    # Rescale the texture with xBRZ.
    & $ScalerTestPath $ScalerStrength $SlicePath $FilterPath | Out-Null
  }
  # Waifu2x was chosen as the filter.
  elseif ($UpscaleFilter -match 'waifu')
  {
    # Get the waifu2x directory because CPP needs to run from here.
    $WaifuDir = [string](Get-ChildItem -LiteralPath $Waifu2xPath).Directory

    # Use waifu2x on the new tiled image. Waifu2x-CPP only wants to run from its current location so push to the containing folder.
    Push-Location -LiteralPath $WaifuDir
    & $Waifu2xPath -i $SlicePath -m $Waifu2xCMode.ToLower() --scale_ratio $UpscaleFactor --noise_level $Waifu2xNoise $wf2xModelA $wf2xModelB $wf2xOpenCL $wf2xNoGpuA $wf2xNoGpuB -o $FilterPath | Out-Null
    Pop-Location
  }
  # Were using a standard filter boyz.
  else
  {
    # ImageMagick takes the size in the form of a percentage so calculate that now.
    $NewScale = ([int]$UpscaleFactor * 100).ToString() + '%'

    # Rescale the texture and apply the filter set by the user.
    & $IMConvert -quiet $SlicePath -filter $UpscaleFilter -resize $NewScale $FilterPath | Out-Null
  }
  # Check for only "noise" in the waifu2x mode.
  if (($UpscaleFilter -match 'waifu') -and ($Waifu2xCMode -eq 'Noise'))
  {
    # For noise only mode, use the original texture dimensions.
    $CropGeometry = $Texture.Width.ToString() + 'x' + $Texture.Height.ToString() + '+' + $WidthLeftover + '+' + $HeightLeftover
  }
  # This path is hit when using any filter other than waifu2x in noise mode.
  else
  {
    # For anything else, crop using the new dimensions.
    $CropGeometry = $NewWidth + 'x' + $NewHeight + '+' + $WidthLeftoverFiltered.ToString() + '+' + $HeightLeftoverFiltered.ToString()
  }
  # Crop the center image from the tiled image.
  & $IMConvert -quiet $FilterPath -crop $CropGeometry '+repage' $ResultPath

  # If the original texture was DDS then convert it back to DDS.
  if ($Texture.Extension -eq $DDS)
  {
    # Path to the renamed texture so texture info can be created.
    $RenamedPath = $TempFilteredPath + '\' + $Texture.Name + $PNG

    # Rename the texture using Move-Item so it can be compatible with PowerShell v2.
    Move-Item -LiteralPath $ResultPath -Destination $RenamedPath -Force

    # Create a texture hash table from the result so it can easily be converted to DDS.
    $DDSTexture = CreateTextureInfo (Get-ChildItem -LiteralPath $RenamedPath)

    # Create the DDS texture.
    $TextureCreated = CreateStandardTexture $DDSTexture $NewWidth $NewHeight $DDS $UpscaledPath
  }
  # If filtering PNG or DDS, mipmaps need to be generated if its a MipMap texture.
  else
  {
    # Path to the renamed texture so resulting texture can be renamed and texture info can be created.
    $RenamedPath = $TempFilteredPath + '\' + $Texture.Name + $PNG

    # Rename the texture using Move-Item so it can be compatible with PowerShell v2.
    Move-Item -LiteralPath $ResultPath -Destination $RenamedPath -Force

    # Copy the generated texture to the output path. This is the final step for the top level.
    Copy-Item -LiteralPath $RenamedPath -Destination $UpscaledTexture -Force

    # No point in doing any of the below if its not a mipmap texture.
    if ($Texture.IsMipMap)
    {
      # Create a texture hash table from the result so mipmaps can be generated.
      $PNGTexture = CreateTextureInfo (Get-ChildItem -LiteralPath $RenamedPath)

      # Create the mipmaps.
      CreatePNGMipMaps $PNGTexture $PNGTexture.Width $PNGTexture.Height $PNG $UpscaledPath
    }
    # Make sure the texture now exists in the path it was supposed to be moved to.
    if (TestPath $UpscaledTexture)
    {
      $TextureCreated = $true
    }
  }
  # Clean up the temporary files and folders.
  RemovePath $TempFilteredPath

  # Return that the texture was actually created.
  return $TextureCreated
}
#==============================================================================================================================================================================================
#  The function that is ran from the main loop which sets up data for the above function.

function ApplyUpscalingFilter()
{
  # Do not run this on enormous textures.
  if (($Texture.Width -gt 4096) -or ($Texture.Height -gt 4096))
  {
    # Log/Console: Add the logging events.
    Write_Host ' Notice     : ' $ConsoleColors Magenta $true
    Write-Host 'Texture exceeds the limit of 4096x4096 so it will not be upscaled!'
    $global:LogMessage = 'Dimensions Exceed 4096x4096'
    return
  }
  # Make sure the directory to create rescaled textures exists.
  $UpscaledPath = CreatePath ($MasterOutputPath + '\FilteredTextures(' + $UpscaleFilter + ')' + $Texture.Relative)

  # Create a temporary PNG image if it's a DDS texture.
  if ($Texture.Extension -eq $DDS)
  {
    # Make sure DDS Utilities is installed.
    if (!$NVDXT_Exists)
    {
      # If it doesn't then display to the console that the texture won't be created.
      Write_Host ' Notice     : ' $ConsoleColors Magenta $true
      Write-Host 'Nvidia DDS Utilities was not found! It must be installed to create DDS textures.'
      return
    }
    # Do not attempt to filter Ishiiruka DDS textures.
    if ($Texture.HasMaterialMap)
    {
      Write_Host ' Notice     : ' $ConsoleColors Magenta $true
      Write-Host 'Ishiiruka DDS textures cannot have upscaling filters applied!'
      return
    }
    # Create a temporary folder to create a PNG file from the image.
    $TempUpscalePath = CreatePath ($TempFolder + '\TempConvert')
    $UpscaleBase = $TempUpscalePath + '\' + $Texture.Name + $PNG

    # Create the temporary texture.
    & $IMConvert -quiet $Texture.FullPath $UpscaleBase

    # Make the final texture in DDS format.
    $UpscaledTexture = $UpscaledPath + '\' + $Texture.Name + $DDS
  }
  # If it's a PNG or JPG image then use the base texture.
  else
  {
    # Use the existing texture in the pack as a base.
    $UpscaleBase = $Texture.FullPath

    # Make the final texture in PNG format.
    $UpscaledTexture = $UpscaledPath + '\' + $Texture.Name + $PNG
  }
  # Store the amount of scaling which will be used instead of the actual amount in functions because it can change below.
  $UpscaleFactor = $FilterNewScale

  # Calculate the new width/height which is determined by the scaling factor.
  $NewWidth  = $Texture.Width * [int]$UpscaleFactor
  $NewHeight = $Texture.Height * [int]$UpscaleFactor

  # Check to make sure we're not creating textures larger than 8192x8192.
  if (($NewWidth -gt 8192) -or ($NewHeight -gt 8192))
  {
    # Choose the greater of the two dimensions to find the new scaling value.
    $DimensionCheck  = [math]::max($Texture.Width, $Texture.Height)
    $DimensionResult = [math]::max($NewWidth, $NewHeight)

    # Find a lower scaling value.
    while($DimensionResult -gt 8192)
    {
      # Each iteration decrements the scale by 1x. We want this in string format for functions...
      $UpscaleFactor = ([int]$UpscaleFactor - 1).ToString()

      # Calculate the new dimension to see if it passes the condition to end the loop.
      $DimensionResult = $DimensionCheck * [int]$UpscaleFactor
    }
    # Make sure the upscaling factor is actually worth our time.
    if ([int]$UpscaleFactor -gt 1)
    {
      # Report to the user the texture will have a reduced upscaling value.
      Write_Host ' Notice     : ' $ConsoleColors Magenta $true
      Write-Host ('A resulting dimension exceeded 8192! Using a smaller scaling value (' + $UpscaleFactor + 'x).')
    }
    # If the upscale factor failed to be greater than 1x.
    else
    {
      # Report to the user that an upscaling filter will not be applied.
      Write_Host ' Notice     : ' $ConsoleColors Magenta $true
      Write-Host 'Texture is too large to apply an upscaling value!'
      return
    }
    # Calculate the new width/height which is determined by the scaling factor.
    $NewWidth  = $Texture.Width * [int]$UpscaleFactor
    $NewHeight = $Texture.Height * [int]$UpscaleFactor
  }
  # Apply the seamless technique if the user desires.
  if (($SeamlessMethod -eq 'All') -or (($SeamlessMethod -eq 'Opaque') -and (!$Texture.HasTransparency)))
  {
    $TextureCreated = SeamlessUpscalingFilter $UpscaleFactor $NewWidth $NewHeight $UpscaledTexture
  }
  # Otherwise just upscale the texture using the standard method.
  else
  {
    $TextureCreated = StandardUpscalingFilter $UpscaleFactor $UpscaledTexture
  }
  # This is a comment. Comments show up in green text. This comment says that the line below stores info about the new texture.
  $FilterResult = ($UpscaleFactor + 'x, ' + $NewWidth.ToString() + 'x' + $NewHeight.ToString() + ', ' + $UpscaleFilter)

  # Log/Console: Report that the texture has been created.
  if ($TextureCreated)
  {
    # Log/Console: Add the logging events.
    SetConsoleMessage 1 ('Successfully upscaled the texture (' + $FilterResult + ')!') ''
    $global:LogMessage = ('Filtered (' + $FilterResult + ')')
  }
  # Log/Console: If the texture was not created, report an error.
  else
  {
    # Log/Console: Add the logging events.
    SetConsoleMessage 0 'Texture failed creation and was not upscaled!' ''
    $global:LogMessage = 'Failed Creation'
  }
  # If the texture was DDS this will need to be cleaned.
  RemovePath $TempUpscalePath
}
#==============================================================================================================================================================================================
#  ADVANCED OPTION 1: GENERATE NEW MIPMAPS
#==============================================================================================================================================================================================
#  Generates new mipmaps within the texture pack itself.

function GenerateNewMipMaps()
{
  # Do not even run any code here if the texture is not a MipMap.
  if (!$Texture.IsMipMap)
  {
    # Log/Console: Add the logging events.
    SetConsoleMessage 1 'Texture is not a MipMap [m] texture.' ''
    $global:LogMessage = 'Not MipMap'
    return
  }
  # If the texture is a DDS texture make sure DDS Utilities is installed.
  if (($Texture.Extension -eq $DDS) -and (!$NVDXT_Exists))
  {
    Write_Host ' Notice     : ' $ConsoleColors Magenta $true
    Write-Host 'Nvidia DDS Utilities was not found! It must be installed to create DDS textures.'
    return
  }
  # Create a temporary folder to generate the MipMaps to.
  $TempForceMipMapsPath = CreatePath ($TempFolder + '\TempForceMipMaps')

  # Create the converted texture. The below function will automatically handle creating mipmaps.
  $MipMappedTexture = CreateTexture $Texture $Texture.Width $Texture.Height $Texture.Extension $TempForceMipMapsPath

  # Loop through all textures in the current directory.
  foreach($subfile in Get-ChildItem -LiteralPath $Texture.Path)
  {
    # Check to see if the current texture name is similar to the target texture name.
    if ($subfile.BaseName -like ($Texture.Name + '*'))
    {
      # Remove the texture/MipMap.
      $RemoveFile = [string]$subfile.Directory + '\' + $subfile.Name
      RemovePath $RemoveFile
    }
  }
  # Loop through all textures found in the temp MipMap directory.
  foreach($subfile in Get-ChildItem -LiteralPath $TempForceMipMapsPath)
  {
    # Check to see if the current texture name is similar to the target texture name.
    if ($subfile.BaseName -like ($Texture.Name + '*'))
    {
      # Move the texture/MipMap to the current texture path.
      $MoveFile = [string]$subfile.Directory + '\' + $subfile.Name
      Move-Item -LiteralPath $MoveFile -Destination $Texture.Path -Force
    }
  }
  # Log/Console: Report that the texture has been created.
  if ($MipMappedTexture)
  {
    # Increment the counting variable.
    $global:CountMipMapped += 1

    # Log/Console: Add the logging events.
    Write_Host ' Message    : ' $ConsoleColors Green $true
    Write-Host 'Generated new mipmaps for this texture!'
    $global:LogMessage = 'MipMaps Generated'
  }
  # Log/Console: If the texture was not created, report an error.
  else
  {
    # Log/Console: Add the logging events.
    Write_Host ' Message    : ' $ConsoleColors Red $true
    Write-Host 'Failed creating mipmaps for this texture!'
    $global:LogMessage = 'MipMaps Failed'
  }
  # Cleanup the temporary textures.
  RemovePath $TempForceMipMapsPath
}
#==============================================================================================================================================================================================
#  ADVANCED OPTION 2: REMOVE INVALID MIPMAPS
#==============================================================================================================================================================================================
#  Removes mipmaps from textures that aren't actually mipmap textures.

function RemoveInvalidMipMaps()
{
  # We only want to work with textures that are not mipmap textures.
  if ($Texture.IsMipMap)
  {
    # Log/Console: Add the logging events.
    SetConsoleMessage 1 'OK' ''
    $global:LogMessage = 'OK'
    return
  }
  # Count for the number of bad MipMaps.
  $InvalidMipMaps = 0
  $InvalidInternal = 0

  # Loop through all textures in the current directory.
  foreach($subfile in Get-ChildItem -LiteralPath $Texture.Path)
  {
    # Check to see if the texture name is similar to the current loop texture.
    if ($subfile.Name -like ($Texture.Name + '*' + $Texture.Extension))
    {
      # Split the texture name into 6 slots.
      $subfileSplit = $subfile.BaseName.Split('_.',6)

      # Loop through slot 5 (detects non-mipmaps) and slot 6 (detects paletted non-mipmaps).
      for($x=4; $x -lt 6; $x++)
      {
        # Are we deep enough yet? If it exists, then check the first letter for "m" (which is extracted from "mip").
        if (($subfileSplit[$x]) -and ($subfileSplit[$x].Substring(0,1) -eq 'm'))
        {
          # Balls deep. If it passes, remove the file.
          RemovePath ($Texture.Path + '\' + $subfile)

          # Console: Update the console with the texture that was removed.
          Write_Host ' Removed    : ' $ConsoleColors Red $true
          Write-Host $subfile

          # Track that MipMaps were deleted and count how many.
          $DeletedMipMaps = $true
          $InvalidMipMaps ++
        }
      }
    }
  }
  # If dealing with a DDS texture, remove any internal mipmaps if present.
  if (($Texture.Extension -eq $DDS))
  {
    # Make sure DDS Utilities exists.
    if ($NVDXT_Exists)
    {
      # Create a folder to extract MipMaps to.
      $ExtractedPath = CreatePath ($TempFolder + '\Extracted')

      # Extract MipMaps from the texture to see if it has internal MipMaps.
      ExtractInternalDDSMipMaps $Texture.FullPath $ExtractedPath

      # Count the number of files that remain in the folder, and subtract 1 to compensate for the top level.
      $InvalidInternal = ((Get-ChildItem -LiteralPath $ExtractedPath | Where-Object {!$_.PSIsContainer} | Measure-Object).Count) - 1

      # Check if there are internal mipmaps.
      if ($InvalidInternal -gt 0)
      {
        # If there was, create a path to the extracted top level that does not contain internal mipmaps.
        $ExtractedTexture = $ExtractedPath + '\' + $Texture.FullName

        # Overwrite the texture in the pack that has internal mipmaps with the texture that does not have internal mipmaps.
        Move-Item -LiteralPath $ExtractedTexture -Destination $Texture.Path -Force

        # Track that MipMaps were deleted.  
        $DeletedInternal = $true

        # Console: Update the console saying mipmaps were removed.
        Write-Host (' Removed    : ' + $InvalidInternal + ' invalid internal mipmaps.') -ForegroundColor Green
      }
      # Remove the temporary directory and all extracted mipmaps.
      RemovePath $ExtractedPath
    }
    else
    {
      Write_Host ' Notice     : ' $ConsoleColors Magenta $true
      Write-Host 'Nvidia DDS Utilities was not found! It must be installed to work with "Internal MipMaps".'
    }
  }
  # Check to see if MipMaps were deleted.
  if ($DeletedMipMaps -or $DeletedInternal)
  {
    # Count the number of textures with invalid mipmaps.
    $global:CountInvalidMips += 1

    # If both types of mipmaps were deleted, then display the number of both.
    if (($DeletedMipMaps) -and ($DeletedInternal))
    {
      $global:LogMessage = ('Removed ' + $InvalidMipMaps + ' Invalid MipMaps, Removed ' + $InvalidInternal + ' Invalid Internal MipMaps')
    }
    # If only external mipmaps were deleted then show those.
    elseif ($DeletedMipMaps)
    {
      $global:LogMessage = ('Removed ' + $InvalidMipMaps + ' Invalid MipMaps')
    }
    # Last possible situation is internal mipmaps were deleted.
    else
    {
      $global:LogMessage = ('Removed ' + $InvalidInternal + ' Invalid Internal MipMaps')
    }
  }
  # No MipMaps were deleted.
  else
  {
    # Log/Console: Because no MipMaps were removed, update both the console and log saying that the texture is ok.
    SetConsoleMessage 1 'OK' ''
    $global:LogMessage = 'OK'
  }
}
#==============================================================================================================================================================================================
#  ADVANCED OPTION 3: REMOVE ALPHA CHANNEL FROM OPAQUE TEXTURES
#==============================================================================================================================================================================================
#  Recreates a texture that has an alpha channel but doesn't actually contain transparent pixels, into a texture that does not have an alpha channel.

function RemoveAlphaChannel()
{
  # Fuck JPG don't do anything with it.
  if ($Texture.Extension -eq $JPG)
  {
    # Log/Console: Report stuff.
    Write_Host ' Message    : ' $ConsoleColors Yellow $true
    Write-Host 'JPG textures can not have transparency so they are skipped.'
    $global:LogMessage = 'Skipped (JPG Format)'
    return
  }
  # Check if there are no transparent pixels.
  if (!$Texture.HasTransparency)
  {
    # Set up the temporary paths.
    $TempPath    = CreatePath ($TempFolder + '\Repaired\')
    $TempTexture = $TempPath + $Texture.FullName

    # PNG is easy, simply generate it without alpha.
    if ($Texture.Extension -eq $PNG)
    {
      # Create the texture without an alpha channel.
      & $IMConvert -quiet $Texture.FullPath -alpha off $TempTexture
    }
    # The function "CreateStandardTexture" automatically handles alpha in DDS files. 
    elseif ($Texture.Extension -eq $DDS)
    {
      # Because it was meant to return something, and this is an unusual but effective use, store it in a random variable to avoid the result spilling over.
      $Pumpkin = CreateStandardTexture $Texture $Texture.Width $Texture.Height $DDS $TempPath
    }
    # Make sure the texture was created.
    if (TestPath $TempTexture)
    {
      # Count the number of textures that had their alpha channel removed.
      $global:CountSlicedAlpha += 1

      # Move the result to the output path.
      Move-Item -LiteralPath $TempTexture -Destination $Texture.FullPath -Force

      # Log/Console: Report stuff.
      Write_Host ' Notice     : ' $ConsoleColors Green $true
      Write-Host 'Alpha channel successfully removed from opaque texture!'
      $global:LogMessage = 'Alpha Removed'
    }
    # Destroy the temporary path.
    RemovePath $TempPath
  }
  # Texture has both transparency + alpha, or no transparency + no alpha.
  else
  {
    # Log/Console: Report stuff.
    SetConsoleMessage 1 'OK' ''
    $global:LogMessage = 'OK'
  }
}
#==============================================================================================================================================================================================
#  ADVANCED OPTION 4: FIX TEXTURES POTENTIALLY BROKEN BY OPTIPNG
#==============================================================================================================================================================================================
# Repairs textures that could have broken by OptiPNG that have less than 8-bit depth on each channel.

function FixBadOptiPNGTexture()
{
  # We gun dun fix dat dere texture if broke.
  $FixBrokenTexture = $false

  # We don't want to fuck with Ishiiruka textures.
  if ($Texture.HasMaterialMap)
  {
    SetConsoleMessage 2 'Skipped: Ishiiruka textures are ignored for this option.' ''
    $global:LogMessage = 'OK'
    return
  }
  # We only want to work with textures that are in PNG format.
  if ($Texture.Extension -ne $PNG)
  {
    SetConsoleMessage 2 'Skipped: Texture is not in PNG format.' ''
    $global:LogMessage = 'OK'
    return
  }
  # Create an OptiPNG hash table.
  $OptiData = CreateOptiPNGData $Texture.FullPath

  # Check if the image failed in both indexed color and the depth check.
  if (($OptiData.Indexed) -and ($OptiData.DepthFail))
  {
    Write_Host ' Message    : ' $ConsoleColors Green $true
    Write-Host ('Texture Repaired! (' + $OptiData.ChannelFailed + ' Channel Less Than 8bpp + Indexed Color Space)')
    $global:LogMessage = 'Repaired: ' + $OptiData.ChannelFailed + ' Channel Less Than 8bpp + Indexed'
    $FixBrokenTexture = $true
  }
  # Check if the image only failed as indexed color space.
  elseif ($OptiData.Indexed)
  {
    Write_Host ' Message    : ' $ConsoleColors Green $true
    Write-Host 'Texture Repaired! (Indexed Color Space)'
    $global:LogMessage = 'Repaired: Indexed Found'
    $FixBrokenTexture = $true
  }
  # Check if the image only failed the depth check.
  elseif ($OptiData.DepthFail)
  {
    Write_Host ' Message    : ' $ConsoleColors Green $true
    Write-Host ('Texture Repaired! (' + $OptiData.ChannelFailed + ' Channel Less Than 8bpp)')
    $global:LogMessage = 'Repaired: ' + $OptiData.ChannelFailed + ' Channel Less Than 8bpp'
    $FixBrokenTexture = $true
  }
  # Texture failed checks so attempt to "repair" it.
  if ($FixBrokenTexture)
  {
    # Set up the temporary paths.
    $TempPath    = CreatePath ($TempFolder + '\Repaired\')
    $TempTexture = $TempPath + $Texture.FullName

    # Get information about the current PNG.
    $PNGData = CreatePNGData $Texture

    # Create the texture in the temporary directory.
    & $IMConvert -quiet $Texture.FullPath -define ('png:color-type=' + $PNGData.ColorType) $TempTexture

    # Remove the old texture.
    RemovePath $Texture.FullPath

    # Move the temp texture to the texture path.
    Move-Item -LiteralPath $TempTexture -Destination $Texture.FullPath -Force

    # Count the number of textures repaired.
    $global:CountRepairOptiPNG += 1
  }
  # The texture is fine.
  else
  {
    SetConsoleMessage 1 'OK' ''
    $global:LogMessage = 'OK'
  }
}
#==============================================================================================================================================================================================
#  MASTER LOOP: COPY NON-TEXTURES
#==============================================================================================================================================================================================
#  Set of conditions to check whether or not to copy a "non-texture file" when using Options 5 or 6.

function CheckNonTextureFile($file)
{
  # Only copy non-texture files if the user is converting or rescaling a pack.
  if (($MasterOperation -eq 'ForceIntScaling') -or ($MasterOperation -eq 'ConvertTextures'))
  {
    # Check to see if a folder snuck its way in or some (bug?) that has no file name or path.
    if ((!$file.PSIsContainer) -and ($file.Name.Length -gt 0))
    {
      # Set up the series of checks in a variable array.
      $CopyCheck = New-Object bool[] 12

      # Go through and store the result of each check into the array.
      $CopyCheck[0]  = ($file.DirectoryName -like '*~*')          # - Verify that the file is not in a generated directory.
      $CopyCheck[1]  = ($file.Name -like 'tex1*.png')           # - Verify that it's not a Dolphin PNG texture.
      $CopyCheck[2]  = ($file.Name -like 'tex1*.dds')           # - Verify that it's not a Dolphin DDS texture.
      $CopyCheck[3]  = ($file.Name -like 'tex1*.jpg')           # - Verify that it's not a Dolphin JPG texture.
      $CopyCheck[4]  = ($file.Extension -eq '.log')           # - Verify that it's not this script's log file (.txt files can still pass).
      $CopyCheck[5]  = ($file.Extension -eq '.ps1')           # - Verify that it's not a PowerShell script.
      $CopyCheck[6]  = ($file.Name -eq 'thumbs.db')           # - Verify that it's not a Windows thumbnail database file.
      $CopyCheck[7]  = ($file.Name -eq 'nvdxt_scratch.tmp')       # - Verify that it's not a leftover DDS Utilities file.
      $CopyCheck[8]  = ($file.Name -eq 'desktop.ini')           # - Verify that it's not a Windows desktop ini file.
      $CopyCheck[9]  = ($file.Name -eq 'CTT-PS Changelog.txt')      # - Verify that it's not the CTT-PS changelog.
      $CopyCheck[10] = ($file.Name -eq 'PS.Execution.Policy.Changer.bat') # - Verify that it's not the policy changer batch script.
      $CopyCheck[11] = ($file.Name -like 'Custom Texture Tool PS')    # - Verify that it has nothing to do with Custom Texture Tool (like the log file).

      # Loop through each check to see if the file should not be copied.
      foreach($Check in $CopyCheck)
      {
        # Test if the check has passed.
        if ($Check)
        {
          # Return false so the file will not be copied.
          return $false
        }
      }
      # If all conditions passed then copy the file.
      return $true
    }
  }
  # If it didn't pass the initial checks then do not copy the file.
  return $false
}
#==============================================================================================================================================================================================
#  Copies a "non-texture file" if it passes all the checks in the above function.

function AttemptCopyNonTextureFile($file)
{
  # Perform rigorous testing to see if the file should be copied.
  if (($CopyNonTextures) -and (CheckNonTextureFile $file))
  {
    # Check to see if Rescale Textures was enabled (which references the current output folder).
    if ($MasterOperation -eq 'ForceIntScaling')
    {
      # Checks if the user did not force converting to a certain format (PNG/DDS/JPG).
      if ($RescaleFormat -eq $null)
      {
        # If a format was not forced, simply use the folder name "RescaledTextures".
        $TempPath = '\RescaledTextures'
      }
      # If the user forced to convert to a certain format (PNG/DDS/JPG).
      else
      {
        # If a format was forced, include the format in the folder name.
        $FileType = ExtensionToText $RescaleFormat
        $TempPath = '\RescaledTextures (' + $FileType + ')'
      }
    }
    # Check to see if Convert Texture Format was enabled (which references the current output folder).
    elseif ($MasterOperation -eq 'ConvertTextures')
    {
      # Include the format in the output folder.
      $FileType = ExtensionToText $ConvertFormat
      $TempPath = '\ConvertedTextures (' + $FileType + ')'
    }
    # Create the folder structure of where the file should go.
    $Relative = $file.DirectoryName.Replace($MasterInputPath,'')
    $NTFolder = (Get-Location | Get-Item).Name
    $FullPath = [string]$file.Directory + '\' + $file
    $CopyPath = CreatePath ($MasterOutputPath + $TempPath + $Relative)

    # Copy the file into the new location.
    Copy-Item -LiteralPath $FullPath -Destination $CopyPath -Force

    # Log/Console: Display that the file has been copied.
    Write_Host ' File       : ' $ConsoleColors Yellow $true
    Write-Host $file -ForegroundColor Red
    Write_Host ' Path       : ' $ConsoleColors Yellow $true
    Write-Host ($NTFolder + $Relative)
    Write_Host ' Message    : ' $ConsoleColors Yellow $true
    Write-Host 'Non-texture file copied to ' -NoNewline
    Write-Host ($TempPath + $Relative) -ForegroundColor Green
    Write_Host '-----------------------------------------------------------------------------------------------------------------------' $ConsoleColors Gray $false
  }
}
#==============================================================================================================================================================================================
#  MASTER LOOP: TITLE BAR PROGRESS
#==============================================================================================================================================================================================
#  Counts the number of textures in a pack, which does not include the number of mipmaps or material maps.

function CountTexturesToProcess()
{
  # Keep track of the number of textures counted. Default to 0 for aesthetic value if zero textures are found (so title bar properly displays 0/0).
  $TotalTextures = 0

  # Force the title bar to display that the length of time is being calculated.
  $host.UI.RawUI.WindowTitle = ($ScriptName + ' - Calculating...')

  # Without Allow All Images, we only want to find Dolphin type textures.
  if (!$AllowAllImages)
  {
    # Add the filter 'tex1' to distinguish Dolphin textures from other images.
    $TexFilter = '*tex1'
  }
  # Get the Input Path and all directories/sub-directories found within the Input Path.
  $Directories = @($MasterInputPath)
  $Directories += [System.IO.Directory]::GetDirectories($MasterInputPath, '*', 'AllDirectories')

  # Loop through all folders found in the collection.
  foreach($FolderPath in $Directories)
  {
    # Omit any folders that contain the ~ symbol.
    if ($FolderPath -notlike '*~*')
    {
      # Build the collection of files within that folder.
      $FileCollection = @()
      $FileCollection += [System.IO.Directory]::GetFiles($FolderPath, ($TexFilter + '*.png'))
      $FileCollection += [System.IO.Directory]::GetFiles($FolderPath, ($TexFilter + '*.dds'))
      $FileCollection += [System.IO.Directory]::GetFiles($FolderPath, ($TexFilter + '*.jpg'))

      # Loop through all files within the collection. We don't want Dolphin textures that are mipmaps, material maps, or material textures.
      foreach($TexFile in $FileCollection)
      {
        # Stacking conditions like this is ugly, but piling all the conditions into a single condition is by far the fastest method (I benchmarked it). 
        if (($TexFile -notlike '*tex1*_mip*') -and ($TexFile -notlike '*tex1*.mat*') -and ($TexFile -notlike '*tex1*.nrm*') -and ($TexFile -notlike '*.bump*') -and ($TexFile -notlike '*.spec*') -and ($TexFile -notlike '*.lum*'))
        {
          # If the texture passed all checks, increment the texture count.
          $TotalTextures ++
        }
      }
    }
  }
  # The title bar won't be updated again until the first file is processed, so force the title bar to display file 0 and 0% before executing the loop.
  $host.UI.RawUI.WindowTitle = ($ScriptName + $TitleBarMessage + 'Texture: '  + '0/' + $TotalTextures + ' (0%)')

  # Return the total number of textures that will be processed by the main loop.
  return $TotalTextures
}
#==============================================================================================================================================================================================
#  Before updating the title bar percentage, make sure a texture is: not in a ~ folder, a valid texture, not a mipmap level, and not any kind of material.

function CheckUpdateTitleBar($file)
{
  # Resolve this now and store in a variable so it doesn't have to be resolved multiple times.
  $FileName = $file.Name

  # Set up the series of checks in a variable array.
  $UpdateCheck = New-Object bool[] 9

  # We only want images, but we don't want Dolphin textures that are mipmaps, material maps, or material textures.
  $UpdateCheck[0] = (($FileName -notlike '*.png') -and ($FileName -notlike '*.dds') -and ($FileName -notlike '*.jpg'))
  $UpdateCheck[1] = ((!$AllowAllImages) -and ($FileName -notlike 'tex1*'))
  $UpdateCheck[2] = ($file.FullName -like '*~*')
  $UpdateCheck[3] = ($FileName -like '*tex1*_mip*')
  $UpdateCheck[4] = ($FileName -like '*tex1*.mat*')
  $UpdateCheck[5] = ($FileName -like '*tex1*.nrm*')
  $UpdateCheck[6] = ($FileName -like '*.bump*')
  $UpdateCheck[7] = ($FileName -like '*.spec*')
  $UpdateCheck[8] = ($FileName -like '*.lum*')

  # Loop through each check.
  foreach($Check in $UpdateCheck)
  {
    # Test if the check has passed.
    if ($Check)
    {
      # Return false so the title bar will not be updated.
      return $false
    }
  }
  # If all conditions passed then update the title bar.
  return $true
}
#==============================================================================================================================================================================================
#  Updates the title bar with progress.

function AttemptUpdateTitleBar($file, [int]$TotalFiles)
{
  # Check to see if the title bar should be updated.
  if (CheckUpdateTitleBar $file)
  {
    # Increment the number of textures processed in the loop.
    $global:CountProcessed += 1

    # Find the absolute value and convert it to a string.
    $Percent = (($CountProcessed / $TotalFiles) * 100).ToString().Split('.',2)

    # Update the title bar with the current percent of progress.
    $host.UI.RawUI.WindowTitle = ($ScriptName + $TitleBarMessage + 'Texture: ' + $CountProcessed + '/' + $TotalFiles + ' (' + $Percent[0] + '%)')
  }
}
#==============================================================================================================================================================================================
#  MASTER LOOP: ESCAPE KEY PRESSED / ALT + F4 PRESSED / CONTROL + C PRESSED
#==============================================================================================================================================================================================
#  Verify that the loop is to be cancelled and clean up some of the junk folders it created.

function VerifyCancelMasterLoop()
{
  # Show the Yes/No dialog and capture the result.
  $YesNoResult = ShowYesNoDialog '  Are you sure you wish to cancel the current operation?'

  # If the user pressed Yes, clean up any created files depending on the selected option.
  if ($YesNoResult)
  {
    # I decided on just removing whatever folder was being generated, instead of removing the entire generated directory.
    switch ($MasterOperation)
    {
      'ScanAllTextures' {  RemovePath ($MasterOutputPath + '\BrokenTextures')
                           RemovePath ($MasterOutputPath + '\RepairedTextures') }
      'ForceIntScaling' {  $FileType = ExtensionToText $RescaleFormat
                           RemovePath ($MasterOutputPath + '\RescaledTextures')
                           RemovePath ($MasterOutputPath + '\RescaledTextures (' + $FileType + ')') }
      'ConvertTextures' {  $FileType = ExtensionToText $ConvertFormat
                           RemovePath ($MasterOutputPath + '\ConvertedTextures (' + $FileType + ')') }
      'CreateMaterials' {  RemovePath ($MasterOutputPath + '\MaterialMaps') }
      'CreateWatermark' {  RemovePath ($MasterOutputPath + '\WatermarkTextures') }
      'OptiPNGTextures' {  RemovePath ($MasterOutputPath + '\OptimizedTextures') }
      'UpscaleTextures' {  RemovePath ($MasterOutputPath + '\FilteredTextures(' + $UpscaleFilter + ')') }
    }
  }
  # Return the result of the pressed button.
  return $YesNoResult
}
#==============================================================================================================================================================================================
#  When the escape key is pressed during a loop, allow cancelling the loop.

function CheckCancelMasterLoop()
{
  # Check for a key press during the loop.
  if ([System.Console]::KeyAvailable)
  {
    # Check to see if the key pressed was Escape.
    $PressedKey = [System.Console]::ReadKey($true)

    # Flush the input buffer in case the user pressed escape multiple times.
    $Host.UI.RawUI.FlushInputBuffer()

    # ESCAPE: If the Escape key was pressed then prompt the user.
    if ($PressedKey.Key -eq 'Space')
    {
        ShowPauseDialog
    }
    # ESCAPE: If the Escape key was pressed then prompt the user.
    if ($PressedKey.Key -eq 'Escape')
    {
      # Return the button pressed result.
      return VerifyCancelMasterLoop
    }
    # CONTROL+C: If the user presses the conventional close combination (Control + C), catch it and cleanly exit.
    elseif (($PressedKey.Modifiers -band [ConsoleModifiers]'Control') -and ($PressedKey.Key -eq 'C'))
    {
      # Enable "FastClose" variable which will tell the Dialog to close which exits the script.
      $global:FastClose = $true

      # Immediately end the loop.
      return $true
    }
    # ALT+F4: If the user presses the conventional close combination (Control + C), catch it and cleanly exit.
    elseif (($PressedKey.Modifiers -band [ConsoleModifiers]'Alt') -and ($PressedKey.Key -eq 'F4'))
    {
      # Enable "FastClose" variable which will tell the Dialog to close which exits the script.
      $global:FastClose = $true

      # Immediately end the loop.
      return $true
    }
  }
  # Continue the loop if Escape was not pressed.
  return $false
}
#==============================================================================================================================================================================================
#  MASTER LOOP: AUTO-RENAME OUTPUT PATH
#==============================================================================================================================================================================================
#  If the user entered a custom name from the GUI when rescaling or converting textures.

function AutoRenameOutputPath()
{
  # Check to see if rescale textures was enabled and if the user entered a custom folder name.
  if (($MasterOperation -eq 'ForceIntScaling') -and ($RescaleAutoText -ne ''))
  {
    # Checks if the user did not force converting to a certain format (PNG/DDS/JPG).
    if ($RescaleFormat -eq $null)
    {
      # If a format was not forced, simply use the folder name "RescaledTextures".
      $RenamePath = $MasterOutputPath + '\RescaledTextures'
      $NewNamePath = $MasterOutputPath + '\' + $RescaleAutoText
    }
    # If the user forced to convert to a certain format (PNG/DDS/JPG).
    else
    {
      # If a format was forced, include the format in the folder name.
      $FileType = ExtensionToText $RescaleFormat
      $RenamePath = $MasterOutputPath + '\RescaledTextures (' + $FileType + ')'
      $NewNamePath = $MasterOutputPath + '\' + $RescaleAutoText
    }
    # Use Move-Item to rename the folder because PS 2.0 does not like -LiteralPath in Rename-Item.
    Move-Item -LiteralPath $RenamePath -Destination $NewNamePath -Force
  }
  # Check to see if convert textures was enabled and if the user entered a custom folder name.
  elseif (($MasterOperation -eq 'ConvertTextures') -and ($ConvertAutoText -ne ''))
  {
    # Include the format in the output folder.
    $FileType = ExtensionToText $ConvertFormat
    $RenamePath = $MasterOutputPath + '\ConvertedTextures (' + $FileType + ')'
    $NewNamePath = $MasterOutputPath + '\' + $ConvertAutoText

    # Use Move-Item to rename the folder because PS 2.0 does not like -LiteralPath in Rename-Item.
    Move-Item -LiteralPath $RenamePath -Destination $NewNamePath -Force
  }
}
#==============================================================================================================================================================================================
#  DOCUMENTATION: THE MASTER LOOP
#==============================================================================================================================================================================================
#  The "Master Loop" is where texture processing begins the moment the GUI "Start" button is pressed.
#
#  My old code used a bunch of variables to determine which option was actually ran. The corresponding variable would be set to "$true" while all others were set to "$false", then a huge
#  collection of "if" statements would pick out the correct one. After the loop was completely finished, all variables would return to false. This was the way I did it since the beginning
#  when this was a batch script. The initial idea was that multiple options could be ran simultaneously. But this idea never happened, and there is no reason for it to happen.
#
#  So now there is a single variable named "$MasterOperation" that stores the current operation that will take place in the master loop. This variable is set depending on which option is
#  highlighted in the GUI when pressing "Start". The values it stores to determine which option was selected uses the old names of the variables that no longer exist. Below is the full list
#  of valid values for "$MasterOperation". Obviously, this is a string variable.
#
#  ScanAllTextures  -  Scan Textures For Issues
#  ForceIntScaling  -  Rescale Textures at Fixed Integer
#  ConvertTextures  -  Convert Textures to Another Format
#  CreateMaterials  -  Create Material Maps With Ishiiruka Tool
#  MaterialInPlace  -  Create Material Maps With Ishiiruka Tool (In-Place)
#  CreateWatermark  -  Add Identifying Watermark to All Textures
#  OptiPNGTextures  -  Optimize PNG Textures With OptiPNG
#  OptimizeInPlace  -  Optimize PNG Textures With OptiPNG (In-Place)
#  UpscaleTextures  -  Apply Upscaling Filter to All Textures
#  GenerateMipMaps  -  Generate New MipMaps
#  RemoveBadMipMap  -  Remove Invalid MipMaps
#  AlphaChannelFix  -  Remove Alpha Channel From Opaque Textures
#  FixBrokeOptiPNG  -  Fix Textures Potentially Broken by OptiPNG
#
#  It was a pain trying to think of names that all have the same length (OCD in full throttle). The (In-Place) variations of the same option use an alternate name to distinguish where the
#  user wanted to output textures. While the loop is in progress, $MasterOperation will always contain which operation is taking place, so it can be referenced to know which option is in 
#  progress. When the loop ends, it will default back to an empty string and can no longer be referenced.
#==============================================================================================================================================================================================
#  MASTER LOOP: THE MASTER LOOP
#==============================================================================================================================================================================================
#  All external functions are ran through this loop in some form. It is executed from the main menu (found near the bottom of this script).

function MasterLoop()
{
  # Prevent Control + C from terminating the PowerShell window unexpectedly.
  [console]::TreatControlCAsInput = $true

  # To avoid a subsequent run from exiting immediately, flush the keyboard input buffer in case the user mashed the "Escape" key in a previous iteration.
  $Host.UI.RawUI.FlushInputBuffer()

  # Console: Output that the loop is about to start to the PS window.
  Clear-Host
  Write_Host '-----------------------------------------------------------------------------------------------------------------------' $ConsoleColors Gray $false
  Write_Host ' Processing textures ...' $ConsoleColors Yellow $false
  Write_Host '-----------------------------------------------------------------------------------------------------------------------' $ConsoleColors Gray $false

  # Count the textures that will be processed.
  $TotalFiles = CountTexturesToProcess

  # Create the log file if it's not disabled.
  AttemptCreateLogFile

  # Loop through all folders and sub-folders to attempt to find texture files.
  foreach($file in Get-ChildItem -LiteralPath $MasterInputPath -Recurse -Force -ErrorAction SilentlyContinue)
  {
    # Creates texture data in the form of a global hash table. Returns "null" if it is not a valid texture file.
    $global:Texture = CreateTextureInfo $file

    # Proceed only if there is valid texture data.
    if ($Texture -ne $null)
    {
      # Console: Show information about the texture before doing work.
      ConsoleUpdateLoopStart

      # Run the Standard or Advanced option that was selected.
      switch ($MasterOperation)
      {
        'ScanAllTextures' { ScanTextureForIssues }   # - Scan Textures For Issues
        'ForceIntScaling' { RescaleTextureInteger }  # - Rescale Textures at Fixed Integer
        'ConvertTextures' { ConvertTextureFormat }   # - Convert Textures to Another Format
        'CreateMaterials' { CreateMaterialMaps 1 }   # - Create Material Maps With Ishiiruka Tool
        'MaterialInPlace' { CreateMaterialMaps 2 }   # - Create Material Maps With Ishiiruka Tool (In-Place)
        'CreateWatermark' { AddTextureWatermark }    # - Add Identifying Watermark to All Textures
        'OptiPNGTextures' { OptimizeWithOptiPNG 1 }  # - Optimize PNG Textures With OptiPNG
        'OptimizeInPlace' { OptimizeWithOptiPNG 2 }  # - Optimize PNG Textures With OptiPNG (In-Place)
        'UpscaleTextures' { ApplyUpscalingFilter }   # - Apply Upscaling Filter to All Textures
        'GenerateMipMaps' { GenerateNewMipMaps }     # - Generate New MipMaps
        'RemoveBadMipMap' { RemoveInvalidMipMaps }   # - Remove Invalid MipMaps
        'AlphaChannelFix' { RemoveAlphaChannel }     # - Remove Alpha Channel From Opaque Textures
        'FixBrokeOptiPNG' { FixBadOptiPNGTexture }   # - Fix Textures Potentially Broken by OptiPNG
      }
      # Console: Show more information about the texture after doing work.
      ConsoleUpdateLoopEnd

      # Log: Attempt to update the log file with texture information.
      AttemptUpdateLogFile
    }
    # If there is no texture data to be had, it is not a texture.
    else
    {
      # Attempt to copy the current file in the loop if "Copy Non-Textures" is enabled.
      AttemptCopyNonTextureFile $file
    }
    # Attempt to update the title bar with the number of textures processed.
    AttemptUpdateTitleBar $file $TotalFiles

    # Check to see if the user cancelled the process.
    if (CheckCancelMasterLoop)
    {
      # Update the title bar with cancelled status.
      $host.UI.RawUI.WindowTitle = ($ScriptName + $TitleBarMessage + 'Cancelled')

      # Console: Report that the process was cancelled.
      Write-Host ''
      Write-Host ' The current operation was cancelled!' -ForeGroundColor Yellow

      # The loop was cancelled so nothing more here needs to be done.
      return
    }
  }
  # Update the title bar with the complete text percent of progress.
  $host.UI.RawUI.WindowTitle = ($ScriptName + $TitleBarMessage + 'Complete: ' + $CountProcessed + '/' + $TotalFiles + ' (100%)')

  # Console + Log: Perform the final update to the console and log file.
  ConsoleAndLogFinalUpdate

  # Completely remove the Temp folder and any remnants that my have been left astray.
  RemovePath $TempFolder

  # Check to see if the user wanted rescaled or converted paths renamed.
  AutoRenameOutputPath
  
  # Alert the user that we're done here.
  Write-Host ' Finished!'
}
#==============================================================================================================================================================================================
#  GUI FUNCTIONS TO GET A FILE OR FOLDER PATH
#==============================================================================================================================================================================================
function Get-FileName([string]$location, [string]$filename)
{
  $OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
  $OpenFileDialog.InitialDirectory = $location
  $OpenFileDialog.Filter = $filename
  $OpenFileDialog.ShowDialog() | Out-Null
  $OpenFileDialog.FileName
}
#==============================================================================================================================================================================================
function Get-Folder([string]$description)
{
  $FolderBrowserDialog = New-Object System.Windows.Forms.FolderBrowserDialog
  $FolderBrowserDialog.ShowNewFolderButton = $false
  $FolderBrowserDialog.Description = $description
  $FolderBrowserDialog.ShowDialog() | Out-Null
  $FolderBrowserDialog.SelectedPath
}
#==============================================================================================================================================================================================
#  IMAGEMAGICK: SEARCH AND SELECTION
#==============================================================================================================================================================================================
function SetImageMagick([string]$MagickPath)
{
  # Test the path chosen by the registry to see if ImageMagick v7 is installed.
  if (TestPath ($MagickPath + '\magick.exe'))
  {
    # If ImageMagick v7 is found, set all executable variables to magick.exe.
    $global:IMConvert   = $MagickPath + '\magick.exe'
    $global:IMIdentify  = $MagickPath + '\magick.exe'
    $global:IMMontage   = $MagickPath + '\magick.exe'
    $global:IMVersion   = '7'
    # ImageMagick v7 now uses a symbolic links to external tools.
    $global:IM7Identify = 'identify'
    $global:IM7Montage  = 'montage'
    return $true
  }
  # Test the path chosen by the registry to see if ImageMagick v6 is installed.
  elseif (TestPath ($MagickPath + '\convert.exe'))
  {
    # If ImageMagick v6 is found, set the executables to variables.
    $global:IMConvert   = $MagickPath + '\convert.exe'
    $global:IMIdentify  = $MagickPath + '\identify.exe'
    $global:IMMontage   = $MagickPath + '\montage.exe'
    $global:IMVersion   = '6'
    # These are only needed for v7 so default to an empty string.
    $global:IM7Identify = ''
    $global:IM7Montage  = ''
    return $true
  }
  return $false
}
#==============================================================================================================================================================================================
function SelectImageMagick()
{
  # Prompt the user for a new input path.
  Write-Host ''
  Write_Host '-----------------------------------------------------------------------------------------------------------------------' $ConsoleColors Gray $false
  Write-Host ' Select a new path to ImageMagick. The path must contain' -NoNewLine
  Write-Host ' convert.exe' -ForegroundColor Yellow -NoNewLine
  Write-Host ' or' -NoNewLine
  Write-Host ' magick.exe' -ForegroundColor Yellow -NoNewLine
  Write-Host ' to succeed.'
  Write-Host ''

  # Display an "Open Folder" menu to get the path.
  $MagickPath = Get-Folder 'Select a new path to ImageMagick. The path must contain "convert.exe" or "magick.exe" to succeed.'

  # Attempt to use enter/selected path to set the location for ImageMagick.
  if (($MagickPath) -and (SetImageMagick $MagickPath))
  {
    # When the script is closed, this variable allows the script to be updated with the new value.
    $global:UpdateImageMagick = $true

    # Update the script with the new paths.
    $global:ImageMagick = $MagickPath

    # Alert that it worked.
    Write-Host ' New path to ImageMagick succeeded!' -ForegroundColor Green
    Write-Host ''
    Write-Host ' Press any key to start the script.'

    # Pause the script and wait for user input.
    [void][System.Console]::ReadKey($true)
    return $true
  }
  # See if the user didn't input anything.
  elseif (!$MagickPath)
  {
    # Special error just for ImageMagick.
    Write-Host ' ERROR:'  -ForegroundColor Red -NoNewLine
    Write-Host ' A path was not selected. How do you expect to find ImageMagick?'
    Write-Host ''
    Write-Host ' Press any key to continue.'
  }
  # The path did not exist.
  else
  {
    # Special error just for ImageMagick.
    Write-Host ' ERROR:'  -ForegroundColor Red -NoNewLine
    Write-Host ' The entered path does not contain the ImageMagick executable' -NoNewLine
    Write-Host ' convert.exe' -ForegroundColor Yellow -NoNewLine
    Write-Host ' or' -NoNewLine
    Write-Host ' magick.exe' -ForegroundColor Yellow -NoNewLine
    Write-Host '.'
    Write-Host ''
    Write-Host ' Press any key to continue.'
  }
  # Pause the script and wait for user input.
  [void][System.Console]::ReadKey($true)
  return $false
}
#==============================================================================================================================================================================================
function FindImageMagick()
{
  # Test the path chosen by the registry to see if ImageMagick is installed.
  if (SetImageMagick $ImageMagick)
  {
    return $true
  }
  # If the path was not found, show a menu to select ImageMagick.
  do
  {
    Clear-Host
    Write_Host '-----------------------------------------------------------------------------------------------------------------------' $ConsoleColors Gray $false
    Write-Host (' ' + $ScriptName) -ForegroundColor Yellow
    Write_Host '-----------------------------------------------------------------------------------------------------------------------' $ConsoleColors Gray $false
    Write-Host ''
    Write-Host ' ERROR: '  -ForegroundColor Red -NoNewLine
    Write-Host 'IMAGEMAGICK WAS NOT FOUND!'
    Write-Host ''
    Write-Host ' Windows does not have native support for writing images in PowerShell, so it is required that you install ImageMagick'
    Write-Host ' in order to use this Texture Tool. If you already have ImageMagick installed, but the script failed to find the path' 
    Write-Host ' to where it was installed, you may attempt to input the path here.'
    Write-Host ''
    Write-Host ' Get ImageMagick v6 at ' -NoNewLine
    Write-Host 'http://www.imagemagick.org/' -ForegroundColor Cyan
    Write-Host ''
    Write_Host '-----------------------------------------------------------------------------------------------------------------------' $ConsoleColors Gray $false
    Write-Host ''
    Write-Host ' Here a new path to ImageMagick can be selected. The path must contain ' -NoNewLine
    Write-Host 'convert.exe' -ForegroundColor Yellow -NoNewLine
    Write-Host ' or ' -NoNewLine
    Write-Host 'magick.exe' -ForegroundColor Yellow -NoNewLine
    Write-Host ' to succeed.'
    Write-Host ''
    Write-Host ' (1:) Select path to ImageMagick'
    Write-Host ' (2:) Open ImageMagick Download Page'
    Write-Host ' (3:) Return to Main Menu'
    Write-Host ''
    $MenuInput = Read-Host '> '
    switch ($MenuInput)
    {
      ''  { return $false }
      '1' { if (SelectImageMagick) {return $true} }
      '2' { Start-Process -FilePath "http://imagemagick.org/script/binary-releases.php" }
      '3' { return $false }
      default { InvalidInput 'option' }
    }
  } while ((!$MenuInput) -or ($MenuInput -ne '3'))
}
#==============================================================================================================================================================================================
#  DDS UTILITIES: SEARCH AND SELECTION
#==============================================================================================================================================================================================
function CheckDDSUtilities()
{
  # Check if DDS Utilities is not installed.
  if (!$NVDXT_Exists)
  {
    Clear-Host
    Write_Host '-----------------------------------------------------------------------------------------------------------------------' $ConsoleColors Gray $false
    Write-Host ' NOTICE: Nvidia DDS Utilities was not found!' -ForegroundColor Yellow
    Write_Host '-----------------------------------------------------------------------------------------------------------------------' $ConsoleColors Gray $false
    Write-Host ''
    Write-Host ' Select a new path to Nvidia DDS Utilities below. The path must contain' -NoNewLine
    Write-Host ' nvdxt.exe'-ForegroundColor Yellow -NoNewLine
    Write-Host ' to succeed.'
    $NewToolsPath = Get-Folder 'Select the path to nvidia DDS Utilities. The past must contain "nvdxt.exe" to succeed!'

    # Use the selected folder to check for the path to the main nvidia tool.
    $NewToolsPath = $NewToolsPath + '\nvdxt.exe'

    # Check to see if the selected path exists.
    if (($NewToolsPath -ne "") -and (TestPath $TestDDSPath))
    {
      # When the script is closed, this variable allows the script to be updated with the new value.
      $global:UpdateNvidiaTools = $true

      # Alert the user that it successful.
      Write-Host ''
      Write-Host ' New path to DDS Utilities succeeded!' -ForegroundColor Green
      Write-Host ''
      Write-Host ' Press any key to continue.'

      # Set the new path to the global variables.
      $global:NVDXT   = $NewToolsPath + '\nvdxt.exe'
      $global:NSTITCH = $NewToolsPath + '\stitch.exe'
      $global:NDETACH = $NewToolsPath + '\detach.exe'

      # Store the old path so the script can be updated.
      $global:NvidiaTools = $NewToolsPath

      # Pause the script and wait for user input.
      [void][System.Console]::ReadKey($true)

      # Signal to exit the menu.
      return $true
    }
    # The path was invalid.
    InvalidInput 'path'
    return $false
  }
  # If DDS Utilities is found just return true.
  return $true
}
#============================================================================================================================================================================================== 
#  UPDATE SCRIPT: OVERWRITE ALL OPTIONS WHEN SCRIPT IS CLOSED
#============================================================================================================================================================================================== 
function OverwriteOption([int]$index, [string]$updatetype, [string]$varname)
{
  # Get the content of the script by searching for the index of the line.
  $CurrentLine = $Content | Select-Object -index $index

  # Get the value of the variable by name.
  $VarValue = Get-Variable -Name $varname -ValueOnly

  # Check for 'text' if updating a value.
  if ($updatetype -eq 'text')
  {
    # Set up the text that will replace the old value.
    $NewText = '$global:' + (ExtendString $varname 19) + '= "' + $VarValue + '"'
  }
  # Check for 'bool' if updating a boolean.
  elseif ($updatetype -eq 'bool')
  {
    # Set up the text that will replace the old value.
    $NewText = '$global:' + (ExtendString $varname 19) + '= $' + $VarValue.ToString().ToLower()
  }
  # Check for 'fext' if updating a file extension.
  elseif ($updatetype -eq 'fext')
  {
    # Set up the text that will replace the old value.
    $NewText = '$global:' + (ExtendString $varname 19) + '= $' + (ExtensionToText $VarValue)
  }
  # Update the script with the new value.
  $global:Content[$index] = $Content[$index].Replace($CurrentLine, $NewText)
}
#============================================================================================================================================================================================== 
#  Replace the old values with the current values. The indexes fed to "OverwriteOption" must match the current line that the option is on, minus 1.
#  You may ask yourself, why the hell am I doing it this way? Couldn't I just loop through all lines and not worry about which line an option falls on?
#  The answer is yes, and that's how I used to do it. But it is slow! Very fucking slow. Like 5x slower than this way. The GUI will hang until all options 
#  are finished updated, so we need it to be as fast as possible because people are impatient! I know I am, and I want speed over easier code.

function StoreAllOptions()
{
  # Grab all text from the script file.
  $global:Content = Get-Content -LiteralPath $ScriptPath

  # If the user does not want to store options, then at least write that to the script before exiting.
  if (!$EnableStoring)
  {
    # The current line that "EnableStoring is found on, minus one.
    $DSIndex = 46

    # Grab the current value of "EnableStoring" stored in the script.
    $Current   = $Content | Select-Object -index $DSIndex
    $TextStart = '$global:EnableStoring      = $'
    $TextValue = $Current.Replace($TextStart,'')

    # Check to see if the value is "false".
    if ($TextValue -eq 'true')
    {
      # We only need to write to the script if the value changed from "false" to "true".
      OverwriteOption $DSIndex 'bool' 'EnableStoring'
      Set-Content -LiteralPath $ScriptPath -Value $Content
    }
    # Exit the function so other options are not written to the script.
    return
  }
  # Update the texture path if the user wishes to store them.
  if (($StoreInputFolder) -and (TestPath $MasterInputPath))
  {
    $global:SavedInputFolder = $MasterInputPath
  }
  # If not, or the path is invalid, then reset the folder.
  else
  {
    $global:SavedInputFolder = ""
  }
  # Update the output path if the user wishes to store them.
  if (($StoreOutputFolder) -and (TestPath $MasterOutputPath.Replace('\~CTT_Generated','')))
  {
    $global:SavedOutputFolder = $MasterOutputPath.Replace('\~CTT_Generated','')
  }
  # If not, or the path is invalid, then reset the folder.
  else
  {
    $global:SavedOutputFolder = ""
  }
  # text = string value ; bool = boolean ; fext = file extension
  OverwriteOption 31 'text' 'CurrentOptions'
  OverwriteOption 32 'text' 'StoredStandard'
  OverwriteOption 33 'text' 'StoredAdvanced'
  OverwriteOption 34 'bool' 'StoreInputFolder'
  OverwriteOption 35 'bool' 'StoreOutputFolder'
  OverwriteOption 36 'text' 'SavedInputFolder'
  OverwriteOption 37 'text' 'SavedOutputFolder'
  OverwriteOption 38 'text' 'IshiirukaTool'
  OverwriteOption 39 'text' 'OptiPNGPath'
  OverwriteOption 40 'text' 'ScalerTestPath'
  OverwriteOption 41 'text' 'Waifu2xPath'
  if ($UpdateTempFolder)
  {
    OverwriteOption 42 'text' 'TempFolder'
  }
  OverwriteOption 43 'bool' 'AllowAllImages'
  OverwriteOption 44 'bool' 'DisableLogFile'
  OverwriteOption 45 'bool' 'DDSForceDXT5'
  OverwriteOption 46 'bool' 'EnableStoring'
  OverwriteOption 47 'text' 'MaterialMapFormat'
  OverwriteOption 48 'bool' 'AutoCenterConsole'
  OverwriteOption 49 'bool' 'DisableTopMost'
  OverwriteOption 50 'bool' 'AlwaysShowConsole'
  OverwriteOption 51 'bool' 'RepairTextures'
  OverwriteOption 52 'bool' 'CopyBadTextures'
  OverwriteOption 53 'bool' 'HideOKTextures'
  OverwriteOption 54 'bool' 'IgnoreDuplicates'
  OverwriteOption 55 'bool' 'AllowNotHD'
  OverwriteOption 56 'text' 'ScaleThreshold'
  OverwriteOption 57 'text' 'AspectThreshold'
  OverwriteOption 58 'text' 'DDSMipMapType'
  OverwriteOption 59 'bool' 'ForceNewMipMaps'
  OverwriteOption 60 'bool' 'CopyNonTextures'
  OverwriteOption 61 'text' 'RescaleFactor'
  OverwriteOption 62 'fext' 'RescaleFormat'
  OverwriteOption 63 'text' 'RescaleScaling'
  OverwriteOption 64 'bool' 'ManualRescale'
  OverwriteOption 65 'fext' 'ConvertFormat'
  OverwriteOption 66 'bool' 'ConvertRepair'
  OverwriteOption 67 'fext' 'IshiirukaFormat'
  OverwriteOption 68 'bool' 'InPlaceMaterial'
  OverwriteOption 69 'text' 'WM_Length'
  OverwriteOption 70 'text' 'WM_FontFace'
  OverwriteOption 71 'text' 'WM_FontSize'
  OverwriteOption 72 'text' 'WM_FontColor'
  OverwriteOption 73 'text' 'WM_BGColor'
  OverwriteOption 74 'bool' 'WM_WordWrap'
  OverwriteOption 75'text' 'OptiPNGTests'
  OverwriteOption 76 'bool' 'InPlaceOptiPNG'
  OverwriteOption 77 'text' 'FilterSelected'
  OverwriteOption 78 'text' 'FilterNewScale'
  OverwriteOption 79 'text' 'SeamlessMethod'
  OverwriteOption 80 'text' 'SeamlessFactor'
  OverwriteOption 81 'text' 'Waifu2xCMode'
  OverwriteOption 82 'text' 'Waifu2xNoise'
  OverwriteOption 83 'bool' 'Waifu2xOpenCL'
  OverwriteOption 84 'text' 'Waifu2xModel'
  OverwriteOption 85 'bool' 'Waifu2xNoGPU'
  OverwriteOption 86 'text' 'TextureRows'
  OverwriteOption 87 'text' 'TextureColumns'
  OverwriteOption 88 'text' 'CombinedName'
  OverwriteOption 89 'bool' 'ConsoleColors'
  if ($UpdateImageMagick)
  {
    OverwriteOption 90 'text' 'ImageMagick'
  }
  if ($UpdateNvidiaTools)
  {
    OverwriteOption 91 'text' 'NvidiaTools'
  }
  # Write the changes to the script file.
  Set-Content -LiteralPath $ScriptPath -Value $Content
}
#==============================================================================================================================================================================================
#  UPDATE SCRIPT: IMPORT OPTIONS SETTINGS
#==============================================================================================================================================================================================
function ImportOption([int]$index, [string]$updatetype, [string]$varname)
{
  # Get the content of the script by searching for the index of the line.
  $CurrentLine = $Content | Select-Object -index $index

  # Check to see if the current line contains the variable name.
  if ($CurrentLine -like ('$global:' + (ExtendString $varname 19) + '= *'))
  {
    # Check for 'text' if updating a value.
    if ($updatetype -eq 'text')
    {
      # All text except the value must be cropped, so store the text that will be cropped away.
      $TextStart = '$global:' + (ExtendString $varname 19) + '= '
      $TextValue = $CurrentLine.Replace($TextStart,'')
      $LastValue = $TextValue.Trim('"')
    }
    # Check for 'bool' if updating a boolean.
    elseif ($updatetype -eq 'bool')
    {
      # Crop start text, and convert the imported text boolean into an actual boolean.
      $TextStart = '$global:' + (ExtendString $varname 19) + '= $'
      $TextValue = $CurrentLine.Replace($TextStart,'')
      $LastValue = [System.Convert]::ToBoolean($TextValue)
    }
    # Check for 'fext' if updating a file extension.
    elseif ($updatetype -eq 'fext')
    {
      # Crop start text, grab the 3 letter word version of the file extension, and store it in a variable using the ".ext" format by pulling the value using the name.
      $TextStart = '$global:' + (ExtendString $varname 19) + '= $'
      $TextValue = $CurrentLine.Replace($TextStart,'')
      $LastValue = Get-Variable -Name $TextValue -ValueOnly
    }
    # Check for 'temp' if updating the temp folder.
    elseif ($updatetype -eq 'temp')
    {
      # Crop start text, grab the 3 letter word version of the file extension, and store it in a variable using the ".ext" format by pulling the value using the name.
      $TextStart = '$global:' + (ExtendString $varname 19) + '= '
      $TextValue = $CurrentLine.Replace($TextStart,'')
      $LastValue = $ExecutionContext.InvokeCommand.ExpandString($TextValue).Trim('"')
    }
    # Update the variable with the new value.
    Set-Variable -Name $varname -Value $LastValue -Scope 'Global'
  }
}
#==============================================================================================================================================================================================
function RefreshGUI()
{
  # Update all GUI values.
  $InputCheck.Checked             = $StoreInputFolder
  $OutputCheck.Checked            = $StoreOutputFolder
  $IshiiPathTextBox.Text          = $IshiirukaTool
  $OptiPathTextBox.Text           = $OptiPNGPath
  $xBRZPathTextBox.Text           = $ScalerTestPath
  $Waifu2xPathTextBox.Text        = $Waifu2xPath
  $TempPathTextBox.Text           = $TempFolder
  $AllowAllImagesCheck.Checked    = $AllowAllImages
  $DisableLogCheck.Checked        = $DisableLogFile
  $DDSForceDXT5Check.Checked      = $DDSForceDXT5
  $EnableStoredCheck.Checked      = $EnableStoring
  $MaterialTypeCombo.SelectedItem = $MaterialMapFormat
  $TopMostCheck.Checked           = $DisableTopMost
  $HideConsoleCheck.Checked       = $AlwaysShowConsole
  $S_RepairCheck.Checked          = $RepairTextures
  $S_CopyBadCheck.Checked         = $CopyBadTextures
  $S_HideOKCheck.Checked          = $HideOKTextures
  $X_HideOKCheck.Checked          = $HideOKTextures
  $Y_HideOKCheck.Checked          = $HideOKTextures
  $Z_HideOKCheck.Checked          = $HideOKTextures
  $S_IgnoreDupesCheck.Checked     = $IgnoreDuplicates
  $S_AllowNotHDCheck.Checked      = $AllowNotHD
  $S_ScaleFixNumBox.Value         = $ScaleThreshold
  $C_ScaleFixNumBox.Value         = $ScaleThreshold
  $S_AspectFixNumBox.Value        = $AspectThreshold
  $S_DDSMipMapCombo.SelectedItem  = $DDSMipMapType
  $R_DDSMipMapCombo.SelectedItem  = $DDSMipMapType
  $C_DDSMipMapCombo.SelectedItem  = $DDSMipMapType
  $G_DDSMipMapCombo.SelectedItem  = $DDSMipMapType
  $S_ForceNewMipsCheck.Checked    = $ForceNewMipMaps
  $R_ForceNewMipsCheck.Checked    = $ForceNewMipMaps
  $C_ForceNewMipsCheck.Checked    = $ForceNewMipMaps
  $G_ForceNewMipsCheck.Checked    = $ForceNewMipMaps
  $R_CopyNonCheck.Checked         = $CopyNonTextures
  $C_CopyNonCheck.Checked         = $CopyNonTextures
  $R_FactorNumBox.Value           = $RescaleFactor
  if ($RescaleFormat -eq $null)
  {
    $R_FormatCombo.SelectedItem = 'Existing'
  }
  else
  {
    $R_FormatCombo.SelectedItem = ExtensionToText $RescaleFormat
  }
  $R_ScalingCombo.SelectedItem    = $RescaleScaling
  $R_ManualCheck.Checked          = $ManualRescale
  $C_FormatCombo.SelectedItem     = ExtensionToText $ConvertFormat
  $C_AutoRepairCheck.Checked      = $ConvertRepair
  $M_FormatCombo.SelectedItem     = ExtensionToText $IshiirukaFormat
  $M_InPlaceCheck.Checked         = $InPlaceMaterial
  $W_TextLengthNumBox.Value       = $WM_Length
  $W_FontSizeNumBox.Value         = $WM_FontSize
  $W_FGColorButton.Text           = $WM_FontColor
  $W_FGColorButton.BackColor      = $WM_FontColor
  $W_BGColorButton.Text           = $WM_BGColor
  $W_BGColorButton.BackColor      = $WM_BGColor
  $W_FontFaceCombo.SelectedItem   = $WM_FontFace
  $W_WordWrapCheck.Checked        = $WM_WordWrap
  $O_TestsNumBox.Value            = $OptiPNGTests
  $O_InPlaceCheck.Checked         = $InPlaceOptiPNG
  $U_FilterCombo.SelectedItem     = $FilterSelected
  $U_FactorNumBox.Value           = $FilterNewScale
  $U_SeamlessCombo.SelectedItem   = $SeamlessMethod
  $U_SeamlessCropNumBox.Value     = $SeamlessFactor
  $U_WF2XModeCombo.SelectedItem   = $Waifu2xCMode
  $U_WF2XNoiseBox.Value           = $Waifu2xNoise
  $U_WF2XModelCombo.SelectedItem  = GUI_TranslateWaifu2xModel $Waifu2xModel 'B'
  $U_WF2XGPUCheck.Checked         = $Waifu2xNoGPU
  $U_WF2XOpenCLCheck.Checked      = $Waifu2xOpenCL
  $SplitRowsNumBox.Value          = $TextureRows
  $CombineRowsNumBox.Value        = $TextureRows
  $SplitColumnsNumBox.Value       = $TextureColumns
  $CombineColumnsNumBox.Value     = $TextureColumns
  $CombineNameTextBox.Text        = $CombinedName + $PNG
}
#==============================================================================================================================================================================================
function ImportStoredOptions()
{
  # Get the path to the desktop for the hell of it.
  $DesktopPath = [Environment]::GetFolderPath("Desktop")

  # Display an "Open File" menu to get the path.
  $TextureToolPath = Get-FileName $DesktopPath 'PS Script|*.ps1'

  # Test if a file was actually selected.
  if (TestPath $TextureToolPath)
  {
    # To properly get the extension of the selected file, retrieve it with Get-ChildItem.
    $TextureTool = Get-ChildItem -LiteralPath $TextureToolPath

    # Check if the file is a PowerShell script.
    if ($TextureTool.Extension -eq '.ps1')
    {
      # Temporarily disable the GUI.
      $Dialog.Enabled = $false

      # Grab all text from the script file.
      $global:Content = Get-Content -LiteralPath $TextureToolPath

      # Loop through the relevant lines.
      for($i=32; $i -le 98; $i++)
      {
        # Replace the current values with the script values. 
        # integer is the line the option is on minus 1.
        # text = string value ; bool = boolean ; fext = file extension ; temp = temp folder
        ImportOption $i 'text' 'CurrentOptions'
        ImportOption $i 'text' 'StoredStandard'
        ImportOption $i 'text' 'StoredAdvanced'
        ImportOption $i 'bool' 'StoreInputFolder'
        ImportOption $i 'bool' 'StoreOutputFolder'
        ImportOption $i 'text' 'SavedInputFolder'
        ImportOption $i 'text' 'SavedOutputFolder'
        ImportOption $i 'text' 'IshiirukaTool'
        ImportOption $i 'text' 'OptiPNGPath'
        ImportOption $i 'text' 'ScalerTestPath'
        ImportOption $i 'text' 'Waifu2xPath'
        ImportOption $i 'temp' 'TempFolder'
        ImportOption $i 'bool' 'AllowAllImages'
        ImportOption $i 'bool' 'DisableLogFile'
        ImportOption $i 'bool' 'DDSForceDXT5'
        ImportOption $i 'bool' 'EnableStoring'
        ImportOption $i 'text' 'MaterialMapFormat'
        ImportOption $i 'bool' 'AutoCenterConsole'
        ImportOption $i 'bool' 'DisableTopMost'
        ImportOption $i 'bool' 'AlwaysShowConsole'
        ImportOption $i 'bool' 'RepairTextures'
        ImportOption $i 'bool' 'CopyBadTextures'
        ImportOption $i 'bool' 'HideOKTextures'
        ImportOption $i 'bool' 'IgnoreDuplicates'
        ImportOption $i 'bool' 'AllowNotHD'
        ImportOption $i 'text' 'ScaleThreshold'
        ImportOption $i 'text' 'AspectThreshold'
        ImportOption $i 'text' 'DDSMipMapType'
        ImportOption $i 'bool' 'ForceNewMipMaps'
        ImportOption $i 'bool' 'CopyNonTextures'
        ImportOption $i 'text' 'RescaleFactor'
        ImportOption $i 'fext' 'RescaleFormat'
        ImportOption $i 'text' 'RescaleScaling'
        ImportOption $i 'bool' 'ManualRescale'
        ImportOption $i 'fext' 'ConvertFormat'
        ImportOption $i 'bool' 'ConvertRepair'
        ImportOption $i 'fext' 'IshiirukaFormat'
        ImportOption $i 'bool' 'InPlaceMaterial'
        ImportOption $i 'text' 'WM_Length'
        ImportOption $i 'text' 'WM_FontFace'
        ImportOption $i 'text' 'WM_FontSize'
        ImportOption $i 'text' 'WM_FontColor'
        ImportOption $i 'text' 'WM_BGColor'
        ImportOption $i 'bool' 'WM_WordWrap'
        ImportOption $i 'text' 'OptiPNGTests'
        ImportOption $i 'bool' 'InPlaceOptiPNG'
        ImportOption $i 'text' 'FilterSelected'
        ImportOption $i 'text' 'FilterNewScale'
        ImportOption $i 'text' 'SeamlessMethod'
        ImportOption $i 'text' 'SeamlessFactor'
        ImportOption $i 'text' 'Waifu2xCMode'
        ImportOption $i 'text' 'Waifu2xNoise'
        ImportOption $i 'bool' 'Waifu2xOpenCL'
        ImportOption $i 'text' 'Waifu2xModel'
        ImportOption $i 'bool' 'Waifu2xNoGPU'
        ImportOption $i 'text' 'TextureRows'
        ImportOption $i 'text' 'TextureColumns'
        ImportOption $i 'text' 'CombinedName'
        ImportOption $i 'bool' 'ConsoleColors'
      }
      # There is a lot text in the script to store in RAM, so clean that shit up.
      $global:Content = $null

      # Update everything on the GUI.
      RefreshGUI

      # Enable the dialog.
      $Dialog.Enabled = $true
    }
  }
}
#==============================================================================================================================================================================================
#  UPDATE SCRIPT: RESTORE DEFAULTS
#==============================================================================================================================================================================================
function RestoreDefaultOptions()
{
  # Display a Yes/No dialog.
  if (ShowYesNoDialog '   Are you sure you wish to restore all default values?')
  {
    # Set all variables to their default values.
    $global:AllowAllImages     = $false
    $global:DisableLogFile     = $false
    $global:DDSForceDXT5       = $false
    $global:EnableStoring      = $true
    $global:StoreInputFolder   = $false
    $global:StoreOutputFolder  = $false
    $global:SavedInputFolder   = ""
    $global:SavedOutputFolder  = ""
    $global:MaterialMapFormat  = "Ishiiruka"
    $global:AutoCenterConsole  = $true
    $global:DisableTopMost     = $true
    $global:AlwaysShowConsole  = $true
    $global:RepairTextures     = $false
    $global:CopyBadTextures    = $false
    $global:HideOKTextures     = $false
    $global:IgnoreDuplicates   = $false
    $global:AllowNotHD         = $true
    $global:ScaleThreshold     = "0.65"
    $global:AspectThreshold    = "0.05"
    $global:DDSMipMapType      = "External"
    $global:ForceNewMipMaps    = $false
    $global:CopyNonTextures    = $true
    $global:RescaleFactor      = "4"
    $global:RescaleFormat      = $PNG
    $global:RescaleScaling     = "All"
    $global:ManualRescale      = $false
    $global:ConvertFormat      = $PNG
    $global:ConvertRepair      = $false
    $global:IshiirukaFormat    = $PNG
    $global:InPlaceMaterial    = $false
    $global:WM_Length          = "0"
    $global:WM_FontFace        = "Courier-New-Bold"
    $global:WM_FontSize        = "8"
    $global:WM_FontColor       = "#FF0000"
    $global:WM_BGColor         = "#00FF00"
    $global:WM_WordWrap        = $true
    $global:OptiPNGTests       = "3"
    $global:InPlaceOptiPNG     = $false
    $global:FilterSelected     = "Point"
    $global:FilterNewScale     = "4"
    $global:SeamlessMethod     = "Opaque"
    $global:SeamlessFactor     = "0.85"
    $global:Waifu2xCMode       = "Noise_Scale"
    if ($Waifu2xApp -eq 'waifu2x-caffe-cui.exe')
    {
      $global:Waifu2xNoise       = "3"
    }
    else
    {
      $global:Waifu2xNoise       = "2"
    }
    $global:Waifu2xOpenCL      = $false
    $global:Waifu2xModel       = "anime_style_art_rgb"
    $global:Waifu2xNoGPU       = $false
    $global:TextureRows        = "2"
    $global:TextureColumns     = "2"
    $global:CombinedName       = "CombinedTexture"
    $global:ConsoleColors      = $true

    # Update everything on the GUI.
    RefreshGUI
  }
}
#==============================================================================================================================================================================================
#  CTT GUI: UPDATE INPUT/OUTPUT PATHS
#==============================================================================================================================================================================================
#  Shared below the next 2 function to reduce duplicate code.

function GUI_UpdateFolderPath_MasterPaths([string]$inputpath)
{
  # Add a work-around for when a directory is chosen that does not contain a sub-folder.
  if ((($inputpath | Measure-Object -Character).Characters) -eq 3)
  {
    $inputpath_B = $inputpath.Replace('\','')
  }
  else
  {
    $inputpath_B = $inputpath
  }
  # Update the corresponding path and the text box.
  if ($this.Name -eq 'Input')
  {
    $InputTextBox.Text = $inputpath
    $OutputTextBox.Text = $inputpath_B + '\~CTT_Generated'
    $global:MasterInputPath = $inputpath
    $global:MasterOutputPath = $inputpath_B + '\~CTT_Generated'
  }
  elseif ($this.Name -eq 'Output')
  {
    $OutputTextBox.Text = $inputpath_B + '\~CTT_Generated'
    $global:MasterOutputPath = $inputpath_B + '\~CTT_Generated'
  }
}
#==============================================================================================================================================================================================
#  Updates the "Texture Path" and "Output Path" with a drag and drop. Forces the output path to also include "\~CTT_Generated".

function GUI_UpdateFolderPath_DragDrop()
{
  # Make sure there is data present before actually doing anything.
  if ($_.Data.GetDataPresent([Windows.Forms.DataFormats]::FileDrop))
  {
    # Create a list of the data to select the first item from the list.
    $DroppedPath = [string]($_.Data.GetData([Windows.Forms.DataFormats]::FileDrop))

    # Make sure the path is a folder and prevent the path from having any form of '~' in it.
    if ((Test-Path -LiteralPath $DroppedPath -PathType Container) -and ($DroppedPath -notlike '*~*') -and ($DroppedPath -notlike "*'*"))
    {
      GUI_UpdateFolderPath_MasterPaths $DroppedPath
    }
  }
}
#==============================================================================================================================================================================================
#  Updates the "Texture Path" and "Output Path" from the button. Forces the output path to also include "\~CTT_Generated".

function GUI_UpdateFolderPath_Button([string]$message)
{
  # Display an "Open Folder" menu to get the path.
  $SelectedFolderPath = Get-Folder $message

  # Check to see if a folder was selected from the Open menu and test if that path exists.
  if (($SelectedFolderPath -ne '') -and (TestPath $SelectedFolderPath))
  {
    GUI_UpdateFolderPath_MasterPaths $SelectedFolderPath
  }
}
#==============================================================================================================================================================================================
#  CTT GUI: UPDATE EXTERNAL TOOL PATHS
#==============================================================================================================================================================================================
#  Shared below the next 2 function to reduce duplicate code.

function GUI_UpdateFilePath_Finish([object]$textbox, [string]$varname, [string]$toolpath)
{
  # Update the variable.
  Set-Variable -Name $varname -Value $toolpath -Scope 'Global'

  # Update the text box with the new path.
  $textbox.Text = $toolpath

  # If the selected path was a Waifu2x path, then hack in some more shit.
  if ($textbox -eq $Waifu2xPathTextBox)
  {
    # Get the name of the selected Waifu2x application.
    $global:Waifu2xApp = [string](Get-ChildItem -LiteralPath $Waifu2xPath).Name

    # Update GUI related stuff depending on which version was selected.
    GUI_UpdateWaifu2xSelection
  }
}
#==============================================================================================================================================================================================
#  Updates the tools paths on the options panel with a drag and drop.

function GUI_UpdateFilePath_DragDrop([string]$toolapp)
{
  # Make sure there is data present before actually doing anything.
  if ($_.Data.GetDataPresent([Windows.Forms.DataFormats]::FileDrop))
  {
    # Create a list of the data to select the first item from the list.
    $DroppedPath = [string]($_.Data.GetData([Windows.Forms.DataFormats]::FileDrop))

    # Make sure the path does not contain the symbols (~) or (').
    if (($DroppedPath -notlike '*~*') -and ($DroppedPath -notlike "*'*"))
    {
      # Make sure the path is a file (defined by type "leaf").
      if (Test-Path -LiteralPath $DroppedPath -PathType Leaf)
      {
        # Get the name of the item.
        $DroppedItem = [string](Get-ChildItem -LiteralPath $DroppedPath).Name

        # Make sure the correct application was chosen.
        if ($toolapp -eq $DroppedItem)
        {
          # Get the name of the variable by pulling it from the textbox.
          $VarName = $this.Name

          # Finish doing everything that needs to be done.
          GUI_UpdateFilePath_Finish $this $VarName $DroppedPath
        }
      }
      # You know what? Let's set up a condition to check a path to see if the file is inside.
      elseif (Test-Path -LiteralPath $DroppedPath -PathType Container)
      {
        # Set up a path to also include the executable file.
        $PathWithExe = $DroppedPath + '\' + $toolapp

        # Make sure the file exists in the chosen path.
        if (TestPath $PathWithExe)
        {
          # Get the name of the variable by pulling it from the text box.
          $VarName = $this.Name

          # Finish doing everything that needs to be done.
          GUI_UpdateFilePath_Finish $this $VarName $PathWithExe
        }
      }
    }
  }
}
#==============================================================================================================================================================================================
#  Updates the tools paths on the options panel with the button.

function GUI_UpdateFilePath_Button([object]$textbox, [string]$toolapp)
{
  # Display an "Open Folder" menu to get the path.
  $SelectedFilePath = Get-FileName 'C:\' $toolapp

  # Check to see if a folder was selected from the Open menu and test if that path exists.
  if (($SelectedFilePath -ne '') -and (TestPath $SelectedFilePath))
  {
    # Get the name of the variable by pulling it from the button.
    $VarName = $this.Name

    # Finish doing everything that needs to be done.
    GUI_UpdateFilePath_Finish $textbox $VarName $SelectedFilePath
  }
}
#==============================================================================================================================================================================================
#  CTT GUI: UPDATE TEMP FOLDER PATH
#==============================================================================================================================================================================================
#  Updates the temporary folder path with a drag and drop.

function GUI_UpdateTempFolderPath_DragDrop()
{
  # Make sure there is data present before actually doing anything.
  if ($_.Data.GetDataPresent([Windows.Forms.DataFormats]::FileDrop))
  {
    # Create a list of the data to select the first item from the list.
    $DroppedPath = [string]($_.Data.GetData([Windows.Forms.DataFormats]::FileDrop))

    # Make sure the path is a folder and prevent the path from having any form of '~' in it.
    if ((Test-Path -LiteralPath $DroppedPath -PathType Container) -and ($DroppedPath -notlike '*~*') -and ($DroppedPath -notlike "*'*"))
    {
      # Update the temp folder when the script is closed.
      $global:UpdateTempFolder = $true

      # Add a work-around for when a directory is chosen that does not contain a sub-folder.
      if ((($DroppedPath | Measure-Object -Character).Characters) -eq 3)
      {
        $DroppedPath = $DroppedPath.Replace('\','')
      }
      $global:TempFolder = $DroppedPath + '\CTT-PS_Temp'

      # Update the text box with the new path.
      $TempPathTextBox.Text = $TempFolder
    }
  }
}
#==============================================================================================================================================================================================
#  Updates the temporary folder path with the button.

function GUI_UpdateTempFolderPath_Button()
{
  # Display an "Open Folder" menu to get the path.
  $SelectedFolderPath = Get-Folder 'Select a new path for where Custom Texture Tool PS will create temporary files. Note that this path and all files it contains are destroyed every time the script is ran!'

  # Check to see if a folder was selected from the Open menu and test if that path exists.
  if (($SelectedFolderPath -ne '') -and (TestPath $SelectedFolderPath))
  {
    # Update the temp folder when the script is closed.
    $global:UpdateTempFolder = $true

    # Add a work-around for when a directory is chosen that does not contain a sub-folder.
    if ((($SelectedFolderPath | Measure-Object -Character).Characters) -eq 3)
    {
      $SelectedFolderPath = $SelectedFolderPath.Replace('\','')
    }
    $global:TempFolder = $SelectedFolderPath + '\CTT-PS_Temp'

    # Update the text box with the new path.
    $TempPathTextBox.Text = $TempFolder
  }
}
#==============================================================================================================================================================================================
#  CTT GUI: WAIFU2X SPECIFIC STUFF THAT I DON'T KNOW WHERE ELSE TO PUT
#==============================================================================================================================================================================================
# Converts menu string into CLI strings and vice versa depending on the entered direction (A or B).

function GUI_TranslateWaifu2xModel([string]$modelname, [string]$direction)
{
  # Translate the menu version into the version we want to feed the CLI.
  if ($direction -eq 'A')
  {
    switch ($modelname)
    {
      '2D Illust (RGB)'   { return 'anime_style_art_rgb' }
      '2D Illust (UpRGB)' { return 'upconv_7_anime_style_art_rgb'}
      '2D Illust (Y)'     { return 'anime_style_art' }
      'Photo (Standard)'  { return 'photo' }
      'Photo (UpPhoto)'   { return 'upconv_7_photo' }
      'Photo (UKBench)'   { return 'ukbench' }
    }
  }
  # Translate the CLI version into the version that shows on the menu.
  else
  {
    switch ($modelname)
    {
      'anime_style_art_rgb'          { return '2D Illust (RGB)' }
      'upconv_7_anime_style_art_rgb' { return '2D Illust (UpRGB)'}
      'anime_style_art'              { return '2D Illust (Y)' }
      'photo'                        { return 'Photo (Standard)' }
      'upconv_7_photo'               { return 'Photo (UpPhoto)' }
      'ukbench'                      { return 'Photo (UKBench)' }
    }
  }
}
#==============================================================================================================================================================================================
# It got annoying to track the visibility and position of these all over the place. So now it has its own function.

function GUI_UpdateWaifu2xSelection()
{
  # Caffe does not use OpenCL, but can configure a model. Also it has a noise reduction maximum of 3.
  if ($Waifu2xApp -eq 'waifu2x-caffe-cui.exe')
  {
    $U_WF2XOpenCLCheck.Hide()
    $U_WF2XModelCombo.Show()
    $U_WF2XModelLabel.Show()
    $U_WF2XGPUCheck.Location = New-Object System.Drawing.Size(182, 96)
    $U_WF2XModelCombo.Location = New-Object System.Drawing.Size(182, 68)
    $U_WF2XModelLabel.Location = New-Object System.Drawing.Size(278, 71)
    $U_WF2XNoiseBox.Maximum = 3
  }
  # CPP does use OpenCL, but can't configure a model. Also it has a noise reduction maximum of 2.
  elseif ($Waifu2xApp -eq 'waifu2x-converter_x64.exe')
  {
    $U_WF2XModelCombo.Hide()
    $U_WF2XModelLabel.Hide()
    $U_WF2XOpenCLCheck.Show()
    $U_WF2XGPUCheck.Location = New-Object System.Drawing.Size(182, 72)
    $U_WF2XModelCombo.Location = New-Object System.Drawing.Size(182, 96)
    $U_WF2XModelLabel.Location = New-Object System.Drawing.Size(278, 98)
    $U_WF2XNoiseBox.Maximum = 2
  }
}
#==============================================================================================================================================================================================
#  CTT GUI: UPDATE OPTION STATE FUNCTIONS
#==============================================================================================================================================================================================
#  When an option is selected from the Standard or Advanced options menus, this updates which sub-options are visible to the user.

function GUI_UpdateSelectedOptions([string]$Index)
{
  # Check to see if an option wasn't forced.
  if ($Index -eq '')
  {
    # Get the selected index in the form of a string to apply it to a switch.
    $Index = $this.SelectedIndex
  }
  # Initially hide all option groups.
  $ScanGroup.Hide()
  $RescaleGroup.Hide()
  $ConvertGroup.Hide()
  $MaterialGroup.Hide()
  $WatermarkGroup.Hide()
  $OptiPNGGroup.Hide()
  $UpscaleFilterGroup.Hide()

  # And the advanced options groups.
  $GenNewMipMapsGroup.Hide()
  $InvalidMipMapsGroup.Hide()
  $RemoveAlphaGroup.Hide()
  $FixBrokeOptiPNGGroup.Hide()
  $CombineTextureGroup.Hide()
  $SplitTextureGroup.Hide()

  # Standard Options
  if ($StandardOptions.Visible)
  {
    # Show the group of options that corresponds to the selected index.
    switch ($Index)
    {
      '0' { $ScanGroup.Show() }
      '1' { $RescaleGroup.Show() }
      '2' { $ConvertGroup.Show() }    
      '3' { $MaterialGroup.Show() }
      '4' { $WatermarkGroup.Show() }
      '5' { $OptiPNGGroup.Show() }
      '6' { $UpscaleFilterGroup.Show() }
    }
    $global:CurrentOptions = 'Standard'
    $global:StoredStandard = $Index
  }
  # Advanced Options
  else
  {
    # Show the group of options that corresponds to the selected index.
    switch ($Index)
    {
      '0'   { $GenNewMipMapsGroup.Show() }
      '1'   { $InvalidMipMapsGroup.Show() }
      '2'   { $RemoveAlphaGroup.Show() }    
      '3'   { $FixBrokeOptiPNGGroup.Show() }
      '4'   { $global:TextureArray = $null
              GUI_UpdateTextureArray
              $CombineTextureGroup.Show() 
            }
      '5'   { $global:TextureArray = $null
              GUI_UpdateTextureArray
              $global:CombinedTexture = 'Select a texture to split into multiple textures...'
              $global:CTTDataFile = '<None>'
              $SplitTextureTextBox.Text = $CombinedTexture
              $SplitTextureGroup.Show()
            }
    }
    $global:CurrentOptions = 'Advanced'
    $global:StoredAdvanced = $Index
  }
}
#==============================================================================================================================================================================================
#  When a button on the side of the menu is pressed, this toggles which menu is visible and updates which options are shown.

function GUI_OptionsButtonPress()
{
  if ($this.Name -eq 'Standard')
  {
    $StandardGroup.Visible = $true
    $AdvancedGroup.Visible = $false
    GUI_UpdateSelectedOptions $StandardOptions.SelectedIndex
  }
  elseif ($this.Name -eq 'Advanced')
  {
    $StandardGroup.Visible = $false
    $AdvancedGroup.Visible = $true
    GUI_UpdateSelectedOptions $AdvancedOptions.SelectedIndex
  }
}
#==============================================================================================================================================================================================
#  Quickly load a specific help topic depending on the currently selected "Standard" or "Advanced" Option.

function GUI_QuickHelp()
{
  # Check to see if the dialog is currently hidden.
  if (!$HelpDialog.Visible)
  {
    # Show the help dialog.
    $HelpDialog.Show()

    # Get the name of the Standard or Advanced option as the node main node to select.
    $MainNode = 'TreeNode: ' + $CurrentOptions + ' Options'

    # Perform some 'Get-Variable' trickery to get the currently selected Standard or Advanced sub-node.
    $Option = Get-Variable -Name ($CurrentOptions + 'Options') -ValueOnly

    # Get the name of the sub-node that will actually be selected based on the selected option.
    $SelectNode = 'TreeNode: ' + $Option.SelectedItem

    # Loop through all nodes in the help dialog.
    foreach($Node in $HelpTopics.Nodes)
    {
      # Select the correct node, either standard or advanced.
      if ($Node.ToString() -eq $MainNode)
      {
        # Loop through all subnodes in the current node.
        foreach ($SubNode in $Node.Nodes)
        {
          # Select the correct subnode based on the selected option.
          if ($SubNode.ToString() -eq $SelectNode)
          {
            # Display the help topic.
            $HelpTopics.SelectedNode = $SubNode
          }
        }
      }
    }
  }
  # The help dialog is already open.
  else
  {
    # So close it.
    $HelpDialog.Hide()
  }
}
#==============================================================================================================================================================================================
#  Toggles showing the side panel with the "Options" button where tool paths and other "Internal Options" can be configured.

function GUI_ToggleOptionsPanel()
{
  # An icky yet effective solution is to check the current width of the dialog.
  if ($Dialog.Width -le $DialogWidth)
  {
    # If it's in the smaller state, make it larger and unhide all the paths options.
    $Dialog.Width = $DialogMaxWidth
    $IshiiPathGroup.Show()
    $OptiPathGroup.Show()
    $xBRZPathGroup.Show()
    $Waifu2xPathGroup.Show()
    $TempPathGroup.Show()
    $InternalGroup.Show()
    $CTTOptionsGroup.Show()
  }
  else
  {
    # If it's in the larger state, make it smaller and hide all the paths options.
    $Dialog.Width = $DialogWidth
    $IshiiPathGroup.Hide()
    $OptiPathGroup.Hide()
    $xBRZPathGroup.Hide()
    $Waifu2xPathGroup.Hide()
    $TempPathGroup.Hide()
    $InternalGroup.Hide()
    $CTTOptionsGroup.Hide()
  }
}
#==============================================================================================================================================================================================
#  Generic function that takes care of all check boxes that have their value toggled.

function GUI_UpdateCheckBoxState()
{
  # Get the name of the variable by pulling it from the CheckBox itself.
  $VarName = $this.Name
  $CheckState = $this.Checked

  # Special cases need to be set up for certain variables.
  switch ($VarName)
  {
  # Hide Ok Textures is found on multiple menus so update them all to reflect the change.
  'HideOKTextures'      { $S_HideOKCheck.Checked = $CheckState
                          $X_HideOKCheck.Checked = $CheckState
                          $Y_HideOKCheck.Checked = $CheckState
                          $Z_HideOKCheck.Checked = $CheckState
                        }
  # Copy Non-Textures is also found on multiple menus so update them all to reflect the change.
  'CopyNonTextures'     { $R_CopyNonCheck.Checked = $CheckState
                          $C_CopyNonCheck.Checked = $CheckState
                        }
  # Force New Mipmaps is also found on multiple menus so update them all to reflect the change.
  'ForceNewMipMaps'     { $S_ForceNewMipsCheck.Checked = $CheckState
                          $R_ForceNewMipsCheck.Checked = $CheckState
                          $C_ForceNewMipsCheck.Checked = $CheckState
                          $G_ForceNewMipsCheck.Checked = $CheckState
                        }
  # Enables/Disables some options depending on the current state of "Attempt Repairs" using "Scan Textures For Issues".
  'RepairTextures'      { $S_ScaleFixNumBox.Enabled    = $CheckState
                          $S_ScaleFixLabel.Enabled     = $CheckState
                          $S_AspectFixNumBox.Enabled   = $CheckState
                          $S_AspectFixLabel.Enabled    = $CheckState
                          $S_ForceNewMipsCheck.Enabled = $CheckState
                        }
  # Enables/Disables Scale-Fix Threshold depending on the current state of "Auto-Repair Textures" using "Convert Textures to Another Format".
  'ConvertRepair'       { $C_ScaleFixNumBox.Enabled = $CheckState   
                          $C_ScaleFixLabel.Enabled  = $CheckState
                        }
  # Toggles PowerShell console visibility.
  'AlwaysShowConsole'   { ShowPowerShellConsole $CheckState
                          if ($CheckState)
                          {
                            $Dialog.Activate()
                          }
                        }
  # Waifu2x can disable the GPU, but this cannot be done with OpenCL enabled.
  'Waifu2xNoGPU'        { if (($CheckState) -and ($U_WF2XOpenCLCheck.Checked) -and ($U_WF2XOpenCLCheck.Visible))
                          {
                            $U_WF2XOpenCLCheck.Checked = $false
                          }
                        }
  # Waifu2x-CPP can use OpenCL, but this cannot be used with "Disable GPU".
  'Waifu2xOpenCL'       { if (($CheckState) -and ($U_WF2XGPUCheck.Checked))
                          {
                            $U_WF2XGPUCheck.Checked = $false
                          }
                        }
  }
  # Update the variable with the reversed state.
  Set-Variable -Name $VarName -Value $CheckState -Scope 'Global'
}
#==============================================================================================================================================================================================
function GUI_PSDoubleClickCheckBoxState()
{
  # Create a temporary folder to create the registry mod.
  $TempRegPath = CreatePath ($TempFolder + '\RegMod\')

  # Set the path to the registry mod.
  $TempRegFile = $TempRegPath + 'regmod.reg'

  # Begin to create the reg file.
  Add-Content -LiteralPath $TempRegFile -value 'Windows Registry Editor Version 5.00'
  Add-Content -LiteralPath $TempRegFile -value ''
  Add-Content -LiteralPath $TempRegFile -value '[HKEY_LOCAL_MACHINE\SOFTWARE\Classes\Microsoft.PowerShellScript.1\Shell]'

  # Get the current state of the value in the registry.
  $PS_DC_State = (Get-ItemProperty -LiteralPath "HKLM:\Software\Classes\Microsoft.PowerShellScript.1\Shell").'(default)'

  # Add the value, but modify it to the opposite state.
  if ($PS_DC_State -eq '0')
  {
    Add-Content -LiteralPath $TempRegFile -value '@="Open"'
  }
  else
  {
    Add-Content -LiteralPath $TempRegFile -value '@="0"'
  }
  # Execute the registry file.
  regedit /s $TempRegFile
}
#==============================================================================================================================================================================================
#  Generic function that takes care of almost all combo boxes that have their value changed.

function GUI_UpdateComboBoxState()
{
  # Get the name of the variable by pulling it from the ComboBox itself.
  $VarName  = $this.Name
  $Selected = $this.SelectedItem

  # A special case for the Rescale Format option when "Existing" is selected.
  if (($VarName -eq 'RescaleFormat') -and ($Selected -eq 'Existing'))
  {
    # Store $null instead of a file extension.
    $NewValue = $null
  }
  # Because file extensions require special attention in setting them.
  elseif (($VarName -eq 'RescaleFormat') -or ($VarName -eq 'ConvertFormat') -or ($VarName -eq 'IshiirukaFormat'))
  {
    # Set the file extension.
    $NewValue = Get-Variable -Name $Selected -ValueOnly
  }
  # Waifu2x uses different strings than what is displayed so it must be converted.
  elseif ($VarName -eq 'Waifu2xModel')
  {
    # Mode "A" converts the string that is displayed on the GUI into the version that is fed to waifu2x CLI.
    $NewValue = GUI_TranslateWaifu2xModel $Selected 'A'
  }
  # Below is what every other ComboBox will do.
  else
  {
    # Get the value that was selected.
    $NewValue = $Selected

    # DDS MipMap Type can be found on multiple menus so update them all.
    if ($VarName -eq 'DDSMipMapType')
    {
      $S_DDSMipMapCombo.SelectedItem = $NewValue
      $R_DDSMipMapCombo.SelectedItem = $NewValue
      $C_DDSMipMapCombo.SelectedItem = $NewValue
      $G_DDSMipMapCombo.SelectedItem = $NewValue
    }
  }
  # Update the variable.
  Set-Variable -Name $VarName -Value $NewValue -Scope 'Global'
}
#==============================================================================================================================================================================================
#  Because so much happens when the combo box for filters is changed, it has its very own function.

function GUI_UpdateFilterComboBoxState()
{
  # Get the value that was selected.
  $NewFilter = $this.SelectedItem

  # xBRZ has a limit of 6x as an upscaling integer so limit the upscaling value.
  if ($NewFilter -eq 'xBRZ')
  {
    $U_FactorNumBox.Maximum = 6
  }
  else
  {
    $U_FactorNumBox.Maximum = 8
  }
  # Check to see if waifu2x was selected as the filter.
  if ($NewFilter -eq 'Waifu2x')
  {
    # Test if the path to waifu2x is valid to avoid errors.
    if (TestPath $Waifu2xPath)
    {
      # Get the name of the selected Waifu2x application.
      $global:Waifu2xApp = [string](Get-ChildItem -LiteralPath $Waifu2xPath).Name

      # Update the visibility of all waifu2x options.
      GUI_UpdateWaifu2xSelection
    }
    # Also show all the other additional options regardless if the path is valid or not.
    $U_WF2XModeCombo.Show()
    $U_WF2XModeLabel.Show()
    $U_WF2XNoiseBox.Show()
    $U_WF2XNoiseLabel.Show()
    $U_WF2XGPUCheck.Show()
  }
  # If any other filter is selected then hide them.
  else
  {
    $U_WF2XModeCombo.Hide()
    $U_WF2XModeLabel.Hide()
    $U_WF2XNoiseBox.Hide()
    $U_WF2XNoiseLabel.Hide()
    $U_WF2XGPUCheck.Hide()
    $U_WF2XOpenCLCheck.Hide()
    $U_WF2XModelCombo.Hide()
    $U_WF2XModelLabel.Hide()
  }
  # Store the current selected filter to compare to the new value.
  $global:FilterSelected = $NewFilter
}
#==============================================================================================================================================================================================
#  Note: I noticed a flaw with "NumericUpDown" boxes. When a user types more than 2 decimal places, the box will correct itself, but the internal value remains 
#  whatever the user typed in. As a work-around, I round this value and manually update the box with it so that it matches what is stored in the global variable.

function GUI_UpdateNumericUpDown([string]$definition)
{
  # Get the name of the variable by pulling it from the ComboBox itself.
  $VarName = $this.Name

  # Convert the value into a decimal format and split the integer from the decimal.
  $ValueSplit = (FormatDecimal $this.Value).Split('.', 2)

  # If the Numeric Up/Down only accepts integers, keep only the integer.
  if ($definition -eq 'integer')
  {
    $NewValue = $ValueSplit[0]
  }
  # If it wants a decimal value, then use the entire number.
  elseif ($definition -eq 'decimal')
  {
    $NewValue = $ValueSplit[0] + '.' + $ValueSplit[1]
  }
  # Update the variable with the new value.
  Set-Variable -Name $VarName -Value $NewValue -Scope 'Global'

  # ScaleThreshold can be found on multiple menus so update them all.
  if ($VarName -eq 'ScaleThreshold')
  {
    $S_ScaleFixNumBox.Value = $ScaleThreshold
    $C_ScaleFixNumBox.Value = $ScaleThreshold
  }
}
#==============================================================================================================================================================================================
#  Checks entered text for text boxes that auto-rename texture packs.

function GUI_VerifyAutoNameText()
{
  # Pull the values from the text box.
  $VarName = $this.Name
  $Entered = $this.Text

  # Do not allow illegal characters or spaces, only alpha-numeric values.
  if ($Entered -match "^[a-zA-Z0-9]+$")
  {
    Set-Variable -Name $VarName -Value $Entered -Scope 'Global'
  }
  # If the text was illegal clear the text box and reset the variable.
  else
  {
    $this.Text = ''
    Set-Variable -Name $VarName -Value '' -Scope 'Global'
  }
}
#==============================================================================================================================================================================================
#  Allows selecting a color for the text or background when using the "Create Watermark" option.

function GUI_ShowColorDialog()
{
  # Get the name of the variable by pulling it from the Button itself.
  $VarName = $this.Name

  # Create and show a color dialog to the user.
  $ColorDialog = New-Object System.Windows.Forms.ColorDialog
  $Selection = $ColorDialog.ShowDialog()

  # Check to see if the color selection passed when the dialog was closed.
  if ($Selection -eq 'OK')
  {
    # Get the old color that is stored in the variable name pulled from the button.
    $OldColor = Get-Variable -Name $VarName -ValueOnly

    # Compile the color into HTML format by converting each value to hexadecimal.
    $NewColor = '#' + $ColorDialog.Color.R.ToString('X2') + $ColorDialog.Color.G.ToString('X2') + $ColorDialog.Color.B.ToString('X2')

    # Update the text and the color displayed on the button.
    $this.Text = $NewColor
    $this.BackColor = $NewColor

    # Update the script with the new color value.
    Set-Variable -Name $VarName -Value $NewColor -Scope 'Global'
  }
}
#==============================================================================================================================================================================================
#  CTT GUI: COMBINE MULTIPLE TEXTURES FUNCTIONS
#==============================================================================================================================================================================================
function GUI_CombineMultipleTextures()
{
  # Output that the loop is about to start to the PS window.
  Clear-Host
  Write_Host '-----------------------------------------------------------------------------------------------------------------------' $ConsoleColors Gray $false
  Write_Host ' Processing textures ...' $ConsoleColors Yellow $false
  Write_Host '-----------------------------------------------------------------------------------------------------------------------' $ConsoleColors Gray $false
  Write-Host ''
  Write-Host ' Combining Textures:'
  Write-Host ''
  # Create the output path if it doesn't exist.
  $OutputPath = CreatePath ($MasterOutputPath + '\CombinedTexture\')

  # Set the full texture output path to include the texture name.
  $TexOutputPath = $OutputPath + $CombinedName + '.png'

  # Display the complete list of textures to the console.
  for($row = 1; $row -le [int]$TextureRows; $row++)
  {
    for($col = 1; $col -le [int]$TextureColumns; $col++)
    {
      Write-Host (' ' + $TextureArray[$row,$col])
    }
  }
  # For the sake of readability, store the tiling format for ImageMagick in a variable.
  $Tile = $TextureRows + 'x' + $TextureColumns

  # Create the image using all images in the texture array.
  & $IMMontage $IM7Montage -tile $Tile -geometry '+0+0' -background none $TextureArray $TexOutputPath

  # Check to see if the texture was created.
  if (TestPath $TexOutputPath)
  {
    # Set the path to generate a CTT file.
    $CTTFile = $OutputPath + $CombinedName + '.ctt'

    # If a CTT file already exists, remove it before starting to add data to it.
    RemovePath $CTTFile

    # Add data to the CTT file.
    Add-Content -LiteralPath $CTTFile -value $TexOutputPath
    Add-Content -LiteralPath $CTTFile -value $TextureRows
    Add-Content -LiteralPath $CTTFile -value $TextureColumns
    for($row = 1; $row -le [int]$TextureRows; $row++)
    {
      for($col = 1; $col -le [int]$TextureColumns; $col++)
      {
        Add-Content -LiteralPath $CTTFile -value ([string](Get-ChildItem -LiteralPath $TextureArray[$row,$col]).Name)
      }
    }
  }
  # Display to the user that we're done here.
  Write-Host ''
  Write_Host '-----------------------------------------------------------------------------------------------------------------------' $ConsoleColors Gray $false
  Write-Host ''
  Write-Host ' Finished!'
}
#----------------------------------------------------------------------------------------------------------------------------------------------
function GUI_CheckTextureArray()
{
  # A variable to store whether or not to the check has passed.
  $CheckPassed = $true

  # Loop through all rows.
  for($row = 1; $row -le [int]$TextureRows; $row++)
  {
    # And loop through all columns.
    for($col = 1; $col -le [int]$TextureColumns; $col++)
    {
      # If this is the first failure create a blank line for the console.
      if ($CheckPassed)
      {
        Write-Host ''
      }
      # If the texture has been selected display the texture's name.
      if ($TextureArray[$row,$col] -eq '<Select a Texture>')
      {
        Write-Host ' ERROR: ' -ForegroundColor Red -NoNewLine
        Write-Host ('No texture selected for Row ' + $row + ' Column ' + $col + '.')
        $CheckPassed = $false
      }
    }
  }
  if (!$CheckPassed)
  {
    Write-Host ''
    Write-Host ' All textures must be selected before processing can begin.'
    Start-Sleep -m 3500
    Clear-Host
  }
  return $CheckPassed
}
#----------------------------------------------------------------------------------------------------------------------------------------------
function GUI_UpdateTextureArray()
{
  # If there is already a texture array then copy all data from it into a temporary array.
  if ($TextureArray -ne $null)
  {
    $OldTextureArray = $TextureArray
  }
  # Recreate the texture array (which inadvertently wipes out all data in it).
  $global:TextureArray = New-Object 'string[,]' ([int]$TextureRows+1),([int]$TextureColumns+1)

  # Loop through all rows and columns.
  for($row = 1; $row -le [int]$TextureRows; $row++)
  {
    for($col = 1; $col -le [int]$TextureColumns; $col++)
    {
      # Check to see if an array was already created.
      if ($OldTextureArray -ne $null)
      {
        # If there was data in the old array then copy that data into the new array.
        if ($OldTextureArray[$row,$col] -ne $null)
        {
          $global:TextureArray[$row,$col] = $OldTextureArray[$row,$col]
        }
        # If there was no data in the previous array then set the initial value to no texture.
        else
        {
          $global:TextureArray[$row,$col] = '<Select a Texture>'
        }
      }
      # If creating a new array then set the initial value to no texture.
      else
      {
        $global:TextureArray[$row,$col] = '<Select a Texture>'
      }
    }
  }
}
#----------------------------------------------------------------------------------------------------------------------------------------------
function GUI_CombineTextures_UpdateName()
{
  # Get the text that was entered by the user.
  $EnteredText = $this.Text

  # Make sure the input only contains letters, numbers, or spaces.
  if (($EnteredText -ne '') -and ($EnteredText -match "^[a-zA-Z0-9\s]+$"))
  {
    # If the check passed then update the name to be used.
    $global:CombinedName = $EnteredText
  }
  # Update the text box with either the new name or the previous name if the above check failed.
  $this.Text = $CombinedName + $PNG
}
#----------------------------------------------------------------------------------------------------------------------------------------------
function GUI_TextureArray_UpdateCells()
{
  # Update the number of rows or cells, and update the texture array with the new value.
  if ($this.Name -eq 'TextureRows')
  {
    $global:TextureRows = $this.Value.ToString()
  }
  else
  {
    $global:TextureColumns = $this.Value.ToString()
  }
  # A dirty method to update other boxes of the same type.
  if ($this -eq $SplitRowsNumBox)
  {
    $CombineRowsNumBox.Value = $TextureRows
  }
  elseif ($this -eq $CombineRowsNumBox)
  {
    $SplitRowsNumBox.Value = $TextureRows
  }
  elseif ($this -eq $SplitColumnsNumBox)
  {
    $CombineColumnsNumBox.Value = $TextureColumns
  }
  elseif ($this -eq $CombineColumnsNumBox)
  {
    $SplitColumnsNumBox.Value = $TextureColumns
  }
  # Update the texture array.
  GUI_UpdateTextureArray
}
#----------------------------------------------------------------------------------------------------------------------------------------------
function GUI_CombineTextures_UpdatePath()
{
  # Store user selection in a temporary variable so it can be verified.
  $TempDirectory = Get-Folder 'Select the default folder for where textures are searched for when selecting a cell. Setting this path will allow selecting textures much more quickly.'

  # Check to see if a folder was selected from the Open menu and test if that path exists.
  if (($TempDirectory -ne '') -and (TestPath $TempDirectory))
  {
    # Add a work-around for when a directory is chosen that does not contain a sub-folder.
    if ((($TempDirectory | Measure-Object -Character).Characters) -eq 3)
    {
      $TempDirectory = $TempDirectory.Replace('\','')
    }
    # If the path is valid then update it.
    $global:SelectionPath = $TempDirectory
  }
}
#----------------------------------------------------------------------------------------------------------------------------------------------
function GUI_CombineTextures_DialogButtonSelect()
{
  # Evaluate which button was clicked by getting its name.
  $Pressed = $this.Name.Split(',')
  $CurrentRow    = [int]$Pressed[0]
  $CurrentColumn = [int]$Pressed[1]

  # Create an open file dialog to grab a PNG image.
  $SelectedFile = Get-FileName $SelectionPath 'PNG Image|*.png'

  # Check if the image exists.
  if (TestPath $SelectedFile)
  {
    # Set the image to the appropriate texture array.
    $global:TextureArray[$CurrentRow,$CurrentColumn] = $SelectedFile

    # Update the button with a preview of the image.
    $ImagePath = [string](Get-ChildItem -LiteralPath $SelectedFile)
    $DiplayImage = [System.Drawing.Image]::FromFile($ImagePath)
    $this.BackgroundImage = $DiplayImage
    $this.Text = ''

    # Update the default path to where the last texture was selected.
    $global:SelectionPath = [string](Get-ChildItem -LiteralPath $SelectedFile).Directory
  }
}
#----------------------------------------------------------------------------------------------------------------------------------------------
function GUI_CombineTextures_DialogDragDrop()
{
  # Make sure there is data present before actually doing anything.
  if ($_.Data.GetDataPresent([Windows.Forms.DataFormats]::FileDrop))
  {
    # Create a list of the data to select the first item from the list.
    $DroppedFile = $_.Data.GetData([Windows.Forms.DataFormats]::FileDrop)
    $FileExtension = [string](Get-ChildItem -LiteralPath $DroppedFile[0]).Extension

    # Make sure the file is a PNG image.
    if ($FileExtension -eq $PNG)
    {
      # Evaluate which button was dropped on by getting it's name.
      $Dropped = $this.Name.Split(',')
      $CurrentRow    = [int]$Dropped[0]
      $CurrentColumn = [int]$Dropped[1]

      # Set the image to the appropriate texture array.
      $global:TextureArray[$CurrentRow,$CurrentColumn] = $DroppedFile[0]

      # Update the button with a preview of the image.
      $ImagePath = [string](Get-ChildItem -LiteralPath $DroppedFile[0])
      $DiplayImage = [System.Drawing.Image]::FromFile($ImagePath)
      $this.BackgroundImage = $DiplayImage
      $this.Text = ''

      # Update the default path to where the last texture was dropped from.
      $global:SelectionPath = [string](Get-ChildItem -LiteralPath $DroppedFile[0]).Directory
    }
  }
}
#----------------------------------------------------------------------------------------------------------------------------------------------
function GUI_CombineTextures_DialogDisplay()
{
  # Set the size of the dialog depending on the number of textures in the array.
  $DialogWidth = 50 * [int]$TextureColumns
  $DialogHeight = 80 + (50 * [int]$TextureRows)

  # Create the dialog that is displayed.
  $CombineDialog = New-Object System.Windows.Forms.Form
  $CombineDialog.AutoSize = $true
  $CombineDialog.AutoSizeMode = [System.Windows.Forms.AutoSizeMode]::GrowAndShrink
  $CombineDialog.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
  $CombineDialog.StartPosition = "CenterScreen"
  $CombineDialog.Text = "Combine Textures"
  $CombineDialog.Size = New-Object System.Drawing.Size($DialogWidth, $DialogHeight)
  $CombineDialog.MinimumSize = New-Object System.Drawing.Size(1, 1)
  $CombineDialog.KeyPreview = $True
  $CombineDialog.MaximizeBox = $false
  $CombineDialog.MinimizeBox = $false
  $CombineDialog.Add_KeyDown( { if ($_.KeyCode -eq "Escape") { $CombineDialog.Close() } } )
  $CombineDialog.Topmost = $True
  $CombineDialog.Add_Shown({$CombineDialog.Activate()})

  # Create arrays, tips, and identifiers for the buttons.
  $global:CombineButton = @()
  $global:CombineTip = @()
  $i = 0

  # Set up the initial offsets for the buttons.
  $ButtonXOffset = 4
  $ButtonYOffset = 4

  # Loop through all rows.
  for($row = 1; $row -le [int]$TextureRows; $row++)
  {
    # And loop through all columns.
    for($col = 1; $col -le [int]$TextureColumns; $col++)
    {
      # Create the current button and add it to the dialog.
      $global:CombineButton += New-Object System.Windows.Forms.Button
      $CombineButton[$i].Location = New-Object System.Drawing.Size($ButtonXOffset, $ButtonYOffset)
      $CombineButton[$i].Size = New-Object System.Drawing.Size(50, 50)
      $CombineButton[$i].Name = ($row.ToString() + ',' + $col.ToString())
      $CombineButton[$i].Text = ($row.ToString() + ',' + $col.ToString())
      $CombineButton[$i].BackgroundImageLayout = 'Stretch'
      $CombineButton[$i].AllowDrop = $true
    # $CombineButton[$i].FlatStyle = [Windows.Forms.FlatStyle]::Flat
    # $CombineButton[$i].FlatAppearance.BorderSize = 0
      $CombineButton[$i].Add_DragEnter({$_.Effect = [Windows.Forms.DragDropEffects]::Copy})
      $CombineButton[$i].Add_DragDrop({GUI_CombineTextures_DialogDragDrop})
      $CombineButton[$i].Add_Click({GUI_CombineTextures_DialogButtonSelect})
      $CombineDialog.Controls.Add($CombineButton[$i])

      # Add a tooltip to show the texture position.
      $global:CombineTip += New-Object System.Windows.Forms.ToolTip
      $CombineTip[$i].InitialDelay = 1000
      $CombineTip[$i].AutoPopDelay = 5000
      $CombineTipString = 'Row ' + $row + ', Column ' + $col
      $CombineTip[$i].SetToolTip($CombineButton[$i], $CombineTipString)

      # If a texture exists in the array then show the image on the current button.
      if ($TextureArray[$row,$col] -ne '<Select a Texture>')
      {
        # Update the button with a preview of the image.
        $ImagePath = $TextureArray[$row,$col]
        $DiplayImage = [System.Drawing.Image]::FromFile($ImagePath)
        $CombineButton[$i].BackgroundImage = $DiplayImage
        $CombineButton[$i].Text = ''
      }
      # Increment the offset and position variables.
      $ButtonXOffset += 50
      $i += 1
    }
    $ButtonXOffset = 4
    $ButtonYOffset += 50
  }
  # Create a "Close" button.
  $CloseButton += New-Object System.Windows.Forms.Button
  $CloseButton.Location = New-Object System.Drawing.Size(4, ($DialogHeight - 60))
  $CloseButton.Size = New-Object System.Drawing.Size(60, 26)
  $CloseButton.Text = 'Done'
  $CloseButton.Add_Click({$CombineDialog.Close()})
  $CombineDialog.Controls.Add($CloseButton)
  $CloseButtonTip = New-Object System.Windows.Forms.ToolTip
  $CloseButtonTip.InitialDelay = $ToolTipDelay
  $CloseButtonTip.AutoPopDelay = $ToolTipDuration
  $CloseButtonTipString = 'Finish adding textures to the array.'
  $CloseButtonTip.SetToolTip($CloseButton, $CloseButtonTipString)

  # After the dialog is fully created, show it to the user.
  $CombineDialog.ShowDialog() | Out-Null
}
#==============================================================================================================================================================================================
#  CTT GUI: SPLIT COMBINED MULTI-TEXTURE FUNCTIONS
#==============================================================================================================================================================================================
function GUI_SplitMultiTexture()
{
  # Output that the loop is about to start to the PS window.
  Clear-Host
  Write_Host '-----------------------------------------------------------------------------------------------------------------------' $ConsoleColors Gray $false
  Write_Host ' Processing textures ...' $ConsoleColors Yellow $false
  Write_Host '-----------------------------------------------------------------------------------------------------------------------' $ConsoleColors Gray $false
  Write-Host ''

  # Create the output path if it doesn't exist.
  $OutputPath = CreatePath ($MasterOutputPath + '\SplitTextures\')

  # Get the name of the texture.
  $OutputName = [string](Get-ChildItem -LiteralPath $CombinedTexture).BaseName

  # Set the full texture output path to include the texture name plus the IM parameter to give it a digit.
  $TexOutputPath = $OutputPath + $OutputName + '_%d.png'

  # Get the width and the height of the image.
  $image = New-Object System.Drawing.Bitmap $CombinedTexture
  $ImageWidth  = $image.Width
  $ImageHeight = $image.Height
  $image.Dispose()

  # Calculate the width and height of each individual image.
  $SplitWidth  = $ImageWidth / [int]$TextureColumns
  $SplitHeight = $ImageHeight / [int]$TextureRows

  # For anything else, crop using the new dimensions.
  $CropGeometry = $SplitWidth.ToString() + 'x' + $SplitHeight.ToString()

  # If a CTT file was selected display that it was loaded.
  if ($CTTDataFile -ne '<None>')
  {
    Write-Host ' Retrieved data from previously generated CTT file...'
    Write-Host ''
  }
  # Otherwise just display that it's being split.
  else
  {
    Write-Host ' Splitting the texture into multiple pieces...'
    Write-Host ''
  }
  # Crop the center image from the tiled image.
  & $IMConvert -quiet $CombinedTexture -crop $CropGeometry '+repage' $TexOutputPath

  # Start with index 0 since that is where ImageMagick starts when renaming the split images.
  $Index = 0

  # Loop through all rows.
  for($row = 1; $row -le [int]$TextureRows; $row++)
  {
    # And loop through all columns.
    for($col = 1; $col -le [int]$TextureColumns; $col++)
    {
      # Create the current name of the texture.
      $CurrentName = $OutputPath + $OutputName + '_' + $Index + '.png'

      # If a CTT file was selected rename all textures back to their original names.
      if ($CTTDataFile -ne '<None>')
      {
        # Create a new name for the texture.
        $UpdateName = $OutputPath + $TextureArray[$row,$col]

        # Display stuff to the console.
        Write-Host (' Texture ' + $row + ',' + $col + ' created as ' + $TextureArray[$row,$col])

        # Rename the texture based on what was found in the CTT file.
        Move-Item -LiteralPath $CurrentName -Destination $UpdateName -Force
      }
      else
      {
        # Update the variable to store only the name of the texture.
        $CurrentName = [string](Get-ChildItem -LiteralPath $CurrentName).Name
      
        # Display stuff to the console.
        Write-Host (' Texture ' + $row + ',' + $col + ' created as ' + $CurrentName)
      }
      # Increment the index number.
      $Index++
    }
  }
  # Pause the script and wait for user input.
  Write-Host ''
  Write_Host '-----------------------------------------------------------------------------------------------------------------------' $ConsoleColors Gray $false
  Write-Host ''
  Write-Host ' Finished!'
}
#----------------------------------------------------------------------------------------------------------------------------------------------
function GUI_CheckCombinedInfo()
{
  if ($CombinedTexture -ne 'Select a texture to split into multiple textures...')
  {
    return $true
  }
  Write-Host ''
  Write-Host ' ERROR: ' -ForegroundColor Red -NoNewLine
  Write-Host 'A texture has not been selected to split.'
  Start-Sleep -m 3500
  Clear-Host
  return $false
}
#----------------------------------------------------------------------------------------------------------------------------------------------
function GUI_SplitTexture_LoadCTTFile()
{
  # Load the selected CTT file.
  $Load_CTTDataFile = Get-FileName $SelectionPath 'CTT File|*.ctt'

  # Test the path to the CTT file.
  if (TestPath $Load_CTTDataFile)
  {
    # Load the selected CTT file.
    $global:CTTDataFile = $Load_CTTDataFile

    # Get the content of the CTT file.
    $CTTContent = Get-Content -LiteralPath $CTTDataFile

    # Update the global variables based on what is found in the CTT file.
    $global:CombinedTexture = $CTTContent | Select-Object -index 0
    $global:TextureRows     = $CTTContent | Select-Object -index 1
    $global:TextureColumns  = $CTTContent | Select-Object -index 2

    # Update the values on the GUI.
    $SplitTextureTextBox.Text   = $CombinedTexture
    $CombineRowsNumBox.Value    = $TextureRows
    $SplitRowsNumBox.Value      = $TextureRows
    $CombineColumnsNumBox.Value = $TextureColumns
    $SplitColumnsNumBox.Value   = $TextureColumns

    # Start reading from line 3.
    $Index = 3

    # Create an array to reference texture names.
    $global:TextureArray = New-Object 'string[,]' ([int]$TextureRows+1),([int]$TextureColumns+1)

    # Loop through all rows.
    for($row = 1; $row -le [int]$TextureRows; $row++)
    {
      # And loop through all columns.
      for($col = 1; $col -le [int]$TextureColumns; $col++)
      {
        # Get the value of the current line.
        $CurrentLine = $CTTContent | Select-Object -index $Index

        # Store the read texture in the current array.
        $TextureArray[$row,$col] = $CurrentLine

        # Increment the index number.
        $Index++
      }
    }
  }
}
#==============================================================================================================================================================================================
#  CTT GUI: MASTER LOOP - PROCESS SINGLE TEXTURE
#==============================================================================================================================================================================================
function UpdateImageButton($inputfile)
{
  # PNG and JPG we can just use the image directly for the preview.
  if (($inputfile.Extension -eq $PNG) -or ($inputfile.Extension -eq $JPG))
  {
    # Get the image from the dropped path.
    $global:ImgObject = [System.Drawing.Image]::FromFile($inputfile)

    # Calculate the new dimensions of the image with proper scaling.
    if ($ImgObject.Width -gt $ImgObject.Height)
    {
      $NewWidth  = 116
      $NewHeight = [int]($ImgObject.Height / ($ImgObject.Width / $NewWidth))
    }
    else
    {
      $NewHeight = 116
      $NewWidth  = [int]($ImgObject.Width / ($ImgObject.Height / $NewHeight))
    }
    # Resize it to fit the button. Convert it into a bitmap so it can be resized.
    $ImgDimens = New-Object System.Drawing.Size($NewWidth, $NewHeight)
    $global:ImgBitMap = New-Object System.Drawing.Bitmap($ImgObject, $ImgDimens)
  }
  # DDS is a bit more complex and requires a temporary texture to be generated.
  elseif ($inputfile.Extension -eq $DDS)
  {
    # Get info about the DDS texture.
    $DDSInfo = GetImageInfo $inputfile $true

    # Calculate the new dimensions of the image with proper scaling.
    if ($DDSInfo.Width -gt $DDSInfo.Height)
    {
      $NewWidth  = 116
      $NewHeight = [int]($DDSInfo.Height / ($DDSInfo.Width / $NewWidth))
    }
    else
    {
      $NewHeight = 116
      $NewWidth  = [int]($DDSInfo.Width / ($DDSInfo.Height / $NewHeight))
    }
    # Create a temporary image for the preview.
    $TempPath    = CreatePath ($TempFolder + '\DDS_Preview\')
    $TempTexture = $TempPath + $inputfile.BaseName + $PNG
    $NewDimensions = $NewWidth.ToString() + 'x' + $NewHeight.ToString()
    & $IMConvert -quiet $inputfile -resize ($NewDimensions + '!') $TempTexture

    # Get the new image as a Drawing.Image.
    $global:ImgObject = [System.Drawing.Image]::FromFile($TempTexture)

    # Resize it to fit the button. Convert it into a bitmap so it can be resized.
    $ImgDimens = New-Object System.Drawing.Size($NewWidth, $NewHeight)
    $global:ImgBitMap = New-Object System.Drawing.Bitmap($ImgObject, $ImgDimens)
  }
  # Add the bitmap to the bitmap list and add the image name to the image file list.
  $global:BitMapList.Add($ImgBitMap)
  $global:ImageFileList.Add($inputfile.Name)

  # Set the image as the preview on the button. Remove the background color and text.
  $this.BackgroundImage = $ImgBitMap
  $this.BackColor = [System.Drawing.Color]::Transparent
  $this.Text = ''

  # Allow pressing the "Start" button.
  $ProcessButton.Enabled = $true

  # Update the default path to where the last texture was dropped from.
  $global:SelectionPath = [string]$inputfile.Directory

  # Set up a temporary path and copy the texture to that path.
  $TempPath    = CreatePath ($TempFolder + '\-SelectedTextures-\')
  $TempTexture = $TempPath + $inputfile.Name
  Copy-Item -LiteralPath $inputfile -Destination $TempTexture -Force

  # Count the number of times an image was dropped onto the window.
  $global:CountStacked += 1

  # Force the current page to the most recently added texture.
  $global:ImageViewPage = $CountStacked

  # If multiple textures are added to the stack, show the count on the button.
  if ($CountStacked -gt 1)
  {
    $this.Font = New-Object System.Drawing.Font('Arial', 20, [Drawing.FontStyle]::Bold)
    $this.Forecolor = [System.Drawing.Color]::White
    $this.Text = $CountStacked.ToString()
    $this.FlatAppearance.BorderSize = 0
    $LeftButton.Enabled = $True
    $RightButton.Enabled = $true
  }
  # Temporarily override the MasterInputPath. This will be set back to normal in "GUI_StartMasterLoop".
  $global:MasterInputPath = $TempFolder
}
#==============================================================================================================================================================================================
function GUI_ProcessSelected_DragAndDrop()
{
  # Make sure there is data present before actually doing anything.
  if ($_.Data.GetDataPresent([Windows.Forms.DataFormats]::FileDrop))
  {
    # Create a list of the data to select the first item from the list.
    $DroppedFile = $_.Data.GetData([Windows.Forms.DataFormats]::FileDrop)

    # Loop through all dropped files.
    foreach($File in $DroppedFile)
    {
      # Get the dropped file.
      $ExtCheck  = $PNG,$DDS,$JPG
      $ImageFile = Get-Item -LiteralPath $File

      # Make sure the texture has a valid extension and it's not already been added to the list.
      if (($ExtCheck -contains $ImageFile.Extension) -and ($ImageFileList -notcontains $ImageFile.Name))
      {
        # Update the image on the button and add the image to the array.
        UpdateImageButton $ImageFile
      }
    }
  }
}
#==============================================================================================================================================================================================
function GUI_ProcessSelected_ButtonClick()
{
  # Create an open file dialog to grab a PNG image.
  $SelectedFile = Get-FileName $SelectionPath 'PNG Image|*.png'

  # Check if the image exists.
  if (TestPath $SelectedFile)
  {
    # Get the selected file.
    $ExtCheck  = $PNG,$DDS,$JPG
    $ImageFile = Get-Item -LiteralPath $SelectedFile

    # Make sure the texture has a valid extension and it's not already been added to the list.
    if (($ExtCheck -contains $ImageFile.Extension) -and ($ImageFileList -notcontains $ImageFile.Name))
    {
      # Update the image on the button and add the image to the array.
      UpdateImageButton $ImageFile
    }
  }
}
#==============================================================================================================================================================================================
function SwitchPage([string]$direction)
{
  # If going left, subtract 1. If going right, add 1.
  if ($direction -eq 'Left') {$Shift = -1} else {$Shift = 1}

  # Alter the page variable.
  $global:ImageViewPage += $Shift

  # If the page has reached 0 (going left), reset it to the top.
  if ($ImageViewPage -le 0)
  {
    $global:ImageViewPage = $CountStacked
  }
  # If the page exceeded the number of images (going right), reset it to the bottom.
  elseif ($ImageViewPage -gt $CountStacked)
  {
    $global:ImageViewPage = 1
  }
  # Convert the list of bitmaps into an array.
  $BitMapList.ToArray()

  # Set the image as the preview on the button. Remove the background color and text.
  $ImageButton.BackgroundImage = $BitMapList[($ImageViewPage-1)]
  $ImageButton.Text = $ImageViewPage
}
#==============================================================================================================================================================================================
function UpdateTempOutputPath()
{
  # Display an "Open Folder" menu to get the path.
  $SelectedFolderPath = Get-Folder 'Select the path to output textures. This change is only temporary, meaning it only affects this run and will not permanently change the global "Output Path".'

  # Check to see if a folder was selected from the Open menu and test if that path exists.
  if (($SelectedFolderPath -ne '') -and (TestPath $SelectedFolderPath))
  {
    # Add a work-around for when a directory is chosen that does not contain a sub-folder.
    if ((($SelectedFolderPath | Measure-Object -Character).Characters) -eq 3)
    {
      $TempOutputPath = $SelectedFolderPath.Replace('\','')
    }
    else
    {
      $TempOutputPath = $SelectedFolderPath
    }
    # Set the output path to the selected path.
    $global:MasterOutputPath = $TempOutputPath + '\~CTT_Generated'
  }
}
#==============================================================================================================================================================================================
function GUI_ProcessSingleTexture()
{
  # Fix for monitor being set to 125% size in Windows. Higher DPI's are still broken but show all menu elements.
  if ($MonitorDPI -eq 120)
  {
    $MenuFont = New-Object System.Drawing.Font('Microsoft Sans Serif', 6.50)
    if (($WindowsVersion -eq '6.0') -or ($WindowsVersion -eq '6.1'))
    {
      $SingleDialogOffset = 5
      $SingleDialogHeight = 232
    }
    else
    {
      $SingleDialogOffset = 8
      $SingleDialogHeight = 246
    }
  }
  else
  {
	$MenuFont = New-Object System.Drawing.Font('Microsoft Sans Serif', 8.25)
	$SingleDialogOffset = 0
	$SingleDialogHeight = 235
  }
  # Back up the MasterInputPath so it can be restored after it has been set to something else.
  $global:MasterInputSave  = $MasterInputPath
  $global:MasterOutputSave = $MasterOutputPath
  $global:CountStacked     = 0
  $global:ImageViewPage    = 0
  $global:ProcessSelected  = $false

  # Create a list to store the collection of images as bitmaps.
  $global:BitMapList = New-Object System.Collections.Generic.List[System.Object]
  $global:ImageFileList = New-Object System.Collections.Generic.List[System.Object]

  # Create the dialog that is displayed.
  $SingleDialog = New-Object System.Windows.Forms.Form
  $SingleDialog.Font = $MenuFont
  $SingleDialog.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
  $SingleDialog.StartPosition = "CenterScreen"
  $SingleDialog.Text = "Process Selected"
  $SingleDialog.Size = New-Object System.Drawing.Size(160, $SingleDialogHeight)
  $SingleDialog.KeyPreview = $True
  $SingleDialog.MaximizeBox = $false
  $SingleDialog.MinimizeBox = $false
  $SingleDialog.Add_KeyDown({if ($_.KeyCode -eq "Escape") {$SingleDialog.Close()}})
  $SingleDialog.Topmost = $True
  $SingleDialog.Add_Shown({$SingleDialog.Activate()})

  # Create the Start button and add it to the dialog.
  $global:ProcessButton = New-Object System.Windows.Forms.Button
  $ProcessButton.Size = New-Object System.Drawing.Size(80, 28)
  $ProcessButton.Location = New-Object System.Drawing.Size((32 + $SingleDialogOffset), 132)
  $ProcessButton.Text = 'Start'
  $ProcessButton.Enabled = $false
  $ProcessButton.Add_Click({$global:ProcessSelected = $true ; $SingleDialog.Close()})
  $SingleDialog.Controls.Add($ProcessButton)

  # Create the image button and add it to the dialog.
  $global:ImageButton = New-Object System.Windows.Forms.Button
  $ImageButton.Size = New-Object System.Drawing.Size(116, 116)
  $ImageButton.Location = New-Object System.Drawing.Size((14 + $SingleDialogOffset), 10)
  $ImageButton.Text = 'Drag and drop images or click here.'
  $ImageButton.BackColor = [System.Drawing.ColorTranslator]::FromHtml('#E0E0E0')
  $ImageButton.BackgroundImageLayout = 'Center'
  $ImageButton.AllowDrop = $true
  $ImageButton.FlatStyle = [Windows.Forms.FlatStyle]::Flat
  $ImageButton.FlatAppearance.BorderSize = 1
  $ImageButton.Add_DragEnter({$_.Effect = [Windows.Forms.DragDropEffects]::Copy})
  $ImageButton.Add_DragDrop({GUI_ProcessSelected_DragAndDrop $ProcessButton})
  $ImageButton.Add_Click({GUI_ProcessSelected_ButtonClick $ProcessButton})
  $SingleDialog.Controls.Add($ImageButton)

  # Create the Left button and add it to the dialog.
  $global:LeftButton = New-Object System.Windows.Forms.Button
  $LeftButton.Size = New-Object System.Drawing.Size(20, 28)
  $LeftButton.Location = New-Object System.Drawing.Size((6 + $SingleDialogOffset), 132)
  $LeftButton.Text = '<'
  $LeftButton.Enabled = $false
  $LeftButton.Add_Click({SwitchPage 'Left'})
  $SingleDialog.Controls.Add($LeftButton)

  # Create the Right button and add it to the dialog.
  $global:RightButton = New-Object System.Windows.Forms.Button
  $RightButton.Size = New-Object System.Drawing.Size(20, 28)
  $RightButton.Location = New-Object System.Drawing.Size((118 + $SingleDialogOffset), 132)
  $RightButton.Text = '>'
  $RightButton.Enabled = $false
  $RightButton.Add_Click({SwitchPage 'Right'})
  $SingleDialog.Controls.Add($RightButton)

  # Create the Output path button and add it to the dialog.
  $global:OutPathButton = New-Object System.Windows.Forms.Button
  $OutPathButton.Size = New-Object System.Drawing.Size(132, 28)
  $OutPathButton.Location = New-Object System.Drawing.Size((6 + $SingleDialogOffset), 164)
  $OutPathButton.Text = 'Change Output Path'
  $OutPathButton.Enabled = $true
  $OutPathButton.Add_Click({UpdateTempOutputPath})
  $SingleDialog.Controls.Add($OutPathButton)

  # After the dialog is fully created, show it to the user.
  $SingleDialog.ShowDialog() | Out-Null

  # Clear the lists and dispose of the bitmaps so windows no longer has hooks to them.
  $global:BitMapList = $null
  $global:ImageFileList = $null
  if ($ImgObject -ne $null) {$ImgObject.Dispose()}
  if ($ImgBitMap -ne $null) {$ImgBitMap.Dispose()}

  # Check that the "Start" button was pressed and that there are images in the stack.
  if (($ProcessSelected) -and ($CountStacked -ge 1))
  {
    # Then process only the images in the stack.
    return $true
  }
  # If the X button was click, set the paths back to what they were.
  $global:MasterInputPath = $MasterInputSave
  $global:MasterOutputPath = $MasterOutputSave

  # Remove all the temporary files this option created.
  RemovePath $TempPath

  # Return to the main menu.
  return $false
}
#==============================================================================================================================================================================================
#  CTT GUI: MASTER LOOP INITIATION
#==============================================================================================================================================================================================
function GUI_Start_ScanTextures()
{
  # Update the title bar and which option to run.
  $global:TitleBarMessage = ' - Scanning '
  $global:MasterOperation = 'ScanAllTextures'
  return $true
}
#==============================================================================================================================================================================================
function GUI_Start_RescaleTextures()
{
  # Update the title bar and which option to run.
  $global:TitleBarMessage = ' - Rescaling '
  $global:MasterOperation = 'ForceIntScaling'
  return $true
}
#==============================================================================================================================================================================================
function GUI_Start_ConvertTextures()
{
  # Update the title bar and which option to run.
  $global:TitleBarMessage = ' - Converting '
  $global:MasterOperation = 'ConvertTextures'
  return $true
}
#==============================================================================================================================================================================================
function GUI_Start_MaterialMapTextures()
{
  # Make sure Ishiiruka Tool location is known.
  if (!(TestPath $IshiirukaTool))
  {
    # If it's not then show an error message and prevent the Master Loop from running.
    Write-Host ''
    Write-Host ' ERROR:' -ForegroundColor Red -NoNewLine
    Write-Host ' Ishiiruka Tool was not found. Click the "Options" button and locate the path to Ishiiruka Tool.'
    Start-Sleep -m 3500
    Clear-Host
    return $false
  }
  # Update the title bar.
  $global:TitleBarMessage = ' - Material Mapping '

  # Update which option to run based on whether or not the user wants to create materials in-place or not.
  if ($InPlaceMaterial)
  {
    $global:MasterOperation = 'MaterialInPlace'
  }
  else
  {
    $global:MasterOperation = 'CreateMaterials'
  }
  return $true
}
#==============================================================================================================================================================================================
function GUI_Start_WatermarkTextures()
{
  # Update the title bar and which option to run.
  $global:TitleBarMessage = ' - Watermarking '
  $global:MasterOperation = 'CreateWatermark'
  return $true
}
#==============================================================================================================================================================================================
function GUI_Start_OptiPNGTextures()
{
  # Make sure OptiPNG location is known.
  if (!(TestPath $OptiPNGPath))
  {
    # If it's not then show an error message and prevent the Master Loop from running.
    Write-Host ''
    Write-Host ' ERROR:' -ForegroundColor Red -NoNewLine
    Write-Host ' OptiPNG was not found. Click the "Options" button and locate the path to OptiPNG.'
    Start-Sleep -m 3500
    Clear-Host
    return $false
  }
  # Update the title bar.
  $global:TitleBarMessage = ' - Optimizing '

  # Update which option to run based on whether or not the user wants to optimize textures in-place or not.
  if ($InPlaceOptiPNG) 
  {
    $global:MasterOperation = 'OptimizeInPlace'
  }
  else
  {
    $global:MasterOperation = 'OptiPNGTextures'
  }
  return $true
}
#==============================================================================================================================================================================================
function GUI_Start_UpscaleFilterTextures()
{
  # Check if xBRZ was selected as the filter.
  if ($FilterSelected -eq 'xBRZ')
  {
    # If ScalerTest is not found then show an error and exit.
    if (!(TestPath $ScalerTestPath))
    {
      Write-Host ''
      Write-Host ' ERROR:' -ForegroundColor Red -NoNewLine
      Write-Host ' xBRZ ScalerTest was not found. Click the "Options" button and locate the path to the xBRZ ScalerTest.'
      Start-Sleep -m 3500
      Clear-Host
      return $false
    }
    # Store the strength in the chosen filter.
    $global:UpscaleFilter = $FilterNewScale + 'xBRZ'
  }
  # Check if waifu2x was selected as the filter.
  elseif ($FilterSelected -eq 'Waifu2x')
  {
    # If waifu2x is not found then show an error and exit.
    if (!(TestPath $Waifu2xPath))
    {
      Write-Host ''
      Write-Host ' ERROR:' -ForegroundColor Red -NoNewLine
      Write-Host ' Waifu2x was not found. Click the "Options" button and locate the path to the Waifu2x.'
      Start-Sleep -m 3500
      Clear-Host
      return $false
    }
    # Store the strength in the chosen filter.
    $global:UpscaleFilter = 'waifu' + $FilterNewScale + 'x'

    # String variables that are fed to waifu2x as paramters in the command line. 
    # Default them to an empty value so they aren't passed unless they are actually needed.
    $global:wf2xOpenCL = ''
    $global:wf2xNoGpuA = ''
    $global:wf2xNoGpuB = ''
    $global:wf2xModelA = ''
    $global:wf2xModelB = ''

    # Set up options based on Waifu2x-CPP.
    if ($Waifu2xApp -eq 'waifu2x-converter_x64.exe')
    {
      # Set up the NoGPU toggle.
      if ($Waifu2xNoGPU)
      {
        $global:wf2xNoGpuA = '--disable-gpu'
        $global:wf2xNoGpuB = ''
      }
      # Set up the OpenCL toggle, this only works with waifu2x-CPP.
      if ($Waifu2xOpenCL)
      {
        $global:wf2xOpenCL = '--force-OpenCL'
      }
    }
    # Set up options based on Waifu2x-Caffe.
    elseif ($Waifu2xApp -eq 'waifu2x-caffe-cui.exe')
    {
      # Set up the NoGPU toggle.
      if ($Waifu2xNoGPU)
      {
        $global:wf2xNoGpuA = '--process'
        $global:wf2xNoGpuB = 'cpu'
      }
      # If using Waifu2x-Caffe, impose the selected model.    
      $global:wf2xModelA = '--model_dir'
      $global:wf2xModelB = "models\" + $Waifu2xModel
    }
  }
  # Any other filter can simply use the selected filter name.
  else
  {
    # Force it to lowercase so it can be passed to ImageMagick.
    $global:UpscaleFilter = $FilterSelected.ToLower()
  }
  # Update the title bar and which option to run.
  $global:TitleBarMessage = ' - Filtering '
  $global:MasterOperation = 'UpscaleTextures'
  return $true
}
#==============================================================================================================================================================================================
function GUI_Start_GenerateMipMaps()
{
  # Update the title bar and which option to run.
  $global:TitleBarMessage = ' - MipMapping '
  $global:MasterOperation = 'GenerateMipMaps'
  return $true
}
#==============================================================================================================================================================================================
function GUI_Start_RemoveBadMipMaps()
{
  # Update the title bar and which option to run.
  $global:TitleBarMessage = ' - Checking '
  $global:MasterOperation = 'RemoveBadMipMap'
  return $true
}
#==============================================================================================================================================================================================
function GUI_Start_AlphaChannel()
{
  # Update the title bar and which option to run.
  $global:TitleBarMessage = ' - De-Alpha-ing '
  $global:MasterOperation = 'AlphaChannelFix'
  return $true
}
#==============================================================================================================================================================================================
function GUI_Start_FixBrokeOptiPNG()
{
  # Update the title bar and which option to run.
  $global:TitleBarMessage = ' - Repairing '
  $global:MasterOperation = 'FixBrokeOptiPNG'
  return $true
}
#==============================================================================================================================================================================================
function GUI_Start_CombineTextures()
{
  # Make sure the texture array is completely filled.
  if (GUI_CheckTextureArray)
  {
    # Update the title bar and which option to run.
    $global:TitleBarMessage = ' - Combining Textures '
    GUI_CombineMultipleTextures
  }
  return $false
}
#==============================================================================================================================================================================================
function GUI_Start_SplitMultiTexture()
{
  # Make sure a texture has been selected.
  if (GUI_CheckCombinedInfo)
  {
    # Update the title bar and which option to run.
    $global:TitleBarMessage = ' - Splitting Multi-Texture '
    GUI_SplitMultiTexture
  }
  return $false
}
#==============================================================================================================================================================================================
function GUI_StartMasterLoop()
{
  # If the control button was held when pressing start.
  if ([System.Windows.Forms.Control]::ModifierKeys -eq [System.Windows.Forms.Keys]::Control)
  {
    # Allow processing selected textures rather than the input folder.
    if (!(GUI_ProcessSingleTexture))
    {
      # If the image was not set when the dialog was closed do not start the loop.
      return
    }
    # Remember that selected textures are being processed so the master input folder can be restored at the end of this function.
    $SelectedTextures = $true
  }
  # If the console was hidden then show it.
  ShowPowerShellConsole $true

  # Hide the main GUI.
  $Dialog.Visible = $false

  # Hide the help dialog if it is visible to the user.
  if ($HelpDialog.Visible)
  {
    $HelpWasVisible = $true
    $HelpDialog.Visible = $false
  }
  # If ImageMagick was not found, prompt the user to find it.
  if (!(FindImageMagick))
  {
    # Remove all the now worthless junk.
    Clear-Host

    # Reshow the dialog.
    $Dialog.Visible = $true

    # Exit the function early.
    return
  }
  # If the standard options menu is visible then run a standard option.
  if ($CurrentOptions -eq 'Standard')
  {
    # Get the index of the selected option.
    $SelectedIndex = $StandardOptions.SelectedIndex.ToString()

    # Set up the corresponding option.
    switch ($SelectedIndex)
    {
      '0' { $RunMasterLoop = GUI_Start_ScanTextures }
      '1' { $RunMasterLoop = GUI_Start_RescaleTextures }
      '2' { $RunMasterLoop = GUI_Start_ConvertTextures}
      '3' { $RunMasterLoop = GUI_Start_MaterialMapTextures }
      '4' { $RunMasterLoop = GUI_Start_WatermarkTextures }
      '5' { $RunMasterLoop = GUI_Start_OptiPNGTextures }
      '6' { $RunMasterLoop = GUI_Start_UpscaleFilterTextures }
    }
  }
  # If the advanced options menu is visible then run an advanced option.
  else
  {
    # Get the index of the selected option.
    $SelectedIndex = $AdvancedOptions.SelectedIndex.ToString()

    # Set up the corresponding option.
    switch ($SelectedIndex)
    {
      '0' { $RunMasterLoop = GUI_Start_GenerateMipMaps}
      '1' { $RunMasterLoop = GUI_Start_RemoveBadMipMaps }
      '2' { $RunMasterLoop = GUI_Start_AlphaChannel }
      '3' { $RunMasterLoop = GUI_Start_FixBrokeOptiPNG }
      '4' { $RunMasterLoop = GUI_Start_CombineTextures }
      '5' { $RunMasterLoop = GUI_Start_SplitMultiTexture }
    }
  }
  # Only run the master loop if no errors were found.
  if ($RunMasterLoop)
  {
    # Run the selected option and then reset all globals.
    MasterLoop
    ResetGlobalVars
  }
  # Enable the GUI.
  $Dialog.Visible = $true
  $Dialog.Activate()

  # Automatically hide the console window if the user wanted.
  if (!$AlwaysShowConsole)
  {
    ShowPowerShellConsole $false
  }
  # If the help dialog was visible then reshow it.
  $HelpDialog.Visible = $HelpWasVisible

  # Restore the MasterInputPath if it was altered for selected textures.
  if ($SelectedTextures)
  {
    $global:MasterInputPath = $MasterInputSave
    $global:MasterOutputPath = $MasterOutputSave
  }
  # If the user pressed Control + C during the loop, exit the script now.
  if ($FastClose)
  {
    $Dialog.Close()
  }
}
#==============================================================================================================================================================================================
#  INITIALIZATION: TEMPORARY FOLDER TEST
#==============================================================================================================================================================================================
#  Tests the temporary folder to se if it can be written to. If not it defaults to "C:\CTT-PS_Temp".

function TestTempFolder()
{
  # Set up a path to attempt to create a test document.
  $TestWritePath = $TempFolder + '\test.txt'

  # Create a folder to store the temporary document in.
  CreatePath $TempFolder | Out-Null

  # Attempt to create a text document.
  Add-Content -LiteralPath $TestWritePath -value "test"

  # Test the path to see if it exists.
  if (!(Test-Path -LiteralPath $TestWritePath))
  {
    # Output an error message to alert the user the Temp Folder is not a valid location.
    Write_Host '-----------------------------------------------------------------------------------------------------------------------' $ConsoleColors Gray $false
    Write-Host (' ' + $ScriptName)
    Write_Host '-----------------------------------------------------------------------------------------------------------------------' $ConsoleColors Gray $false
    Write-Host ''
    Write-Host ' NOTICE:'  -ForegroundColor Red -NoNewLine
    Write-Host ' FAILED TO WRITE TO TEMP FOLDER'
    Write-Host ''
    Write-Host ' Temp Folder will be automatically relocated to "C:\CTT-PS_Temp"'
    Write-Host ' This path may be changed by pressing the "Options" button on the GUI.'
    Write-Host ''
    Write-Host ' Press any key to start the script.'

    # Update the temp folder when the script is closed.
    $global:UpdateTempFolder = $true

    # Update the global variable with the new path.
    $global:TempFolder = "C:\CTT-PS_Temp"

    # Pause the script and wait for user input.
    [void][System.Console]::ReadKey($true)
  }
  # The file was successfully created.
  else
  {
    # Destroy the Temp Folder.
    RemovePath $TempFolder
  }
}
#==============================================================================================================================================================================================
#  INITIALIZATION A: STUFF TO DO BEFORE CREATING THE GUI - Yep there's an INITIALIZATION B section as well at the end of this script.
#==============================================================================================================================================================================================
# Clean any junk off the screen.
Clear-Host

# Get the folder the script is in.
$global:BaseFolder = Split-Path $script:MyInvocation.MyCommand.Path

# Test if the user stored a texture folder using the checkbox.
if (($StoreInputFolder) -and (TestPath $SavedInputFolder))
{
  # If the folder exists, set the master input path here.
  $global:MasterInputPath = $SavedInputFolder
}
# Otherwise just use the current folder the script is in.
else
{
  $global:MasterInputPath = $BaseFolder
}
# Test if the user stored an output folder using the checkbox.
if (($StoreOutputFolder) -and (TestPath $SavedOutputFolder))
{
  # If the folder exists, set the master output path here.
  $global:MasterOutputPath = $SavedOutputFolder + '\~CTT_Generated'
}
# Otherwise just use the current folder the script is in.
else
{
  $global:MasterOutputPath = $BaseFolder + '\~CTT_Generated'
}
# Get the name of the script and the path to the script.
$global:ScriptName = $MyInvocation.MyCommand.Name.Replace('.ps1','')
$global:ScriptPath = $MyInvocation.MyCommand.Path

# Store the current version of PowerShell as a single number (ex: "5.0.10240.16384" simply becomes "5")
$PSSplit = $PSVersionTable.PSVersion.ToString().Split('.',2)
$global:PSVersion = [int]$PSSplit[0]

# Function that tests if the temporary folder can be written to. Defaults the folder to "C:\CTT-PS_Temp" if it can't.
TestTempFolder

# Set the paths to all DDS Utilities.
if (TestPath $NvidiaTools)
{
  $global:NVDXT   = $NvidiaTools + '\nvdxt.exe'
  $global:NSTITCH = $NvidiaTools + '\stitch.exe'
  $global:NDETACH = $NvidiaTools + '\detach.exe'

  # Easy variable to reference if Nvidia Tools are installed.
  $global:NVDXT_Exists = Test-Path -LiteralPath $NVDXT
}
#  If Waifu2x exists get which one is currently selected.
if (TestPath $Waifu2xPath)
{
  $global:Waifu2xApp = [string](Get-Item -LiteralPath $Waifu2xPath).Name
}
# Set all global variables to their default state. This most likely isn't necessary, but it can't hurt either.
ResetGlobalVars

# Force the PowerShell console window size (fixes size for PowerShell v2 and allows more lines for all PS versions).
$host.UI.RawUI.BufferSize = New-Object System.Management.Automation.Host.Size(120,20000)
$host.UI.RawUI.WindowSize = New-Object System.Management.Automation.Host.Size(120,50)

# Find the number of running instances of powershell.
$PSInstances = @(Get-Process powershell -ErrorAction SilentlyContinue).Count

# Don't attempt to center the console if PowerShell v2 is found, if the user disabled it, or if there is already a running instance.
if (($PSVersion -gt 2) -and ($AutoCenterConsole) -and ($PSInstances -lt 2))
{
  # Get the resolution of the primary monitor.
  [int]$Screen_X = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Width
  [int]$Screen_Y = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Height

  # Calculate the new position of the screen.
  $ScreenPosition_X = (($Screen_X / 2) - 436) # The PS console is (873) pixels wide, so divide the resolution in half and subtract half the PS window (436).
  $ScreenPosition_Y = (($Screen_Y / 2) - 319) # The PS console is (639) pixels tall, so divide the resolution in half and subtract half the PS window (319).

  # Set the position of the PowerShell window.
  Get-Process powershell | Set-Window -X $ScreenPosition_X -Y $ScreenPosition_Y
}
#==============================================================================================================================================================================================
#  CTT GUI - MAIN DIALOG CREATION
#==============================================================================================================================================================================================
#  Create an icon for the GUI using a Base64 string. 
#  Source: https://blog.netnerds.net/2015/10/use-base64-for-notifyicon-in-powershell/

function DialogSetIcon($InputDialog)
{
  $B64 =  'iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH4AsUEzAXMM7u5gAACspJREFUWMOVl2uMVdd1x
      3977/O47zsPZpjBA8MMGIhNsIEQjNyoEQ/xclNSp477QI7qurbSfmiiyFXtRlHSWq7qtEkTqWmbtnEiQlrJrVsTnjXExdgxxhAS7BjCy8O8GWbu3Dv33vPce/fDMHatOLG6v6yjo33W+q//Olp
      r/QW/5IyPjzN//nyGhoak53kdUsrlwD1CiA1CiGVA+82rU8AFY8zLxph9wIXLly/f2LBhg7XWMjAwwOLFi98zhnivl2NjY3R1dc093+E4zmellBuFED1CCKSU7+nMWosxBmPMsDHmWJqmX+/u7
      j71y5IU78PANxzHeUQphRCzV+cs2Pd0Za1926ZpqtM0/XpXV9dnKpUKtVqN3t7eXwxgZGSEBQsWMDo6ukJKucd13bVKKaukEGGUcL3SoNqICBNNmgLCYuysEyXAdwTlYoaOljyFnE+qDcYYkiQ
      5myTJb/X09JwfGBh4F4ifY2B4ePhux3G+77pui5QSJQWvXxrjpwM3WHRLJx1tRXzPQTkO8iYb2liMTonjhOuTNa6NTNDbWeSuVX1oY9FaE8fxRJIkmxYuXHju6tWr9PX1vQPg2rVrLFq0iMHBw
      RWu6/7Q87wWpRRBGHPk5M+YCix3r16K57sYK7BCYsVcFezbVmIRFqIo5JWzl0iDJvduWkVLKY/WmiiKkiiKevr6+q7P/WfvYmBoaOg13/fXOo7DxNQMew7/hGypzIbVS1GuQ4pAG9AWtAFzs95
      zJVDS4gpQWIxOOPPGW4wMjrB7+xoW93QQxwlhGP4sDMP1S5cunQYQV65cob+/n4GBgW/4vv+I67pEccJTe16k6Ra551dXYqRDagWRtkSppZkYYm0x1iIBJSyOEPgOZBzwlcCTkEYxx187z9hbA
      3zhD7bSNa+FKI6Jougvoyh6bNmyZVYAXLp06Q7f989mMhnru0o8tedljl2s8Jvb1lFuyRMbSTPVTIcGRwg+0leiv83nwo2AH1yaphZqXMEsACXIOFD0JVkFo+PTHD95jvme5ck/3IbvuQRBECV
      J0tff3z8qz549K6WUn3UcB9eR4sBL53n6+DDZzvmEymW0bhisxVyZiunMK3579TzuXlyip8VjZZtka1+GZpQyPhMzWAmpNGO23tbBgrxkqBrh5TJUnQInLs9w8KU3kULgOI5vrX0SwMnlch03m
      wyNZsiTe89SzXcQ+0UmmobYxNRCw0Mfbqev1aet4FMNE7514iqHrwZIwFECLGQd+POdK7g0Ps3+NybxXUXBkwSqyA2nyJ998zi7ProSIQRKqQdOnTr1aQksl1L2AJx+Y4QLIwk1Wea6zjBWT7k
      8FbO4LFhQdGkt5qhFKfvPjfHvFwJiIwi1YCYyVIOUDy0soJTg268McbUSMlwNyHuSG9qlZrOMjSb8677XcF2FlJJCofCAtNbeI4TAWsPJM4OEMx6YLBN1xVA14ddva+ETq7tpK+WYDlPeHJpi1
      50LWNOTpxpo6lFKI0yZiVJSbRDAH228FWsNXSWfe9d0c6MGaBf8Ev/wLz/EdeQcCzuktXbDXOt89UfjoDKQukxWLI9vvoXfv2sBfe05ZiLNc2cGWLGwDaUkf7trCesWF6hpQ1UblnRm+NSGHlI
      LC9vz/P3vrOapT6zie6fGiOsGYgkiw7XBBmMT1bmWvtwBlgHoVHNlfAYKbYCCRPL0C2Os6y2TGMmViRqPvTDBq2NNvrrrduqp5Mv3LOGLL1xjpBry19v7KfkuRkgO/mSQgckmpwbr/NerNWxsw
      SjI+qRZj+GRCrf2d2Kt7XKste0AxhqqUQqtEhwLQrL3RwrpXOCJjy/mjw9dg0KW565b0v1v8hebV5BxJE9s7EVJmEmgkUqOnh/gd/cNzwZsaJi52etcAa6D8RQzzXhuYOWl1hpjDFprlCdAWVA
      apAHPsve84sP/eJmfGh9KLqI1w6HE429eHyIxlloKUxHUEst3zw/x0MnreK05cHxIFGQUuBIcwBPgSQQWY2ZHt2OMmbLWdmChtewwLpJZAJ4FD0zeZTyXR5TAK8Y4BQebcbmYUSRWEOrZUaCEo
      OL50FUiaXhgYkgtCAOhBiHABeVCseDNJd1wtNYXtNYdQgiWLipyfiAEqcEzkBVQktAqsHlNvSVL0uKzvuTylc4sEghSixIgpODzyzsIHMVXLs+AzAAGrAaRggFI8XxBV0eRm8yPyTRNX07TFGs
      ta5fPAx2AiMDTkBdQFJBL6JyneHxZiccW5vhWd5aCFDS14Nlqle/emEQZwURi+NKSVv7qtjKiZKHVg5ILOQWuBRtye1+JciE7N6LPO1rrfUmSPOo4Dncu6aAjc42KDUgdDX4KvqS94HBmzXwwB
      lcpLJAgOD49wd+1tiAcBzk+zu91dFJJLI/0lLHa8OjpScgrCAWqmqCbDT61dTVxokmShCRJDso0TS/EcTxsjGH54nnc3uGRi6rkbIOMDBEi5tGePC9NVNk5cJ1jkzW0FpypN/hSawtF1yUHfHt
      eO/85PY0xghuR5dO9bXztjjZKXkpWJGTTBh/sdvnouiXESUoYhkxNTe1V69evD9rb2+/0PO8O3/Pp6/B57uUr5FuL5PIKJ+cgdJN/0i6TbW0cdRyWBw0avs+Lrovl5n5gJT9A0nF9gt5CmanY0
      F/MYRt1Lg6M402M8fiulSzqaiOOY+r1+tObN2/+N/nwww/bMAy/1mg00lRrblvazUMf6UZMTZAN6pSTiFciF5tY5EzIBwyszBZ5oR4QRNCILI3I0owMJobPpy7/PThCauDHwxMcOHcVpzbNr/T
      mWPuBWzBa02w2dZIknwNQly9fZu3atSO7d+9uU0rd5bget/a0MjA4zltTMRlf4TsKISXdOmY3CfsqMxwUDjo12FBDECMaEaIe4jUSfny9RjI5yT+/epHKyDR9psaf3ruG1kKOKAhoNBpPNRqN7
      z/44IOIo0ePsmnTJgBOnDhxptzSslp5HtONOl/43mleT7MUFsxDzitjygV01iPNeRjHwarZhUwYEFqjogQVxKjaDExWaY5N0xvXeOL+NXSWiqRRRLVSGZ2cnFyya9eu4F1b8cmTJ6nWaisKudz
      /FMvlTum6hEnEN59/kyMDTeJSiWx7EVHMQ9bHeg5WqdmPjUEmKYQxtt4kqtRhqsr6dodHtixnfrmIiWNmqtWparX6oR07dlx9/vnn2bx58zsADh06xLZt2zhy5MgHs9ns6WK57DqeR5imXByd4
      j9eG+T4tQayXMIt5nAyHlIJEAKrDTpKiRoBcaXGmg6X+9YtZNWiDvKeSxpF1Gu1qSAINm3ZsuXsXPCf0wWHDx9m69at7N+/v7NQKLyYLxaX+ZkMRggSnTJameHYuRFOv1VlIrQYJW+WQFN2YdU
      tRbasWsCS7jaUVChriYKAmVpttF6r3f1rH/vY1feVZgcOHGDHjh08++yzLaVS6U/8TOYzmWzW9zwPKyVCzE7OZhTTCDQGQ953yGd9lJRYM1uSJI4JgkDHYfjlyYmJL953//3BXILvqw2PHTvGx
      o0beeaZZ0ShUOhSSj3p+f4D2WwWx3WRcnajsQje0SdvyzCiMCQKw6e11p8Lg+bUro//hj148CDbt2///4nT/3v2fOc7uXmdnQ+4rrfDcdRyJVWXEOQtAmttwxo9lqT6fJrEB6vV6t77PvnJKsD
      +/fvZuXPnL/T7v2ctaRyINKcJAAAAAElFTkSuQmCC'

  # Powershell doesn't care about the spaces in the string but remove them anyway. Makes it easier to export the icon if I want to.
  $B64 = [regex]::Replace($B64,'\s','')

  # Create a streaming image by streaming the base64 string.
  $Stream = [System.IO.MemoryStream][System.Convert]::FromBase64String($B64)
  $Bitmap = New-Object System.Drawing.Bitmap($Stream)

  # Convert the bitmap into an icon and display it on the dialog.
  $Image = $Bitmap
  $Icon  = [System.Drawing.Icon]::FromHandle($Image.GetHicon())
  $InputDialog.Icon = $Icon
  $Bitmap.Dispose()
}
#==============================================================================================================================================================================================
#  CTT GUI - MAIN DIALOG
#==============================================================================================================================================================================================
$ToolTipDelay = 1000
$ToolTipDuration = 30000
#==============================================================================================================================================================================================
# Get the version of Windows so different values can be assigned to the size of the form based on which version of Windows is found.
# The reason is because the values set for forms do not seem to be consistent between earlier and later versions of windows.
#==============================================================================================================================================================================================
$GetWinVersion = ([System.Environment]::OSVersion.Version).ToString().Split('.')
$WindowsVersion = $GetWinVersion[0] + '.' + $GetWinVersion[1]

# Windows Vista/7
if (($WindowsVersion -eq '6.0') -or ($WindowsVersion -eq '6.1'))
{
  $DialogWidth    = 404
  $DialogMaxWidth = 794
}
# Windows 8-10
else
{
  $DialogWidth    = 414
  $DialogMaxWidth = 806
}
#==============================================================================================================================================================================================
# Depending on the monitor's DPI, adjust the font displayed on all dialogs and tweak the dialog's height.
#==============================================================================================================================================================================================
# Get an instance of the graphics class to get the monitor's current Dpi.
$Graphics   = [System.Drawing.Graphics]::FromHwnd([IntPtr]::Zero)
$MonitorDPI = $Graphics.DpiX

# If the monitor is set to 125% size in Windows.
if ($MonitorDPI -eq 120)
{
  $MenuFont = New-Object System.Drawing.Font('Microsoft Sans Serif', 6.50)
  if (($WindowsVersion -eq '6.0') -or ($WindowsVersion -eq '6.1'))
  {
    $DialogHeight = 456
  }
  else
  {
    $DialogHeight = 470
  }
}
# For some reason 100%, 150%, 175%, and beyond come back as 96 DPI.
else
{
  $MenuFont = New-Object System.Drawing.Font('Microsoft Sans Serif', 8.25)
  $DialogHeight = 464
}
#==============================================================================================================================================================================================
#  CTT GUI - Create the main Dialog.
#==============================================================================================================================================================================================
$Dialog = New-Object System.Windows.Forms.Form
$Dialog.Text = $ScriptName
$Dialog.Size = New-Object System.Drawing.Size($DialogWidth, $DialogHeight)
$Dialog.MinimumSize = New-Object System.Drawing.Size($DialogWidth, $DialogHeight)
$Dialog.MaximumSize = New-Object System.Drawing.Size($DialogMaxWidth, $DialogHeight)
$Dialog.MaximizeBox = $false
$Dialog.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::None
$Dialog.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
$Dialog.StartPosition = "CenterScreen"
$Dialog.KeyPreview = $true
$Dialog.Topmost = !$DisableTopMost
$Dialog.Add_KeyDown({if ($_.KeyCode -eq "Escape") {$Dialog.Close()}})
$Dialog.Font = $MenuFont
DialogSetIcon $Dialog
#$Dialog.Add_Shown({ })
#$Dialog.Add_FormClosed({ })
#==============================================================================================================================================================================================
#  CTT GUI - Create Input Path Selection
#==============================================================================================================================================================================================
$InputGroup = New-Object System.Windows.Forms.GroupBox
$InputGroup.Size = New-Object System.Drawing.Size(380, 50)
$InputGroup.Location = New-Object System.Drawing.Size(10, 5)
$InputGroup.Text = ' Texture Path '
$Dialog.Controls.Add($InputGroup)
$InputGroupTip = New-Object System.Windows.Forms.ToolTip
$InputGroupTip.InitialDelay = $ToolTipDelay
$InputGroupTip.AutoPopDelay = $ToolTipDuration
$InputGroupTipString = 'Path to the folder that contains textures.'
$InputGroupTip.SetToolTip($InputGroup, $InputGroupTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$InputCheck = New-Object System.Windows.Forms.CheckBox
$InputCheck.Name = 'StoreInputFolder'
$InputCheck.Size = New-Object System.Drawing.Size(14, 14)
$InputCheck.Location = New-Object System.Drawing.Size(4, 24)
$InputCheck.Checked = $StoreInputFolder
$InputCheck.Text = ''
$InputCheck.Add_CheckStateChanged({GUI_UpdateCheckBoxState})
$InputCheckTip = New-Object System.Windows.Forms.ToolTip
$InputCheckTip.InitialDelay = 500
$InputCheckTip.AutoPopDelay = $ToolTipDuration
$InputCheckTipString = 'Saves the selected texture path when the script is closed.'
$InputCheckTip.SetToolTip($InputCheck, $InputCheckTipString)
$InputGroup.Controls.Add($InputCheck)
#----------------------------------------------------------------------------------------------------------------------------------------------
$InputTextBox = New-Object System.Windows.Forms.TextBox
$InputTextBox.Name = 'Input'
$InputTextBox.Size = New-Object System.Drawing.Size(320, 22)
$InputTextBox.Location = New-Object System.Drawing.Size(20, 20)
$InputTextBox.Text = $MasterInputPath
$InputTextBox.ReadOnly = $true
$InputTextBox.AllowDrop = $true
$InputTextBox.Add_DragEnter({$_.Effect = [Windows.Forms.DragDropEffects]::Copy})
$InputTextBox.Add_DragDrop({GUI_UpdateFolderPath_DragDrop})
$InputGroup.Controls.Add($InputTextBox)
#----------------------------------------------------------------------------------------------------------------------------------------------
$InputButton = New-Object System.Windows.Forms.Button
$InputButton.Name = 'Input'
$InputButton.Size = New-Object System.Drawing.Size(26, 22)
$InputButton.Location = New-Object System.Drawing.Size(346, 18)
$InputButton.Text = '...'
$InputButtonMessage = 'Select a folder that contains textures. This should be a Dolphin texture pack folder that contains the 3-digit or 6-digit GameID. Example: SX4 or SX4E01'
$InputButton.Add_Click({GUI_UpdateFolderPath_Button $InputButtonMessage})
$InputGroup.Controls.Add($InputButton)
#==============================================================================================================================================================================================
#  CTT GUI - Create Output Path Selection
#==============================================================================================================================================================================================
$OutputGroup = New-Object System.Windows.Forms.GroupBox
$OutputGroup.Size = New-Object System.Drawing.Size(380, 50)
$OutputGroup.Location = New-Object System.Drawing.Size(10, 60)
$OutputGroup.Text = ' Output Path '
$Dialog.Controls.Add($OutputGroup)
$OutputGroupTip = New-Object System.Windows.Forms.ToolTip
$OutputGroupTip.InitialDelay = $ToolTipDelay
$OutputGroupTip.AutoPopDelay = $ToolTipDuration
$OutputGroupTipString = 'Path to where this script will generate textures.'
$OutputGroupTip.SetToolTip($OutputGroup, $OutputGroupTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$OutputCheck = New-Object System.Windows.Forms.CheckBox
$OutputCheck.Name = 'StoreOutputFolder'
$OutputCheck.Size = New-Object System.Drawing.Size(14, 14)
$OutputCheck.Location = New-Object System.Drawing.Size(4, 24)
$OutputCheck.Checked = $StoreOutputFolder
$OutputCheck.Text = ''
$OutputCheck.Add_CheckStateChanged({GUI_UpdateCheckBoxState})
$OutputCheckTip = New-Object System.Windows.Forms.ToolTip
$OutputCheckTip.InitialDelay = 500
$OutputCheckTip.AutoPopDelay = $ToolTipDuration
$OutputCheckTipString = 'Saves the selected output path when the script is closed.'
$OutputCheckTip.SetToolTip($OutputCheck, $OutputCheckTipString)
$OutputGroup.Controls.Add($OutputCheck)
#----------------------------------------------------------------------------------------------------------------------------------------------
$OutputTextBox = New-Object System.Windows.Forms.TextBox
$OutputTextBox.Name = 'Output'
$OutputTextBox.Size = New-Object System.Drawing.Size(320, 22)
$OutputTextBox.Location = New-Object System.Drawing.Size(20, 20)
$OutputTextBox.Text = $MasterOutputPath
$OutputTextBox.ReadOnly = $true
$OutputTextBox.AllowDrop = $true
$OutputTextBox.Add_DragEnter({$_.Effect = [Windows.Forms.DragDropEffects]::Copy})
$OutputTextBox.Add_DragDrop({GUI_UpdateFolderPath_DragDrop})
$OutputGroup.Controls.Add($OutputTextBox)
#----------------------------------------------------------------------------------------------------------------------------------------------
$OutputButton = New-Object System.Windows.Forms.Button
$OutputButton.Name = 'Output'
$OutputButton.Size = New-Object System.Drawing.Size(26, 22)
$OutputButton.Location = New-Object System.Drawing.Size(346, 18)
$OutputButton.Text = '...'
$OutputButtonMessage = 'Select a folder to output generated textures. Textures generated by this script will be created in the output folder in a sub-folder named "~CTT_Generated".'
$OutputButton.Add_Click({GUI_UpdateFolderPath_Button $OutputButtonMessage})
$OutputGroup.Controls.Add($OutputButton)
#==============================================================================================================================================================================================
# CTT GUI - Create the Main Options list.
#==============================================================================================================================================================================================
$StandardGroup = New-Object System.Windows.Forms.GroupBox
$StandardGroup.Size = New-Object System.Drawing.Size(380, 140)
$StandardGroup.Location = New-Object System.Drawing.Size(10, 115)
$StandardGroup.Text = ' Standard Options '
$Dialog.Controls.Add($StandardGroup)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Window that holds all of the Main Menu options.
$StandardOptions = New-Object System.Windows.Forms.ListBox
$StandardOptions.Size = New-Object System.Drawing.Size(288, 116)
$StandardOptions.Location = New-Object System.Drawing.Size(10, 20)
$StandardOptions.Items.Add('Scan Textures For Issues') | Out-Null
$StandardOptions.Items.Add('Rescale Textures at Fixed Integer') | Out-Null
$StandardOptions.Items.Add('Convert Textures to Another Format') | Out-Null
$StandardOptions.Items.Add('Create Material Maps With Ishiiruka Tool') | Out-Null
$StandardOptions.Items.Add('Add Identifying Watermark to All Textures') | Out-Null
$StandardOptions.Items.Add('Optimize PNG Textures With OptiPNG') | Out-Null
$StandardOptions.Items.Add('Apply Upscaling Filter to All Textures') | Out-Null
$StandardOptions.SelectedIndex = $StoredStandard
$StandardOptions.Add_SelectedIndexChanged({GUI_UpdateSelectedOptions ''})
$StandardGroup.Controls.Add($StandardOptions)
#----------------------------------------------------------------------------------------------------------------------------------------------
$StandardButtonA = New-Object System.Windows.Forms.Button
$StandardButtonA.Name = 'Standard'
$StandardButtonA.Size = New-Object System.Drawing.Size(72, 30)
$StandardButtonA.Location = New-Object System.Drawing.Size(302, 20)
$StandardButtonA.Text = 'Standard'
$StandardButtonA.Add_Click({GUI_OptionsButtonPress})
$StandardGroup.Controls.Add($StandardButtonA)
$StandardButtonATip = New-Object System.Windows.Forms.ToolTip
$StandardButtonATip.InitialDelay = $ToolTipDelay
$StandardButtonATip.AutoPopDelay = $ToolTipDuration
$StandardButtonATipString = 'Standard options perform actions on texture copies and do not{0}'
$StandardButtonATipString += 'modify the texture pack directly. Textures created with these options{0}'
$StandardButtonATipString += 'will be output to a subfolder within a "~CTT_Generated" folder.'
$StandardButtonATipString = [String]::Format($StandardButtonATipString, [Environment]::NewLine)
$StandardButtonATip.SetToolTip($StandardButtonA, $StandardButtonATipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$StandardButtonB = New-Object System.Windows.Forms.Button
$StandardButtonB.Name = 'Advanced'
$StandardButtonB.Size = New-Object System.Drawing.Size(72, 30)
$StandardButtonB.Location = New-Object System.Drawing.Size(302, 58)
$StandardButtonB.Text = 'Advanced'
$StandardButtonB.Add_Click({GUI_OptionsButtonPress})
$StandardGroup.Controls.Add($StandardButtonB)
$StandardButtonBTip = New-Object System.Windows.Forms.ToolTip
$StandardButtonBTip.InitialDelay = $ToolTipDelay
$StandardButtonBTip.AutoPopDelay = $ToolTipDuration
$StandardButtonBTipString = 'Advanced options modify the texture pack directly, so they need to be{0}'
$StandardButtonBTipString += 'used with caution. It is suggested to back up the texture pack before{0}'
$StandardButtonBTipString += 'using these options because changes are irreversible.'
$StandardButtonBTipString = [String]::Format($StandardButtonBTipString, [Environment]::NewLine)
$StandardButtonBTip.SetToolTip($StandardButtonB, $StandardButtonBTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$StandardButtonC = New-Object System.Windows.Forms.Button
$StandardButtonC.Name = 'Description'
$StandardButtonC.Size = New-Object System.Drawing.Size(72, 30)
$StandardButtonC.Location = New-Object System.Drawing.Size(302, 96)
$StandardButtonC.Text = 'Description'
$StandardButtonC.Add_Click({GUI_QuickHelp})
$StandardGroup.Controls.Add($StandardButtonC)
$StandardButtonCTip = New-Object System.Windows.Forms.ToolTip
$StandardButtonCTip.InitialDelay = $ToolTipDelay
$StandardButtonCTip.AutoPopDelay = $ToolTipDuration
$StandardButtonCTipString = "Opens the Help dialog and quickly links to this option's explantion."
$StandardButtonCTip.SetToolTip($StandardButtonC, $StandardButtonCTipString)
#==============================================================================================================================================================================================
# CTT GUI - Create the Advanced Options list.
#==============================================================================================================================================================================================
$AdvancedGroup = New-Object System.Windows.Forms.GroupBox
$AdvancedGroup.Size = New-Object System.Drawing.Size(380, 140)
$AdvancedGroup.Location = New-Object System.Drawing.Size(10, 115)
$AdvancedGroup.Text = ' Advanced Options '
$Dialog.Controls.Add($AdvancedGroup)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Window that holds all of the Advanced Menu options.
$AdvancedOptions = New-Object System.Windows.Forms.ListBox
$AdvancedOptions.Size = New-Object System.Drawing.Size(288, 116)
$AdvancedOptions.Location = New-Object System.Drawing.Size(10, 20)
$AdvancedOptions.Items.Add('Generate New MipMaps') | Out-Null
$AdvancedOptions.Items.Add('Remove Invalid MipMaps') | Out-Null
$AdvancedOptions.Items.Add('Remove Alpha Channel From Opaque Textures') | Out-Null
$AdvancedOptions.Items.Add('Fix Textures Potentially Broken by OptiPNG') | Out-Null
$AdvancedOptions.Items.Add('Combine Multiple Textures') | Out-Null
$AdvancedOptions.Items.Add('Split Combined Multi-Texture') | Out-Null
$AdvancedOptions.SelectedIndex = $StoredAdvanced
$AdvancedOptions.Add_SelectedIndexChanged({GUI_UpdateSelectedOptions ''})
$AdvancedGroup.Controls.Add($AdvancedOptions)
#----------------------------------------------------------------------------------------------------------------------------------------------
$AdvancedButtonA = New-Object System.Windows.Forms.Button
$AdvancedButtonA.Name = 'Standard'
$AdvancedButtonA.Size = New-Object System.Drawing.Size(72, 30)
$AdvancedButtonA.Location = New-Object System.Drawing.Size(302, 20)
$AdvancedButtonA.Text = 'Standard'
$AdvancedButtonA.Add_Click({GUI_OptionsButtonPress})
$AdvancedGroup.Controls.Add($AdvancedButtonA)
$AdvancedButtonATip = New-Object System.Windows.Forms.ToolTip
$AdvancedButtonATip.InitialDelay = $ToolTipDelay
$AdvancedButtonATip.AutoPopDelay = $ToolTipDuration
$AdvancedButtonATipString = 'Standard options perform actions on texture copies and do not{0}'
$AdvancedButtonATipString += 'modify the texture pack directly. Textures created with these options{0}'
$AdvancedButtonATipString += 'will be output to a subfolder within a "~CTT_Generated" folder.'
$AdvancedButtonATipString = [String]::Format($AdvancedButtonATipString, [Environment]::NewLine)
$AdvancedButtonATip.SetToolTip($AdvancedButtonA, $AdvancedButtonATipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$AdvancedButtonB = New-Object System.Windows.Forms.Button
$AdvancedButtonB.Name = 'Advanced'
$AdvancedButtonB.Size = New-Object System.Drawing.Size(72, 30)
$AdvancedButtonB.Location = New-Object System.Drawing.Size(302, 58)
$AdvancedButtonB.Text = 'Advanced'
$AdvancedButtonB.Add_Click({GUI_OptionsButtonPress})
$AdvancedGroup.Controls.Add($AdvancedButtonB)
$AdvancedButtonBTip = New-Object System.Windows.Forms.ToolTip
$AdvancedButtonBTip.InitialDelay = $ToolTipDelay
$AdvancedButtonBTip.AutoPopDelay = $ToolTipDuration
$AdvancedButtonBTipString = 'Advanced options modify the texture pack directly, so they need to be{0}'
$AdvancedButtonBTipString += 'used with caution. It is suggested to back up the texture pack before{0}'
$AdvancedButtonBTipString += 'using these options because changes are irreversible.'
$AdvancedButtonBTipString = [String]::Format($AdvancedButtonBTipString, [Environment]::NewLine)
$AdvancedButtonBTip.SetToolTip($AdvancedButtonB, $AdvancedButtonBTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$AdvancedButtonC = New-Object System.Windows.Forms.Button
$AdvancedButtonC.Name = 'Description'
$AdvancedButtonC.Size = New-Object System.Drawing.Size(72, 30)
$AdvancedButtonC.Location = New-Object System.Drawing.Size(302, 96)
$AdvancedButtonC.Text = 'Description'
$AdvancedButtonC.Add_Click({GUI_QuickHelp})
$AdvancedGroup.Controls.Add($AdvancedButtonC)
$AdvancedButtonCTip = New-Object System.Windows.Forms.ToolTip
$AdvancedButtonCTip.InitialDelay = $ToolTipDelay
$AdvancedButtonCTip.AutoPopDelay = $ToolTipDuration
$AdvancedButtonCTipString = "Opens the Help dialog and quickly links to this option's explantion."
$AdvancedButtonCTip.SetToolTip($AdvancedButtonC, $AdvancedButtonCTipString)
#==============================================================================================================================================================================================
#  CTT GUI - Create Bottom Buttons
#==============================================================================================================================================================================================
# Start Processing
$StartButton = New-Object System.Windows.Forms.Button
$StartButton.Size = New-Object System.Drawing.Size(80, 28)
$StartButton.Location = New-Object System.Drawing.Size(10, 390)
$StartButton.Text = 'Start'
$StartButton.Add_Click({GUI_StartMasterLoop})
$Dialog.Controls.Add($StartButton)
$StartTip = New-Object System.Windows.Forms.ToolTip
$StartTip.InitialDelay = $ToolTipDelay
$StartTip.AutoPopDelay = $ToolTipDuration
$StartTipString = 'Begins processing textures with the selected option.'
$StartTip.SetToolTip($StartButton, $StartTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Internal Options
$OptionsButton = New-Object System.Windows.Forms.Button
$OptionsButton.Size = New-Object System.Drawing.Size(80, 28)
$OptionsButton.Location = New-Object System.Drawing.Size(110, 390)
$OptionsButton.Text = 'Options'
$OptionsButton.Add_Click({GUI_ToggleOptionsPanel})
$Dialog.Controls.Add($OptionsButton)
$OptionsTip = New-Object System.Windows.Forms.ToolTip
$OptionsTip.InitialDelay = $ToolTipDelay
$OptionsTip.AutoPopDelay = $ToolTipDuration
$OptionsTipString = 'Opens the Options panel to set tool paths and miscellaneous options.'
$OptionsTip.SetToolTip($OptionsButton, $OptionsTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Help Button
$HelpButton = New-Object System.Windows.Forms.Button
$HelpButton.Name = 'Help'
$HelpButton.Size = New-Object System.Drawing.Size(80, 28)
$HelpButton.Location =  New-Object System.Drawing.Size(208, 390)
$HelpButton.Text = 'Help'
$HelpButton.Add_Click({if (!$HelpDialog.Visible) {$HelpDialog.Show()} else {$HelpDialog.Hide()}})
$Dialog.Controls.Add($HelpButton)
$HelpButtonTip = New-Object System.Windows.Forms.ToolTip
$HelpButtonTip.InitialDelay = $ToolTipDelay
$HelpButtonTip.AutoPopDelay = $ToolTipDuration
$HelpButtonTipString = 'Opens the Help dialog which fully covers how to use this script and more.'
$HelpButtonTip.SetToolTip($HelpButton, $HelpButtonTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Close the Dialog
$CloseButton = New-Object System.Windows.Forms.Button
$CloseButton.Size = New-Object System.Drawing.Size(80, 28)
$CloseButton.Location = New-Object System.Drawing.Size(308, 390)
$CloseButton.Text = 'Exit'
$CloseButton.Add_Click({$Dialog.Close()})
$Dialog.Controls.Add($CloseButton)
$CloseTip = New-Object System.Windows.Forms.ToolTip
$CloseTip.InitialDelay = $ToolTipDelay
$CloseTip.AutoPopDelay = $ToolTipDuration
$CloseTipString = 'Closes the GUI and exits Custom Texture Tool PS.'
$CloseTip.SetToolTip($CloseButton, $CloseTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Default Stored Options
$DefaultButton = New-Object System.Windows.Forms.Button
$DefaultButton.Size = New-Object System.Drawing.Size(130, 28)
$DefaultButton.Location = New-Object System.Drawing.Size(450, 390)
$DefaultButton.Text = 'Restore Defaults'
$DefaultButton.Add_Click({RestoreDefaultOptions})
$Dialog.Controls.Add($DefaultButton)
$DefaultTip = New-Object System.Windows.Forms.ToolTip
$DefaultTip.InitialDelay = $ToolTipDelay
$DefaultTip.AutoPopDelay = $ToolTipDuration
$DefaultTipString = 'Resets all options to their default values.'
$DefaultTip.SetToolTip($DefaultButton, $DefaultTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Import Stored Options
$ImportButton = New-Object System.Windows.Forms.Button
$ImportButton.Size = New-Object System.Drawing.Size(130, 28)
$ImportButton.Location = New-Object System.Drawing.Size(600, 390)
$ImportButton.Text = 'Import Stored Options'
$ImportButton.Add_Click({ImportStoredOptions})
$Dialog.Controls.Add($ImportButton)
$ImportTip = New-Object System.Windows.Forms.ToolTip
$ImportTip.InitialDelay = $ToolTipDelay
$ImportTip.AutoPopDelay = $ToolTipDuration
$ImportTipString = 'Allows importing all Stored Options from another version of Custom Texture{0}'
$ImportTipString += 'Tool PS by simply selecting the script file. It should work on any version of{0}'
$ImportTipString += 'the PowerShell versions of the script. This feature exists to retain settings{0}'
$ImportTipString += 'in future versions of this script, and not have to set them every single time.'
$ImportTipString = [String]::Format($ImportTipString, [Environment]::NewLine)
$ImportTip.SetToolTip($ImportButton, $ImportTipString)
#==============================================================================================================================================================================================
#  CTT GUI - Ishiiruka Tool Path Selection
#==============================================================================================================================================================================================
$IshiiPathGroup = New-Object System.Windows.Forms.GroupBox
$IshiiPathGroup.Size = New-Object System.Drawing.Size(380, 50)
$IshiiPathGroup.Location = New-Object System.Drawing.Size(400, 5)
$IshiiPathGroup.Text = ' Ishiiruka Tool Path '
$Dialog.Controls.Add($IshiiPathGroup)
$IshiiPathTip = New-Object System.Windows.Forms.ToolTip
$IshiiPathTip.InitialDelay = $ToolTipDelay
$IshiiPathTip.AutoPopDelay = $ToolTipDuration
$IshiiPathTipString = 'The path to the texture encoder by Tino that can combine bump/spec/lum/nrm{0}'
$IshiiPathTipString += 'textures into a Material Map. This tool is also needed to work with already{0}'
$IshiiPathTipString += 'combined Material Maps (meaning the "nrm" file created from the previously{0}'
$IshiiPathTipString += 'mentioned textures). If a pack contains Material Maps or Material Textures, an{0}'
$IshiiPathTipString += 'option is selected to convert textures to another format, and this tool is not {0}'
$IshiiPathTipString += 'found, then these textures will not be converted.{0}'
$IshiiPathTipString += '{0}'
$IshiiPathTipString += 'It is important to set the path to this tool to work with Material Textures using{0}'
$IshiiPathTipString += 'any option that generates textures.'
$IshiiPathTipString = [String]::Format($IshiiPathTipString, [Environment]::NewLine)
$IshiiPathTip.SetToolTip($IshiiPathGroup, $IshiiPathTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$IshiiPathTextBox = New-Object System.Windows.Forms.TextBox
$IshiiPathTextBox.Name = 'IshiirukaTool'
$IshiiPathTextBox.Size = New-Object System.Drawing.Size(320, 22)
$IshiiPathTextBox.Location = New-Object System.Drawing.Size(10, 20)
$IshiiPathTextBox.Text = $IshiirukaTool
$IshiiPathTextBox.ReadOnly = $true
$IshiiPathTextBox.AllowDrop = $true
$IshiiPathTextBox.Add_DragEnter({$_.Effect = [Windows.Forms.DragDropEffects]::Copy})
$IshiiPathTextBox.Add_DragDrop({GUI_UpdateFilePath_DragDrop 'TextureEncoder.exe'})
#----------------------------------------------------------------------------------------------------------------------------------------------
$IshiiPathButton = New-Object System.Windows.Forms.Button
$IshiiPathButton.Name = 'IshiirukaTool'
$IshiiPathButton.Size = New-Object System.Drawing.Size(26, 22)
$IshiiPathButton.Location = New-Object System.Drawing.Size(342, 18)
$IshiiPathButton.Text = '...'
$IshiiPathButton.Add_Click({GUI_UpdateFilePath_Button $IshiiPathTextBox 'Ishiiruka Tool|TextureEncoder.exe'})
#----------------------------------------------------------------------------------------------------------------------------------------------
$IshiiPathGroup.Controls.Add($IshiiPathTextBox)
$IshiiPathGroup.Controls.Add($IshiiPathButton)
#==============================================================================================================================================================================================
#  CTT GUI - OptiPNG Path Selection
#==============================================================================================================================================================================================
$OptiPathGroup = New-Object System.Windows.Forms.GroupBox
$OptiPathGroup.Size = New-Object System.Drawing.Size(380, 50)
$OptiPathGroup.Location = New-Object System.Drawing.Size(400, 60)
$OptiPathGroup.Text = ' OptiPNG Path '
$Dialog.Controls.Add($OptiPathGroup)
$OptiPathTip = New-Object System.Windows.Forms.ToolTip
$OptiPathTip.InitialDelay = $ToolTipDelay
$OptiPathTip.AutoPopDelay = $ToolTipDuration
$OptiPathTipString = 'This is the path to OptiPNG which is completely optional. OptiPNG attempts{0}'
$OptiPathTipString += 'to recompress PNG files in order to reduce their file size by running a number{0}'
$OptiPathTipString += 'of different "tests" and going with the best results.{0}'
$OptiPathTipString += '{0}'
$OptiPathTipString += 'Used with standard option "Optimize PNG Textures With OptiPNG".'
$OptiPathTipString = [String]::Format($OptiPathTipString, [Environment]::NewLine)
$OptiPathTip.SetToolTip($OptiPathGroup, $OptiPathTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$OptiPathTextBox = New-Object System.Windows.Forms.TextBox
$OptiPathTextBox.Name = 'OptiPNGPath'
$OptiPathTextBox.Size = New-Object System.Drawing.Size(320, 22)
$OptiPathTextBox.Location = New-Object System.Drawing.Size(10, 20)
$OptiPathTextBox.Text = $OptiPNGPath
$OptiPathTextBox.ReadOnly = $true
$OptiPathTextBox.AllowDrop = $true
$OptiPathTextBox.Add_DragEnter({$_.Effect = [Windows.Forms.DragDropEffects]::Copy})
$OptiPathTextBox.Add_DragDrop({GUI_UpdateFilePath_DragDrop 'optipng.exe'})
#----------------------------------------------------------------------------------------------------------------------------------------------
$OptiPathButton = New-Object System.Windows.Forms.Button
$OptiPathButton.Name = 'OptiPNGPath'
$OptiPathButton.Size = New-Object System.Drawing.Size(26, 22)
$OptiPathButton.Location = New-Object System.Drawing.Size(342, 18)
$OptiPathButton.Text = '...'
$OptiPathButton.Add_Click({GUI_UpdateFilePath_Button $OptiPathTextBox 'OptiPNG|optipng.exe'})
#----------------------------------------------------------------------------------------------------------------------------------------------
$OptiPathGroup.Controls.Add($OptiPathTextBox)
$OptiPathGroup.Controls.Add($OptiPathButton)
#==============================================================================================================================================================================================
#  CTT GUI - xBRZ Path Selection
#==============================================================================================================================================================================================
$xBRZPathGroup = New-Object System.Windows.Forms.GroupBox
$xBRZPathGroup.Size = New-Object System.Drawing.Size(380, 50)
$xBRZPathGroup.Location = New-Object System.Drawing.Size(400, 115)
$xBRZPathGroup.Text = ' xBRZ ScalerTest Path '
$Dialog.Controls.Add($xBRZPathGroup)
$xBRZPathTip = New-Object System.Windows.Forms.ToolTip
$xBRZPathTip.InitialDelay = $ToolTipDelay
$xBRZPathTip.AutoPopDelay = $ToolTipDuration
$xBRZPathTipString = 'This tool makes it possible to apply the xBRZ upscaling filter to a folder{0}'
$xBRZPathTipString += 'full of textures. This tool is only used when applying the xBRZ filter, all{0}'
$xBRZPathTipString += 'other filters are applied to textures using ImageMagick.{0}'
$xBRZPathTipString += '{0}'
$xBRZPathTipString += 'Used with standard option "Apply Upscaling Filter to All Textures".'
$xBRZPathTipString = [String]::Format($xBRZPathTipString, [Environment]::NewLine)
$xBRZPathTip.SetToolTip($xBRZPathGroup, $xBRZPathTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$xBRZPathTextBox = New-Object System.Windows.Forms.TextBox
$xBRZPathTextBox.Name = 'ScalerTestPath'
$xBRZPathTextBox.Size = New-Object System.Drawing.Size(320, 22)
$xBRZPathTextBox.Location = New-Object System.Drawing.Size(10, 20)
$xBRZPathTextBox.Text = $ScalerTestPath
$xBRZPathTextBox.ReadOnly = $true
$xBRZPathTextBox.AllowDrop = $true
$xBRZPathTextBox.Add_DragEnter({$_.Effect = [Windows.Forms.DragDropEffects]::Copy})
$xBRZPathTextBox.Add_DragDrop({GUI_UpdateFilePath_DragDrop 'ScalerTest.exe'})
#----------------------------------------------------------------------------------------------------------------------------------------------
$xBRZPathButton = New-Object System.Windows.Forms.Button
$xBRZPathButton.Name = 'ScalerTestPath'
$xBRZPathButton.Size = New-Object System.Drawing.Size(26, 22)
$xBRZPathButton.Location = New-Object System.Drawing.Size(342, 18)
$xBRZPathButton.Text = '...'
$xBRZPathButton.Add_Click({GUI_UpdateFilePath_Button $xBRZPathTextBox 'xBRZ|ScalerTest.exe'})
#----------------------------------------------------------------------------------------------------------------------------------------------
$xBRZPathGroup.Controls.Add($xBRZPathTextBox)
$xBRZPathGroup.Controls.Add($xBRZPathButton)
#==============================================================================================================================================================================================
#  CTT GUI - Waifu2x Path Selection
#==============================================================================================================================================================================================
$Waifu2xPathGroup = New-Object System.Windows.Forms.GroupBox
$Waifu2xPathGroup.Size = New-Object System.Drawing.Size(380, 50)
$Waifu2xPathGroup.Location = New-Object System.Drawing.Size(400, 170)
$Waifu2xPathGroup.Text = ' Waifu2x Path '
$Dialog.Controls.Add($Waifu2xPathGroup)
$Waifu2xPathTip = New-Object System.Windows.Forms.ToolTip
$Waifu2xPathTip.InitialDelay = $ToolTipDelay
$Waifu2xPathTip.AutoPopDelay = $ToolTipDuration
$Waifu2xPathTipString = 'Allows upscaling textures with the waifu2x filter. There are two popular{0}'
$Waifu2xPathTipString += 'waifu2x applications for Windows, one is waifu2x-caffe, and the other is{0}'
$Waifu2xPathTipString += 'waifu2x-cpp. Both versions of waifu2x are compatible with this script.{0}'
$Waifu2xPathTipString += '{0}'
$Waifu2xPathTipString += 'Used with standard option "Apply Upscaling Filter to All Textures".'
$Waifu2xPathTipString = [String]::Format($Waifu2xPathTipString, [Environment]::NewLine)
$OptiPathTip.SetToolTip($Waifu2xPathGroup, $Waifu2xPathTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$Waifu2xPathTextBox = New-Object System.Windows.Forms.TextBox
$Waifu2xPathTextBox.Name = 'Waifu2xPath'
$Waifu2xPathTextBox.Size = New-Object System.Drawing.Size(320, 22)
$Waifu2xPathTextBox.Location = New-Object System.Drawing.Size(10, 20)
$Waifu2xPathTextBox.Text = $Waifu2xPath
$Waifu2xPathTextBox.ReadOnly = $true
$Waifu2xPathTextBox.AllowDrop = $true
$Waifu2xPathTextBox.Add_DragEnter({$_.Effect = [Windows.Forms.DragDropEffects]::Copy})
$Waifu2xPathTextBox.Add_DragDrop({GUI_UpdateFilePath_DragDrop 'waifu2x-caffe-cui.exe' ; GUI_UpdateFilePath_DragDrop 'waifu2x-converter_x64.exe'})
#----------------------------------------------------------------------------------------------------------------------------------------------
$Waifu2xPathButton = New-Object System.Windows.Forms.Button
$Waifu2xPathButton.Name = 'Waifu2xPath'
$Waifu2xPathButton.Size = New-Object System.Drawing.Size(26, 22)
$Waifu2xPathButton.Location = New-Object System.Drawing.Size(342, 18)
$Waifu2xPathButton.Text = '...'
$Waifu2xPathButton.Add_Click({GUI_UpdateFilePath_Button $Waifu2xPathTextBox 'Caffe|waifu2x-caffe-cui.exe|CPP|waifu2x-converter_x64.exe'})
#----------------------------------------------------------------------------------------------------------------------------------------------
$Waifu2xPathGroup.Controls.Add($Waifu2xPathTextBox)
$Waifu2xPathGroup.Controls.Add($Waifu2xPathButton)
#==============================================================================================================================================================================================
#  CTT GUI - Temp Path Selection
#==============================================================================================================================================================================================
$TempPathGroup = New-Object System.Windows.Forms.GroupBox
$TempPathGroup.Size = New-Object System.Drawing.Size(380, 50)
$TempPathGroup.Location = New-Object System.Drawing.Size(400, 225)
$TempPathGroup.Text = ' Temp Folder '
$Dialog.Controls.Add($TempPathGroup)
$TempPathTip = New-Object System.Windows.Forms.ToolTip
$TempPathTip.InitialDelay = $ToolTipDelay
$TempPathTip.AutoPopDelay = $ToolTipDuration
$TempPathTipString = 'When temporary textures need to be generated, this is the folder they will{0}'
$TempPathTipString += 'be created. Temporary files will always be deleted when they are no longer{0}'
$TempPathTipString += 'needed, and are wiped out on every execution/completion of one of the scripts{0}'
$TempPathTipString += 'options. The default location is "\AppData\Local\Temp\CTT-PS_Temp", but can{0}'
$TempPathTipString += 'be changed to anywhere. This is useful if a user has trouble creating content{0}'
$TempPathTipString += 'in the AppData folder, or just simply wants to relocate the Temp folder.'
$TempPathTipString = [String]::Format($TempPathTipString, [Environment]::NewLine)
$TempPathTip.SetToolTip($TempPathGroup, $TempPathTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$TempPathTextBox = New-Object System.Windows.Forms.TextBox
$TempPathTextBox.Name = 'TempFolder'
$TempPathTextBox.Size = New-Object System.Drawing.Size(320, 22)
$TempPathTextBox.Location = New-Object System.Drawing.Size(10, 20)
$TempPathTextBox.Text = $TempFolder
$TempPathTextBox.ReadOnly = $true
$TempPathTextBox.AllowDrop = $true
$TempPathTextBox.Add_DragEnter({$_.Effect = [Windows.Forms.DragDropEffects]::Copy})
$TempPathTextBox.Add_DragDrop({GUI_UpdateTempFolderPath_DragDrop})
#----------------------------------------------------------------------------------------------------------------------------------------------
$TempPathButton = New-Object System.Windows.Forms.Button
$TempPathButton.Name = 'TempFolder'
$TempPathButton.Size = New-Object System.Drawing.Size(26, 22)
$TempPathButton.Location = New-Object System.Drawing.Size(342, 18)
$TempPathButton.Text = '...'
$TempPathButton.Add_Click({GUI_UpdateTempFolderPath_Button})
#----------------------------------------------------------------------------------------------------------------------------------------------
$TempPathGroup.Controls.Add($TempPathTextBox)
$TempPathGroup.Controls.Add($TempPathButton)
#==============================================================================================================================================================================================
#  CTT GUI - Global Options
#==============================================================================================================================================================================================
$InternalGroup = New-Object System.Windows.Forms.GroupBox
$InternalGroup.Size = New-Object System.Drawing.Size(208, 104)
$InternalGroup.Location = New-Object System.Drawing.Size(400, 280)
$InternalGroup.Text = ' Global Options '
$Dialog.Controls.Add($InternalGroup)
$InternalGroupTip = New-Object System.Windows.Forms.ToolTip
$InternalGroupTip.InitialDelay = $ToolTipDelay
$InternalGroupTip.AutoPopDelay = $ToolTipDuration
$InternalGroupTipString = 'These options affect the way the script will generate textures.'
$InternalGroupTip.SetToolTip($InternalGroup, $InternalGroupTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Allow All Images
$AllowAllImagesCheck = New-Object System.Windows.Forms.CheckBox
$AllowAllImagesCheck.Name = 'AllowAllImages'
$AllowAllImagesCheck.Size = New-Object System.Drawing.Size(120, 16)
$AllowAllImagesCheck.Location = New-Object System.Drawing.Size(10, 18)
$AllowAllImagesCheck.Checked = $AllowAllImages
$AllowAllImagesCheck.Text = ' Allow All Images'
$AllowAllImagesCheck.Add_CheckStateChanged({GUI_UpdateCheckBoxState})
$InternalGroup.Controls.Add($AllowAllImagesCheck)
$AllowAllTip = New-Object System.Windows.Forms.ToolTip
$AllowAllTip.InitialDelay = $ToolTipDelay
$AllowAllTip.AutoPopDelay = $ToolTipDuration
$AllowAllTipString = 'This option allows any PNG/DDS/JPG image to pass validation by ignoring the {0}'
$AllowAllTipString += 'search for the "tex1" prefix used by Dolphin textures. This works well enough {0}'
$AllowAllTipString += 'that other images may be converted to other formats, have watermarks applied,{0}'
$AllowAllTipString += 'optimized with OptiPNG, or have the various upscaling filters applied.{0}'
$AllowAllTipString += '{0}'
$AllowAllTipString += 'Error checking these images will not work because there is no data to reference.{0}'
$AllowAllTipString += 'Dolphin textures are dumped in a way that the name of the texture holds the data{0}'
$AllowAllTipString += 'of the original texture dumped. When this option is enabled and the image is not{0}'
$AllowAllTipString += 'a Dolphin texture, then the "original" data will be set to the "current" data.'
$AllowAllTipString = [String]::Format($AllowAllTipString, [Environment]::NewLine)
$AllowAllTip.SetToolTip($AllowAllImagesCheck, $AllowAllTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# DDS Force DXT5
$DDSForceDXT5Check = New-Object System.Windows.Forms.CheckBox
$DDSForceDXT5Check.Name = 'DDSForceDXT5'
$DDSForceDXT5Check.Size = New-Object System.Drawing.Size(150, 16)
$DDSForceDXT5Check.Location = New-Object System.Drawing.Size(10, 38)
$DDSForceDXT5Check.Checked = $DDSForceDXT5
$DDSForceDXT5Check.Text = " Force DDS DXT5"
$DDSForceDXT5Check.Add_CheckStateChanged({GUI_UpdateCheckBoxState})
$InternalGroup.Controls.Add($DDSForceDXT5Check)
$DDSForceDXT5Tip = New-Object System.Windows.Forms.ToolTip
$DDSForceDXT5Tip.InitialDelay = $ToolTipDelay
$DDSForceDXT5Tip.AutoPopDelay = $ToolTipDuration
$DDSForceDXT5TipString = 'When converting to DDS, forces the compression to DXT5.{0}'
$DDSForceDXT5TipString += 'When this option is disabled, DXT1 is chosen for opaque {0}'
$DDSForceDXT5TipString += 'textures and DXT5 is chosen for textures with transparency.'
$DDSForceDXT5TipString += '{0}{0}'
$DDSForceDXT5TipString += 'DXT5 yields higher quality, is slower to encode, and the {0}'
$DDSForceDXT5TipString += 'file size of the result is twice the size of DXT1 textures.'
$DDSForceDXT5TipString = [String]::Format($DDSForceDXT5TipString, [Environment]::NewLine)
$DDSForceDXT5Tip.SetToolTip($DDSForceDXT5Check, $DDSForceDXT5TipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Log File Disable
$DisableLogCheck = New-Object System.Windows.Forms.CheckBox
$DisableLogCheck.Name = 'DisableLogFile'
$DisableLogCheck.Size = New-Object System.Drawing.Size(120, 16)
$DisableLogCheck.Location = New-Object System.Drawing.Size(10, 58)
$DisableLogCheck.Checked = $DisableLogFile
$DisableLogCheck.Text = ' Disable Log File'
$DisableLogCheck.Add_CheckStateChanged({GUI_UpdateCheckBoxState})
$InternalGroup.Controls.Add($DisableLogCheck)
$DisableLogTip = New-Object System.Windows.Forms.ToolTip
$DisableLogTip.InitialDelay = $ToolTipDelay
$DisableLogTip.AutoPopDelay = $ToolTipDuration
$DisableLogTipString = 'Disables creation of the log file. This option should not be{0}'
$DisableLogTipString += 'enabled when scanning textures for issues, as that option{0}'
$DisableLogTipString += 'depends on the log file to create the collection of issues.'
$DisableLogTipString = [String]::Format($DisableLogTipString, [Environment]::NewLine)
$DisableLogTip.SetToolTip($DisableLogCheck, $DisableLogTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Material Map Type
$MaterialTypeCombo = New-Object System.Windows.Forms.ComboBox
$MaterialTypeCombo.Name = 'MaterialMapFormat'
$MaterialTypeCombo.Size = New-Object System.Drawing.Size(78, 28)
$MaterialTypeCombo.Location = New-Object System.Drawing.Size(10, 79)
$MaterialTypeCombo.Items.Add('Ishiiruka') | Out-Null
$MaterialTypeCombo.Items.Add('Dolphin') | Out-Null
$MaterialTypeCombo.SelectedItem = $MaterialMapFormat
$MaterialTypeCombo.Add_SelectedIndexChanged({GUI_UpdateComboBoxState})
$MaterialTypeCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$MaterialTypeLabel = New-Object System.Windows.Forms.Label
$MaterialTypeLabel.Size = New-Object System.Drawing.Size(110, 20)
$MaterialTypeLabel.Location = New-Object System.Drawing.Size(90, 82)
$MaterialTypeLabel.Text = 'Material Map Format'
$InternalGroup.Controls.Add($MaterialTypeCombo)
$InternalGroup.Controls.Add($MaterialTypeLabel)
$MaterialTypeTip = New-Object System.Windows.Forms.ToolTip
$MaterialTypeTip.InitialDelay = $ToolTipDelay
$MaterialTypeTip.AutoPopDelay = $ToolTipDuration
$MaterialTypeTipString = 'This option configures how the script handles Ishiiruka material maps. Ishiiruka{0}'
$MaterialTypeTipString += 'Tool creates DDS color textures in a format that is not compatible with the master{0}'
$MaterialTypeTipString += 'branch of Dolphin. It is possible to use this option to convert these color textures{0}'
$MaterialTypeTipString += 'into a DDS format that does work with the master branch of Dolphin.{0}'
$MaterialTypeTipString += '{0}'
$MaterialTypeTipString += 'Ishiiruka: Generate material maps from existing material maps (mat/nrm) or from{0}'
$MaterialTypeTipString += 'any material textures (bump/spec/nrm/lum) that are found. If the output format is{0}'
$MaterialTypeTipString += 'set to DDS, color textures will only work with Ishiiruka and not Dolphin.{0}'
$MaterialTypeTipString += '{0}'
$MaterialTypeTipString += 'Dolphin: Convert DDS color textures generated with Ishiiruka Tool to a Dolphin{0}'
$MaterialTypeTipString += 'compatible format. While in this mode, material map textures will not be created{0}'
$MaterialTypeTipString += 'at all even if the output format is set to PNG.'
$MaterialTypeTipString = [String]::Format($MaterialTypeTipString, [Environment]::NewLine)
$MaterialTypeTip.SetToolTip($MaterialTypeLabel, $MaterialTypeTipString)
#==============================================================================================================================================================================================
#  CTT GUI - CTT-PS Options
#==============================================================================================================================================================================================
$CTTOptionsGroup = New-Object System.Windows.Forms.GroupBox
$CTTOptionsGroup.Size = New-Object System.Drawing.Size(174, 104)
$CTTOptionsGroup.Location = New-Object System.Drawing.Size(606, 280)
$CTTOptionsGroup.Text = ' CTT-PS Options '
$Dialog.Controls.Add($CTTOptionsGroup)
$CTTOptionsGroupTip = New-Object System.Windows.Forms.ToolTip
$CTTOptionsGroupTip.InitialDelay = $ToolTipDelay
$CTTOptionsGroupTip.AutoPopDelay = $ToolTipDuration
$CTTOptionsGroupTipString = 'These options only affect the CTT-PS interface.'
$CTTOptionsGroupTip.SetToolTip($CTTOptionsGroup, $CTTOptionsGroupTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# PS Double Click
$PS_DC_State = (Get-ItemProperty -LiteralPath "HKLM:\Software\Classes\Microsoft.PowerShellScript.1\Shell").'(default)'
$PSDoubleClick = $PS_DC_State -eq '0'
$PSDoubleCLickCheck = New-Object System.Windows.Forms.CheckBox
$PSDoubleCLickCheck.Name = 'PSDoubleClick'
$PSDoubleCLickCheck.Size = New-Object System.Drawing.Size(120, 16)
$PSDoubleCLickCheck.Location = New-Object System.Drawing.Size(12, 15)
$PSDoubleCLickCheck.Checked = $PSDoubleClick
$PSDoubleCLickCheck.Text = ' PS Double Click'
$PSDoubleCLickCheck.Add_CheckStateChanged({GUI_PSDoubleClickCheckBoxState})
$CTTOptionsGroup.Controls.Add($PSDoubleCLickCheck)
$PSDoubleCLickTip = New-Object System.Windows.Forms.ToolTip
$PSDoubleCLickTip.InitialDelay = $ToolTipDelay
$PSDoubleCLickTip.AutoPopDelay = $ToolTipDuration
$PSDoubleCLickTipString = 'Allows opening PowerShell scripts with a double click. This requires {0}'
$PSDoubleCLickTipString += 'modification to the Windows registry, so toggling this checkbox will {0}'
$PSDoubleCLickTipString += 'update the "open" value for PowerShell scripts in the registry.{0}'
$PSDoubleCLickTipString += '{0}'
$PSDoubleCLickTipString += "This option is 100% safe, so fear not. If unsure, don't touch it. See{0}"
$PSDoubleCLickTipString += "the related help topic for more information on how it works."
$PSDoubleCLickTipString = [String]::Format($PSDoubleCLickTipString, [Environment]::NewLine)
$PSDoubleCLickTip.SetToolTip($PSDoubleCLickCheck, $PSDoubleCLickTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Toggle Top-Most Windows
$TopMostCheck = New-Object System.Windows.Forms.CheckBox
$TopMostCheck.Name = 'DisableTopMost'
$TopMostCheck.Size = New-Object System.Drawing.Size(120, 16)
$TopMostCheck.Location = New-Object System.Drawing.Size(12, 32)
$TopMostCheck.Checked = $DisableTopMost
$TopMostCheck.Text = ' Disable Top-Most'
$TopMostCheck.Add_CheckStateChanged({GUI_UpdateCheckBoxState ; $Dialog.Topmost = !$DisableTopMost})
$CTTOptionsGroup.Controls.Add($TopMostCheck)
$TopMostTip = New-Object System.Windows.Forms.ToolTip
$TopMostTip.InitialDelay = $ToolTipDelay
$TopMostTip.AutoPopDelay = $ToolTipDuration
$TopMostTipString = 'Disables forcing CTT-PS GUI over top of all other open windows.'
$TopMostTip.SetToolTip($TopMostCheck, $TopMostTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Auto-Hide Console
$HideConsoleCheck = New-Object System.Windows.Forms.CheckBox
$HideConsoleCheck.Name = 'AlwaysShowConsole'
$HideConsoleCheck.Size = New-Object System.Drawing.Size(140, 16)
$HideConsoleCheck.Location = New-Object System.Drawing.Size(12, 49)
$HideConsoleCheck.Checked = $AlwaysShowConsole
$HideConsoleCheck.Text = ' Always Show Console'
$HideConsoleCheck.Add_CheckStateChanged({GUI_UpdateCheckBoxState})
$CTTOptionsGroup.Controls.Add($HideConsoleCheck)
$HideConsoleCheckTip = New-Object System.Windows.Forms.ToolTip
$HideConsoleCheckTip.InitialDelay = $ToolTipDelay
$HideConsoleCheckTip.AutoPopDelay = $ToolTipDuration
$HideConsoleTipString = 'If disabled, hides the PowerShell console window while it is not{0}'
$HideConsoleTipString += 'in use, and only shows it while textures are being processed.'
$HideConsoleTipString = [String]::Format($HideConsoleTipString, [Environment]::NewLine)
$HideConsoleCheckTip.SetToolTip($HideConsoleCheck, $HideConsoleTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Auto-Hide Console
$ConsoleColorsCheck = New-Object System.Windows.Forms.CheckBox
$ConsoleColorsCheck.Name = 'ConsoleColors'
$ConsoleColorsCheck.Size = New-Object System.Drawing.Size(140, 16)
$ConsoleColorsCheck.Location = New-Object System.Drawing.Size(12, 66)
$ConsoleColorsCheck.Checked = $ConsoleColors
$ConsoleColorsCheck.Text = ' More Console Colors'
$ConsoleColorsCheck.Add_CheckStateChanged({GUI_UpdateCheckBoxState})
$CTTOptionsGroup.Controls.Add($ConsoleColorsCheck)
$ConsoleColorsCheckTip = New-Object System.Windows.Forms.ToolTip
$ConsoleColorsCheckTip.InitialDelay = $ToolTipDelay
$ConsoleColorsCheckTip.AutoPopDelay = $ToolTipDuration
$ConsoleColorsTipString = 'Enable additional colors in the PowerShell console.'
$ConsoleColorsCheckTip.SetToolTip($ConsoleColorsCheck, $ConsoleColorsTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Disable Stored Options
$EnableStoredCheck = New-Object System.Windows.Forms.CheckBox
$EnableStoredCheck.Name = 'EnableStoring'
$EnableStoredCheck.Size = New-Object System.Drawing.Size(150, 16)
$EnableStoredCheck.Location = New-Object System.Drawing.Size(12, 83)
$EnableStoredCheck.Checked = $EnableStoring
$EnableStoredCheck.Text = " Enable Stored Options"
$EnableStoredCheck.Add_CheckStateChanged({GUI_UpdateCheckBoxState})
$CTTOptionsGroup.Controls.Add($EnableStoredCheck)
$EnableStoredTip = New-Object System.Windows.Forms.ToolTip
$EnableStoredTip.InitialDelay = $ToolTipDelay
$EnableStoredTip.AutoPopDelay = $ToolTipDuration
$EnableStoredTipString = 'Disables saving changes made to options when the script is closed.'
$EnableStoredTip.SetToolTip($EnableStoredCheck, $EnableStoredTipString)
#==============================================================================================================================================================================================
# CTT GUI - Create Option 1: Scan
#==============================================================================================================================================================================================
$ScanGroup = New-Object System.Windows.Forms.GroupBox
$ScanGroup.Size = New-Object System.Drawing.Size(380, 124)
$ScanGroup.Location = New-Object System.Drawing.Size(10, 260)
$ScanGroup.Text = ' Scan Textures Options '
$Dialog.Controls.Add($ScanGroup)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Attempt Repairs
$S_RepairCheck = New-Object System.Windows.Forms.CheckBox
$S_RepairCheck.Name = 'RepairTextures'
$S_RepairCheck.Size = New-Object System.Drawing.Size(110, 16)
$S_RepairCheck.Location = New-Object System.Drawing.Size(10, 20)
$S_RepairCheck.Checked = $RepairTextures
$S_RepairCheck.Text = ' Attempt Repairs'
$S_RepairCheck.Add_CheckStateChanged({GUI_UpdateCheckBoxState})
$ScanGroup.Controls.Add($S_RepairCheck)
$S_RepairTip = New-Object System.Windows.Forms.ToolTip
$S_RepairTip.InitialDelay = $ToolTipDelay
$S_RepairTip.AutoPopDelay = $ToolTipDuration
$S_RepairTipString = 'Attempts to repair textures with issues. Repaired textures can{0}'
$S_RepairTipString += 'be found in the Output Path in a folder named "RepairedTextures".{0}'
$S_RepairTipString += '{0}'
$S_RepairTipString += 'Issues that can be fixed with this option are:{0}'
$S_RepairTipString += '- Uneven Scale - Scaling value mismatch between width/height.{0}'
$S_RepairTipString += "- Bad Width/Height - Dimensions don't match calculated values.{0}"
$S_RepairTipString += "- Bad Aspect Ratio - Texture aspect doesn't match original.{0}"
$S_RepairTipString += '- Bad MipMap Scale - MipMap dimensions are incorrect.{0}'
$S_RepairTipString += '- Missing MipMaps - Some or all MipMap levels are missing.{0}'
$S_RepairTipString += '{0}'
$S_RepairTipString += 'The type of DDS mipmaps that are repaired depends on the value{0}'
$S_RepairTipString += 'that is set in the "DDS Mipmap Type" field.'
$S_RepairTipString = [String]::Format($S_RepairTipString, [Environment]::NewLine)
$S_RepairTip.SetToolTip($S_RepairCheck, $S_RepairTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Copy Bad Textures
$S_CopyBadCheck = New-Object System.Windows.Forms.CheckBox
$S_CopyBadCheck.Name = 'CopyBadTextures'
$S_CopyBadCheck.Size = New-Object System.Drawing.Size(125, 16)
$S_CopyBadCheck.Location = New-Object System.Drawing.Size(10, 40)
$S_CopyBadCheck.Checked = $CopyBadTextures
$S_CopyBadCheck.Text = ' Copy Bad Textures'
$S_CopyBadCheck.Add_CheckStateChanged({GUI_UpdateCheckBoxState})
$ScanGroup.Controls.Add($S_CopyBadCheck)
$S_CopyBadTip = New-Object System.Windows.Forms.ToolTip
$S_CopyBadTip.InitialDelay = $ToolTipDelay
$S_CopyBadTip.AutoPopDelay = $ToolTipDuration
$S_CopyBadTipString = 'Copies textures that have issues to the Output Path in a{0}'
$S_CopyBadTipString += 'folder named "BrokenTextures".{0}'
$S_CopyBadTipString += '{0}'
$S_CopyBadTipString += 'If the option "Attempt Repairs" is enabled and a texture is{0}'
$S_CopyBadTipString += 'successfully repaired, then the texture will not be copied.'
$S_CopyBadTipString = [String]::Format($S_CopyBadTipString, [Environment]::NewLine)
$S_CopyBadTip.SetToolTip($S_CopyBadCheck, $S_CopyBadTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Hide OK Textures
$S_HideOKCheck = New-Object System.Windows.Forms.CheckBox
$S_HideOKCheck.Name = 'HideOKTextures'
$S_HideOKCheck.Size = New-Object System.Drawing.Size(120, 16)
$S_HideOKCheck.Location = New-Object System.Drawing.Size(10, 60)
$S_HideOKCheck.Checked = $HideOKTextures
$S_HideOKCheck.Text = ' Hide OK Textures'
$S_HideOKCheck.Add_CheckStateChanged({GUI_UpdateCheckBoxState})
$ScanGroup.Controls.Add($S_HideOKCheck)
$S_HideOKTip = New-Object System.Windows.Forms.ToolTip
$S_HideOKTip.InitialDelay = $ToolTipDelay
$S_HideOKTip.AutoPopDelay = $ToolTipDuration
$S_HideOKTipString = 'Textures that have no issues are flagged as "OK". This option{0}'
$S_HideOKTipString += 'prevents these textures from showing up in the log file.'
$S_HideOKTipString = [String]::Format($S_HideOKTipString, [Environment]::NewLine)
$S_HideOKTip.SetToolTip($S_HideOKCheck, $S_HideOKTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Ignore Duplicates
$S_IgnoreDupesCheck = New-Object System.Windows.Forms.CheckBox
$S_IgnoreDupesCheck.Name = 'IgnoreDuplicates'
$S_IgnoreDupesCheck.Size = New-Object System.Drawing.Size(120, 16)
$S_IgnoreDupesCheck.Location = New-Object System.Drawing.Size(10, 80)
$S_IgnoreDupesCheck.Checked = $IgnoreDuplicates
$S_IgnoreDupesCheck.Text = ' Ignore Duplicates'
$S_IgnoreDupesCheck.Add_CheckStateChanged({GUI_UpdateCheckBoxState})
$ScanGroup.Controls.Add($S_IgnoreDupesCheck)
$S_IgnoreDupesTip = New-Object System.Windows.Forms.ToolTip
$S_IgnoreDupesTip.InitialDelay = $ToolTipDelay
$S_IgnoreDupesTip.AutoPopDelay = $ToolTipDuration
$S_IgnoreDupesTipString = 'This option disables the script from finding duplicate textures{0}'
$S_IgnoreDupesTipString += 'and printing them to the log. It can be useful to hide duplicates{0}'
$S_IgnoreDupesTipString += 'to prevent log spam if a pack contains "Optional Textures" that{0}'
$S_IgnoreDupesTipString += 'has many textures with the same name/hash.'
$S_IgnoreDupesTipString = [String]::Format($S_IgnoreDupesTipString, [Environment]::NewLine)
$S_IgnoreDupesTip.SetToolTip($S_IgnoreDupesCheck, $S_IgnoreDupesTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Allow Not HD Textures
$S_AllowNotHDCheck = New-Object System.Windows.Forms.CheckBox
$S_AllowNotHDCheck.Name = 'AllowNotHD'
$S_AllowNotHDCheck.Size = New-Object System.Drawing.Size(140, 16)
$S_AllowNotHDCheck.Location = New-Object System.Drawing.Size(10, 100)
$S_AllowNotHDCheck.Checked = $AllowNotHD
$S_AllowNotHDCheck.Text = ' Allow NotHD Textures'
$S_AllowNotHDCheck.Add_CheckStateChanged({GUI_UpdateCheckBoxState})
$ScanGroup.Controls.Add($S_AllowNotHDCheck)
$S_AllowNotHDTip = New-Object System.Windows.Forms.ToolTip
$S_AllowNotHDTip.InitialDelay = $ToolTipDelay
$S_AllowNotHDTip.AutoPopDelay = $ToolTipDuration
$S_AllowNotHDTipString = 'Allows textures that have the same dimensions as the original{0}'
$S_AllowNotHDTipString += 'texture to pass validation and get treated as an HD texture.'
$S_AllowNotHDTipString = [String]::Format($S_AllowNotHDTipString, [Environment]::NewLine)
$S_AllowNotHDTip.SetToolTip($S_AllowNotHDCheck, $S_AllowNotHDTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# DDS MipMap Type
$S_DDSMipMapCombo = New-Object System.Windows.Forms.ComboBox
$S_DDSMipMapCombo.Name = 'DDSMipMapType'
$S_DDSMipMapCombo.Size = New-Object System.Drawing.Size(70, 28)
$S_DDSMipMapCombo.Location = New-Object System.Drawing.Size(174, 20)
$S_DDSMipMapCombo.Items.Add('External') | Out-Null
$S_DDSMipMapCombo.Items.Add('Internal') | Out-Null
$S_DDSMipMapCombo.Items.Add('Both') | Out-Null
$S_DDSMipMapCombo.SelectedItem = $DDSMipMapType
$S_DDSMipMapCombo.Add_SelectedIndexChanged({GUI_UpdateComboBoxState})
$S_DDSMipMapCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$S_DDSMipMapLabel = New-Object System.Windows.Forms.Label
$S_DDSMipMapLabel.Size = New-Object System.Drawing.Size(120, 22)
$S_DDSMipMapLabel.Location = New-Object System.Drawing.Size(248, 22)
$S_DDSMipMapLabel.Text = 'DDS MipMap Type'
$ScanGroup.Controls.Add($S_DDSMipMapCombo)
$ScanGroup.Controls.Add($S_DDSMipMapLabel)
$S_DDSMipMapTip = New-Object System.Windows.Forms.ToolTip
$S_DDSMipMapTip.InitialDelay = $ToolTipDelay
$S_DDSMipMapTip.AutoPopDelay = $ToolTipDuration
$S_DDSMipMapTipString = 'Determines which type of DDS MipMaps are scanned for issues{0}'
$S_DDSMipMapTipString += 'and the type generated when "Attempt Repairs" is enabled.{0}'
$S_DDSMipMapTipString += '{0}'
$S_DDSMipMapTipString += 'External: These can be used with any version of Dolphin.{0}'
$S_DDSMipMapTipString += 'Internal: Can only be used by Dolphin Ishiiruka.{0}'
$S_DDSMipMapTipString += 'Both: Scan/Repair both types. Repair takes lots of disk space.'
$S_DDSMipMapTipString = [String]::Format($S_DDSMipMapTipString, [Environment]::NewLine)
$S_DDSMipMapTip.SetToolTip($S_DDSMipMapLabel, $S_DDSMipMapTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Scale-Fix Threshold
$S_ScaleFixNumBox = New-Object System.Windows.Forms.NumericUpDown
$S_ScaleFixNumBox.Name = 'ScaleThreshold'
$S_ScaleFixNumBox.Size = New-Object System.Drawing.Size(70, 10)
$S_ScaleFixNumBox.Location = New-Object System.Drawing.Size(174, 45)
$S_ScaleFixNumBox.DecimalPlaces = 2
$S_ScaleFixNumBox.Value = $ScaleThreshold
$S_ScaleFixNumBox.Minimum = 0.00
$S_ScaleFixNumBox.Maximum = 0.99
$S_ScaleFixNumBox.Increment = 0.01
$S_ScaleFixNumBox.Add_ValueChanged({GUI_UpdateNumericUpDown 'decimal'})
$S_ScaleFixNumBox.Enabled = $RepairTextures
$S_ScaleFixLabel = New-Object System.Windows.Forms.Label
$S_ScaleFixLabel.Size = New-Object System.Drawing.Size(120, 22)
$S_ScaleFixLabel.Location = New-Object System.Drawing.Size(248, 47)
$S_ScaleFixLabel.Text = 'Scale-Fix Threshold'
$S_ScaleFixLabel.Enabled = $RepairTextures
$ScanGroup.Controls.Add($S_ScaleFixNumBox)
$ScanGroup.Controls.Add($S_ScaleFixLabel)
$S_ScaleFixTip = New-Object System.Windows.Forms.ToolTip
$S_ScaleFixTip.InitialDelay = $ToolTipDelay
$S_ScaleFixTip.AutoPopDelay = $ToolTipDuration
$S_ScaleFixTipString = 'Sets the minimum decimal value of the scale to auto-repair{0}'
$S_ScaleFixTipString += 'textures to the next highest integer scale.{0}'
$S_ScaleFixTipString += '{0}'
$S_ScaleFixTipString += 'Example: Scale-Fix Threshold = 0.45 will upscale 4.45-4.99{0}'
$S_ScaleFixTipString += 'to 5x scale, but downscale 4.01-4.44 to 4x scale.'
$S_ScaleFixTipString = [String]::Format($S_ScaleFixTipString, [Environment]::NewLine)
$S_ScaleFixTip.SetToolTip($S_ScaleFixLabel, $S_ScaleFixTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Aspect-Fix Threshold
$S_AspectFixNumBox = New-Object System.Windows.Forms.NumericUpDown
$S_AspectFixNumBox.Name = 'AspectThreshold'
$S_AspectFixNumBox.Size = New-Object System.Drawing.Size(70, 10)
$S_AspectFixNumBox.Location = New-Object System.Drawing.Size(174, 70)
$S_AspectFixNumBox.DecimalPlaces = 2
$S_AspectFixNumBox.Value = $AspectThreshold
$S_AspectFixNumBox.Minimum = 0.00
$S_AspectFixNumBox.Maximum = 0.99
$S_AspectFixNumBox.Increment = 0.01
$S_AspectFixNumBox.Add_ValueChanged({GUI_UpdateNumericUpDown 'decimal'})
$S_AspectFixNumBox.Enabled = $RepairTextures
$S_AspectFixLabel = New-Object System.Windows.Forms.Label
$S_AspectFixLabel.Size = New-Object System.Drawing.Size(120, 22)
$S_AspectFixLabel.Location = New-Object System.Drawing.Size(248, 73)
$S_AspectFixLabel.Text = 'Aspect-Fix Threshold'
$S_AspectFixLabel.Enabled = $RepairTextures
$ScanGroup.Controls.Add($S_AspectFixNumBox)
$ScanGroup.Controls.Add($S_AspectFixLabel)
$S_AspectFixTip = New-Object System.Windows.Forms.ToolTip
$S_AspectFixTip.InitialDelay = $ToolTipDelay
$S_AspectFixTip.AutoPopDelay = $ToolTipDuration
$S_AspectFixTipString = 'Sets a minimum limit of aspect ratio difference between the original and{0}'
$S_AspectFixTipString += 'custom texture. Aspect is calculated from dividing the width by the height,{0}'
$S_AspectFixTipString += 'and both the original and custom texture should have identical aspects. The{0}'
$S_AspectFixTipString += 'value of Aspect-Fix Threshold is compared against the original texture aspect{0}'
$S_AspectFixTipString += 'minus the custom texture aspect. It is not suggested to use a value above 0.10.{0}'
$S_AspectFixTipString += '{0}'
$S_AspectFixTipString += 'Example: {0}'
$S_AspectFixTipString += 'Original = 200x32  - Aspect 6.25{0}'
$S_AspectFixTipString += 'Custom  = 800x130 - Aspect 6.15{0}'
$S_AspectFixTipString += 'Aspects 6.25 - 6.15 = 0.10 Aspect Difference{0}'
$S_AspectFixTipString += 'Minimum Aspect-Fix Threshold = 0.10 to Auto-Repair Texture'
$S_AspectFixTipString = [String]::Format($S_AspectFixTipString, [Environment]::NewLine)
$S_AspectFixTip.SetToolTip($S_AspectFixLabel, $S_AspectFixTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Force New MipMaps
$S_ForceNewMipsCheck = New-Object System.Windows.Forms.CheckBox
$S_ForceNewMipsCheck.Name = 'ForceNewMipMaps'
$S_ForceNewMipsCheck.Size = New-Object System.Drawing.Size(130, 16)
$S_ForceNewMipsCheck.Location = New-Object System.Drawing.Size(174, 100)
$S_ForceNewMipsCheck.Checked = $ForceNewMipMaps
$S_ForceNewMipsCheck.Text = ' Force New MipMaps'
$S_ForceNewMipsCheck.Add_CheckStateChanged({GUI_UpdateCheckBoxState})
$S_ForceNewMipsCheck.Enabled = $RepairTextures
$ScanGroup.Controls.Add($S_ForceNewMipsCheck)
$S_ForceNewMipsTip = New-Object System.Windows.Forms.ToolTip
$S_ForceNewMipsTip.InitialDelay = $ToolTipDelay
$S_ForceNewMipsTip.AutoPopDelay = $ToolTipDuration
$S_ForceNewMipsTipString = 'Forces the script to ignore included mipmaps and generate{0}'
$S_ForceNewMipsTipString += 'new ones from the base texture (top layer).'
$S_ForceNewMipsTipString = [String]::Format($S_ForceNewMipsTipString, [Environment]::NewLine)
$S_ForceNewMipsTip.SetToolTip($S_ForceNewMipsCheck, $S_ForceNewMipsTipString)
#==============================================================================================================================================================================================
# CTT GUI - Create Option 2: Rescale Textures
#==============================================================================================================================================================================================
$RescaleGroup = New-Object System.Windows.Forms.GroupBox
$RescaleGroup.Size = New-Object System.Drawing.Size(380, 124)
$RescaleGroup.Location = New-Object System.Drawing.Size(10, 260)
$RescaleGroup.Text = ' Rescale Textures Options '
$Dialog.Controls.Add($RescaleGroup)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Rescale Factor
$R_FactorNumBox = New-Object System.Windows.Forms.NumericUpDown
$R_FactorNumBox.Name = 'RescaleFactor'
$R_FactorNumBox.Size = New-Object System.Drawing.Size(80, 10)
$R_FactorNumBox.Location = New-Object System.Drawing.Size(10, 20)
$R_FactorNumBox.DecimalPlaces = 0
$R_FactorNumBox.Value = $RescaleFactor
$R_FactorNumBox.Minimum = 2
$R_FactorNumBox.Maximum = 16
$R_FactorNumBox.Increment = 1
$R_FactorNumBox.Add_ValueChanged({GUI_UpdateNumericUpDown 'integer'})
$R_FactorLabel = New-Object System.Windows.Forms.Label
$R_FactorLabel.Size = New-Object System.Drawing.Size(100, 22)
$R_FactorLabel.Location = New-Object System.Drawing.Size(92, 22)
$R_FactorLabel.Text = 'Rescale Factor'
$RescaleGroup.Controls.Add($R_FactorNumBox)
$RescaleGroup.Controls.Add($R_FactorLabel)
$R_FactorTip = New-Object System.Windows.Forms.ToolTip
$R_FactorTip.InitialDelay = $ToolTipDelay
$R_FactorTip.AutoPopDelay = $ToolTipDuration
$R_FactorTipString = 'The multiplicand that is used to rescale textures. The new{0}'
$R_FactorTipString += 'dimensions of the custom texture are calculated using{0}'
$R_FactorTipString += 'the equation: (Original Dimensions * Rescale Factor).'
$R_FactorTipString = [String]::Format($R_FactorTipString, [Environment]::NewLine)
$R_FactorTip.SetToolTip($R_FactorLabel, $R_FactorTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
function RescaleFormatToggle()
{
  $R_DDSMipMapCombo.Enabled = (($R_FormatCombo.SelectedItem -eq 'DDS') -or ($R_FormatCombo.SelectedItem -eq 'Existing'))
  $R_DDSMipMapLabel.Enabled = (($R_FormatCombo.SelectedItem -eq 'DDS') -or ($R_FormatCombo.SelectedItem -eq 'Existing'))
}
#----------------------------------------------------------------------------------------------------------------------------------------------
# Output Format
$R_FormatCombo = New-Object System.Windows.Forms.ComboBox
$R_FormatCombo.Name = 'RescaleFormat'
$R_FormatCombo.Size = New-Object System.Drawing.Size(80, 28)
$R_FormatCombo.Location = New-Object System.Drawing.Size(10, 44)
$R_FormatCombo.Items.Add('PNG') | Out-Null
if ($NVDXT_Exists) { $R_FormatCombo.Items.Add('DDS') | Out-Null }
$R_FormatCombo.Items.Add('JPG') | Out-Null
$R_FormatCombo.Items.Add('Existing') | Out-Null
if ($RescaleFormat -eq $null) { $R_FormatCombo.SelectedItem = 'Existing' }
else { $R_FormatCombo.SelectedItem = ExtensionToText $RescaleFormat }
$R_FormatCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$R_FormatCombo.Add_SelectedIndexChanged({GUI_UpdateComboBoxState ; RescaleFormatToggle})
$R_FormatLabel = New-Object System.Windows.Forms.Label
$R_FormatLabel.Size = New-Object System.Drawing.Size(100, 22)
$R_FormatLabel.Location = New-Object System.Drawing.Size(92, 47)
$R_FormatLabel.Text = 'Output Format'
$RescaleGroup.Controls.Add($R_FormatCombo)
$RescaleGroup.Controls.Add($R_FormatLabel)
$R_FormatTip = New-Object System.Windows.Forms.ToolTip
$R_FormatTip.InitialDelay = $ToolTipDelay
$R_FormatTip.AutoPopDelay = $ToolTipDuration
$R_FormatTipString = 'The output format that textures will be created. DDS requires nvidia{0}'
$R_FormatTipString += 'DDS Utilities to be installed. If "Existing" is selected, the new texture{0}'
$R_FormatTipString += "will be recreated with the custom texture's current file extension."
$R_FormatTipString = [String]::Format($R_FormatTipString, [Environment]::NewLine)
$R_FormatTip.SetToolTip($R_FormatLabel, $R_FormatTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Allowed Scaling
$R_ScalingCombo = New-Object System.Windows.Forms.ComboBox
$R_ScalingCombo.Name = 'RescaleScaling'
$R_ScalingCombo.Size = New-Object System.Drawing.Size(80, 28)
$R_ScalingCombo.Location = New-Object System.Drawing.Size(10, 68)
$R_ScalingCombo.Items.Add('All') | Out-Null
$R_ScalingCombo.Items.Add('Downscale') | Out-Null
$R_ScalingCombo.Items.Add('Upscale') | Out-Null
$R_ScalingCombo.SelectedItem = $RescaleScaling
$R_ScalingCombo.Add_SelectedIndexChanged({GUI_UpdateComboBoxState})
$R_ScalingCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$R_ScalingLabel = New-Object System.Windows.Forms.Label
$R_ScalingLabel.Size = New-Object System.Drawing.Size(100, 22)
$R_ScalingLabel.Location = New-Object System.Drawing.Size(92, 71)
$R_ScalingLabel.Text = 'Allowed Scaling'
$RescaleGroup.Controls.Add($R_ScalingCombo)
$RescaleGroup.Controls.Add($R_ScalingLabel)
$R_ScalingTip = New-Object System.Windows.Forms.ToolTip
$R_ScalingTip.InitialDelay = $ToolTipDelay
$R_ScalingTip.AutoPopDelay = $ToolTipDuration
$R_ScalingTipString = 'Filters which textures are rescaled. This option compares the value entered{0}'
$R_ScalingTipString += "for Rescale Factor against the current texture's width and height scales. The{0}"
$R_ScalingTipString += 'texture will only be rescaled if the selected condition is met.{0}'
$R_ScalingTipString += '{0}'
$R_ScalingTipString += 'All - All textures will always be rescaled.{0}'
$R_ScalingTipString += 'Downscale - Texture scales must be greater than the Rescale Factor.{0}'
$R_ScalingTipString += 'Upscale - Texture scales must be less than the Rescale Factor.'
$R_ScalingTipString = [String]::Format($R_ScalingTipString, [Environment]::NewLine)
$R_ScalingTip.SetToolTip($R_ScalingLabel, $R_ScalingTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# DDS MipMap Type
$R_DDSMipMapCombo = New-Object System.Windows.Forms.ComboBox
$R_DDSMipMapCombo.Name = 'DDSMipMapType'
$R_DDSMipMapCombo.Size = New-Object System.Drawing.Size(80, 28)
$R_DDSMipMapCombo.Location = New-Object System.Drawing.Size(10, 93)
$R_DDSMipMapCombo.Items.Add('External') | Out-Null
$R_DDSMipMapCombo.Items.Add('Internal') | Out-Null
$R_DDSMipMapCombo.Items.Add('Both') | Out-Null
$R_DDSMipMapCombo.SelectedItem = $DDSMipMapType
$R_DDSMipMapCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$R_DDSMipMapCombo.Enabled = (($R_FormatCombo.SelectedItem -eq 'DDS') -or ($R_FormatCombo.SelectedItem -eq 'Existing'))
$R_DDSMipMapCombo.Add_SelectedIndexChanged({GUI_UpdateComboBoxState})
$R_DDSMipMapLabel = New-Object System.Windows.Forms.Label
$R_DDSMipMapLabel.Size = New-Object System.Drawing.Size(100, 22)
$R_DDSMipMapLabel.Location = New-Object System.Drawing.Size(92, 96)
$R_DDSMipMapLabel.Text = 'DDS MipMap Type'
$R_DDSMipMapLabel.Enabled = (($R_FormatCombo.SelectedItem -eq 'DDS') -or ($R_FormatCombo.SelectedItem -eq 'Existing'))
$RescaleGroup.Controls.Add($R_DDSMipMapCombo)
$RescaleGroup.Controls.Add($R_DDSMipMapLabel)
$R_DDSMipMapTip = New-Object System.Windows.Forms.ToolTip
$R_DDSMipMapTip.InitialDelay = $ToolTipDelay
$R_DDSMipMapTip.AutoPopDelay = $ToolTipDuration
$R_DDSMipMapTipString = 'Determines which types of mipmaps are generated for DDS textures.{0}'
$R_DDSMipMapTipString += '{0}'
$R_DDSMipMapTipString += 'External: These can be used with any version of Dolphin.{0}'
$R_DDSMipMapTipString += 'Internal: Can only be used by Dolphin Ishiiruka.{0}'
$R_DDSMipMapTipString += 'Both: Generate both types, but this takes lots of disk space.'
$R_DDSMipMapTipString = [String]::Format($R_DDSMipMapTipString, [Environment]::NewLine)
$R_DDSMipMapTip.SetToolTip($R_DDSMipMapLabel, $R_DDSMipMapTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Copy Non-Textures
$R_CopyNonCheck = New-Object System.Windows.Forms.CheckBox
$R_CopyNonCheck.Name = 'CopyNonTextures'
$R_CopyNonCheck.Size = New-Object System.Drawing.Size(130, 16)
$R_CopyNonCheck.Location = New-Object System.Drawing.Size(200, 20)
$R_CopyNonCheck.Checked = $CopyNonTextures
$R_CopyNonCheck.Text = ' Copy Non-Textures'
$R_CopyNonCheck.Add_CheckStateChanged({GUI_UpdateCheckBoxState})
$RescaleGroup.Controls.Add($R_CopyNonCheck)
$R_CopyNonTip = New-Object System.Windows.Forms.ToolTip
$R_CopyNonTip.InitialDelay = $ToolTipDelay
$R_CopyNonTip.AutoPopDelay = $ToolTipDuration
$R_CopyNonTipString = 'Copies files that are not images (such as .txt) into the newly generated pack.'
$R_CopyNonTip.SetToolTip($R_CopyNonCheck, $R_CopyNonTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Force New MipMaps
$R_ForceNewMipsCheck = New-Object System.Windows.Forms.CheckBox
$R_ForceNewMipsCheck.Name = 'ForceNewMipMaps'
$R_ForceNewMipsCheck.Size = New-Object System.Drawing.Size(130, 16)
$R_ForceNewMipsCheck.Location = New-Object System.Drawing.Size(200, 40)
$R_ForceNewMipsCheck.Checked = $ForceNewMipMaps
$R_ForceNewMipsCheck.Text = ' Force New MipMaps'
$R_ForceNewMipsCheck.Add_CheckStateChanged({GUI_UpdateCheckBoxState})
$RescaleGroup.Controls.Add($R_ForceNewMipsCheck)
$R_ForceNewMipsTip = New-Object System.Windows.Forms.ToolTip
$R_ForceNewMipsTip.InitialDelay = $ToolTipDelay
$R_ForceNewMipsTip.AutoPopDelay = $ToolTipDuration
$R_ForceNewMipsTipString = 'Forces the script to ignore included mipmaps and generate{0}'
$R_ForceNewMipsTipString += 'new ones from the base texture (top layer).'
$R_ForceNewMipsTipString = [String]::Format($R_ForceNewMipsTipString, [Environment]::NewLine)
$R_ForceNewMipsTip.SetToolTip($R_ForceNewMipsCheck, $R_ForceNewMipsTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Manual Rescale
$R_ManualCheck = New-Object System.Windows.Forms.CheckBox
$R_ManualCheck.Name = 'ManualRescale'
$R_ManualCheck.Size = New-Object System.Drawing.Size(130, 16)
$R_ManualCheck.Location = New-Object System.Drawing.Size(200, 60)
$R_ManualCheck.Checked = $ManualRescale
$R_ManualCheck.Text = ' Manual Rescale'
$R_ManualCheck.Add_CheckStateChanged({GUI_UpdateCheckBoxState})
$RescaleGroup.Controls.Add($R_ManualCheck)
$R_ManualTip = New-Object System.Windows.Forms.ToolTip
$R_ManualTip.InitialDelay = $ToolTipDelay
$R_ManualTip.AutoPopDelay = $ToolTipDuration
$R_ManualTipString = 'This option allows rescaling each texture individually with a different integer{0}'
$R_ManualTipString += 'scale chosen by the user. Very large scaling values from 1-100 are allowed to be{0}'
$R_ManualTipString += 'set in this mode so choose reasonable values. The amount that was entered for{0}'
$R_ManualTipString += '"Rescale Factor" acts as a default value, which will be used if no value is entered{0}'
$R_ManualTipString += 'when prompted.{0}'
$R_ManualTipString += '{0}'
$R_ManualTipString += 'It is NOT suggested to use this option on packs with a lot of textures as it will{0}'
$R_ManualTipString += 'take forever to rescale them all. The purpose of this option is to rescale a folder{0}'
$R_ManualTipString += 'with only a few textures that require different scaling values.'
$R_ManualTipString = [String]::Format($R_ManualTipString, [Environment]::NewLine)
$R_ManualTip.SetToolTip($R_ManualCheck, $R_ManualTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Auto-Rename Output Pack
$global:RescaleAutoText = ''
$R_AutoNameTextBox = New-Object System.Windows.Forms.TextBox
$R_AutoNameTextBox.Name = 'RescaleAutoText'
$R_AutoNameTextBox.Size = New-Object System.Drawing.Size(150, 20)
$R_AutoNameTextBox.Location = New-Object System.Drawing.Size(200, 94)
$R_AutoNameTextBox.Text = ''
$R_AutoNameTextBox.Add_Leave({GUI_VerifyAutoNameText})
$R_AutoNameLabel = New-Object System.Windows.Forms.Label
$R_AutoNameLabel.Size = New-Object System.Drawing.Size(140, 22)
$R_AutoNameLabel.Location = New-Object System.Drawing.Size(200, 80)
$R_AutoNameLabel.Text = 'Auto-Rename Output:'
$RescaleGroup.Controls.Add($R_AutoNameTextBox)
$RescaleGroup.Controls.Add($R_AutoNameLabel)
$R_AutoNameTip = New-Object System.Windows.Forms.ToolTip
$R_AutoNameTip.InitialDelay = $ToolTipDelay
$R_AutoNameTip.AutoPopDelay = $ToolTipDuration
$R_AutoNameTipString = 'Automatically renames the "RescaledTextures" folder to the specified text{0}'
$R_AutoNameTipString += 'entered here. If no value is entered, the folder will not be renamed. This{0}'
$R_AutoNameTipString += "should usually be the first 3 letters of the texture pack's GameID."
$R_AutoNameTipString = [String]::Format($R_AutoNameTipString, [Environment]::NewLine)
$R_AutoNameTip.SetToolTip($R_AutoNameLabel, $R_AutoNameTipString)
#==============================================================================================================================================================================================
# Create Option 3: Convert Textures
#==============================================================================================================================================================================================
$ConvertGroup = New-Object System.Windows.Forms.GroupBox
$ConvertGroup.Size = New-Object System.Drawing.Size(380, 124)
$ConvertGroup.Location = New-Object System.Drawing.Size(10, 260)
$ConvertGroup.Text = ' Convert Textures Options '
$Dialog.Controls.Add($ConvertGroup)
#----------------------------------------------------------------------------------------------------------------------------------------------
function ConvertFormatToggle()
{
  $C_DDSMipMapCombo.Enabled = ($C_FormatCombo.SelectedItem -eq 'DDS')
  $C_DDSMipMapLabel.Enabled = ($C_FormatCombo.SelectedItem -eq 'DDS')
}
#----------------------------------------------------------------------------------------------------------------------------------------------
# Output Format
$C_FormatCombo = New-Object System.Windows.Forms.ComboBox
$C_FormatCombo.Name = 'ConvertFormat'
$C_FormatCombo.Size = New-Object System.Drawing.Size(70, 10)
$C_FormatCombo.Location = New-Object System.Drawing.Size(10, 20)
$C_FormatCombo.Items.Add('PNG') | Out-Null
if ($NVDXT_Exists) { $C_FormatCombo.Items.Add('DDS') | Out-Null }
$C_FormatCombo.Items.Add('JPG') | Out-Null
$C_FormatCombo.SelectedItem = ExtensionToText $ConvertFormat
$C_FormatCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$C_FormatCombo.Add_SelectedIndexChanged({GUI_UpdateComboBoxState ; ConvertFormatToggle})
$C_FormatLabel = New-Object System.Windows.Forms.Label
$C_FormatLabel.Size = New-Object System.Drawing.Size(100, 22)
$C_FormatLabel.Location = New-Object System.Drawing.Size(84, 23)
$C_FormatLabel.Text = 'Output Format'
$ConvertGroup.Controls.Add($C_FormatCombo)
$ConvertGroup.Controls.Add($C_FormatLabel)
$C_FormatTip = New-Object System.Windows.Forms.ToolTip
$C_FormatTip.InitialDelay = $ToolTipDelay
$C_FormatTip.AutoPopDelay = $ToolTipDuration
$C_FormatTipString = 'The output format that textures will be created. The{0}'
$C_FormatTipString += 'DDS option requires nvidia DDS Utilities to be installed.'
$C_FormatTipString = [String]::Format($C_FormatTipString, [Environment]::NewLine)
$C_FormatTip.SetToolTip($C_FormatLabel, $C_FormatTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# DDS MipMap Type
$C_DDSMipMapCombo = New-Object System.Windows.Forms.ComboBox
$C_DDSMipMapCombo.Name = 'DDSMipMapType'
$C_DDSMipMapCombo.Size = New-Object System.Drawing.Size(70, 28)
$C_DDSMipMapCombo.Location = New-Object System.Drawing.Size(10, 48)
$C_DDSMipMapCombo.Items.Add('External') | Out-Null
$C_DDSMipMapCombo.Items.Add('Internal') | Out-Null
$C_DDSMipMapCombo.Items.Add('Both') | Out-Null
$C_DDSMipMapCombo.SelectedItem = $DDSMipMapType
$C_DDSMipMapCombo.Add_SelectedIndexChanged({GUI_UpdateComboBoxState})
$C_DDSMipMapCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$C_DDSMipMapCombo.Enabled = ($C_FormatCombo.SelectedItem -eq 'DDS')
$C_DDSMipMapLabel = New-Object System.Windows.Forms.Label
$C_DDSMipMapLabel.Size = New-Object System.Drawing.Size(100, 22)
$C_DDSMipMapLabel.Location = New-Object System.Drawing.Size(82, 50)
$C_DDSMipMapLabel.Text = 'DDS MipMap Type'
$C_DDSMipMapLabel.Enabled = ($C_FormatCombo.SelectedItem -eq 'DDS')
$ConvertGroup.Controls.Add($C_DDSMipMapCombo)
$ConvertGroup.Controls.Add($C_DDSMipMapLabel)
$C_DDSMipMapTip = New-Object System.Windows.Forms.ToolTip
$C_DDSMipMapTip.InitialDelay = $ToolTipDelay
$C_DDSMipMapTip.AutoPopDelay = $ToolTipDuration
$C_DDSMipMapTipString = 'Determines which types of mipmaps are generated for DDS textures.{0}'
$C_DDSMipMapTipString += '{0}'
$C_DDSMipMapTipString += 'External: These can be used with any version of Dolphin.{0}'
$C_DDSMipMapTipString += 'Internal: Can only be used by Dolphin Ishiiruka.{0}'
$C_DDSMipMapTipString += 'Both: Generate both types, but this takes lots of disk space.'
$C_DDSMipMapTipString = [String]::Format($C_DDSMipMapTipString, [Environment]::NewLine)
$C_DDSMipMapTip.SetToolTip($C_DDSMipMapLabel, $C_DDSMipMapTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Copy Non-Textures
$C_CopyNonCheck = New-Object System.Windows.Forms.CheckBox
$C_CopyNonCheck.Name = 'CopyNonTextures'
$C_CopyNonCheck.Size = New-Object System.Drawing.Size(130, 16)
$C_CopyNonCheck.Location = New-Object System.Drawing.Size(10, 77)
$C_CopyNonCheck.Checked = $CopyNonTextures
$C_CopyNonCheck.Text = ' Copy Non-Textures'
$C_CopyNonCheck.Add_CheckStateChanged({GUI_UpdateCheckBoxState})
$ConvertGroup.Controls.Add($C_CopyNonCheck)
$C_CopyNonTip = New-Object System.Windows.Forms.ToolTip
$C_CopyNonTip.InitialDelay = $ToolTipDelay
$C_CopyNonTip.AutoPopDelay = $ToolTipDuration
$C_CopyNonTipString = 'Copies files that are not images (such as .txt) into the newly generated pack.'
$C_CopyNonTip.SetToolTip($C_CopyNonCheck, $C_CopyNonTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Force New MipMaps
$C_ForceNewMipsCheck = New-Object System.Windows.Forms.CheckBox
$C_ForceNewMipsCheck.Name = 'ForceNewMipMaps'
$C_ForceNewMipsCheck.Size = New-Object System.Drawing.Size(130, 16)
$C_ForceNewMipsCheck.Location = New-Object System.Drawing.Size(10, 100)
$C_ForceNewMipsCheck.Checked = $ForceNewMipMaps
$C_ForceNewMipsCheck.Text = ' Force New MipMaps'
$C_ForceNewMipsCheck.Add_CheckStateChanged({GUI_UpdateCheckBoxState})
$ConvertGroup.Controls.Add($C_ForceNewMipsCheck)
$C_ForceNewMipsTip = New-Object System.Windows.Forms.ToolTip
$C_ForceNewMipsTip.InitialDelay = $ToolTipDelay
$C_ForceNewMipsTip.AutoPopDelay = $ToolTipDuration
$C_ForceNewMipsTipString = 'Forces the script to ignore included mipmaps and generate{0}'
$C_ForceNewMipsTipString += 'new ones from the base texture (top layer).'
$C_ForceNewMipsTipString = [String]::Format($C_ForceNewMipsTipString, [Environment]::NewLine)
$C_ForceNewMipsTip.SetToolTip($C_ForceNewMipsCheck, $C_ForceNewMipsTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Auto-Repair Dimensions
$C_AutoRepairCheck = New-Object System.Windows.Forms.CheckBox
$C_AutoRepairCheck.Name = 'ConvertRepair'
$C_AutoRepairCheck.Size = New-Object System.Drawing.Size(150, 16)
$C_AutoRepairCheck.Location = New-Object System.Drawing.Size(188, 24)
$C_AutoRepairCheck.Checked = $ConvertRepair
$C_AutoRepairCheck.Text = ' Auto-Repair Dimensions'
$C_AutoRepairCheck.Add_CheckStateChanged({GUI_UpdateCheckBoxState})
$ConvertGroup.Controls.Add($C_AutoRepairCheck)
$C_AutoRepairTip = New-Object System.Windows.Forms.ToolTip
$C_AutoRepairTip.InitialDelay = $ToolTipDelay
$C_AutoRepairTip.AutoPopDelay = $ToolTipDuration
$C_AutoRepairTipString = 'Attempts to repair textures with fractional scaling values. Enabling this option recalculates all dimensions{0}'
$C_AutoRepairTipString += 'by multiplying the original dimensions * lowest integer scale between width and height. Scale-Fix Threshold{0}'
$C_AutoRepairTipString += 'determines if this integer is rounded up or down based on the decimal value of the current scale.{0}'
$C_AutoRepairTipString += '{0}'
$C_AutoRepairTipString += 'Examples: {0}'
$C_AutoRepairTipString += 'Auto-Repair=True  Original=24x24 Custom=75x75 (scale 3.12) PNG-New=72x72 DDS-New=72x72 Correct=72x72{0}'
$C_AutoRepairTipString += 'Auto-Repair=False Original=24x24 Custom=75x75 (scale 3.12) PNG-New=75x75 DDS-New=76x76 Correct=72x72{0}'
$C_AutoRepairTipString += '{0}'
$C_AutoRepairTipString += 'Setting this option to "True" is useful to get the most accurate dimensions and fix bad scales/aspect ratios.{0}'
$C_AutoRepairTipString += 'Setting this option to "False" is useful when textures have very low scaling values or mismatched aspect ratios.'
$C_AutoRepairTipString = [String]::Format($C_AutoRepairTipString, [Environment]::NewLine)
$C_AutoRepairTip.SetToolTip($C_AutoRepairCheck, $C_AutoRepairTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Scale-Fix Threshold
$C_ScaleFixNumBox = New-Object System.Windows.Forms.NumericUpDown
$C_ScaleFixNumBox.Name = 'ScaleThreshold'
$C_ScaleFixNumBox.Size = New-Object System.Drawing.Size(70, 10)
$C_ScaleFixNumBox.Location = New-Object System.Drawing.Size(188, 48)
$C_ScaleFixNumBox.DecimalPlaces = 2
$C_ScaleFixNumBox.Value = $ScaleThreshold
$C_ScaleFixNumBox.Minimum = 0.00
$C_ScaleFixNumBox.Maximum = 0.99
$C_ScaleFixNumBox.Increment = 0.01
$C_ScaleFixNumBox.Add_ValueChanged({GUI_UpdateNumericUpDown 'decimal'})
$C_ScaleFixNumBox.Enabled = $ConvertRepair
$C_ScaleFixLabel = New-Object System.Windows.Forms.Label
$C_ScaleFixLabel.Size = New-Object System.Drawing.Size(108, 22)
$C_ScaleFixLabel.Location = New-Object System.Drawing.Size(260, 50)
$C_ScaleFixLabel.Text = 'Scale-Fix Threshold'
$C_ScaleFixLabel.Enabled = $ConvertRepair
$ConvertGroup.Controls.Add($C_ScaleFixNumBox)
$ConvertGroup.Controls.Add($C_ScaleFixLabel)
$ScanGroup.Controls.Add($S_ScaleFixNumBox)
$ScanGroup.Controls.Add($S_ScaleFixLabel)
$C_ScaleFixTip = New-Object System.Windows.Forms.ToolTip
$C_ScaleFixTip.InitialDelay = $ToolTipDelay
$C_ScaleFixTip.AutoPopDelay = $ToolTipDuration
$C_ScaleFixTipString = 'Sets the minimum decimal value of the scale to auto-repair{0}'
$C_ScaleFixTipString += 'textures to the next highest integer scale.{0}'
$C_ScaleFixTipString += '{0}'
$C_ScaleFixTipString += 'Example: Scale-Fix Threshold = 0.45 will upscale 4.45-4.99{0}'
$C_ScaleFixTipString += 'to 5x scale, but downscale 4.01-4.44 to 4x scale.'
$C_ScaleFixTipString = [String]::Format($C_ScaleFixTipString, [Environment]::NewLine)
$C_ScaleFixTip.SetToolTip($C_ScaleFixLabel, $C_ScaleFixTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Auto-Rename Output Pack
$global:ConvertAutoText = ''
$C_AutoNameTextBox = New-Object System.Windows.Forms.TextBox
$C_AutoNameTextBox.Name = 'ConvertAutoText'
$C_AutoNameTextBox.Size = New-Object System.Drawing.Size(150, 20)
$C_AutoNameTextBox.Location = New-Object System.Drawing.Size(188, 90)
$C_AutoNameTextBox.Text = ''
$C_AutoNameTextBox.Add_Leave({GUI_VerifyAutoNameText})
$C_AutoNameLabel = New-Object System.Windows.Forms.Label
$C_AutoNameLabel.Size = New-Object System.Drawing.Size(140, 22)
$C_AutoNameLabel.Location = New-Object System.Drawing.Size(188, 76)
$C_AutoNameLabel.Text = 'Auto-Rename Output:'
$ConvertGroup.Controls.Add($C_AutoNameTextBox)
$ConvertGroup.Controls.Add($C_AutoNameLabel)
$C_AutoNameTip = New-Object System.Windows.Forms.ToolTip
$C_AutoNameTip.InitialDelay = $ToolTipDelay
$C_AutoNameTip.AutoPopDelay = $ToolTipDuration
$C_AutoNameTipString = 'Automatically renames the "ConvertedTextures" folder to the specified text{0}'
$C_AutoNameTipString += 'entered here. If no value is entered, the folder will not be renamed. This{0}'
$C_AutoNameTipString += "should usually be the first 3 letters of the texture pack's GameID."
$C_AutoNameTipString = [String]::Format($C_AutoNameTipString, [Environment]::NewLine)
$C_AutoNameTip.SetToolTip($C_AutoNameLabel, $C_AutoNameTipString)
#==============================================================================================================================================================================================
# Create Option 4: Material Textures
#==============================================================================================================================================================================================
$MaterialGroup = New-Object System.Windows.Forms.GroupBox
$MaterialGroup.Location = New-Object System.Drawing.Size(10, 260)
$MaterialGroup.Size = New-Object System.Drawing.Size(380, 124)
$MaterialGroup.Text = ' Ishiiruka Tool Options '
$Dialog.Controls.Add($MaterialGroup)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Material Output Format
$M_FormatCombo = New-Object System.Windows.Forms.ComboBox
$M_FormatCombo.Name = 'IshiirukaFormat'
$M_FormatCombo.Size = New-Object System.Drawing.Size(70, 10)
$M_FormatCombo.Location = New-Object System.Drawing.Size(10, 20)
$M_FormatCombo.Items.Add('PNG') | Out-Null
$M_FormatCombo.Items.Add('DDS') | Out-Null
$M_FormatCombo.SelectedItem = ExtensionToText $IshiirukaFormat
$M_FormatCombo.Add_SelectedIndexChanged({GUI_UpdateComboBoxState})
$M_FormatCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$M_FormatLabel = New-Object System.Windows.Forms.Label
$M_FormatLabel.Size = New-Object System.Drawing.Size(100, 22)
$M_FormatLabel.Location = New-Object System.Drawing.Size(84, 23)
$M_FormatLabel.Text = 'Output Format'
$MaterialGroup.Controls.Add($M_FormatCombo)
$MaterialGroup.Controls.Add($M_FormatLabel)
$M_FormatTip = New-Object System.Windows.Forms.ToolTip
$M_FormatTip.InitialDelay = $ToolTipDelay
$M_FormatTip.AutoPopDelay = $ToolTipDuration
$M_FormatTipString = 'The output format that textures and material maps will be created. Requires Ishiiruka Tool.'
$M_FormatTip.SetToolTip($M_FormatLabel, $M_FormatTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Because the warning label variable is not yet declared, toggle it in a function.
function GUI_MaterialWarningToggle()
{
  $M_InPlaceWarning.Visible = $this.Checked
}
#----------------------------------------------------------------------------------------------------------------------------------------------
# Create In-Place
$M_InPlaceCheck = New-Object System.Windows.Forms.CheckBox
$M_InPlaceCheck.Name = 'InPlaceMaterial'
$M_InPlaceCheck.Size = New-Object System.Drawing.Size(170, 16)
$M_InPlaceCheck.Location = New-Object System.Drawing.Size(190, 22)
$M_InPlaceCheck.Checked = $InPlaceMaterial
$M_InPlaceCheck.Text = ' Create Materials In-Place'
$M_InPlaceCheck.Add_CheckStateChanged({GUI_UpdateCheckBoxState ; GUI_MaterialWarningToggle})
$MaterialGroup.Controls.Add($M_InPlaceCheck)
$M_InPlaceTip = New-Object System.Windows.Forms.ToolTip
$M_InPlaceTip.InitialDelay = $ToolTipDelay
$M_InPlaceTip.AutoPopDelay = $ToolTipDuration
$M_InPlaceTipString = 'Creates materials within the texture pack itself rather than the{0}'
$M_InPlaceTipString += 'selected output folder, but removes the bump/spec/lum/nrm textures.'
$M_InPlaceTipString = [String]::Format($M_InPlaceTipString, [Environment]::NewLine)
$M_InPlaceTip.SetToolTip($M_InPlaceCheck, $M_InPlaceTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# In-Place Warning Label
$M_InPlaceWarning = New-Object System.Windows.Forms.Label
$M_InPlaceWarning.Size = New-Object System.Drawing.Size(360, 60)
$M_InPlaceWarning.Location = New-Object System.Drawing.Size(10, 58)
$M_InPlaceWarningText = 'Warning: This option will create a combined material from any bump/spec/lum/nrm textures that are found, but it will destroy them in '
$M_InPlaceWarningText += 'the process and replace them with the generated (.nrm) texture. If these textures are to be kept, then disable "Create Materials In-Place".'
$M_InPlaceWarning.Text = $M_InPlaceWarningText
$M_InPlaceWarning.ForeColor = '#901616'
$M_InPlaceWarning.Visible = $InPlaceMaterial
$MaterialGroup.Controls.Add($M_InPlaceWarning)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Create Option 5: Watermark Textures
#----------------------------------------------------------------------------------------------------------------------------------------------
$WatermarkGroup = New-Object System.Windows.Forms.GroupBox
$WatermarkGroup.Size = New-Object System.Drawing.Size(380, 124)
$WatermarkGroup.Location = New-Object System.Drawing.Size(10, 260)
$WatermarkGroup.Text = ' Watermark Options '
$Dialog.Controls.Add($WatermarkGroup)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Text Length
$W_TextLengthNumBox = New-Object System.Windows.Forms.NumericUpDown
$W_TextLengthNumBox.Name = 'WM_Length'
$W_TextLengthNumBox.Size = New-Object System.Drawing.Size(82, 10)
$W_TextLengthNumBox.Location = New-Object System.Drawing.Size(10, 20)
$W_TextLengthNumBox.DecimalPlaces = 0
$W_TextLengthNumBox.Value = $WM_Length
$W_TextLengthNumBox.Minimum = 0
$W_TextLengthNumBox.Maximum = 22
$W_TextLengthNumBox.Increment = 1
$W_TextLengthNumBox.Add_ValueChanged({GUI_UpdateNumericUpDown 'integer'})
$W_TextLengthLabel = New-Object System.Windows.Forms.Label
$W_TextLengthLabel.Size = New-Object System.Drawing.Size(70, 22)
$W_TextLengthLabel.Location = New-Object System.Drawing.Size(93, 22)
$W_TextLengthLabel.Text = 'Text Length'
$WatermarkGroup.Controls.Add($W_TextLengthNumBox)
$WatermarkGroup.Controls.Add($W_TextLengthLabel)
$W_TextLengthTip = New-Object System.Windows.Forms.ToolTip
$W_TextLengthTip.InitialDelay = $ToolTipDelay
$W_TextLengthTip.AutoPopDelay = $ToolTipDuration
$W_TextLengthTipString = 'Defines how many characters to pull from the end of the texture{0}'
$W_TextLengthTipString += 'name to display on the texture as a watermark. If a value of 0 is{0}'
$W_TextLengthTipString += 'entered, then the script will use the entire name of the texture. If{0}'
$W_TextLengthTipString += 'a value of 1-5 is entered, than a value of 6 will be forced internally.'
$W_TextLengthTipString = [String]::Format($W_TextLengthTipString, [Environment]::NewLine)
$W_TextLengthTip.SetToolTip($W_TextLengthLabel, $W_TextLengthTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Font Size
$W_FontSizeNumBox = New-Object System.Windows.Forms.NumericUpDown
$W_FontSizeNumBox.Name = 'WM_FontSize'
$W_FontSizeNumBox.Size = New-Object System.Drawing.Size(82, 10)
$W_FontSizeNumBox.Location = New-Object System.Drawing.Size(10, 44)
$W_FontSizeNumBox.DecimalPlaces = 0
$W_FontSizeNumBox.Value = $WM_FontSize
$W_FontSizeNumBox.Minimum = 1
$W_FontSizeNumBox.Maximum = 20
$W_FontSizeNumBox.Increment = 1
$W_FontSizeNumBox.Add_ValueChanged({GUI_UpdateNumericUpDown 'integer'})
$W_FontSizeLabel = New-Object System.Windows.Forms.Label
$W_FontSizeLabel.Size = New-Object System.Drawing.Size(60, 22)
$W_FontSizeLabel.Location = New-Object System.Drawing.Size(93, 47)
$W_FontSizeLabel.Text = 'Font Size'
$WatermarkGroup.Controls.Add($W_FontSizeNumBox)
$WatermarkGroup.Controls.Add($W_FontSizeLabel)
$W_FontSizeTip = New-Object System.Windows.Forms.ToolTip
$W_FontSizeTip.InitialDelay = $ToolTipDelay
$W_FontSizeTip.AutoPopDelay = $ToolTipDuration
$W_FontSizeTipString = 'Defines the size of the font that will be used for the watermark. This{0}'
$W_FontSizeTipString += 'is not the fonts actual size, it is instead a multiplier used to scale the{0}'
$W_FontSizeTipString += 'font using the formula (NewWidth / 128 * FontSize). This ensures{0}'
$W_FontSizeTipString += 'that the font remains a constant size across all textures.'
$W_FontSizeTipString = [String]::Format($W_FontSizeTipString, [Environment]::NewLine)
$W_FontSizeTip.SetToolTip($W_FontSizeLabel, $W_FontSizeTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Font FG Color
$W_FGColorButton = New-Object System.Windows.Forms.Button
$W_FGColorButton.Name = 'WM_FontColor'
$W_FGColorButton.Size = New-Object System.Drawing.Size(80, 22)
$W_FGColorButton.Location = New-Object System.Drawing.Size(10, 68)
$W_FGColorButton.Text = $WM_FontColor
$W_FGColorButton.BackColor = $WM_FontColor
$W_FGColorButton.Add_Click({GUI_ShowColorDialog})
$W_FGColorLabel = New-Object System.Windows.Forms.Label
$W_FGColorLabel.Size = New-Object System.Drawing.Size(108, 22)
$W_FGColorLabel.Location = New-Object System.Drawing.Size(93, 72)
$W_FGColorLabel.Text = 'Font FG Color'
$WatermarkGroup.Controls.Add($W_FGColorButton)
$WatermarkGroup.Controls.Add($W_FGColorLabel)
$W_FGColorTip = New-Object System.Windows.Forms.ToolTip
$W_FGColorTip.InitialDelay = $ToolTipDelay
$W_FGColorTip.AutoPopDelay = $ToolTipDuration
$W_FGColorTipString = 'Defines the color of the font used for the watermark.'
$W_FGColorTip.SetToolTip($W_FGColorLabel, $W_FGColorTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Font BG Color
$W_BGColorButton = New-Object System.Windows.Forms.Button
$W_BGColorButton.Name = 'WM_BGColor'
$W_BGColorButton.Size = New-Object System.Drawing.Size(80, 22)
$W_BGColorButton.Location = New-Object System.Drawing.Size(10, 94)
$W_BGColorButton.Text = $WM_BGColor
$W_BGColorButton.BackColor = $WM_BGColor
$W_BGColorButton.Add_Click({GUI_ShowColorDialog})
$W_BGColorLabel = New-Object System.Windows.Forms.Label
$W_BGColorLabel.Size = New-Object System.Drawing.Size(108, 20)
$W_BGColorLabel.Location = New-Object System.Drawing.Size(93, 98)
$W_BGColorLabel.Text = 'Font BG Color'
$WatermarkGroup.Controls.Add($W_BGColorButton)
$WatermarkGroup.Controls.Add($W_BGColorLabel)
$W_BGColorTip = New-Object System.Windows.Forms.ToolTip
$W_BGColorTip.InitialDelay = $ToolTipDelay
$W_BGColorTip.AutoPopDelay = $ToolTipDuration
$W_BGColorTipString = 'Defines the color of the background that surrounds the font used for the watermark.'
$W_BGColorTip.SetToolTip($W_BGColorLabel, $W_BGColorTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Font Face
$W_FontFaceCombo = New-Object System.Windows.Forms.ComboBox
$W_FontFaceCombo.Name = 'WM_FontFace'
$W_FontFaceCombo.Size = New-Object System.Drawing.Size(120, 10)
$W_FontFaceCombo.Location = New-Object System.Drawing.Size(184, 20)
$W_FontFaceCombo.Items.Add('Arial-Bold') | Out-Null
$W_FontFaceCombo.Items.Add('Comic-Sans-MS-Bold') | Out-Null
$W_FontFaceCombo.Items.Add('Courier-New-Bold') | Out-Null
$W_FontFaceCombo.Items.Add('Georgia-Bold') | Out-Null
$W_FontFaceCombo.Items.Add('Lucida-Console') | Out-Null
$W_FontFaceCombo.Items.Add('Sylfaen') | Out-Null
$W_FontFaceCombo.Items.Add('Times-New-Roman-Bold') | Out-Null
$W_FontFaceCombo.Items.Add('Trebuchet-MS-Bold') | Out-Null
$W_FontFaceCombo.Items.Add('Verdana-Bold') | Out-Null 
$W_FontFaceCombo.SelectedItem = $WM_FontFace
$W_FontFaceCombo.Add_SelectedIndexChanged({GUI_UpdateComboBoxState})
$W_FontFaceCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$W_FontFaceLabel = New-Object System.Windows.Forms.Label
$W_FontFaceLabel.Size = New-Object System.Drawing.Size(60, 22)
$W_FontFaceLabel.Location = New-Object System.Drawing.Size(306, 22)
$W_FontFaceLabel.Text = 'Font Face'
$WatermarkGroup.Controls.Add($W_FontFaceCombo)
$WatermarkGroup.Controls.Add($W_FontFaceLabel)
$W_FontFaceTip = New-Object System.Windows.Forms.ToolTip
$W_FontFaceTip.InitialDelay = $ToolTipDelay
$W_FontFaceTip.AutoPopDelay = $ToolTipDuration
$W_FontFaceTipString = 'Defines the font that will be used for the texture watermark.'
$W_FontFaceTip.SetToolTip($W_FontFaceLabel, $W_FontFaceTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Word Wrap
$W_WordWrapCheck = New-Object System.Windows.Forms.CheckBox
$W_WordWrapCheck.Name = 'WM_WordWrap'
$W_WordWrapCheck.Size = New-Object System.Drawing.Size(120, 16)
$W_WordWrapCheck.Location = New-Object System.Drawing.Size(184, 48)
$W_WordWrapCheck.Checked = $WM_WordWrap
$W_WordWrapCheck.Text = 'Word Wrap'
$W_WordWrapCheck.Add_CheckStateChanged({GUI_UpdateCheckBoxState})
$WatermarkGroup.Controls.Add($W_WordWrapCheck)
$W_WordWrapTip = New-Object System.Windows.Forms.ToolTip
$W_WordWrapTip.InitialDelay = $ToolTipDelay
$W_WordWrapTip.AutoPopDelay = $ToolTipDuration
$W_WordWrapTipString = 'If the watermark is too long to scale to the texture, this option{0}'
$W_WordWrapTipString += 'creates a new line for the texture name. This makes sure the{0}'
$W_WordWrapTipString += 'watermark is fully contained and does not run off the edges.'
$W_WordWrapTipString = [String]::Format($W_WordWrapTipString, [Environment]::NewLine)
$W_WordWrapTip.SetToolTip($W_WordWrapCheck, $W_WordWrapTipString)
#==============================================================================================================================================================================================
# Create Option 6: OptiPNG Textures
#==============================================================================================================================================================================================
$OptiPNGGroup = New-Object System.Windows.Forms.GroupBox
$OptiPNGGroup.Size = New-Object System.Drawing.Size(380, 124)
$OptiPNGGroup.Location = New-Object System.Drawing.Size(10, 260)
$OptiPNGGroup.Text = ' OptiPNG Options '
$Dialog.Controls.Add($OptiPNGGroup)
#----------------------------------------------------------------------------------------------------------------------------------------------
# OptiPNG Tests
$O_TestsNumBox = New-Object System.Windows.Forms.NumericUpDown
$O_TestsNumBox.Name = 'OptiPNGTests'
$O_TestsNumBox.Size = New-Object System.Drawing.Size(70, 10)
$O_TestsNumBox.Location = New-Object System.Drawing.Size(10, 20)
$O_TestsNumBox.DecimalPlaces = 0
$O_TestsNumBox.Value = $OptiPNGTests
$O_TestsNumBox.Minimum = 1
$O_TestsNumBox.Maximum = 20
$O_TestsNumBox.Increment = 1
$O_TestsNumBox.Add_ValueChanged({GUI_UpdateNumericUpDown 'integer'})
$O_TestsLabel = New-Object System.Windows.Forms.Label
$O_TestsLabel.Size = New-Object System.Drawing.Size(100, 22)
$O_TestsLabel.Location = New-Object System.Drawing.Size(84, 23)
$O_TestsLabel.Text = 'Tests Performed'
$OptiPNGGroup.Controls.Add($O_TestsNumBox)
$OptiPNGGroup.Controls.Add($O_TestsLabel)
$O_TestsTip = New-Object System.Windows.Forms.ToolTip
$O_TestsTip.InitialDelay = $ToolTipDelay
$O_TestsTip.AutoPopDelay = $ToolTipDuration
$O_TestsTipString = 'Sets the number of tests that OptiPNG runs on textures in an attempt{0}'
$O_TestsTipString += 'to optimize them. The more tests that are ran, the higher the chance{0}'
$O_TestsTipString += 'of getting a smaller texture. But each test will significanly increase the{0}'
$O_TestsTipString += 'time it takes for OptiPNG to optimize a texture. It is not suggested to{0}'
$O_TestsTipString += 'go above 3 tests which is usually overkill in itself.'
$O_TestsTipString = [String]::Format($O_TestsTipString, [Environment]::NewLine)
$O_TestsTip.SetToolTip($O_TestsLabel, $O_TestsTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Create In-Place
$O_InPlaceCheck = New-Object System.Windows.Forms.CheckBox
$O_InPlaceCheck.Name = 'InPlaceOptiPNG'
$O_InPlaceCheck.Size = New-Object System.Drawing.Size(170, 16)
$O_InPlaceCheck.Location = New-Object System.Drawing.Size(190, 22)
$O_InPlaceCheck.Checked = $InPlaceOptiPNG
$O_InPlaceCheck.Text = ' Optimize Textures In-Place'
$O_InPlaceCheck.Add_CheckStateChanged({GUI_UpdateCheckBoxState})
$OptiPNGGroup.Controls.Add($O_InPlaceCheck)
$O_InPlaceTip = New-Object System.Windows.Forms.ToolTip
$O_InPlaceTip.InitialDelay = $ToolTipDelay
$O_InPlaceTip.AutoPopDelay = $ToolTipDuration
$O_InPlaceTipString = 'Overwrites the old texture with the optimized texture within the{0}'
$O_InPlaceTipString += 'texture pack rather than recreate it within the "OptimizedTextures"{0}'
$O_InPlaceTipString += 'output folder. This option is safe to use freely.'
$O_InPlaceTipString = [String]::Format($O_InPlaceTipString, [Environment]::NewLine)
$O_InPlaceTip.SetToolTip($O_InPlaceCheck, $O_InPlaceTipString)
#==============================================================================================================================================================================================
# Create Option 7: Upscale Filter
#==============================================================================================================================================================================================
$UpscaleFilterGroup = New-Object System.Windows.Forms.GroupBox
$UpscaleFilterGroup.Size = New-Object System.Drawing.Size(380, 124)
$UpscaleFilterGroup.Location = New-Object System.Drawing.Size(10, 260)
$UpscaleFilterGroup.Text = ' Upscale Filter Options '
$Dialog.Controls.Add($UpscaleFilterGroup)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Applied Upscaling Filter
$U_FilterCombo = New-Object System.Windows.Forms.ComboBox
$U_FilterCombo.Name = 'FilterSelected'
$U_FilterCombo.Size = New-Object System.Drawing.Size(72, 10)
$U_FilterCombo.Location = New-Object System.Drawing.Size(10, 20)
$U_FilterCombo.Items.Add('xBRZ') | Out-Null
$U_FilterCombo.Items.Add('Waifu2x') | Out-Null
$U_FilterCombo.Items.Add('Point') | Out-Null
$U_FilterCombo.Items.Add('Cubic') | Out-Null
$U_FilterCombo.Items.Add('Lancoz') | Out-Null
$U_FilterCombo.SelectedItem = $FilterSelected
$U_FilterCombo.Add_SelectedIndexChanged({GUI_UpdateFilterComboBoxState})
$U_FilterCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$U_FilterLabel = New-Object System.Windows.Forms.Label
$U_FilterLabel.Size = New-Object System.Drawing.Size(96, 22)
$U_FilterLabel.Location = New-Object System.Drawing.Size(84, 22)
$U_FilterLabel.Text = 'Upscale Filter'
$UpscaleFilterGroup.Controls.Add($U_FilterCombo)
$UpscaleFilterGroup.Controls.Add($U_FilterLabel)
$U_FilterTip = New-Object System.Windows.Forms.ToolTip
$U_FilterTip.InitialDelay = $ToolTipDelay
$U_FilterTip.AutoPopDelay = $ToolTipDuration
$U_FilterTipString = 'Sets the upscaling filter that will be applied to all textures. {0}'
$U_FilterTipString += '{0}'
$U_FilterTipString += 'xBRZ and Waifu2x require a proper path set to these tools in the Options panel.'
$U_FilterTipString = [String]::Format($U_FilterTipString, [Environment]::NewLine)
$U_FilterTip.SetToolTip($U_FilterLabel, $U_FilterTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Upscale Factor
$U_FactorNumBox = New-Object System.Windows.Forms.NumericUpDown
$U_FactorNumBox.Name = 'FilterNewScale'
$U_FactorNumBox.Size = New-Object System.Drawing.Size(72, 10)
$U_FactorNumBox.Location = New-Object System.Drawing.Size(10, 44)
$U_FactorNumBox.DecimalPlaces = 0
$U_FactorNumBox.Value = $FilterNewScale
$U_FactorNumBox.Minimum = 2
if ($FilterSelected -eq 'xBRZ') { $U_FactorNumBox.Maximum = 6 }
else { $U_FactorNumBox.Maximum = 8 }
$U_FactorNumBox.Increment = 1
$U_FactorNumBox.Add_ValueChanged({GUI_UpdateNumericUpDown 'integer'})
$U_FactorLabel = New-Object System.Windows.Forms.Label
$U_FactorLabel.Size = New-Object System.Drawing.Size(96, 22)
$U_FactorLabel.Location = New-Object System.Drawing.Size(84, 47)
$U_FactorLabel.Text = 'Upscale Factor'
$UpscaleFilterGroup.Controls.Add($U_FactorNumBox)
$UpscaleFilterGroup.Controls.Add($U_FactorLabel)
$U_FactorTip = New-Object System.Windows.Forms.ToolTip
$U_FactorTip.InitialDelay = $ToolTipDelay
$U_FactorTip.AutoPopDelay = $ToolTipDuration
$U_FactorTipString = 'The factor to upscale the image. The resulting image size is the product{0}'
$U_FactorTipString += 'of (Dimensions * Upscale Factor). Most filters will allow a maximum value{0}'
$U_FactorTipString += 'of 8, except xBRZ which only allows a maximum upscale value of 6.'
$U_FactorTipString = [String]::Format($U_FactorTipString, [Environment]::NewLine)
$U_FactorTip.SetToolTip($U_FactorLabel, $U_FactorTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Seamless Method
$U_SeamlessCombo = New-Object System.Windows.Forms.ComboBox
$U_SeamlessCombo.Name = 'SeamlessMethod'
$U_SeamlessCombo.Size = New-Object System.Drawing.Size(72, 10)
$U_SeamlessCombo.Location = New-Object System.Drawing.Size(10, 68)
$U_SeamlessCombo.Items.Add('Opaque') | Out-Null
$U_SeamlessCombo.Items.Add('All') | Out-Null
$U_SeamlessCombo.Items.Add('Disable') | Out-Null
$U_SeamlessCombo.SelectedItem = $SeamlessMethod
$U_SeamlessCombo.Add_SelectedIndexChanged({GUI_UpdateComboBoxState})
$U_SeamlessCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$U_SeamlessLabel = New-Object System.Windows.Forms.Label
$U_SeamlessLabel.Size = New-Object System.Drawing.Size(96, 22)
$U_SeamlessLabel.Location = New-Object System.Drawing.Size(84, 71)
$U_SeamlessLabel.Text = 'Seamless Method'
$UpscaleFilterGroup.Controls.Add($U_SeamlessCombo)
$UpscaleFilterGroup.Controls.Add($U_SeamlessLabel)
$U_SeamlessTip = New-Object System.Windows.Forms.ToolTip
$U_SeamlessTip.InitialDelay = $ToolTipDelay
$U_SeamlessTip.AutoPopDelay = $ToolTipDuration
$U_SeamlessTipString = 'It should be noted that this option will not break non-seamless textures in{0}'
$U_SeamlessTipString += 'any way, but does have the possiblity to slow down the conversion.{0}'
$U_SeamlessTipString += '{0}'
$U_SeamlessTipString += 'The "Seamless Method" is a technique that involves tiling a texture 9 times{0}'
$U_SeamlessTipString += 'in a 3x3 grid, then applies the selected upscaling filter to the tiled texture.{0}'
$U_SeamlessTipString += 'After the tiled texture is filtered, the outer 8 tiles are cropped away. This{0}'
$U_SeamlessTipString += 'prevents the resulting texture from creating visible seams when it is tiled{0}'
$U_SeamlessTipString += 'in-game because it gives the upscaling filter neighboring pixels to work with{0}'
$U_SeamlessTipString += 'along the edges of the texture.{0}'
$U_SeamlessTipString += '{0}'
$U_SeamlessTipString += 'This option is only useful for seamless textures, as it adds processing time{0}'
$U_SeamlessTipString += 'when upscaling the texture. The outer tiles have some percentage cropped{0}'
$U_SeamlessTipString += 'to increase the speed which is configurable below this option. Most textures{0}'
$U_SeamlessTipString += 'that are seamless have no transparent pixels, but this is not always true so{0}'
$U_SeamlessTipString += 'when to apply this method is configurable.{0}'
$U_SeamlessTipString += '{0}'
$U_SeamlessTipString += 'Opaque: Only apply this method to textures that have no transparent pixels.{0}'
$U_SeamlessTipString += 'All: Apply this method to all textures even if they have transparent pixels.{0}'
$U_SeamlessTipString += 'Disable: Do not apply the seamless method to any textures.'
$U_SeamlessTipString = [String]::Format($U_SeamlessTipString, [Environment]::NewLine)
$U_SeamlessTip.SetToolTip($U_SeamlessLabel, $U_SeamlessTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Seamless Crop %
$U_SeamlessCropNumBox = New-Object System.Windows.Forms.NumericUpDown
$U_SeamlessCropNumBox.Name = 'SeamlessFactor'
$U_SeamlessCropNumBox.Size = New-Object System.Drawing.Size(72, 10)
$U_SeamlessCropNumBox.Location = New-Object System.Drawing.Size(10, 93)
$U_SeamlessCropNumBox.DecimalPlaces = 2
$U_SeamlessCropNumBox.Value = $SeamlessFactor
$U_SeamlessCropNumBox.Minimum = 0.00
$U_SeamlessCropNumBox.Maximum = 0.99
$U_SeamlessCropNumBox.Increment = 0.01
$U_SeamlessCropNumBox.Add_ValueChanged({GUI_UpdateNumericUpDown 'decimal'})
$U_SeamlessCropLabel = New-Object System.Windows.Forms.Label
$U_SeamlessCropLabel.Size = New-Object System.Drawing.Size(96, 22)
$U_SeamlessCropLabel.Location = New-Object System.Drawing.Size(84, 96)
$U_SeamlessCropLabel.Text = 'Seamless Crop %'
$UpscaleFilterGroup.Controls.Add($U_SeamlessCropNumBox)
$UpscaleFilterGroup.Controls.Add($U_SeamlessCropLabel)
$U_SeamlessCropTip = New-Object System.Windows.Forms.ToolTip
$U_SeamlessCropTip.InitialDelay = $ToolTipDelay
$U_SeamlessCropTip.AutoPopDelay = $ToolTipDuration
$U_SeamlessCropTipString = 'The seamless method involves tiling the texture 9 times, then applies the upscaling{0}'
$U_SeamlessCropTipString += 'filter to the texture. This will increase the amount of time it takes to process the{0}'
$U_SeamlessCropTipString += 'texture. To reduce processing time, the outer 8 tiles are cropped before applying the{0}'
$U_SeamlessCropTipString += 'upscaling filter. The % value entered here determines how much of the outer tiles are{0}'
$U_SeamlessCropTipString += 'removed. After the image is upscaled, the rest of the outer tiles are removed so only{0}'
$U_SeamlessCropTipString += 'the resulting texture remains.{0}'
$U_SeamlessCropTipString += '{0}'
$U_SeamlessCropTipString += 'The lower this value is, the more pixels the upscaler has to work with. Lower values{0}'
$U_SeamlessCropTipString += 'can give better results, but the amount of processing time is increased. Higher values{0}'
$U_SeamlessCropTipString += 'reduce the processing time, but too high of a value can defeat the purpose of the{0}'
$U_SeamlessCropTipString += 'seamless method altogether. Lower values may be useful for smaller textures. Higher{0}'
$U_SeamlessCropTipString += 'values can be useful for very large textures. A value of around 75% should handle{0}'
$U_SeamlessCropTipString += 'just about any size texture.'
$U_SeamlessCropTipString = [String]::Format($U_SeamlessCropTipString, [Environment]::NewLine)
$U_SeamlessCropTip.SetToolTip($U_SeamlessCropLabel, $U_SeamlessCropTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Waifu2x Conversion Mode
$U_WF2XModeCombo = New-Object System.Windows.Forms.ComboBox
$U_WF2XModeCombo.Name = 'Waifu2xCMode'
$U_WF2XModeCombo.Size = New-Object System.Drawing.Size(94, 10)
$U_WF2XModeCombo.Location = New-Object System.Drawing.Size(182, 20)
$U_WF2XModeCombo.Items.Add('Scale') | Out-Null
$U_WF2XModeCombo.Items.Add('Noise') | Out-Null
$U_WF2XModeCombo.Items.Add('Noise_Scale') | Out-Null
$U_WF2XModeCombo.SelectedItem = $Waifu2xCMode
$U_WF2XModeCombo.Add_SelectedIndexChanged({GUI_UpdateComboBoxState})
$U_WF2XModeCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$U_WF2XModeLabel = New-Object System.Windows.Forms.Label
$U_WF2XModeLabel.Size = New-Object System.Drawing.Size(96, 22)
$U_WF2XModeLabel.Location = New-Object System.Drawing.Size(278, 22)
$U_WF2XModeLabel.Text = 'Conversion Mode'
$UpscaleFilterGroup.Controls.Add($U_WF2XModeCombo)
$UpscaleFilterGroup.Controls.Add($U_WF2XModeLabel)
$U_WF2XModeTip = New-Object System.Windows.Forms.ToolTip
$U_WF2XModeTip.InitialDelay = $ToolTipDelay
$U_WF2XModeTip.AutoPopDelay = $ToolTipDuration
$U_WF2XModeTipString = 'This option tells waifu2x when to upscale and when to apply noise reduction. {0}'
$U_WF2XModeTipString += '{0}'
$U_WF2XModeTipString += 'Scale: Upscale the image, but do not apply noise reduction. {0}'
$U_WF2XModeTipString += 'Noise: Apply noise reduction, but do not upscale the image. {0}'
$U_WF2XModeTipString += 'Noise-Scale: Upscale and apply noise reduction to the image. {0}'
$U_WF2XModeTipString += '{0}'
$U_WF2XModeTipString += 'Upscale Factor/Noise Reduction only work in the respective modes.'
$U_WF2XModeTipString = [String]::Format($U_WF2XModeTipString, [Environment]::NewLine)
$U_WF2XModeTip.SetToolTip($U_WF2XModeLabel, $U_WF2XModeTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Waifu2x Noise Reduction
$U_WF2XNoiseBox = New-Object System.Windows.Forms.NumericUpDown
$U_WF2XNoiseBox.Name = 'Waifu2xNoise'
$U_WF2XNoiseBox.Size = New-Object System.Drawing.Size(94, 10)
$U_WF2XNoiseBox.Location = New-Object System.Drawing.Size(182, 44)
$U_WF2XNoiseBox.DecimalPlaces = 0
$U_WF2XNoiseBox.Value = $Waifu2xNoise
$U_WF2XNoiseBox.Minimum = 1
if ($Waifu2xApp -eq 'waifu2x-caffe-cui.exe') { $U_WF2XNoiseBox.Maximum = 3 }
else { $U_WF2XNoiseBox.Maximum = 2 }
$U_WF2XNoiseBox.Increment = 1
$U_WF2XNoiseBox.Add_ValueChanged({GUI_UpdateNumericUpDown 'integer'})
$U_WF2XNoiseLabel = New-Object System.Windows.Forms.Label
$U_WF2XNoiseLabel.Size = New-Object System.Drawing.Size(94, 22)
$U_WF2XNoiseLabel.Location = New-Object System.Drawing.Size(278, 47)
$U_WF2XNoiseLabel.Text = 'Noise Reduction'
$UpscaleFilterGroup.Controls.Add($U_WF2XNoiseBox)
$UpscaleFilterGroup.Controls.Add($U_WF2XNoiseLabel)
$U_WF2XNoiseTip = New-Object System.Windows.Forms.ToolTip
$U_WF2XNoiseTip.InitialDelay = $ToolTipDelay
$U_WF2XNoiseTip.AutoPopDelay = $ToolTipDuration
$U_WF2XNoiseTipString = 'The amount of noise reduction to apply to the image. The higher the value, the{0}'
$U_WF2XNoiseTipString += 'smoother the resulting image will be. Waifu2x-CPP only supports a value up to 2,{0}'
$U_WF2XNoiseTipString += 'while Waifu2x-Caffe supports a value of 3. If 3 is selected when using this with{0}'
$U_WF2XNoiseTipString += 'Waifu2x-CPP, it will automatically set the value back to 2 before processing the{0}'
$U_WF2XNoiseTipString += 'textures. This option has no effect when the "Conversion Mode" is set to "Scale".'
$U_WF2XNoiseTipString = [String]::Format($U_WF2XNoiseTipString, [Environment]::NewLine)
$U_WF2XNoiseTip.SetToolTip($U_WF2XNoiseLabel, $U_WF2XNoiseTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Waifu2x Upscale Model (Caffe Only)
$U_WF2XModelCombo = New-Object System.Windows.Forms.ComboBox
$U_WF2XModelCombo.Name = 'Waifu2xModel'
$U_WF2XModelCombo.Size = New-Object System.Drawing.Size(94, 10)
$U_WF2XModelCombo.Location = New-Object System.Drawing.Size(182, 96)
$U_WF2XModelCombo.Items.Add('2D Illust (RGB)') | Out-Null
$U_WF2XModelCombo.Items.Add('2D Illust (UpRGB)') | Out-Null
$U_WF2XModelCombo.Items.Add('2D Illust (Y)') | Out-Null
$U_WF2XModelCombo.Items.Add('Photo (Standard)') | Out-Null
$U_WF2XModelCombo.Items.Add('Photo (UpPhoto)') | Out-Null
$U_WF2XModelCombo.Items.Add('Photo (UKBench)') | Out-Null
$U_WF2XModelCombo.SelectedItem = GUI_TranslateWaifu2xModel $Waifu2xModel 'B'
$U_WF2XModelCombo.Add_SelectedIndexChanged({GUI_UpdateComboBoxState})
$U_WF2XModelCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$U_WF2XModelLabel = New-Object System.Windows.Forms.Label
$U_WF2XModelLabel.Size = New-Object System.Drawing.Size(94, 22)
$U_WF2XModelLabel.Location = New-Object System.Drawing.Size(278, 98)
$U_WF2XModelLabel.Text = 'Upscale Model'
$UpscaleFilterGroup.Controls.Add($U_WF2XModelCombo)
$UpscaleFilterGroup.Controls.Add($U_WF2XModelLabel)
$U_WF2XModelTip = New-Object System.Windows.Forms.ToolTip
$U_WF2XModelTip.InitialDelay = $ToolTipDelay
$U_WF2XModelTip.AutoPopDelay = $ToolTipDuration
$U_WF2XModelTipString = 'Allows selecting the model that waifu2x-Caffe uses. The names{0}'
$U_WF2XModelTipString += 'used on this GUI match those found on the GUI of waif2x-Caffe.{0}'
$U_WF2XModelTipString += '{0}'
$U_WF2XModelTipString += '2D Illust (RGB): 2-dimensional image model for converting RGB.{0}'
$U_WF2XModelTipString += 'Internally uses the model "anime_style_art_rgb". {0}'
$U_WF2XModelTipString += '{0}'
$U_WF2XModelTipString += '2D Illust (UpRGB): Higher quality than the previous. Uses more{0}'
$U_WF2XModelTipString += 'VRAM. Internally uses the model "upconv_7_anime_style_art_rgb".{0}'
$U_WF2XModelTipString += '{0}'
$U_WF2XModelTipString += '2D Illust (Y): 2-dimensional illustration model that converts only{0}'
$U_WF2XModelTipString += 'the luminance. Internally uses the model "anime_style_art".{0}'
$U_WF2XModelTipString += '{0}'
$U_WF2XModelTipString += 'Photo (Standard): Standard model for photography or animation.{0}'
$U_WF2XModelTipString += 'Internally uses the model "photo".{0}'
$U_WF2XModelTipString += '{0}'
$U_WF2XModelTipString += 'Photo (UpPhoto): Higher quality than the previous. Uses more{0}'
$U_WF2XModelTipString += 'VRAM. Internally uses the model "upconv_7_photo".{0}'
$U_WF2XModelTipString += '{0}'
$U_WF2XModelTipString += 'Photo (UKBench): Old-fashioned model for photographs. Can only{0}'
$U_WF2XModelTipString += 'upscale and not denoise. Internally uses the model "ukbench".'
$U_WF2XModelTipString = [String]::Format($U_WF2XModelTipString, [Environment]::NewLine)
$U_WF2XModelTip.SetToolTip($U_WF2XModelLabel, $U_WF2XModelTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Waifu2x Disable GPU
$U_WF2XGPUCheck = New-Object System.Windows.Forms.CheckBox
$U_WF2XGPUCheck.Name = 'Waifu2xNoGPU'
$U_WF2XGPUCheck.Size = New-Object System.Drawing.Size(100, 16)
$U_WF2XGPUCheck.Location = New-Object System.Drawing.Size(184, 72)
$U_WF2XGPUCheck.Checked = $Waifu2xNoGPU
$U_WF2XGPUCheck.Text = ' Disable GPU'
$U_WF2XGPUCheck.Add_CheckStateChanged({GUI_UpdateCheckBoxState})
$UpscaleFilterGroup.Controls.Add($U_WF2XGPUCheck)
$U_WF2XGPUTip = New-Object System.Windows.Forms.ToolTip
$U_WF2XGPUTip.InitialDelay = $ToolTipDelay
$U_WF2XGPUTip.AutoPopDelay = $ToolTipDuration
$U_WF2XGPUTipString = 'Force using the CPU instead of the GPU. Waifu2x relies on nvidia CUDA, so this{0}'
$U_WF2XGPUTipString += 'option should only be used if a nvidia GPU is not available. Using the CPU is{0}'
$U_WF2XGPUTipString += 'much slower, but allows using Waifu2x with other GPU vendors (such as Intel).{0}'
$U_WF2XGPUTipString += '{0}'
$U_WF2XGPUTipString += 'AMD GPU users can instead use OpenCL with Waifu2x-CPP. This is much faster{0}'
$U_WF2XGPUTipString += 'than using the CPU, but it still will not be as fast as nvidia CUDA. This option{0}'
$U_WF2XGPUTipString += 'can not be enabled with "Enable OpenCL" and is forced off if using Waifu2x-CPP.'
$U_WF2XGPUTipString = [String]::Format($U_WF2XGPUTipString, [Environment]::NewLine)
$U_WF2XGPUTip.SetToolTip($U_WF2XGPUCheck, $U_WF2XGPUTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Waifu2x OpenCL (CPP Only)
$U_WF2XOpenCLCheck = New-Object System.Windows.Forms.CheckBox
$U_WF2XOpenCLCheck.Name = 'Waifu2xOpenCL'
$U_WF2XOpenCLCheck.Size = New-Object System.Drawing.Size(110, 16)
$U_WF2XOpenCLCheck.Location = New-Object System.Drawing.Size(184, 96)
$U_WF2XOpenCLCheck.Checked = $Waifu2xOpenCL
$U_WF2XOpenCLCheck.Text = ' Enable OpenCL'
$U_WF2XOpenCLCheck.Add_CheckStateChanged({GUI_UpdateCheckBoxState})
$UpscaleFilterGroup.Controls.Add($U_WF2XOpenCLCheck)
$U_WF2XOpenCLTip = New-Object System.Windows.Forms.ToolTip
$U_WF2XOpenCLTip.InitialDelay = $ToolTipDelay
$U_WF2XOpenCLTip.AutoPopDelay = $ToolTipDuration
$U_WF2XOpenCLTipString = 'If a nvidia GPU is not available, Waifu2x-CPP can attempt to use OpenCL to speed up{0}'
$U_WF2XOpenCLTipString += 'the upscaling process when compared to using the CPU. This option should be enabled{0}'
$U_WF2XOpenCLTipString += 'if the system is using an AMD GPU, and may work with some Intel integrated chipsets. '
$U_WF2XOpenCLTipString = [String]::Format($U_WF2XOpenCLTipString, [Environment]::NewLine)
$U_WF2XOpenCLTip.SetToolTip($U_WF2XOpenCLCheck, $U_WF2XOpenCLTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Updates the visibility and position of some options depending on which waifu2x is selected (caffe or cpp).
GUI_UpdateWaifu2xSelection
#----------------------------------------------------------------------------------------------------------------------------------------------
# If Waifu2x is not the selected filter, then hide all waifu2x options from the user.
if ($FilterSelected -ne 'Waifu2x')
{
  $U_WF2XModeCombo.Hide()
  $U_WF2XModeLabel.Hide()
  $U_WF2XNoiseBox.Hide()
  $U_WF2XNoiseLabel.Hide()
  $U_WF2XGPUCheck.Hide()
  $U_WF2XOpenCLCheck.Hide()
  $U_WF2XModelCombo.Hide()
  $U_WF2XModelLabel.Hide()
}
#==============================================================================================================================================================================================
#  Create Advanced Option 1: Generate New MipMaps
#==============================================================================================================================================================================================
$GenNewMipMapsGroup = New-Object System.Windows.Forms.GroupBox
$GenNewMipMapsGroup.Size = New-Object System.Drawing.Size(380, 124)
$GenNewMipMapsGroup.Location = New-Object System.Drawing.Size(10, 260)
$GenNewMipMapsGroup.Text = ' Description '
$Dialog.Controls.Add($GenNewMipMapsGroup)
#----------------------------------------------------------------------------------------------------------------------------------------------
$GenNewMipMapsLabel = New-Object System.Windows.Forms.Label
$GenNewMipMapsLabel.Size = New-Object System.Drawing.Size(360, 66)
$GenNewMipMapsLabel.Location = New-Object System.Drawing.Size(10, 24)
$GenNewMipMapsString = 'This option generates new mipmaps within the texture pack itself. Dynamic mipmaps are preserved unless the "Force New Mipmaps" option is ticked. '
$GenNewMipMapsString += 'Care must be taken with this option as textures with incorrect dimensions will have incorrect mipmaps. If in doubt, use "Scan Texture For Issues" '
$GenNewMipMapsString += 'and check "Auto-Repair".'
$GenNewMipMapsLabel.Text = $GenNewMipMapsString
$GenNewMipMapsGroup.Controls.Add($GenNewMipMapsLabel)
#----------------------------------------------------------------------------------------------------------------------------------------------
# DDS MipMap Type
$G_DDSMipMapCombo = New-Object System.Windows.Forms.ComboBox
$G_DDSMipMapCombo.Name = 'DDSMipMapType'
$G_DDSMipMapCombo.Size = New-Object System.Drawing.Size(80, 28)
$G_DDSMipMapCombo.Location = New-Object System.Drawing.Size(12, 94)
$G_DDSMipMapCombo.Items.Add('External') | Out-Null
$G_DDSMipMapCombo.Items.Add('Internal') | Out-Null
$G_DDSMipMapCombo.Items.Add('Both') | Out-Null
$G_DDSMipMapCombo.SelectedItem = $DDSMipMapType
$G_DDSMipMapCombo.Add_SelectedIndexChanged({GUI_UpdateComboBoxState})
$G_DDSMipMapCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$GenNewMipMaps_DDSMipMapLabel = New-Object System.Windows.Forms.Label
$GenNewMipMaps_DDSMipMapLabel.Size = New-Object System.Drawing.Size(106, 22)
$GenNewMipMaps_DDSMipMapLabel.Location = New-Object System.Drawing.Size(94, 97)
$GenNewMipMaps_DDSMipMapLabel.Text = 'DDS MipMap Type'
$GenNewMipMapsGroup.Controls.Add($G_DDSMipMapCombo)
$GenNewMipMapsGroup.Controls.Add($GenNewMipMaps_DDSMipMapLabel)
$GenNewMipMaps_DDSMipMapTip = New-Object System.Windows.Forms.ToolTip
$GenNewMipMaps_DDSMipMapTip.InitialDelay = $ToolTipDelay
$GenNewMipMaps_DDSMipMapTip.AutoPopDelay = $ToolTipDuration
$GenNewMipMaps_DDSMipMapTipString = 'Determines which types of mipmaps are generated for DDS textures. {0}'
$GenNewMipMaps_DDSMipMapTipString += '{0}'
$GenNewMipMaps_DDSMipMapTipString += 'External: These can be used with any version of Dolphin. {0}'
$GenNewMipMaps_DDSMipMapTipString += 'Internal: Can only be used by Dolphin Ishiiruka. {0}'
$GenNewMipMaps_DDSMipMapTipString += 'Both: Generate both types, but this takes lots of disk space.'
$GenNewMipMaps_DDSMipMapTipString = [String]::Format($GenNewMipMaps_DDSMipMapTipString, [Environment]::NewLine)
$GenNewMipMaps_DDSMipMapTip.SetToolTip($GenNewMipMaps_DDSMipMapLabel, $GenNewMipMaps_DDSMipMapTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Force New MipMaps
$G_ForceNewMipsCheck = New-Object System.Windows.Forms.CheckBox
$G_ForceNewMipsCheck.Name = 'ForceNewMipMaps'
$G_ForceNewMipsCheck.Size = New-Object System.Drawing.Size(130, 16)
$G_ForceNewMipsCheck.Location = New-Object System.Drawing.Size(210, 96)
$G_ForceNewMipsCheck.Checked = $ForceNewMipMaps
$G_ForceNewMipsCheck.Text = ' Force New MipMaps'
$G_ForceNewMipsCheck.Add_CheckStateChanged({GUI_UpdateCheckBoxState})
$GenNewMipMapsGroup.Controls.Add($G_ForceNewMipsCheck)
$GenNewMipMaps_ForceNewMipsTip = New-Object System.Windows.Forms.ToolTip
$GenNewMipMaps_ForceNewMipsTip.InitialDelay = $ToolTipDelay
$GenNewMipMaps_ForceNewMipsTip.AutoPopDelay = $ToolTipDuration
$GenNewMipMaps_ForceNewMipsTipString = 'Forces the script to ignore included mipmaps and generate{0}'
$GenNewMipMaps_ForceNewMipsTipString += 'new ones from the base texture.'
$GenNewMipMaps_ForceNewMipsTipString = [String]::Format($GenNewMipMaps_ForceNewMipsTipString, [Environment]::NewLine)
$GenNewMipMaps_ForceNewMipsTip.SetToolTip($G_ForceNewMipsCheck, $GenNewMipMaps_ForceNewMipsTipString)
#==============================================================================================================================================================================================
#  Create Advanced Option 2: Remove Invalid MipMaps
#==============================================================================================================================================================================================
$InvalidMipMapsGroup = New-Object System.Windows.Forms.GroupBox
$InvalidMipMapsGroup.Size = New-Object System.Drawing.Size(380, 124)
$InvalidMipMapsGroup.Location = New-Object System.Drawing.Size(10, 260)
$InvalidMipMapsGroup.Text = ' Description '
$Dialog.Controls.Add($InvalidMipMapsGroup)
#----------------------------------------------------------------------------------------------------------------------------------------------
$InvalidMipMapsLabel = New-Object System.Windows.Forms.Label
$InvalidMipMapsLabel.Size = New-Object System.Drawing.Size(360, 66)
$InvalidMipMapsLabel.Location = New-Object System.Drawing.Size(10, 24)
$InvalidMipMapsString = 'Scans a texture pack for textures that contain mipmap levels that are not actually a mipmap texture and deletes them. This can find both external '
$InvalidMipMapsString += 'and internal mipmaps. Internal mipmaps are only searched for if the texture is a DDS texture.'
$InvalidMipMapsLabel.Text = $InvalidMipMapsString
$InvalidMipMapsGroup.Controls.Add($InvalidMipMapsLabel)
#----------------------------------------------------------------------------------------------------------------------------------------------
$X_HideOKCheck = New-Object System.Windows.Forms.CheckBox
$X_HideOKCheck.Name = 'HideOKTextures'
$X_HideOKCheck.Size = New-Object System.Drawing.Size(120, 16)
$X_HideOKCheck.Location = New-Object System.Drawing.Size(12, 90)
$X_HideOKCheck.Checked = $HideOKTextures
$X_HideOKCheck.Text = ' Hide OK Textures'
$X_HideOKCheck.Add_CheckStateChanged({GUI_UpdateCheckBoxState})
$InvalidMipMapsGroup.Controls.Add($X_HideOKCheck)
$X_HideOKTip = New-Object System.Windows.Forms.ToolTip
$X_HideOKTip.InitialDelay = $ToolTipDelay
$X_HideOKTip.AutoPopDelay = $ToolTipDuration
$X_HideOKTipString = 'Textures that do not have mipmaps removed are flagged as "OK".{0}'
$X_HideOKTipString += 'This option prevents these textures from showing up in the log file.'
$X_HideOKTipString = [String]::Format($X_HideOKTipString, [Environment]::NewLine)
$X_HideOKTip.SetToolTip($X_HideOKCheck, $X_HideOKTipString)
#==============================================================================================================================================================================================
#  Create Advanced Option 3: Remove Alpha Channel From Opaque Textures
#==============================================================================================================================================================================================
$RemoveAlphaGroup = New-Object System.Windows.Forms.GroupBox
$RemoveAlphaGroup.Size = New-Object System.Drawing.Size(380, 124)
$RemoveAlphaGroup.Location = New-Object System.Drawing.Size(10, 260)
$RemoveAlphaGroup.Text = ' Description '
$Dialog.Controls.Add($RemoveAlphaGroup)
#----------------------------------------------------------------------------------------------------------------------------------------------
$RemoveAlphaLabel = New-Object System.Windows.Forms.Label
$RemoveAlphaLabel.Size = New-Object System.Drawing.Size(360, 66)
$RemoveAlphaLabel.Location = New-Object System.Drawing.Size(10, 24)
$RemoveAlphaString = "Textures that are found to have an alpha channel but don't actually contain any transparent pixels will have the alpha channel removed. "
$RemoveAlphaString += 'Although this option works with DDS textures, it is most useful for PNG textures. DDS textures created with this script will not have this issue.'
$RemoveAlphaLabel.Text = $RemoveAlphaString
$RemoveAlphaGroup.Controls.Add($RemoveAlphaLabel)
#----------------------------------------------------------------------------------------------------------------------------------------------
$Y_HideOKCheck = New-Object System.Windows.Forms.CheckBox
$Y_HideOKCheck.Name = 'HideOKTextures'
$Y_HideOKCheck.Size = New-Object System.Drawing.Size(120, 16)
$Y_HideOKCheck.Location = New-Object System.Drawing.Size(12, 90)
$Y_HideOKCheck.Checked = $HideOKTextures
$Y_HideOKCheck.Text = ' Hide OK Textures'
$Y_HideOKCheck.Add_CheckStateChanged({GUI_UpdateCheckBoxState})
$RemoveAlphaGroup.Controls.Add($Y_HideOKCheck)
$Y_HideOKTip = New-Object System.Windows.Forms.ToolTip
$Y_HideOKTip.InitialDelay = $ToolTipDelay
$Y_HideOKTip.AutoPopDelay = $ToolTipDuration
$Y_HideOKTipString = 'Textures that do not have an alpha channel removed are flagged as "OK".{0}'
$Y_HideOKTipString += 'This option prevents these textures from showing up in the log file.'
$Y_HideOKTipString = [String]::Format($Y_HideOKTipString, [Environment]::NewLine)
$Y_HideOKTip.SetToolTip($Y_HideOKCheck, $Y_HideOKTipString)
#==============================================================================================================================================================================================
#  Create Advanced Option 4: Fix Textures Potentially Broken by OptiPNG
#==============================================================================================================================================================================================
$FixBrokeOptiPNGGroup = New-Object System.Windows.Forms.GroupBox
$FixBrokeOptiPNGGroup.Size = New-Object System.Drawing.Size(380, 124)
$FixBrokeOptiPNGGroup.Location = New-Object System.Drawing.Size(10, 260)
$FixBrokeOptiPNGGroup.Text = ' Description '
$Dialog.Controls.Add($FixBrokeOptiPNGGroup)
#----------------------------------------------------------------------------------------------------------------------------------------------
$FixBrokeOptiPNGLabel = New-Object System.Windows.Forms.Label
$FixBrokeOptiPNGLabel.Size = New-Object System.Drawing.Size(360, 66)
$FixBrokeOptiPNGLabel.Location = New-Object System.Drawing.Size(10, 24)
$FixBrokeOptiPNGString = 'Textures that have less than 8-Bit depth or indexed color space can become "broken" in Dolphin when optimized with '
$FixBrokeOptiPNGString += 'OptiPNG. This script now properly prevents this when using OptiPNG, so this option is not very useful unless OptiPNG was used externally from this script.'
$FixBrokeOptiPNGLabel.Text = $FixBrokeOptiPNGString
$FixBrokeOptiPNGGroup.Controls.Add($FixBrokeOptiPNGLabel)
#----------------------------------------------------------------------------------------------------------------------------------------------
$Z_HideOKCheck = New-Object System.Windows.Forms.CheckBox
$Z_HideOKCheck.Name = 'HideOKTextures'
$Z_HideOKCheck.Size = New-Object System.Drawing.Size(120, 16)
$Z_HideOKCheck.Location = New-Object System.Drawing.Size(12, 90)
$Z_HideOKCheck.Checked = $HideOKTextures
$Z_HideOKCheck.Text = ' Hide OK Textures'
$Z_HideOKCheck.Add_CheckStateChanged({GUI_UpdateCheckBoxState})
$FixBrokeOptiPNGGroup.Controls.Add($Z_HideOKCheck)
$Z_HideOKTip = New-Object System.Windows.Forms.ToolTip
$Z_HideOKTip.InitialDelay = $ToolTipDelay
$Z_HideOKTip.AutoPopDelay = $ToolTipDuration
$Z_HideOKTipString = 'Textures that were not repaired are flagged as "OK". This {0}'
$Z_HideOKTipString += 'option prevents these textures from showing up in the log file.'
$Z_HideOKTipString = [String]::Format($Z_HideOKTipString, [Environment]::NewLine)
$Z_HideOKTip.SetToolTip($Z_HideOKCheck, $Z_HideOKTipString)
#==============================================================================================================================================================================================
#  Create Advanced Option 5: Combine Multiple Textures
#==============================================================================================================================================================================================
$CombineTextureGroup = New-Object System.Windows.Forms.GroupBox
$CombineTextureGroup.Size = New-Object System.Drawing.Size(380, 124)
$CombineTextureGroup.Location = New-Object System.Drawing.Size(10, 260)
$CombineTextureGroup.Text = ' Combine Texture Options '
$Dialog.Controls.Add($CombineTextureGroup)
#----------------------------------------------------------------------------------------------------------------------------------------------
$CombineNameTextBox = New-Object System.Windows.Forms.TextBox
$CombineNameTextBox.Name = 'CombinedName'
$CombineNameTextBox.Size = New-Object System.Drawing.Size(150, 20)
$CombineNameTextBox.Location = New-Object System.Drawing.Size(126, 20)
$CombineNameTextBox.Text = $CombinedName + $PNG
$CombineNameTextBox.Add_Leave({GUI_CombineTextures_UpdateName})
$CombineNameLabel = New-Object System.Windows.Forms.Label
$CombineNameLabel.Size = New-Object System.Drawing.Size(130, 22)
$CombineNameLabel.Location = New-Object System.Drawing.Size(10, 23)
$CombineNameLabel.Text = 'Texture Output Name'
$CombineTextureGroup.Controls.Add($CombineNameTextBox)
$CombineTextureGroup.Controls.Add($CombineNameLabel)
$CombineRowsTip = New-Object System.Windows.Forms.ToolTip
$CombineRowsTip.InitialDelay = $ToolTipDelay
$CombineRowsTip.AutoPopDelay = $ToolTipDuration
$CombineRowsTipString = 'The name of the final texture that is created from the texture array. It is not necessary to{0}'
$CombineRowsTipString += 'include a file extension in the name as it will be automatically added. Trying to force the file{0}'
$CombineRowsTipString += 'extension will not force the texture into a different format as the entire method of combining{0}'
$CombineRowsTipString += 'textures is limited to creating PNG files only.'
$CombineRowsTipString = [String]::Format($CombineRowsTipString, [Environment]::NewLine)
$CombineRowsTip.SetToolTip($CombineNameLabel, $CombineRowsTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$CombineRowsNumBox = New-Object System.Windows.Forms.NumericUpDown
$CombineRowsNumBox.Name = 'TextureRows'
$CombineRowsNumBox.Size = New-Object System.Drawing.Size(72, 10)
$CombineRowsNumBox.Location = New-Object System.Drawing.Size(10, 50)
$CombineRowsNumBox.DecimalPlaces = 0
$CombineRowsNumBox.Value = $TextureRows
$CombineRowsNumBox.Minimum = 1
$CombineRowsNumBox.Maximum = 18
$CombineRowsNumBox.Increment = 1
$CombineRowsNumBox.Add_ValueChanged({GUI_TextureArray_UpdateCells})
$CombineRowsLabel = New-Object System.Windows.Forms.Label
$CombineRowsLabel.Size = New-Object System.Drawing.Size(82, 18)
$CombineRowsLabel.Location = New-Object System.Drawing.Size(84, 52)
$CombineRowsLabel.Text = 'Texture Rows'
$CombineTextureGroup.Controls.Add($CombineRowsNumBox)
$CombineTextureGroup.Controls.Add($CombineRowsLabel)
$CombineRowsTip = New-Object System.Windows.Forms.ToolTip
$CombineRowsTip.InitialDelay = $ToolTipDelay
$CombineRowsTip.AutoPopDelay = $ToolTipDuration
$CombineRowsTipString = 'The number of rows in the texture grid. This value (along with columns) is {0}'
$CombineRowsTipString += 'essential in calculating the correct number of cells the final texture will {0}'
$CombineRowsTipString += 'have. The number of textures in the final texture is simply (rows * colums).'
$CombineRowsTipString = [String]::Format($CombineRowsTipString, [Environment]::NewLine)
$CombineRowsTip.SetToolTip($CombineRowsLabel, $CombineRowsTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$CombineColumnsNumBox = New-Object System.Windows.Forms.NumericUpDown
$CombineColumnsNumBox.Name = 'TextureColumns'
$CombineColumnsNumBox.Size = New-Object System.Drawing.Size(72, 10)
$CombineColumnsNumBox.Location = New-Object System.Drawing.Size(190, 50)
$CombineColumnsNumBox.DecimalPlaces = 0
$CombineColumnsNumBox.Value = $TextureColumns
$CombineColumnsNumBox.Minimum = 1
$CombineColumnsNumBox.Maximum = 18
$CombineColumnsNumBox.Increment = 1
$CombineColumnsNumBox.Add_ValueChanged({GUI_TextureArray_UpdateCells})
$CombineColumnsLabel = New-Object System.Windows.Forms.Label
$CombineColumnsLabel.Size = New-Object System.Drawing.Size(100, 18)
$CombineColumnsLabel.Location = New-Object System.Drawing.Size(266, 52)
$CombineColumnsLabel.Text = 'Texture Columns'
$CombineTextureGroup.Controls.Add($CombineColumnsNumBox)
$CombineTextureGroup.Controls.Add($CombineColumnsLabel)
$CombineColumnsTip = New-Object System.Windows.Forms.ToolTip
$CombineColumnsTip.InitialDelay = $ToolTipDelay
$CombineColumnsTip.AutoPopDelay = $ToolTipDuration
$CombineColumnsTipString = 'The number of columns in the texture grid. This value (along with rows) is {0}'
$CombineColumnsTipString += 'essential in calculating the correct number of cells the final texture will {0}'
$CombineColumnsTipString += 'have. The number of textures in the final texture is simply (rows * colums).'
$CombineColumnsTipString = [String]::Format($CombineColumnsTipString, [Environment]::NewLine)
$CombineColumnsTip.SetToolTip($CombineColumnsLabel, $CombineColumnsTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$CombineSelectButton = New-Object System.Windows.Forms.Button
$CombineSelectButton.Size = New-Object System.Drawing.Size(100, 28)
$CombineSelectButton.Location = New-Object System.Drawing.Size(138, 84)
$CombineSelectButton.Text = 'Select Textures'
$CombineSelectButton.Add_Click({GUI_CombineTextures_DialogDisplay})
$CombineTextureGroup.Controls.Add($CombineSelectButton)
$CombineSelectTip = New-Object System.Windows.Forms.ToolTip
$CombineSelectTip.InitialDelay = $ToolTipDelay
$CombineSelectTip.AutoPopDelay = $ToolTipDuration
$CombineSelectTipString = 'Opens the button grid that allows adding textures into the texture array.{0}'
$CombineSelectTipString = 'It is also possible to drop textures onto the buttons to add them to the array.{0}'
$CombineSelectTipString += '{0}'
$CombineSelectTipString += 'Warning: The texture array is wiped out every time one of the Standard or{0}'
$CombineSelectTipString += 'Advanced options is selected, which removes all selected textures!'
$CombineSelectTipString = [String]::Format($CombineSelectTipString, [Environment]::NewLine)
$CombineSelectTip.SetToolTip($CombineSelectButton, $CombineSelectTipString)
#==============================================================================================================================================================================================
#  Create Advanced Option 6: Split Combined Multi-Texture
#==============================================================================================================================================================================================
$global:CombinedTexture = 'Select a texture to split into multiple textures...'
$global:CTTDataFile = '<None>'
#----------------------------------------------------------------------------------------------------------------------------------------------
$SplitTextureGroup = New-Object System.Windows.Forms.GroupBox
$SplitTextureGroup.Size = New-Object System.Drawing.Size(380, 124)
$SplitTextureGroup.Location = New-Object System.Drawing.Size(10, 260)
$SplitTextureGroup.Text = ' Split Multi-Texture Options '
$Dialog.Controls.Add($SplitTextureGroup)
#----------------------------------------------------------------------------------------------------------------------------------------------
$SplitTextureTextBox = New-Object System.Windows.Forms.TextBox
$SplitTextureTextBox.Name = 'CombinedTexture'
$SplitTextureTextBox.Size = New-Object System.Drawing.Size(320, 22)
$SplitTextureTextBox.Location = New-Object System.Drawing.Size(10, 20)
$SplitTextureTextBox.Text = $CombinedTexture
$SplitTextureTextBox.ReadOnly = $true
$SplitTextureTextBox.Add_Click({GUI_UpdateFilePath_Button $SplitTextureTextBox 'PNG Image|*.png'})
$SplitTextureGroup.Controls.Add($SplitTextureTextBox)
$SplitTextureTipA = New-Object System.Windows.Forms.ToolTip
$SplitTextureTipA.InitialDelay = $ToolTipDelay
$SplitTextureTipA.AutoPopDelay = $ToolTipDuration
$SplitTextureTipAString = 'The path to the texture that is to be split. Loading a CTT file will{0}'
$SplitTextureTipAString += 'fill this value in automatically, but the path may have changed so{0}'
$SplitTextureTipAString += 'this field will need to be updated in that case.'
$SplitTextureTipAString = [String]::Format($SplitTextureTipAString, [Environment]::NewLine)
$SplitTextureTipA.SetToolTip($SplitTextureTextBox, $SplitTextureTipAString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$SplitTextureButton = New-Object System.Windows.Forms.Button
$SplitTextureButton.Name = 'CombinedTexture'
$SplitTextureButton.Size = New-Object System.Drawing.Size(26, 22)
$SplitTextureButton.Location = New-Object System.Drawing.Size(342, 18)
$SplitTextureButton.Text = '...'
$SplitTextureButton.Add_Click({GUI_UpdateFilePath_Button $SplitTextureTextBox 'PNG Image|*.png'})
$SplitTextureGroup.Controls.Add($SplitTextureButton)
$SplitTextureTipB = New-Object System.Windows.Forms.ToolTip
$SplitTextureTipB.InitialDelay = $ToolTipDelay
$SplitTextureTipB.AutoPopDelay = $ToolTipDuration
$SplitTextureTipBString = 'The path to the texture that is to be split. Loading a CTT file will{0}'
$SplitTextureTipBString += 'fill this value in automatically, but the path may have changed so{0}'
$SplitTextureTipBString += 'this field will need to be updated in that case.'
$SplitTextureTipBString = [String]::Format($SplitTextureTipBString, [Environment]::NewLine)
$SplitTextureTipB.SetToolTip($SplitTextureButton, $SplitTextureTipBString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$SplitRowsNumBox = New-Object System.Windows.Forms.NumericUpDown
$SplitRowsNumBox.Name = 'TextureRows'
$SplitRowsNumBox.Size = New-Object System.Drawing.Size(72, 10)
$SplitRowsNumBox.Location = New-Object System.Drawing.Size(10, 50)
$SplitRowsNumBox.DecimalPlaces = 0
$SplitRowsNumBox.Value = $TextureRows
$SplitRowsNumBox.Minimum = 1
$SplitRowsNumBox.Maximum = 18
$SplitRowsNumBox.Increment = 1
$SplitRowsNumBox.Add_ValueChanged({GUI_TextureArray_UpdateCells})
$SplitRowsLabel = New-Object System.Windows.Forms.Label
$SplitRowsLabel.Size = New-Object System.Drawing.Size(82, 18)
$SplitRowsLabel.Location = New-Object System.Drawing.Size(84, 52)
$SplitRowsLabel.Text = 'Texture Rows'
$SplitTextureGroup.Controls.Add($SplitRowsNumBox)
$SplitTextureGroup.Controls.Add($SplitRowsLabel)
$SplitRowsTip = New-Object System.Windows.Forms.ToolTip
$SplitRowsTip.InitialDelay = $ToolTipDelay
$SplitRowsTip.AutoPopDelay = $ToolTipDuration
$SplitRowsTipString = 'The number of rows in the texture grid. This value (along with columns) is essential{0}'
$SplitRowsTipString += 'in calculating the correct number of textures that will be split from the multi-texture.{0}'
$SplitRowsTipString += 'Loading a CTT file will fill this value in automatically, but a CTT file is not necessary{0}'
$SplitRowsTipString += 'if the number of rows and columns has already been calculated. The number of textures{0}'
$SplitRowsTipString += 'created from the final texture is simply (rows * colums). '
$SplitRowsTipString = [String]::Format($SplitRowsTipString, [Environment]::NewLine)
$SplitRowsTip.SetToolTip($SplitRowsLabel, $SplitRowsTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$SplitColumnsNumBox = New-Object System.Windows.Forms.NumericUpDown
$SplitColumnsNumBox.Name = 'TextureColumns'
$SplitColumnsNumBox.Size = New-Object System.Drawing.Size(72, 10)
$SplitColumnsNumBox.Location = New-Object System.Drawing.Size(190, 50)
$SplitColumnsNumBox.DecimalPlaces = 0
$SplitColumnsNumBox.Value = $TextureColumns
$SplitColumnsNumBox.Minimum = 1
$SplitColumnsNumBox.Maximum = 18
$SplitColumnsNumBox.Increment = 1
$SplitColumnsNumBox.Add_ValueChanged({GUI_TextureArray_UpdateCells})
$SplitColumnsLabel = New-Object System.Windows.Forms.Label
$SplitColumnsLabel.Size = New-Object System.Drawing.Size(100, 18)
$SplitColumnsLabel.Location = New-Object System.Drawing.Size(266, 52)
$SplitColumnsLabel.Text = 'Texture Columns'
$SplitTextureGroup.Controls.Add($SplitColumnsNumBox)
$SplitTextureGroup.Controls.Add($SplitColumnsLabel)
$SplitColumnsTip = New-Object System.Windows.Forms.ToolTip
$SplitColumnsTip.InitialDelay = $ToolTipDelay
$SplitColumnsTip.AutoPopDelay = $ToolTipDuration
$SplitColumnsTipString = 'The number of columns in the texture grid. This value (along with rows) is essential{0}'
$SplitColumnsTipString += 'in calculating the correct number of textures that will be split from the multi-texture.{0}'
$SplitColumnsTipString += 'Loading a CTT file will fill this value in automatically, but a CTT file is not necessary{0}'
$SplitColumnsTipString += 'if the number of rows and columns has already been calculated. The number of textures{0}'
$SplitColumnsTipString += 'created from the final texture is simply (rows * colums). '
$SplitColumnsTipString = [String]::Format($SplitColumnsTipString, [Environment]::NewLine)
$SplitColumnsTip.SetToolTip($SplitColumnsLabel, $SplitColumnsTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$SplitCTTButton = New-Object System.Windows.Forms.Button
$SplitCTTButton.Size = New-Object System.Drawing.Size(100, 28)
$SplitCTTButton.Location = New-Object System.Drawing.Size(138, 84)
$SplitCTTButton.Text = 'Load CTT File'
$SplitCTTButton.Add_Click({GUI_SplitTexture_LoadCTTFile})
$SplitTextureGroup.Controls.Add($SplitCTTButton)
$SplitCTTTip = New-Object System.Windows.Forms.ToolTip
$SplitCTTTip.InitialDelay = $ToolTipDelay
$SplitCTTTip.AutoPopDelay = $ToolTipDuration
$SplitCTTTipString = 'If a multi-texture was created using the option "Combine Multiple Textures", the script will also generate a file with{0}'
$SplitCTTTipString += 'the texture name and a (.ctt) extension. This file holds the path to the texture, the number of columns and rows, and{0}'
$SplitCTTTipString += 'every texture hash/name that was used to generate the multi-texture. Loading a CTT file will automatically fill in the{0}'
$SplitCTTTipString += 'correct values for rows and columns, and when the texture is created all split textures will be renamed with the hash{0}'
$SplitCTTTipString += 'they had before being combined. The path will be where the texture was last generated, so it may need to be changed.{0}'
$SplitCTTTipString += '{0}'
$SplitCTTTipString += 'Note that a CTT file is not necessary to split an image, it just provides a shortcut to the correct number of rows and{0}'
$SplitCTTTipString += 'columns and automatically renames the individual textures after splitting the image. If a CTT is not selected, images{0}'
$SplitCTTTipString += 'will be renamed from the main texture + an incrementing integer, and dimensions will be calculated from rows/columns.'
$SplitCTTTipString = [String]::Format($SplitCTTTipString, [Environment]::NewLine)
$SplitCTTTip.SetToolTip($SplitCTTButton, $SplitCTTTipString)
#==============================================================================================================================================================================================
#  CTT GUI MAIN DIALOG - INITIAL VISIBILITY
#==============================================================================================================================================================================================
# Hide the Option groups and Global Options by default.
$StandardGroup.Hide()
$AdvancedGroup.Hide()
$IshiiPathGroup.Hide()
$OptiPathGroup.Hide()
$xBRZPathGroup.Hide()
$Waifu2xPathGroup.Hide()
$TempPathGroup.Hide()
$InternalGroup.Hide()
$CTTOptionsGroup.Hide()

# Do this crap in a function so "$MenuGroups" becomes a local variable instead of sticking around until the script is closed.
function SetMenuVisibility()
{
  # Create an array to easily reference all standard and advanced options.
  $MenuGroups = New-Object Object[] 13

  # Standard Options
  $MenuGroups[0]  = $ScanGroup
  $MenuGroups[1]  = $RescaleGroup
  $MenuGroups[2]  = $ConvertGroup
  $MenuGroups[3]  = $MaterialGroup
  $MenuGroups[4]  = $WatermarkGroup
  $MenuGroups[5]  = $OptiPNGGroup
  $MenuGroups[6]  = $UpscaleFilterGroup

  # Advanced Options
  $MenuGroups[7]  = $GenNewMipMapsGroup
  $MenuGroups[8]  = $InvalidMipMapsGroup
  $MenuGroups[9]  = $RemoveAlphaGroup
  $MenuGroups[10] = $FixBrokeOptiPNGGroup
  $MenuGroups[11] = $CombineTextureGroup
  $MenuGroups[12] = $SplitTextureGroup

  # Initially hide all groups.
  for($i=0; $i -lt $MenuGroups.Length; $i++)
  {
    $MenuGroups[$i].Hide()
  }
  # Initially display a standard option if it was selected.
  if ($CurrentOptions -eq 'Standard')
  {
    $StandardGroup.Show()
    $CalcStored = [int]$StoredStandard
    $MenuGroups[$CalcStored].Show()
  }
  # Or show an advanced option.
  else
  {
    $AdvancedGroup.Show()
    $CalcStored = 7 + [int]$StoredAdvanced
    $MenuGroups[$CalcStored].Show()
  }
}
# Show the option that has been stored.
SetMenuVisibility
#==============================================================================================================================================================================================
#  CTT GUI - YES/NO DIALOG
#==============================================================================================================================================================================================
#  Shows a yes/no dialog and returns the button that was pressed.

function ShowYesNoDialog($DisplayText)
{
  [System.Media.SystemSounds]::Beep.Play()
  $YesNoLabel.Text = $DisplayText
  $YesNoDialog.Add_Shown({$YesNoDialog.Activate()})
  $YesNoDialog.ShowDialog() | Out-Null
  return $YesNoChoice
}
#==============================================================================================================================================================================================
# Create the yes/no dialog.
$YesNoDialog = New-Object System.Windows.Forms.Form
$YesNoDialog.Font = $MenuFont
$YesNoDialog.Text = $ScriptName
$YesNoDialog.Size = New-Object System.Drawing.Size(320, 130)
$YesNoDialog.MaximumSize = New-Object System.Drawing.Size(320, 130)
$YesNoDialog.MinimumSize = New-Object System.Drawing.Size(320, 130)
$YesNoDialog.MaximizeBox = $false
$YesNoDialog.MinimizeBox = $false
$YesNoDialog.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Inherit
$YesNoDialog.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
$YesNoDialog.StartPosition = "CenterScreen"
$YesNoDialog.KeyPreview = $true
$YesNoDialog.Topmost = $true
#==============================================================================================================================================================================================
# Display the question to ask.
$YesNoLabel = New-Object System.Windows.Forms.Label
$YesNoLabel.Size = New-Object System.Drawing.Size(300, 20)
$YesNoLabel.Location = New-Object System.Drawing.Size(10, 10)
$YesNoLabel.Text = 'Are you sure you want to cancel the current operation?'
$YesNoDialog.Controls.Add($YesNoLabel)
#==============================================================================================================================================================================================
# Create the "Yes" button.
$YesButton = New-Object System.Windows.Forms.Button
$YesButton.Size = New-Object System.Drawing.Size(80, 28)
$YesButton.Location = New-Object System.Drawing.Size(52, 48)
$YesButton.Text = 'Yes'
$YesButton.Add_Click({$global:YesNoChoice = $true ; $YesNoDialog.Close()})
$YesNoDialog.Controls.Add($YesButton)
#==============================================================================================================================================================================================
# Create the "No" button.
$NoButton = New-Object System.Windows.Forms.Button
$NoButton.Size = New-Object System.Drawing.Size(80, 28)
$NoButton.Location = New-Object System.Drawing.Size(170, 48)
$NoButton.Text = 'No'
$NoButton.Add_Click({$global:YesNoChoice = $false ; $YesNoDialog.Close()})
$YesNoDialog.Controls.Add($NoButton)
#==============================================================================================================================================================================================
#  CTT GUI - PAUSE DIALOG
#==============================================================================================================================================================================================
#  Shows a yes/no dialog and returns the button that was pressed.

function ShowPauseDialog()
{
  [System.Media.SystemSounds]::Beep.Play()
  $PauseDialog.Add_Shown({$PauseDialog.Activate()})
  $PauseDialog.ShowDialog() | Out-Null
}
#==============================================================================================================================================================================================
# Create the yes/no dialog.
$PauseDialog = New-Object System.Windows.Forms.Form
$PauseDialog.Font = $MenuFont
$PauseDialog.Text = $ScriptName
$PauseDialog.Size = New-Object System.Drawing.Size(320, 130)
$PauseDialog.MaximumSize = New-Object System.Drawing.Size(320, 130)
$PauseDialog.MinimumSize = New-Object System.Drawing.Size(320, 130)
$PauseDialog.MaximizeBox = $false
$PauseDialog.MinimizeBox = $false
$PauseDialog.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Inherit
$PauseDialog.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
$PauseDialog.StartPosition = "CenterScreen"
$PauseDialog.KeyPreview = $true
$PauseDialog.Topmost = $true
#==============================================================================================================================================================================================
# Display the question to ask.
$PauseLabel = New-Object System.Windows.Forms.Label
$PauseLabel.Size = New-Object System.Drawing.Size(300, 20)
$PauseLabel.Location = New-Object System.Drawing.Size(10, 10)
$PauseLabel.Text = 'The loop has been paused. Press "OK" to resume.'
$PauseDialog.Controls.Add($PauseLabel)
#==============================================================================================================================================================================================
# Create the "OK" button.
$PauseButton = New-Object System.Windows.Forms.Button
$PauseButton.Size = New-Object System.Drawing.Size(80, 28)
$PauseButton.Location = New-Object System.Drawing.Size(110, 48)
$PauseButton.Text = 'OK'
$PauseButton.Add_Click({$PauseDialog.Close()})
$PauseDialog.Controls.Add($PauseButton)
#==============================================================================================================================================================================================
#  CTT GUI - HELP DIALOG
#==============================================================================================================================================================================================
$HelpDialog = New-Object System.Windows.Forms.Form
$HelpDialog.Text = ('CTT-PS Help')
$HelpDialog.Size = New-Object System.Drawing.Size(800, 500)
$HelpDialog.MinimumSize = New-Object System.Drawing.Size(550, 300)
$HelpDialog.MaximizeBox = $true
$HelpDialog.MinimizeBox = $true
$HelpDialog.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Inherit
$HelpDialog.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::Sizable
$HelpDialog.StartPosition = "CenterScreen"
$HelpDialog.KeyPreview = $true
$HelpDialog.Add_FormClosing({$HelpDialog.Hide() ; $_.Cancel = $true})
$HelpDialog.Add_Shown({$HelpDialog.Activate()})
DialogSetIcon $HelpDialog
#==============================================================================================================================================================================================
$HelpTopicsLabel = New-Object System.Windows.Forms.Label
$HelpTopicsLabel.Size = New-Object System.Drawing.Size(120, 18)
$HelpTopicsLabel.Location = New-Object System.Drawing.Size(8, 10)
$HelpTopicsLabel.Text = 'Help Topics:'
$HelpDialog.Controls.Add($HelpTopicsLabel)
#==============================================================================================================================================================================================
$HelpTopics = New-Object System.Windows.Forms.TreeView
$HelpTopics.Size = New-Object System.Drawing.Size(260, 390)
$HelpTopics.Location = New-Object System.Drawing.Size(8, 30)
$HelpTopics.Anchor = ([System.Windows.Forms.AnchorStyles]::Top, [System.Windows.Forms.AnchorStyles]::Bottom, [System.Windows.Forms.AnchorStyles]::Left)
$HelpTopics.BeginUpdate()
$HelpTopics.Nodes.Add('Introduction') | Out-Null
$HelpTopics.Nodes.Add('Features') | Out-Null
$HelpTopics.Nodes.Add('Quick Guide') | Out-Null
$HelpTopics.Nodes.Add('Information') | Out-Null
$CurrentNode = 4
$HelpTopics.Nodes.Add('Requirements') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('ImageMagick') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('DDS Utilities') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('Ishiiruka Tool') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('OptiPNG') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('xBRZ ScalerTest') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('Waifu2x') | Out-Null
$HelpTopics.Nodes.Add('Texture/Output Paths') | Out-Null
$HelpTopics.Nodes.Add('Process Selected') | Out-Null
$CurrentNode = 7
$HelpTopics.Nodes.Add('Standard Options') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('Scan Textures For Issues') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('Rescale Textures At Fixed Integer') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('Convert Textures to Another Format') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('Create Material Maps With Ishiiruka Tool') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('Add Identifying Watermark to All Textures') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('Optimize PNG Textures With OptiPNG') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('Apply Upscaling Filter to All Textures') | Out-Null
$CurrentNode = 8
$HelpTopics.Nodes.Add('Advanced Options') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('Generate New MipMaps') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('Remove Invalid MipMaps') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('Remove Alpha Channel From Opaque Textures') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('Fix Textures Potentially Broken by OptiPNG') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('Combine Multiple Textures') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('Split Combined Multi-Texture') | Out-Null
$CurrentNode = 9
$HelpTopics.Nodes.Add('Global Options') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('Tool Paths') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('Allow All Images') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('Force DDS DXT5') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('Disable Log File') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('Material Map Format') | Out-Null
$CurrentNode = 10
$HelpTopics.Nodes.Add('CTT-PS Options') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('PS Double Click') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('Disable Top-Most') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('Always Show Console') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('More Console Colors') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('Enable Stored Options') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('Restore Defaults') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('Import Stored Options') | Out-Null
$CurrentNode = 11
$HelpTopics.Nodes.Add('Guides') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('Creating DDS Packs') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('Rescaling Packs') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('MipMap Information') | Out-Null
$HelpTopics.Nodes[$CurrentNode].Nodes.Add('Ishiiruka Tool and Material Maps') | Out-Null
$HelpTopics.Nodes.Add('Credits') | Out-Null
$HelpTopics.Nodes.Add('About') | Out-Null
$HelpTopics.Add_AfterSelect({GUI_DisplayHelpTopic})
$HelpDialog.Controls.Add($HelpTopics)
$CurrentNode = $null
#==============================================================================================================================================================================================
$HelpDescriptionLabel = New-Object System.Windows.Forms.Label
$HelpDescriptionLabel.Size = New-Object System.Drawing.Size(120, 18)
$HelpDescriptionLabel.Location = New-Object System.Drawing.Size(276, 10)
$HelpDescriptionLabel.Text = 'Description:'
$HelpDialog.Controls.Add($HelpDescriptionLabel)
#==============================================================================================================================================================================================
$HelpDescription = New-Object System.Windows.Forms.RichTextBox
$HelpDescription.Size = New-Object System.Drawing.Size(500, 390)
$HelpDescription.Location = New-Object System.Drawing.Size(276, 30)
$HelpDescription.ReadOnly = $true
$HelpDescription.BackColor = [System.Drawing.SystemColors]::Window
$HelpDescription.Font = New-Object System.Drawing.Font('Tahoma', 10)
$HelpDescription.Text = 'You should never see me. If you do, something went wrong somewhere!'
$HelpDescription.BulletIndent = 15
$HelpDescription.DetectUrls = $true
$HelpDescription.Anchor = ([System.Windows.Forms.AnchorStyles]::Top, [System.Windows.Forms.AnchorStyles]::Bottom, [System.Windows.Forms.AnchorStyles]::Left, [System.Windows.Forms.AnchorStyles]::Right)
$HelpDescription.Add_LinkClicked({[System.Diagnostics.Process]::Start($_.LinkText)})
$HelpDialog.Controls.Add($HelpDescription)
#==============================================================================================================================================================================================
$HelpCloseButton = New-Object System.Windows.Forms.Button
$HelpCloseButton.Size = New-Object System.Drawing.Size(80, 28)
$HelpCloseButton.Location = New-Object System.Drawing.Size(695, 424)
$HelpCloseButton.Text = 'Close'
$HelpCloseButton.Anchor = ([System.Windows.Forms.AnchorStyles]::Bottom, [System.Windows.Forms.AnchorStyles]::Right)
$HelpCloseButton.Add_Click({$HelpDialog.Hide()})
$HelpDialog.Controls.Add($HelpCloseButton)
#==============================================================================================================================================================================================
$HelpZoomInButton = New-Object System.Windows.Forms.Button
$HelpZoomInButton.Size = New-Object System.Drawing.Size(28, 28)
$HelpZoomInButton.Location = New-Object System.Drawing.Size(276, 424)
$HelpZoomInButton.Text = '+'
$HelpZoomInButton.Anchor = ([System.Windows.Forms.AnchorStyles]::Bottom, [System.Windows.Forms.AnchorStyles]::Left)
$HelpZoomInButton.Add_Click({ if ($HelpDescription.ZoomFactor -lt 4) {$HelpDescription.ZoomFactor = ($HelpDescription.ZoomFactor + 0.2)}})
$HelpDialog.Controls.Add($HelpZoomInButton)
#==============================================================================================================================================================================================
$HelpZoomOutButton = New-Object System.Windows.Forms.Button
$HelpZoomOutButton.Size = New-Object System.Drawing.Size(28, 28)
$HelpZoomOutButton.Location = New-Object System.Drawing.Size(310, 424)
$HelpZoomOutButton.Text = '-'
$HelpZoomOutButton.Anchor = ([System.Windows.Forms.AnchorStyles]::Bottom, [System.Windows.Forms.AnchorStyles]::Left)
$HelpZoomOutButton.Add_Click({ if ($HelpDescription.ZoomFactor -gt 0.5) {$HelpDescription.ZoomFactor = ($HelpDescription.ZoomFactor - 0.2)}})
$HelpDialog.Controls.Add($HelpZoomOutButton)
#==============================================================================================================================================================================================
$HelpResetZoomButton = New-Object System.Windows.Forms.Button
$HelpResetZoomButton.Size = New-Object System.Drawing.Size(28, 28)
$HelpResetZoomButton.Location = New-Object System.Drawing.Size(344, 424)
$HelpResetZoomButton.Text = '='
$HelpResetZoomButton.Anchor = ([System.Windows.Forms.AnchorStyles]::Bottom, [System.Windows.Forms.AnchorStyles]::Left)
$HelpResetZoomButton.Add_Click({ $HelpDescription.ZoomFactor = 1.0 })
$HelpDialog.Controls.Add($HelpResetZoomButton)
#==============================================================================================================================================================================================
#  CTT GUI: HELP DIALOG TOPICS
#==============================================================================================================================================================================================
function GUI_DisplayHelpTopic()
{
  # Convert the object into a string.
  $SelectedNode = $this.SelectedNode.ToString()

  # Reset all formatting before displaying the new description.
  $HelpDescription.SelectionStart = 0
  $HelpDescription.ScrollToCaret()
  $HelpDescription.SelectAll()
  $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10)

  # Find the matching node and set the description accordingly.
  if ($SelectedNode -eq 'TreeNode: Introduction')
  {
    $Text = "Custom Texture Tool PS{0}"
    $Text += "By Bighead"
    $Text += "{0}{0}"
    $Text += "This is a PowerShell script for Windows that makes use of the command line options of several external programs that "
    $Text += "can perform a variety of functions for custom textures used in Dolphin. It has evolved to a point where it can be used "
	$Text += "for almost any retexturing project (even PC games). The script acts as a front end to these programs providing an "
    $Text += "entirely new level of features geared towards retexturing projects that these programs do not provide on their own."
    $Text += "{0}{0}"
    $Text += "Because of the numerous amount of options available it may seem overwhelming to use at first. But fear not, it is "
    $Text += "actually quite simple to use and by now there should be enough documentation available that everything that it can "
    $Text += "do is explained in detail."
    $Text += "{0}{0}"
    $Text += "If there are any questions, concerns, bug reports, etc. then PM me on the dolphin forums. I can also be contacted via "
    $Text += "my email address at: bighead.0@gmail{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Custom Texture Tool PS")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("bighead.0@gmail")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Features')
  {
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
    $HelpDescription.SelectedText = "Features" + [Environment]::NewLine
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10)
    $HelpDescription.SelectedText = [Environment]::NewLine
    $HelpDescription.SelectedText = "Some of the most prominent features include:" + [Environment]::NewLine
    $HelpDescription.SelectedText = [Environment]::NewLine
    $HelpDescription.SelectionBullet = $true
    $HelpDescription.SelectedText = "Check textures for a variety of issues (scaling factors, aspect ratios, etc..)." + [Environment]::NewLine
    $HelpDescription.SelectedText = "Copy textures identified with issues to a folder for manual fixing." + [Environment]::NewLine
    $HelpDescription.SelectedText = "Auto-repair most textures that are identified with issues." + [Environment]::NewLine
    $HelpDescription.SelectedText = "Convert textures between PNG, DDS, and JPG formats." + [Environment]::NewLine
    $HelpDescription.SelectedText = "Rescale all textures at a fixed integer scale as PNG, DDS, or JPG. " + [Environment]::NewLine
    $HelpDescription.SelectedText = "Missing mipmaps are automatically generated when repairing/converting." + [Environment]::NewLine
    $HelpDescription.SelectedText = "Provide custom mipmaps or the script can be forced to generate new ones." + [Environment]::NewLine
    $HelpDescription.SelectedText = "The type of DDS mipmaps generated (internal/external) can be configured." + [Environment]::NewLine
    $HelpDescription.SelectedText = "Create material maps from color/bump/spec/lum/nrm textures." + [Environment]::NewLine
    $HelpDescription.SelectedText = "Existing material maps and/or materials are automatically handled when found." + [Environment]::NewLine
    $HelpDescription.SelectedText = "Optimize PNG file sizes using OptiPNG without breaking anything." + [Environment]::NewLine
    $HelpDescription.SelectedText = "Apply various upscaling filters to all textures including xBRZ and Waifu2x." + [Environment]::NewLine
    $HelpDescription.SelectionBullet = $false
  }
  elseif ($SelectedNode -eq 'TreeNode: Quick Guide')
  {
    $Text = "Quick Guide"
    $Text += "{0}{0}"
    $Text += "This section quickly explains how to get all features working without having to read anything else."
    $Text += "{0}{0}"
    $Text += "Step 1: Required Programs"
    $Text += "{0}{0}"
    $Text += "The two most important programs that are required are ImageMagick and DDS Utilities. These must be installed prior "
    $Text += "to launching the script."
    $Text += "{0}{0}"
    $Text += "ImageMagick: Used in almost every option of this script.{0}"
    $Text += "http://imagemagick.org/script/binary-releases.php#windows {0}{0}"
    $Text += "DDS Utilities: Required to create DDS textures and/or work with Internal MipMaps.{0}"
    $Text += "https://developer.nvidia.com/gameworksdownload#?dn=dds-utilities-8-31 "
    $Text += "{0}{0}"
    $Text += "Step 2: Optional Programs"
    $Text += "{0}{0}"
    $Text += "At this point almost everything the script can do will work except a few special features. These features do require "
    $Text += "additional tools that must be configured in the GUI options panel."
    $Text += "{0}{0}"
    $Text += "Ishiiruka Tool: Creates and works with material maps.{0}"
    $Text += "https://forums.dolphin-emu.org/Thread-unofficial-ishiiruka-dolphin-custom-version?pid=297815#pid297815 {0}{0}"
    $Text += "OptiPNG: Can reduce PNG file size.{0}"
    $Text += "http://optipng.sourceforge.net/ {0}{0}"
    $Text += "xBRZ ScalerTest: Upscales textures with xBRZ filter.{0}"
    $Text += "https://sourceforge.net/projects/xbrz/ {0}{0}"
    $Text += "Waifu2x: Upscales textures with waifu2x filter.{0}"
    $Text += "https://github.com/lltcggie/waifu2x-caffe/releases - use with Nvidia GPU {0}"
    $Text += "https://github.com/tanakamura/waifu2x-converter-cpp - use with AMD GPU"
    $Text += "{0}{0}"
    $Text += "Step 3: Done"
    $Text += "{0}{0}"
    $Text += "It's a pain to set up this many tools, but with great power comes great migraines, and only the Required Programs are... "
    $Text += "required. At this point all options of the script are fully unlocked, and it's possible to do what you will. I do suggest "
    $Text += "taking the time to read some of the other help topics as well, especially the 'Guides' section which goes into detail of "
    $Text += "how to perform some basic operations that most users will commonly want to perform.{0} "
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Quick Guide")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Step 1: Required Programs")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 11, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("ImageMagick:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("DDS Utilities:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Step 2: Optional Programs")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 11, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Ishiiruka Tool:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("OptiPNG:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("xBRZ ScalerTest:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Waifu2x:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Step 3: Done")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 11, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Information')
  {
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
    $HelpDescription.SelectedText = "Information" + [Environment]::NewLine
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10)
    $HelpDescription.SelectedText = [Environment]::NewLine
    $HelpDescription.SelectedText = "This section is a collection of random but useful information." + [Environment]::NewLine
    $HelpDescription.SelectedText = [Environment]::NewLine
    $HelpDescription.SelectionBullet = $true
    $HelpDescription.SelectedText = "BACKUP YOUR TEXTURE PACK. This script should be 100% safe but I do not want to be responsible for any issues that may occur." + [Environment]::NewLine
    $HelpDescription.SelectedText = "This script is compatible with PNG, DDS, and JPG packs, but it is suggested to resolve all issues with PNG textures before converting to other formats." + [Environment]::NewLine
    $HelpDescription.SelectedText = "When performing almost any Standard or Advanced option, pressing the 'Escape' button will cleanly cancel the current operation in progress." + [Environment]::NewLine
    $HelpDescription.SelectedText = "This script cannot be in a base path that contains an apostrophe or the ~ symbol or it will not work! Sub-folders may contain an apostrophe, however." + [Environment]::NewLine
    $HelpDescription.SelectedText = "It is possible to force the script to skip a folder and all of its containing subfolders by placing a ~ character in front of the folder name." + [Environment]::NewLine
    $HelpDescription.SelectedText = "There are two ways DDS Internal MipMaps are created with this script, and this affects whether or not most image editors will find these mipmaps." + [Environment]::NewLine
    $HelpDescription.SelectedText = "First method: image editors won't find them. If custom mipmaps are provided OR MipMap type is set to anything other than Internal (Both doesn't work)." + [Environment]::NewLine
    $HelpDescription.SelectedText = "Second method: image editors will find them. If DDS MipMap type is set to Internal AND no custom mipmaps exist, OR Force New MipMaps is enabled." + [Environment]::NewLine
    $HelpDescription.SelectedText = "DDS Utilities cannot generate textures with dimensions beyond 8192x4096 or 4096x8192. Larger textures will instead be created with ImageMagick. " + [Environment]::NewLine
    $HelpDescription.SelectedText = "JPG textures will not be created from PNG/DDS textures that have an alpha channel. The reason for this is JPG does not support transparency." + [Environment]::NewLine
    $HelpDescription.SelectedText = "DDS Ishiiruka textures are exclusive to Ishiiruka and do not work in almost anything else, including the master branch of Dolphin and all image editors." + [Environment]::NewLine
    $HelpDescription.SelectedText = "This script can use some trickery to convert these textures to a standard DDS format using a combination of Ishiiruka Tool, ImageMagick, and DDS Utilities. " + [Environment]::NewLine
    $HelpDescription.SelectedText = "If the script finds a DDS Ishiiruka color texture with a missing material, it will be 'repaired' using ImageMagick + Ishiiruka Tool to a compatible DDS format." + [Environment]::NewLine
    $HelpDescription.SelectionBullet = $false
  }
  elseif ($SelectedNode -eq 'TreeNode: Requirements')
  {
    $Text = "Requirements"
    $Text += "{0}{0}"
    $Text += "ImageMagick - ImageMagick is required, the script will not function without it.{0}"
    $Text += "DDS Utilities - Allows creating textures in DDS format.{0}"
    $Text += "Ishiiruka Tool - Creates materials from bump/spec/lum/nrm, or existing materials.{0}"
    $Text += "OptiPNG - Attempts to reduce the file size of PNG textures.{0}"
    $Text += "xBRZ ScalerTest - Allows upscaling textures with the xBRZ filter up to 6x.{0}"
    $Text += "waifu2x Caffe/CPP - Allows upscaling textures with the waifu2x filter up to 8x."
    $Text += "{0}{0}"
    $Text += "More details on these programs can be found in their corresponding help topics.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Requirements")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("ImageMagick")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("DDS Utilities")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Ishiiruka Tool")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("OptiPNG")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("xBRZ ScalerTest")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("waifu2x Caffe/CPP")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: ImageMagick')
  {
    $Text = "ImageMagick by ImageMagick Studio LLC"
    $Text += "{0}{0}"
    $Text += "http://imagemagick.org/script/binary-releases.php#windows"
    $Text += "{0}{0}"
    $Text += "Description:"
    $Text += "{0}{0}"
    $Text += "ImageMagick(r) is a software suite to create, edit, compose, or convert bitmap images. It can read and write images in a variety of formats (over 200) including PNG, JPEG, "
    $Text += "JPEG-2000, GIF, TIFF, DPX, EXR, WebP, Postscript, PDF, and SVG. Use ImageMagick to resize, flip, mirror, rotate, distort, shear and transform images, adjust image colors, "
    $Text += "apply various special effects, or draw text, lines, polygons, ellipses and B껩er curves."
    $Text += "{0}{0}"
    $Text += "Why it's needed:"
    $Text += "{0}{0}"
    $Text += "This is the meat and potatoes that makes this script possible. It supports command line processing and supports so many features that other image processing programs can't "
    $Text += "even begin to compare. This script makes use of it's ability to read data from PNG/JPG/DDS images and write PNG/JPG images. It is used for some of the lower tier upscaling "
    $Text += "filters such as 'Point' and 'Lancoz'. The Seamless Method when applying any upscaling filter and combining multiple textures is also made possible using ImageMagick's 'montage' "
    $Text += "ability. Applying watermarks to textures using the name is made possible using the 'paint' and 'composite' abilities. This doesn't even begin to cover how useful this program truly is.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("ImageMagick")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Description:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 11, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Why it's needed:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 11, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: DDS Utilities')
  {
    $Text = "DDS Utilities by Nvidia"
    $Text += "{0}{0}"
    $Text += "https://developer.nvidia.com/gameworksdownload#?dn=dds-utilities-8-31"
    $Text += "{0}{0}"
    $Text += "Description:"
    $Text += "{0}{0}"
    $Text += "A set of utilities for manipulating DDS image files, including: nvDXT, a command-line binary version of the nvDXT library, detach, a tool that extracts MIP levels from a "
    $Text += "DDS file, stitch, a tool that recombines MIP levels into a single DDS file and readDXT, which reads compressed images and writes TGA files."
    $Text += "{0}{0}"
    $Text += "Why it's needed:"
    $Text += "{0}{0}"
    $Text += "As great as ImageMagick is, it does not support the features required for this script when it comes to creating DDS files. DDS utilities provide everything that is needed "
    $Text += "to create images with DXT1 or DXT5 compression, combine custom mipmaps into a single texture, and extract internal mipmaps from DDS textures. ImageMagick in the past has "
    $Text += "had issues with creating DDS files with transparency (there was noticeable banding), and it cannot extract internal mipmaps or combine custom mipmaps.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("DDS Utilities")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Description:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 11, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Why it's needed:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 11, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Ishiiruka Tool')
  {
    $Text = "Ishiiruka Tool by Tino"
    $Text += "{0}{0}"
    $Text += "https://forums.dolphin-emu.org/Thread-unofficial-ishiiruka-dolphin-custom-version?pid=297815#pid297815"
    $Text += "{0}{0}"
    $Text += "Description:"
    $Text += "{0}{0}"
    $Text += "Since Ishiiiruka 436 support for normal mapping and phong lighting has been added. To Support this additional textures are required:{0}"
    $Text += "* Depth Texture: deviation distance from the plane. Values greater than 127 (byte) are above the surface. required for displacement mapping.{0}"
    $Text += "* -Name = <TextureID>.bump.extension"
    $Text += "* Normal Texture: normal map. Optional, if not present will be calculated from the bump texture.{0}"
    $Text += "* -Name = <TextureID>.nrm.extension{0}"
    $Text += "* Specular Texture : maps how polished is the surface of the material. A black (0) Texture will give as a result a opaque paper like material. White (255) will give a polished metallic like surface.{0}"
    $Text += "* -Name = <TextureID>.spec.extension{0}"
    $Text += "* Emissive Texture : maps the color of the light emitted by a material on every pixel on light emitting materials.{0}"
    $Text += "* -Name = <TextureID>.lum.extension{0}"
    $Text += "{0}"
    $Text += "But adding all this textures will take a huge hit in memory usage so I pack them in a single texture with the following format:{0}"
    $Text += "* Red Channel: Specular data 0-255 0=opaque 255=fully reflective specular exponent 64{0}"
    $Text += "* Green Channel: Normal Y component unsigned (reduced from [-1.0 1.0] to [0.0 1.0]){0}"
    $Text += "* Blue Channel: Bump map depth (reduced from [-1.0 1.0] to [0.0 1.0]){0}"
    $Text += "* Alpha Channel: Normal X component unsigned (reduced from [-1.0 1.0] to [0.0 1.0]){0}"
    $Text += "{0}"
    $Text += "This file has the .nrm sufix to make them compatible with raw normals to make testing easy.{0}"
    $Text += "{0}"
    $Text += "Why it's needed:"
    $Text += "{0}{0}"
    $Text += "Tino's material map format is proprietary to Dolphin Ishiiruka, so there isn't a tool in existence that can create these textures other than his Ishiiruka Tool. Fortunately "
    $Text += "he was very willing to add command line support so its functionality could be used with this script. {0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Ishiiruka Tool")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Description:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 11, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Why it's needed:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 11, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: OptiPNG')
  {
    $Text = "OptiPNG by cosmin and rctruta"
    $Text += "{0}{0}"
    $Text += "http://optipng.sourceforge.net/"
    $Text += "{0}{0}"
    $Text += "Description:"
    $Text += "{0}{0}"
    $Text += "OptiPNG is a PNG optimizer that recompresses image files to a smaller size, without losing any information. This program also converts external formats (BMP, GIF, PNM and TIFF) "
    $Text += "to optimized PNG, and performs PNG integrity checks and corrections."
    $Text += "{0}{0}"
    $Text += "Why it's needed:"
    $Text += "{0}{0}"
    $Text += "While it's not necessarily 'needed', this is a great program that can reduce the file size of PNG files and still keep 100% quality. The script will work fine without it, but "
    $Text += "any options that use OptiPNG will not be able to function."
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("OptiPNG")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Description:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 11, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Why it's needed:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 11, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: xBRZ ScalerTest')
  {
    $Text = "xBRZ ScalerTest by Zenju"
    $Text += "{0}{0}"
    $Text += "https://sourceforge.net/projects/xbrz/"
    $Text += "{0}{0}"
    $Text += "Description:"
    $Text += "{0}{0}"
    $Text += "xBRZ is a high-quality image upscaling filter for creating beautiful HD representations from low-resolution images."
    $Text += "{0}{0}"
    $Text += "Why it's needed:"
    $Text += "{0}{0}"
    $Text += "This tool is required to apply the xBRZ upscaling filter when using the option 'Apply Upscaling Filter to All Textures'.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("xBRZ ScalerTest")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Description:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 11, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Why it's needed:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 11, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Waifu2x')
  {
    $Text = "Waifu2x by nagadomi, -Caffe by lltcggie, -CPP by WL-Amigo/tanakamura"
    $Text += "{0}{0}"
    $Text += "https://github.com/lltcggie/waifu2x-caffe/releases {0}"
    $Text += "https://github.com/tanakamura/waifu2x-converter-cpp "
    $Text += "{0}{0}"
    $Text += "Description:"
    $Text += "{0}{0}"
    $Text += "Image Super-Resolution for Anime-style art using Deep Convolutional Neural Networks. And it supports photo."
    $Text += "{0}{0}"
    $Text += "Why it's needed:"
    $Text += "{0}{0}"
    $Text += "This tool is required to apply the Waifu2x upscaling filter when using the option 'Apply Upscaling Filter to All Textures'. Waifu2x-Caffe is most likely the better choice if "
    $Text += "the target system has a nvidia GPU. Waifu2x-CPP is preferable for AMD graphics card because they do not support CUDA, and CPP does support OpenCL which can speed up the upscaling "
    $Text += "process significantly. It should be noted that Waifu2x-CPP does have a higher failure rate at preserving transparency if images have few colors."
    $Text += "{0}{0}"
    $Text += "Although Waifu2x was designed to upscale anime art, it has proven to be extremely good at upscaling various game textures as well.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Waifu2x")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("-Caffe")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("-CPP")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Description:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 11, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Why it's needed:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 11, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Texture/Output Paths')
  {
    $Text = "Texture/Output Paths"
    $Text += "{0}{0}"
    $Text += "These folders default to the current location of the script. It is possible to save these paths when the script is closed by checking the box next to the path you want to save."
    $Text += "{0}{0}"
    $Text += "Texture Path:{0}"
    $Text += "This is the folder that contains the textures you wish to run through this script. This is usually a folder named by the GameID or the 3-digit equivalent."
    $Text += "{0}{0}"
    $Text += "Output Path:{0}"
    $Text += "Where CTT-PS will output generated files. When selecting the Texture Path, this will default to the same folder, but can be changed to anywhere. Selecting this "
    $Text += "folder will always append a '\~CTT_Generated' folder, which is where all the various output folders will be found after running one of the script's options."
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Texture/Output Paths")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Texture Path:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 11, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Output Path:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 11, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Process Selected')
  {
    $Text = "Process Selected"
    $Text += "{0}{0}"
    $Text += "This is a hidden option that allows processing a texture (or group of textures) that are manually selected by the user. To access this hidden option, simply "
    $Text += "highlight the desired 'Standard' option and hold the 'Control' key when pressing the 'Start' button."
    $Text += "{0}{0}"
    $Text += "Textures can be added to the array by simply dragging and dropping them onto the window or by clicking the window and manually adding them through the file browser. "
    $Text += "It only supports PNG, DDS, and JPG images. When two or more images are added to the array, the left and right 'Arrow' buttons can navigate through the list. This "
    $Text += "feature does have its limitations and will not work correctly with most 'Advanced' options."
    $Text += "{0}{0}"
    $Text += "By default, textures will be output to wherever the 'Output Path' points to. This can temporarily be changed on this option's window to output the textures to a different "
    $Text += "folder. This only changes the Output Path for the current run, and resets it back to its previous value when textures are processed or the window is closed."
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Process Selected")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Standard Options')
  {
    $Text = "Standard Options"
    $Text += "{0}{0}"
    $Text += "These can also be considered the 'Main' functions of this script. All standard options will output textures to wherever the 'Output Path' was selected, within the folder '\~CTT_Generated'. "
    $Text += "{0}{0}"
    $Text += "Standard options usually do not modify the texture pack directly, with the exception of the 'In-Place' options when using the 'Optimize PNG Textures "
    $Text += "With OptiPNG' or 'Create Material Maps With Ishiiruka Tool' functions.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Standard Options")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Scan Textures For Issues')
  {
    $Text = "Scan Textures For Issues"
    $Text += "{0}{0}"
    $Text += "Scans textures for issues and offers the ability to repair any 'broken' textures that are found. Several options are available to configure which issues "
    $Text += "are found and how repaired textures will be generated. Detailed information about these options can be found by hovering the mouse over them which displays "
    $Text += "a tooltip. Below is a list of all issues that can be found when scanning."
    $Text += "{0}{0}"
    $Text += "NotHD Texture: A texture with the original dimensions or lower.{0}"
    $Text += "Duplicate Texture: Multiple textures that contain the same name.{0}"
    $Text += "Dolphin Duplicate: Dolphin named duplicates with .1, .2, etc. suffixes.{0}"
    $Text += "Uneven Scale: Width and height were not scaled with the same factor.{0}"
    $Text += "Non-Integer Scale: The custom texture width or height was not scaled with an integer scale and contains a decimal value.{0}"
    $Text += "Bad Aspect Ratio: Original and custom texture contain a different aspect ratio.{0}"
    $Text += "MipMaps Missing: Detects any missing mipmap levels for mipmap [m] textures and lists the number of them missing.{0}"
    $Text += "MipMaps Bad Scale: Detects bad mipmap scales for [m] textures and lists the number of mipmaps with bad scaling values found.{0}"
    $Text += "Material Textures: Texture contains material textures (bump/spec/lum/nrm). Repairing the texture will create a material map.{0}"
    $Text += "Bad DDS Dimensions: When DDS texture dimensions do not match the best possible dimensions calculated from the original dimensions."
    $Text += "{0}{0}"
    $Text += "Several folders can be created when using this option to easily identify which textures have the issue in the pack, or if they were repaired."
    $Text += "{0}{0}"
    $Text += "BrokenTextures: Textures that are found with issues and were not repaired.{0}"
    $Text += "RepairedTextures: Textures that are found with issues but were repaired.{0}"
    $Text += "NotHDTextures: Textures that have the original dimensions or lower.{0}"
    $Text += "DuplicateTextures: Textures found that have the same name as other textures.{0}"
    $Text += "DolphinDuplicates: Textures found with the '.#' suffix appended by Dolphin.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Scan Textures For Issues")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("NotHD Texture:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Dolphin Duplicate:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Duplicate Texture:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Uneven Scale:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Non-Integer Scale:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Bad Aspect Ratio:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("MipMaps Missing:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("MipMaps Bad Scale:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Material Textures:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Bad DDS Dimensions:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("BrokenTextures:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("RepairedTextures:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("NotHDTextures:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("DuplicateTextures:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("DolphinDuplicates:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Rescale Textures At Fixed Integer')
  {
    $Text = "Rescale Textures At Fixed Integer"
    $Text += "{0}{0}"
    $Text += "This option rescales all textures with new dimensions, that are calculated from multiplying the 'Rescale Factor' by the texture's original dimensions. "
    $Text += "This means that this option completely ignores the 'current' dimensions of the custom texture as they have no use."
    $Text += "{0}{0}"
    $Text += "Textures can be created as PNG, DDS, JPG, or they can use the texture's existing file extension. Creating DDS textures requires a valid path to Nvidia DDS Utilities, or the "
    $Text += "DDS option will not appear in the drop down menu. A JPG texture is only created if the source texture does not contain any transparent pixels. In this case, the texture will instead "
    $Text += "be copied to the target pack so the finished pack is complete."
    $Text += "{0}{0}"
    $Text += "Enabling the option 'Manual Rescale' changes how this option works. When enabled, the Rescale Factor acts as a default scaling value and a prompt appears for each texture to rescale "
    $Text += "them individually from 1-100. If 0 is entered as the scale, the texture is effectively skipped. It is not suggested to use Manual Rescale on an entire texture pack, as it could take "
    $Text += "a very long time to manually rescale each texture individually. This option is most useful to rescale a handful of textures at different scales."
    $Text += "{0}{0}"
    $Text += "Textures generated with this option are output to a 'RescaledTextures' folder followed by the chosen file extension. If a file extension was not chosen, then the output "
    $Text += "folder will not contain one. After the rescaling process is finished, this folder can safely be renamed to the 3-digit GameID and used as a Dolphin texture pack.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Rescale Textures At Fixed Integer")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("'RescaledTextures'")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Convert Textures to Another Format')
  {
    $Text = "Convert Textures to Another Format"
    $Text += "{0}{0}"
    $Text += "This option (if possible) performs a 1:1 conversion of all textures to the chosen format. Creating DDS textures requires a valid path to Nvidia DDS Utilities, or the DDS option "
    $Text += "will not appear in the drop down menu. A JPG texture is only created if the source texture does not contain any transparent pixels. In this case, the texture will instead be "
    $Text += "copied to the target pack so the finished pack is complete."
    $Text += "{0}{0}"
    $Text += "Due to the nature of DDS files, some textures may end up with dimensions that are slightly off by 1-3 pixels compared to the source texture. This is because DDS dimensions must "
    $Text += "be a multiple of 4, which means that the texture may not always end up with a perfect integer upscale. Nothing can be done about this. Opaque textures are converted with DXT1 "
    $Text += "compression which is the smallest possible file size. Textures with transparency are converted with DXT5 compression."
    $Text += "{0}{0}"
    $Text += "The user may also choose to auto-repair textures by checking the 'Auto-Repair Dimensions' check box. This will ensure the texture has the most accurate dimensions, but there is "
    $Text += "the possibility it could screw up the dimensions if textures were purposely created with a bad integer scale. This option is not suggested for textures with very low scaling "
    $Text += "values even if it's not an integer scale. For example, if the texture is upscaled with a value of 1.80, there is a chance CTT-PS will use the '1' and the texture will end up with "
    $Text += "the original dimensions, meaning the dumped dimensions. Scale-Fix Threshold can round the value up, more information can be found on the options tool tip."
    $Text += "{0}{0}"
    $Text += "Textures generated with this option are output to a 'ConvertedTextures' folder followed by the chosen file extension. After the rescaling process is finished, this "
    $Text += "folder can safely be renamed to the 3-digit GameID and used as a Dolphin texture pack.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Convert Textures to Another Format")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("'ConvertedTextures'")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Create Material Maps With Ishiiruka Tool')
  {
    $Text = "Create Material Maps With Ishiiruka Tool"
    $Text += "{0}{0}"
    $Text += "Requires a valid path to Ishiiruka Tool which can be set in the Options panel."
    $Text += "{0}{0}"
    $Text += "Finds textures that have accompanying material textures (bump/spec/nrm/lum) and generates a material map (mat) from them. "
    $Text += "At this time, material maps are only usable by Dolphin Ishiiruka. These textures are capable of adding further graphical "
    $Text += "enhancements to the in-game textures such as bump map displacement using the bumpmap and normal map textures, and additional "
    $Text += "lighting effects using the specularity and luminance materials."
    $Text += "{0}{0}"
    $Text += "Older versions of Ishiiruka Tool generated the combined material as a normal map (nrm), but newer versions now generate the "
    $Text += "result with a new format (mat). I can only assume this is so Ishiiruka (nrms) were not confused with standard (nrms). It is "
    $Text += "important to always use the latest version of Ishiiruka Tool with this script as it relies on its behavior. Younger iterations "
    $Text += "of the tool suffer from bugs and some features may not be compatible. "
    $Text += "{0}{0}"
    $Text += "It is not required to use this option to generate material maps from material textures. Using any option that creates textures "
    $Text += "such as Scan + Repair, Rescale, and Convert will also generate material maps from any materials found. These options may be "
    $Text += "even better since it creates a full pack and they preserve the original materials in the base pack you are generating from. "
    $Text += "{0}{0}"
    $Text += "Textures generated with this option are output to a 'MaterialMaps' folder. It is also possible to generate material maps "
    $Text += "directly in the pack using the 'Create Materials In-Place' option. Do note that this will destroy the original materials! "
    $Text += "I do not suggest the in-place option because I believe in backups.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Create Material Maps With Ishiiruka Tool")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("'MaterialMaps'")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Add Identifying Watermark to All Textures')
  {
    $Text = "Add Identifying Watermark to All Textures"
    $Text += "{0}{0}"
    $Text += "Generates a watermark in the center of all textures that displays the texture name. The purpose of this option is to "
    $Text += "be able to easily identify where textures are located when loaded into a game. All textures will be created as PNG "
    $Text += "images with a minimum width of 256 pixels so the text is easily readable, and several options are available to configure "
    $Text += "the output. This option works with all supported formats (PNG/DDS/JPG)."
    $Text += "{0}{0}"
    $Text += "Note that DDS textures created with Ishiiruka Tool will require a valid path to Ishiiruka Tool to successfully create "
    $Text += "the watermark. If Ishiiruka Tool is not found, the texture will be generated as a black image that contains the watermark. "
    $Text += "This is still useful as it will still notify where the texture is in-game when loaded into Dolphin."
    $Text += "{0}{0}"
    $Text += "Textures generated with this option are output to a 'WatermarkTextures' folder.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Add Identifying Watermark to All Textures")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("'WatermarkTextures'")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Optimize PNG Textures With OptiPNG')
  {
    $Text = "Optimize PNG Textures With OptiPNG"
    $Text += "{0}{0}"
    $Text += "Requires a valid path to OptiPNG which can be set in the Options panel."
    $Text += "{0}{0}"
    $Text += "OptiPNG attempts to recompresses PNG files in order to shrink their file size by running a number of different tests "
    $Text += "and going with the best results. This script sets the number of OptiPNG tests to 3 by default, but can be configured "
    $Text += "with the corresponding option. There is a limit of 1-20 tests, as each test will significantly increase the time it "
    $Text += "takes to optimize a texture. It is not suggested to go above 5 tests at the most unless you want to run it for days."
    $Text += "{0}{0}"
    $Text += "Textures generated with this option are output to a 'OptimizedTextures' folder. Textures may also be created 'In-Place' "
    $Text += "which overwrites the unoptimized texture within the texture pack itself."
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Optimize PNG Textures With OptiPNG")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("'OptimizedTextures'")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Apply Upscaling Filter to All Textures')
  {
    $Text = "Apply Upscaling Filter to All Textures"
    $Text += "{0}{0}"
    $Text += "This option allows applying an upscaling filter to all textures. The output size of the filtered texture is calculated by "
    $Text += "multiplying the width/height of the texture by the entered 'Upscale Factor'. Several filters are available, and most of them "
    $Text += "are applied with ImageMagick. xBRZ requires the xBRZ ScalerTest, and Waifu2x requires either Caffe or CPP."
    $Text += "{0}{0}"
    $Text += "The resulting filtered texture dimensions cannot exceed 8192x8192. If they do, the script will automatically lower the "
    $Text += "Upscale Factor by 1 and try again. It will keep trying to find a lower value until it reaches 2, where it will then give "
    $Text += "up if 2 still yields dimensions above 8192x8192. This means the lowest resolution a texture can have is 4096x4096 if any "
    $Text += "filter is going to be applied. And at this resolution, the Upscale Factor will be reduced to 2."
    $Text += "{0}{0}"
    $Text += "One great feature that this script has is the 'Seamless Method'. This tiles a texture 9 times in a 3x3 grid, crops some "
    $Text += "percentage of the outer 8 tiles, applies the upscaling filter, and then crops whatever remains of the outer 8 tiles. This "
    $Text += "gives the upscaling filter neighboring pixels around the texture edges to work with so the resulting texture does not "
    $Text += "have visible seams when tiled in-game. This is obviously only useful for seamless textures, and it adds processing time, "
    $Text += "so when to apply this method and how much of the outer tiles are cropped before processing is configurable."
    $Text += "{0}{0}"
    $Text += "It should be noted that the Seamless Method does not break non-seamless textures. By default the method is set to 'Opaque' "
    $Text += "which means the Seamless Method is only applied to textures that don't have transparent pixels. The vast majority of seamless "
    $Text += "textures are used in game environments such as floors, walls, and skies. But this is not always true, so the option 'All' is "
    $Text += "available to force the Seamless Method on all textures even if they contain transparent pixels. It's also possible to disable "
    $Text += "the Seamless Method altogether if you are absolutely sure the textures you are upscaling are not seamless."
    $Text += "{0}{0}"
    $Text += "Waifu2x is unique in that it provides additional options. 'Conversion Mode' controls whether the texture is upscaled, denoised, "
    $Text += "or both. When 'Scale' is not present, the Upscale Factor is ignored. 'Noise Reduction' controls the amount of, umm, noise reduction. "
    $Text += "When using Waifu2x-Caffe, the maximum value is 3, but with Waifu2x-CPP, the maximum value is 2. 'Disable GPU' uses the host CPU "
    $Text += "rather than the GPU. This can be useful if the user wants to use Caffe with an AMD card, because Caffe only supports nvidia CUDA. "
    $Text += "Waifu2x-CPP offers the additional option 'Enable OpenCL' which allows AMD users to use the GPU, which is still not nearly as fast "
    $Text += "as CUDA, but is still much faster than using the CPU. "
    $Text += "{0}{0}"
    $Text += "Depending on your CPU, using 'Disable GPU' can be SLOW. Case in point, if your GPU is made by nvidia, use Waifu2x-Caffe. If your GPU "
    $Text += "is made by AMD, use Waifu2x-CPP and check 'Enable OpenCL'. The only time Disable GPU is useful is when using Caffe with an AMD card because "
    $Text += "Waifu2x-CPP is just not as developed as CPP. Don't get me wrong, CPP is great in 99% of cases, but it has the potential to ignore the "
    $Text += "texture's transparency and output it as black. This is 100% guaranteed when working on grayscale images, which has been fixed in Caffe."
    $Text += "{0}{0}"
    $Text += "Textures generated with this option are output to a 'FilteredTextures' folder followed by the chosen filter.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Apply Upscaling Filter to All Textures")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("'FilteredTextures'")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Advanced Options')
  {
    $Text = "Advanced Options"
    $Text += "{0}{0}"
    $Text += "Advanced options modify the texture pack directly, so caution should be used when using them. It is highly suggested to "
    $Text += "create a backup of your texture pack before using these options in case you do not get the desired effect! "
    $Text += "{0}{0}"
    $Text += "The options 'Combine Multiple Textures' and 'Split Combined Multi-Texture' are the exception to the rule as they output "
    $Text += "generated textures to the selected 'Output Path'{0}."
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Advanced Options")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Generate New MipMaps')
  {
    $Text = "Generate New MipMaps"
    $Text += "{0}{0}"
    $Text += "This option generates new mipmaps within the texture pack itself. Dynamic mipmaps are preserved unless the 'Force New Mipmaps' "
    $Text += "option is ticked. Care must be taken with this option as textures with incorrect dimensions will have incorrect mipmaps. If in "
    $Text += "doubt, use 'Scan Texture For Issues' and check 'Auto-Repair'. "
    $Text += "{0}{0}"
    $Text += "This option is only useful as a shortcut to creating new mipmaps when you are certain all textures have the correct dimensions.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Generate New MipMaps")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Remove Invalid MipMaps')
  {
    $Text = "Remove Invalid MipMaps"
    $Text += "{0}{0}"
    $Text += "Scans a texture pack for textures that contain external mipmap levels that are not actually a mipmap [m] texture and deletes them. "
    $Text += "This option can also detect invalid internal mipmaps that are stored within DDS textures and remove those as well."
    $Text += "{0}{0}"
    $Text += "Example: tex1_32x32_d0f9034aa0ff4873_14 is not a MipMap texture, but contains external MipMap levels..."
    $Text += "{0}{0}"
    $Text += "tex1_32x32_d0f9034aa0ff4873_14_mip1{0}"
    $Text += "tex1_32x32_d0f9034aa0ff4873_14_mip2{0}"
    $Text += "tex1_32x32_d0f9034aa0ff4873_14_mip3"
    $Text += "{0}{0}"
    $Text += "Because this is not a MipMap texture, these MipMap levels will be removed. If it were a mipmap texture, the name would contain "
    $Text += "an [m], as in the example:"
    $Text += "{0}{0}"
    $Text += "tex1_32x32_m_d0f9034aa0ff4873_14{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Remove Invalid MipMaps")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Remove Alpha Channel From Opaque Textures')
  {
    $Text = "Remove Alpha Channel From Opaque Textures"
    $Text += "{0}{0}"
    $Text += "Occasionally texture artists will create a fully opaque texture but mistakenly include an alpha channel. This adds "
    $Text += "unnecessary file size to the texture because an alpha channel is not required if there are no transparent pixels. "
    $Text += "This option will strip the alpha channel from the texture if there are no transparent pixels, reducing file size."
    $Text += "{0}{0}"
    $Text += "While this option works on both PNG and DDS textures, it is probably most useful on PNG textures. When using this "
    $Text += "script to convert to DDS using any option, the resulting texture already has its alpha channel removed if does not "
    $Text += "contain any transparent pixels, and it is converted with DXT1 compression.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Remove Alpha Channel From Opaque Textures")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Fix Textures Potentially Broken by OptiPNG')
  {
    $Text = "Fix Textures Potentially Broken by OptiPNG"
    $Text += "{0}{0}"
    $Text += "OptiPNG tends to store PNG data in a way that is unrecognisable by Dolphin if any color channel contains less than "
    $Text += "8-Bit depth, or if the texture contains indexed color space. This option checks for any textures that have less than "
    $Text += "8bpp in any channel or if they are indexed and recreates the texture using ImageMagick. This will not increase the "
    $Text += "color depth of each channel, so subsequent runs will also regenerate the texture (false positives). Less than 8bpp and "
    $Text += "indexed color space is usually okay in Dolphin, but since the broken textures are random, the script attempts to fix "
    $Text += "any textures that are found that match these conditions. "
    $Text += "{0}{0}"
    $Text += "This option is also capable of false positives, meaning a texture that was not actually optimized by OptiPNG will be "
    $Text += "'repaired' even if it would work in Dolphin. A bypass has been added to the script to no longer attempt to optimize "
    $Text += "these textures when running OptiPNG. In time this option will lose its usefulness (if it hasn't already), so it will "
    $Text += "only find use if OptiPNG was ran on textures externally from this script.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Fix Textures Potentially Broken by OptiPNG")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Combine Multiple Textures')
  {
    $Text = "Combine Multiple Textures"
    $Text += "{0}{0}"
    $Text += "Allows combining multiple textures into a single texture. This option is useful if the game has backgrounds or other "
    $Text += "types of textures that are composed of multiple textures in a grid. The grid in this option is defined by the number "
    $Text += "of rows and columns that are entered, so the total number of textures can be calculated by multiplying the number of "
    $Text += "rows * columns."
    $Text += "{0}{0}"
    $Text += "Using this option to combine textures will also generate a (.ctt) file along with the texture that can be used in the "
    $Text += "option below this one to resplit the texture and rename each individual texture back to their original names, even if "
    $Text += "it was retextured with different dimensions.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Combine Multiple Textures")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Split Combined Multi-Texture')
  {
    $Text = "Split Combined Multi-Texture"
    $Text += "{0}{0}"
    $Text += "This option can split large multi-textures into multiple smaller textures. The number of images created is determined "
    $Text += "by the number of rows and columns entered, and the dimensions are also calculated from these values. Width is calculated "
    $Text += "by dividing the texture's width by the number of columns, and height is calculated from dividing the textures height "
    $Text += "by the number of rows."
    $Text += "{0}{0}"
    $Text += "Each new texture that is created from the chosen texture will be named from that texture unless a (.ctt) file generated "
    $Text += "from 'Combine Multiple Textures' is selected. Do note that a (.ctt) file is not necessary to split textures.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Split Combined Multi-Texture")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Global Options')
  {
    $Text = "Global Options"
    $Text += "{0}{0}"
    $Text += "This set of options can be accessed by pressing the 'Options' button on the GUI. Depending on how these options are "
    $Text += "accessed also depends on which options are presented. The GUI now exposes most Internal Options in the feature they "
    $Text += "are used in, while the rest of them can now be found in this section."
    $Text += "{0}{0}"
    $Text += "Any options that are changed are stored within the CTT-PS (.ps1) file itself. When the script is exited, it is updated "
    $Text += "to store any changes made to the various options. Because there is no external database file containing these settings, "
    $Text += "it is possible to import these stored options from another version of CTT-PS using the 'Import Stored Options' feature. "
    $Text += "This exists so any personal options set can be saved from previous versions of the script and not have to be set all "
    $Text += "over again (such as the tool paths)."
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Global Options")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Tool Paths')
  {
    $Text = "Tool Paths"
    $Text += "{0}{0}"
    $Text += "Pretty self-explanatory, these are the paths to the programs that this script requires. When configuring a path, "
    $Text += "the executable file must be selected to set the new location to the tool. It is also possible to drag and drop either "
    $Text += "the executable (.exe) file onto the text box, or drag and drop the containing folder. When configuring the Waifu2x path "
    $Text += "from the GUI, a dropdown menu is available to select between the Caffe and CPP executables."
    $Text += "{0}{0}"
    $Text += "The exception is the 'Temp Folder'. This location is where CTT-PS will generate temporary textures. By default, this "
    $Text += "path is set to the user's 'AppData\Local\Temp' folder. It is possible some users may have trouble creating files here "
    $Text += "which is why the path is configurable. When the script is started, this path is tested to see if it can be written to "
    $Text += "and if it fails, CTT-PS will prompt the user to select a new TempFolder. "
    $Text += "{0}{0}"
    $Text += "No matter where the TempFolder is set to, it will go one directory deeper with a folder named 'CTT-PS_Temp'. This is to "
    $Text += "prevent destroying all files that are contained within this folder because CTT-PS completely wipes this folder out when "
    $Text += "it is done with it. I learned this the hard way.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Tool Paths")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Allow All Images')
  {
    $Text = "Allow All Images"
    $Text += "{0}{0}"
    $Text += "When CTT-PS finds an image, it verifies that the discovered image is a Dolphin texture by looking for the 'tex1' prefix "
    $Text += "within the texture's name. This allows a way for the script to separate Dolphin textures from all other image files. "
    $Text += "{0}{0}"
    $Text += "This is important because the pack may contain preview screenshots that the user wishes to copy into the new pack using "
    $Text += "the 'Copy Non-Textures' option when converting or rescaling textures. It's also important to know which images are Dolphin "
    $Text += "textures so that the original dimensions can be retrieved, and it can be identified whether or not it is a mipmap texture."
    $Text += "{0}{0}"
    $Text += "Enabling this option allows all images to pass the script's verification process whether it contains 'tex1' or not. Dolphin "
    $Text += "textures are still identified as Dolphin textures, but non-Dolphin images will now be able to be processed by all Standard "
    $Text += "Options except 'Scan Textures For Issues'. Non-Dolphin images will always pass all checks and fail the NotHD check because "
    $Text += "the 'original dimensions' are faked by setting them to the 'current dimensions'. "
    $Text += "{0}{0}"
    $Text += "Enabling this option works well enough that the script can be used for just about any texture project whether it be for "
    $Text += "Dolphin or someone's favorite PC game. Textures can be converted to other formats, optimized with OptiPNG, watermarks can "
    $Text += "be generated, and the various upscaling filters can be applied.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Allow All Images")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Force DDS DXT5')
  {
    $Text = "Force DDS DXT5"
    $Text += "{0}{0}"
    $Text += 'When DDS textures are created with "Rescale Textures at Fixed Integer" or "Convert Textures to Another Format", this option '
    $Text += "forces the compression type to DXT5. By default, the script will convert opaque textures (no transparent pixels) to DXT1 and "
    $Text += "textures that contain transparent pixels to DXT5."
    $Text += "{0}{0}"
    $Text += "DXT5 can result in higher quality textures than DXT1. Quality is maybe 0-10% better with DXT5, but usually the difference is "
    $Text += "nearly imperceivable. Also note that DXT5 textures are twice the size of DXT1, and DXT1 has slightly better performance. Use "
    $Text += "this option if you want the absolute best texture quality at the sacrifice of opaque textures being 2x the file size."
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Force DDS DXT5")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Disable Log File')
  {
    $Text = "Disable Log File"
    $Text += "{0}{0}"
    $Text += "Does exactly what it says. It's not suggested to disable the log file when running the 'Scan Textures For Issues' option "
    $Text += "as it relies on the log file to create a list of issues. The issues that are found will still be printed to the PowerShell "
    $Text += "console, but the console is not nearly as organized, nor is it a permanent list that can be referenced.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Disable Log File")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Material Map Format')
  {
    $Text = "Material Map Format"
    $Text += "{0}{0}"
    $Text += "This option configures how the script handles Ishiiruka material maps. Ishiiruka Tool creates DDS color textures in a "
    $Text += "format that is not compatible with the master branch of Dolphin. It is possible to use this option to convert these "
    $Text += "color textures into a DDS format that does work with the master branch of Dolphin. "
    $Text += "{0}{0}"
    $Text += "Ishiiruka: Generate material maps from existing ones (mat/nrm) or from any material textures (bump/spec/nrm/lum) that "
    $Text += "are found. If the output format is set to DDS, color textures will only work with Ishiiruka and not Dolphin."
    $Text += "{0}{0}"
    $Text += "Dolphin: Convert DDS color textures generated with Ishiiruka Tool to a Dolphin compatible format. While in this mode,"
    $Text += "material map textures will not be created at all even if the output format is set to PNG."
    $Text += "{0}{0}"
    $Text += "Although it should be obvious I'll say it anyway, this requires a valid path to Ishiiruka Tool to be able to convert the "
    $Text += "textures to a Dolphin compatible format.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Ishiiruka:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Dolphin:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Material Map Format")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: CTT-PS Options')
  {
    $Text = "CTT-PS Options"
    $Text += "{0}{0}"
    $Text += "This set of options can only be found on the GUI, and can be accessed by pressing the 'Options' button. These options "
    $Text += "configure aspects of CTT-PS only, and do not affect texture generation in any way."
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("CTT-PS Options")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: PS Double Click')
  {
    $Text = "PS Double Click"
    $Text += "{0}{0}"
    $Text += "Allows opening PowerShell scripts with a double click rather than having to right click it and selecting the 'Run with "
    $Text += "Powershell' option. Toggling this option makes a small change to the Windows registry, but I assure you that it's 100% "
    $Text += "safe to do this. If you fear that this will screw up your computer, or that I'm up to no good, then just ignore that this "
    $Text += "option even exists and keep doing things the hard way. "
    $Text += "{0}{0}"
    $Text += "I'll explain how it works. When the GUI is created on startup, the value in the registry that controls how PowerShell scripts "
    $Text += "are executed is checked, and the GUI checkbox is created with the value's current state. When the checkbox is toggled, the "
    $Text += "registry state is checked once again. Depending on the state, a small registry script is generated into the TempFolder and is "
    $Text += "executed in 'Silent' mode so it does not interfere with the user. This generated script simply reverses the current state of "
    $Text += "the registry setting and is then removed from the TempFolder."
    $Text += "{0}{0}"
    $Text += "And that's all it does. It does not affect any other values or modify anything else. If you don't believe me, check the code. "
    $Text += "PowerShell code isn't exactly hidden away in a compiled state.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("PS Double Click")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Disable Top-Most')
  {
    $Text = "Disable Top-Most"
    $Text += "{0}{0}"
    $Text += "This option determines whether or not CTT-PS GUI will stay over top of other windows even while it is not the active window.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Disable Top-Most")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Always Show Console')
  {
    $Text = "Always Show Console"
    $Text += "{0}{0}"
    $Text += "Pretty self explanatory. When enabled, the PowerShell console is always visible. This is useful when running any option because "
    $Text += "the information from the last loop will remain visible until another option is ran or the script is closed. When disabled, it "
    $Text += "will hide the PowerShell console window while the GUI is visible, and only display it when a loop is in progress."
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Always Show Console")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: More Console Colors')
  {
    $Text = "More Console Colors"
    $Text += "{0}{0}"
    $Text += "Enables additional colors on the Powershell console when processing textures. The additional colors should help differentiate "
    $Text += "message headers from relevant output. If users don't like colors, this can be disabled."
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("More Console Colors")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Enable Stored Options')
  {
    $Text = "Enable Stored Options"
    $Text += "{0}{0}"
    $Text += "When the script is closed, any options that were changed are saved to the script file itself. This feature can be disabled "
    $Text += "by unchecking this option so that changes are forgotten between runs.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Enable Stored Options")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Restore Defaults')
  {
    $Text = "Restore Defaults"
    $Text += "{0}{0}"
    $Text += "When CTT-PS is closed, the script file (.ps1) is updated to permanently store any options that were changed by the user. "
    $Text += "This option will reset the values of all options to their default values. It should be noted that this option does not "
    $Text += "reset any paths to external tools."
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Restore Defaults")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Import Stored Options')
  {
    $Text = "Import Stored Options"
    $Text += "{0}{0}"
    $Text += "When CTT-PS is closed, the script file (.ps1) is updated to permanently store any options that were changed by the user. "
    $Text += "This option allows importing Stored Options from another version of Custom Texture Tool PS by simply selecting the script "
    $Text += "(.ps1) file. It should work on any version of the PowerShell versions of the script. This feature exists to retain option "
    $Text += "settings in future versions of this script, and not have to reset them every single time."
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Import Stored Options")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Guides')
  {
    $Text = "Guides"
    $Text += "{0}{0}"
    $Text += "Okay I get it. This tool has way too many options for something as simple as creating images right? Well I can agree that "
    $Text += "maybe I went over the top in some cases, but I feel like every option included is necessary to personally tweak a texture "
    $Text += "pack to get the best possible results. And to be honest, this tool is still very limited, there is no replacing an artist's "
    $Text += "personal touch. There is only so much that can be done to automate the creation of art. "
    $Text += "{0}{0}"
    $Text += "These guides are aimed at some of the more general operations that most users will seek this tool for, such as creating DDS "
    $Text += "textures, rescaling textures, or creating material maps. Some guides may read more like a tutorial, while others are just a "
    $Text += "general information section. Hopefully the guides can help where the rest of this already bloated help section fails to.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Guides")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Creating DDS Packs')
  {
    $Text = "Creating DDS Packs"
    $Text += "{0}{0}"
    $Text += "Because there is no way to create a tool to work perfectly with all Dolphin texture packs by default, there are a number "
    $Text += "of options available to tweak and try to get the best results. There are several programs that can generate DDS files from "
    $Text += "PNG/JPG files, but they do not offer enough options to fit all edge cases of Dolphin textures. This guide offers step-by-step "
    $Text += "instructions of how to convert a PNG/JPG pack to DDS. I can only assume ImageMagick and DDS Utilities are installed."
    $Text += "{0}{0}"
    $Text += "(1:) Set the 'Texture Path' field to the texture pack root folder.{0}"
    $Text += "(2:) (Optional) Set the 'Output Path' to wherever you want to create textures.{0}"
    $Text += "(3:) Choose the Standard Option 'Convert Textures to Another Format'.{0}"
    $Text += "(4:) Set the 'Output Format' to DDS. This requires DDS Utilities.{0}"
    $Text += "(5:) Enter the first 3 digits of the GameID into the 'Auto-Rename Output' field.{0}"
    $Text += "(6:) Press the Start button to start converting.{0}"
    $Text += "(7:) Wait for the script to finish converting textures. This can take some time!{0}"
    $Text += "(8:) Find the new pack in the '~CTT_Generated' folder.{0}"
    $Text += "(9:) If this pack exists in 'C:\User\Documents\Dolphin Emulator\Load\Textures' then remove it and move in the newly "
    $Text += "generated/renamed pack."
    $Text += "{0}{0}"
    $Text += "And you should be finished. All information beyond this point is gravy."
    $Text += "{0}{0}"
    $Text += "Notice: Material map exists, but path to Ishiiruka Tool not found! {0}"
    $Text += "This means the texture pack was designed for Dolphin Ishiiruka, and requires Ishiiruka Tool to convert these textures. "
    $Text += "See the 'Quick Guide' help topic for a link and how to locate it within the script. Also see the 'Material Map Format' "
    $Text += "sub-section within the 'Global Options' section for more info. For example the Legend of Zelda: Twilight Princess 4K "
    $Text += "pack contains material map textures."
    $Text += "{0}{0}"
    $Text += "When should I change the 'DDS MipMap Type' option? {0}"
    $Text += "In all cases, 'External' will work with all Dolphin versions. If generating a personal pack for Ishiiruka, the option "
    $Text += "'Internal' can be used. If creating a public pack for the best compatibility, 'Both' can be used but it is not suggested "
    $Text += "because this will increase the size of the pack by nearly double for all mipmap textures. "
    $Text += "{0}{0}"
    $Text += "Should I use the 'Force New MipMaps' option? {0}"
    $Text += "It's not really necessary for straight converting, the script will automatically create any missing mipmaps. If a pack "
    $Text += "contains dynamic mipmaps, meaning different images on descending mipmap layers and you don't like them, then this option "
    $Text += "can be useful to replace those layers with the same image on all layers. For example the Xenoblade Chronicles pack contains "
    $Text += "several dynamic mipmaps. "
    $Text += "{0}{0}"
    $Text += "And what about this 'Auto-Repair Dimensions' option? {0}"
    $Text += "This is actually a very useful feature, and I would love to enable it by default but it has the potential to break some "
    $Text += "texture packs. In almost all cases, this option 'should' be enabled. This option can correct common mistakes made by texture "
    $Text += "artists such as not creating textures with an integer scale, or textures having slightly bad aspect ratios. It can break some "
    $Text += "texture packs if the custom textures are not much larger than the original textures, or if the aspect ratios are purposely "
    $Text += "distorted to achieve some effect. An example is the Tales of Symphonia pack.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Creating DDS Packs")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Notice: Material map exists, but path to Ishiiruka Tool not found!")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("When should I change the 'DDS MipMap Type' option?")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Should I use the 'Force New MipMaps' option?")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("And what about this 'Auto-Repair Dimensions' option?")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Rescaling Packs')
  {
    $Text = "Rescaling Packs"
    $Text += "{0}{0}"
    $Text += "This guide covers how to rescale all textures within a texture pack. In most cases, the purpose of doing this is to downscale "
    $Text += "a texture pack that contains very large textures, and the user's system struggles to keep solid frame rates or experiences a "
    $Text += "significant amount of 'stutter'. This option takes a 'Rescale Factor' which is then multiplied by the texture's original dimensions "
    $Text += "to calculate the new dimensions."
    $Text += "{0}{0}"
    $Text += "(1:) Set the 'Texture Path' field to the texture pack root folder.{0}"
    $Text += "(2:) (Optional) Set the 'Output Path' to wherever you want to create textures.{0}"
    $Text += "(3:) Choose the option 'Rescale Textures at Fixed Integer'.{0}"
    $Text += "(4:) Set the 'Rescale Factor'. A value of 4 is fine for 1080p.{0}"
    $Text += "(5:) Set the 'Output Format' to DDS.{0}"
    $Text += "(6:) Set 'Allowed Scaling' to Downscale so small textures are not upscaled.{0}"
    $Text += "(7:) Enter the first 3 digits of the GameID into the 'Auto-Rename Output' field.{0}"
    $Text += "(8:) Press the Start button to start rescaling.{0}"
    $Text += "(9:) Wait for the script to finish rescaling textures. This can take some time!"
    $Text += "(10:) Find the new pack in the '~CTT_Generated' folder.{0}"
    $Text += "(11:) If this pack exists in 'C:\User\Documents\Dolphin Emulator\Load\Textures' then remove it and move in the newly "
    $Text += "generated/renamed pack."
    $Text += "{0}{0}"
    $Text += "And you should be finished. All information beyond this point is gravy."
    $Text += "{0}{0}"
    $Text += "Notice: Material map exists, but path to Ishiiruka Tool not found! {0}"
    $Text += "This means the texture pack was designed for Dolphin Ishiiruka, and requires Ishiiruka Tool to convert these textures. "
    $Text += "See the 'Quick Guide' help topic for a link and how to locate it within the script. Also see the 'Material Map Format' "
    $Text += "sub-section within the 'Global Options' section for more info. For example the Legend of Zelda: Twilight Princess 4K "
    $Text += "pack contains material map textures."
    $Text += "{0}{0}"
    $Text += "When should I change the 'DDS MipMap Type' option? {0}"
    $Text += "In all cases, 'External' will work with all Dolphin versions. If generating a personal pack for Ishiiruka, the option "
    $Text += "'Internal' can be used. If creating a public pack for the best compatibility, 'Both' can be used but it is not suggested "
    $Text += "because this will increase the size of the pack by nearly double for all mipmap textures. "
    $Text += "{0}{0}"
    $Text += "Should I use the 'Force New MipMaps' option? {0}"
    $Text += "It's not really necessary for straight converting, the script will automatically create any missing mipmaps. If a pack "
    $Text += "contains dynamic mipmaps, meaning different images on descending mipmap layers and you don't like them, then this option "
    $Text += "can be useful to replace those layers with the same image on all layers. For example the Xenoblade Chronicles pack contains "
    $Text += "several dynamic mipmaps. "
    $Text += "{0}{0}"
    $Text += "And what is this 'Manual Rescale' option? {0}"
    $Text += "For most users, this option has little to no use, and is geared towards texture artists. This allows rescaling a folder "
    $Text += "full of textures one by one, setting the 'Rescale Factor' individually for each texture. There may be very little value "
    $Text += "in this option, I myself have only found a use for it twice when working on the Xenoblade Chronicles texture pack when "
    $Text += "modifying BrunoFBK's textures and when working on some of my own textures.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Rescaling Packs")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Notice: Material map exists, but path to Ishiiruka Tool not found!")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("When should I change the 'DDS MipMap Type' option?")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Should I use the 'Force New MipMaps' option?")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("And what is this 'Manual Rescale' option?")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: MipMap Information')
  {
    $Text = "MipMap Information"
    $Text += "{0}{0}"
    $Text += "Mipmap textures are a collection of images that in most cases, represent the same image at a progressively lower resolution. It may be easier to "
    $Text += "view them as a cascade of progressively shrinking 'layers' with the top layer having the highest resolution, and the bottom layer having the "
    $Text += "lowest resolution. Each descending layer is half of the resolution of the previous layer, usually all the way down to a resolution of 1x1."
    $Text += "{0}{0}"
    $Text += "An example would be an image with the resolution of 64x64. This is the 'top layer'. The next layer down would contain a 32x32 version of the "
    $Text += "same image. Moving down one more layer reveals a 16x16 version of the same image. This cascade usually continues all the way down to the lowest "
    $Text += "layer which contains an image that is 1x1, but in some cases mipmap levels end at 8x8 or 4x4. It's up to the artist/developer."
    $Text += "{0}{0}"
    $Text += "Mipmaps serve several purposes. For one, they reduce hardware requirements when rendering a scene. Suppose the scene is of a field that uses a "
    $Text += "grass texture that is visible from the camera's base and extends all the way to the horizon. As the distance from the camera increases, the "
    $Text += "renderer can make use of these additional mipmap layers. Each descending layer means less pixels to sample when an actual screen pixel is "
    $Text += "calculated which reduces hardware requirements. "
    $Text += "{0}{0}"
    $Text += "In the same scenario as above, mipmaps provide a reduced level of detail which adds to the perception of 'realism'. The farther the grass is "
    $Text += "from the focal point, less detail should be apparent. As you gaze down the street, you will notice the amount of perceivable detail in the road "
    $Text += "decreases such as the granularity, cracks, pebbles, etc. The reduced image quality of additional mipmap layers makes for a more convincing "
    $Text += "reduction in the level of detail in 3-Dimensional world. "
    $Text += "{0}{0}"
    $Text += "Mipmaps come in many forms. Some of us in the Dolphin community have developed our own terminology for them to help distinguish between the "
    $Text += "different forms they come in, so these are not 'official' terms in any way. But basically, the 3 types of mipmaps that I will explain here "
    $Text += "have been dubbed: External Mipmaps, Internal MipMaps, and Dynamic MipMaps. "
    $Text += "{0}{0}"
    $Text += "External MipMaps: The PNG format can only store a single image, so the additional layers of mipmaps must come from additional images. If the "
    $Text += "image requires 12 additional layers of mipmaps, then the collection will entail of 13 images in total. The largest image is commonly referred "
    $Text += "to as the 'top layer' or 'top level', and the additional layers are commonly referred to as the 'lower levels' or 'lower layers'. External "
    $Text += "mipmaps are not limited to the PNG format. These can be found in any format such as DDS, TGA, JPG, BMP, etc. But for Dolphin, PNG and DDS are "
    $Text += "the most common."
    $Text += "{0}{0}"
    $Text += "Internal MipMaps: These types of mipmaps are exclusive to the DDS format. DDS textures are capable of storing all layers of mipmaps within a "
    $Text += "single DDS file. This has the advantage that it makes for a much more organized texture pack. The drawback is that at this time, the master "
    $Text += "branch of Dolphin can not make use of them. Tino has added support for internal mipmaps for Dolphin Ishiiruka however, so if the texture pack "
    $Text += "is only to be used with Ishiiruka, then it can take advantage of DDS internal mipmaps. "
    $Text += "{0}{0}"
    $Text += "Dynamic MipMaps: These types of mipmaps contain variations of the same image on descending layers, but are not necessarily the exact image. "
    $Text += "Texture artists make use of dynamic mipmaps to add additional effects through textures, usually lighting. It is not a common practice, but "
    $Text += "these textures do exist so they are worth mentioning because it is why this script does not force new mipmaps by default. As of now, only the "
    $Text += "Xenoblade Chronicles pack contains them. It might not be obvious, but dynamic mipmaps can be either external or internal.{0}"
    $Text += "{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("MipMap Information")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("External MipMaps:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Internal MipMaps:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Dynamic MipMaps:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Ishiiruka Tool and Material Maps')
  {
    $Text = "Ishiiruka Tool and Material Maps"
    $Text += "{0}{0}"
    $Text += "A big thanks goes to Tino for supporting command line in his tool, and adding a few options that made integration into "
    $Text += "this script possible. I will categorize materials into two types: combined and uncombined. Uncombined materials can consist "
    $Text += "of a color texture, a normal map (.nrm), a bump map (.bump), a specularity map (.spec), and an emissive map (.lum). A combined "
    $Text += "material is a type of texture that is created with Ishiiruka Tool from the uncombined textures, also known as a material map. "
    $Text += "{0}{0}"
    $Text += "Combined materials can have one of two types of accompanying color textures: the standard format, or if it was generated with a "
    $Text += "(.lum) texture, the emissive data will be stored in the alpha channel and the texture will be named with (_lum) suffix."
    $Text += "{0}{0}"
    $Text += "The script must know where Ishiiruka Tool is located. If 'TextureEncoder.exe' is not found when the script finds material "
    $Text += "textures or combined material maps, a 'Notice' message will be displayed in the PowerShell console. The location of Ishiiruka "
    $Text += "Tool can be selected within the 'Options' panel."
    $Text += "{0}{0}"
    $Text += "To create a material map, a color texture, a bump map, and specularity map is required. The color texture is just your normal "
    $Text += "everyday texture that you wish to apply affects to with materials. If a normal map is not provided, it will be calculated from "
    $Text += "the bump map texture. The emissive texture is also optional, and is not required to generate a combined material. All material "
    $Text += "textures must be in the same folder, including the color texture because Ishiiruka Tool looks for them together. "
    $Text += "{0}{0}"
    $Text += "Combing Materials into a Material Map"
    $Text += "{0}{0}"
    $Text += "There are several options in this script that can create material maps from uncombined materials. Depending on the option selected "
    $Text += "depends on how and where the material map will be created."
    $Text += "{0}{0}"
    $Text += "(1.) Scan Textures For Issues: The 'Attempt Repairs' checkbox must also be ticked. This option sees uncombined materials as "
    $Text += "an 'issue' that can be 'fixed' so it creates the material map. The materials from the source pack will remain in-tact, and "
    $Text += "the combined material map will be created in the 'RepairedTextures' output folder. "
    $Text += "{0}{0}"
    $Text += "(2.) Convert Textures to Another Format: The script will automatically create material maps from uncombined materials in the "
    $Text += "newly generated pack. The materials from the source pack will remain in-tact, and the combined material map will be created in "
    $Text += "the 'ConvertedTextures' output folder. "
    $Text += "{0}{0}"
    $Text += "(3.) Rescale Textures at Fixed Integer: Like the convert textures option, it will create material maps from any uncombined "
    $Text += "materials that are found. Depending on the 'Rescale Factor' set, all material textures will be rescaled at the calculated "
    $Text += "resolution before being combined into a material map. The materials from the source pack will remain in-tact, and the "
    $Text += "combined material map will be created in the 'RescaledTextures' output folder. "
    $Text += "{0}{0}"
    $Text += "(4.) Create Material Maps With Ishiiruka Tool: This option exists if all you want to do is create material maps. This can be "
    $Text += "done directly with the Ishiiruka Tool GUI. Whether or not this tool is used or Ishiiruka Tool is used directly is a matter of "
    $Text += "personal preference. The Ishiiruka Tool GUI offers more options which are automated in Custom Texture Tool PS. The materials "
    $Text += "from the source folder will remain in-tact, and the combined material maps will be created in the 'MaterialMap' output folder. "
    $Text += "There also exists an option to create the materials 'in-place', but this option destroys the original materials. "
    $Text += "{0}{0}"
    $Text += "Working With Combined Material Maps"
    $Text += "{0}{0}"
    $Text += "There was a time when working with an already combined material map wasn't possible. Once the materials were combined that was "
    $Text += "it, there was nothing else that could be done with it. Image editors have no idea what it is. Thanks to Tino and my relentless "
    $Text += "(and most likely annoying) demands, it is now possible to work with already combined material maps using Ishiiruka Tool.  "
    $Text += "{0}{0}"
    $Text += "I have extended the capabilities by throwing in ImageMagick and DDS Utilities which is capable of converting Ishiiruka DDS color "
    $Text += "textures into either PNG or a DDS format that most image editors will once again recognize. Combined materials in this script can"
    $Text += "be converted to other formats when asked, and rescaled with new dimensions using the rescaling option. Other than that, not much "
    $Text += "else can be done with them. Most other options will just ignore they exist. It is possible to generate watermarks on the color "
    $Text += "texture, but the material map will be discarded since watermarks are only used for identification. "
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Ishiiruka Tool and Material Maps")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 13, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Combing Materials into a Material Map")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 12, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Scan Textures For Issues:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Convert Textures to Another Format:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Rescale Textures at Fixed Integer:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Create Material Maps With Ishiiruka Tool:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Working With Combined Material Maps")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 12, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: Credits')
  {
    $Text = "Credits"
    $Text += "{0}{0}"
    $Text += "I like to give credit where credit is deserved. Truth is, even though I am the sole creator of this script, it would not have come this far without the "
    $Text += "testing and ideas of others that helped shape it into what it is today."
    $Text += "{0}{0}"
    $Text += "Bighead: The creator. Writes terrible code that kind of works.{0}"
    $Text += "Dolphin Devs: All of you are awesome for this emulator!{0}"
    $Text += "ImageMagick Team: ImageMagick is amazing and makes this script possible.{0}"
    $Text += "Nvidia: DDS Utilities is perfect, simple but useful features other programs lack.{0}"
    $Text += "degasus: Planted the initial idea for this script into my head.{0}"
    $Text += "frozenwings: Personally tested dozens of early versions until I started to get it.{0}"
    $Text += "Tino: Ishiiruka Tool command line support. Thanks Tino!{0}"
    $Text += "Zenju: Added command line to the xBRZ ScalerTest, without hesitation!{0}"
    $Text += "uncleiroh: Created the initial idea of putting watermarks on textures.{0}"
    $Text += "MeleeHD: Alerted me of uncleiroh's idea of watermarks.{0}"
    $Text += "StripTheSoul: Inadvertently gave me the idea to support OptiPNG.{0}"
    $Text += "masterotaku: Gave me the idea to implement upscaling filters.{0}"
    $Text += "TheCrach: Requested progress indication which led to the title bar progress.{0}"
    $Text += "CyberGlitch: Solely responsible for the idea behind the Seamless Method.{0}"
    $Text += "Admentus: Alerted and helped me test out an issue with decimals as commas.{0}"
    $Text += "DarthVitrial: Always reminded me to get ImageMagick v7 to work.{0}"
    $Text += "BennyAlex98: Idea for saving texture/output paths and waifu2x model select.{0}"
    $Text += "CTCaer: Motivated me to add the option to force DXT5 for DDS textures.{0}"
    $Text += "Dolphin Community: The feedback and testing is much appreciated and helped motivate me to improve it! Thanks to anyone I failed to mentioned.{0}"
    $Text += "CTT-PS Current Icon: http://icons.mysitemyway.com{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Credits")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 12, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Bighead:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Dolphin Devs:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("ImageMagick Team:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Nvidia:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("degasus:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("frozenwings:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Tino:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Zenju:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("uncleiroh:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("MeleeHD:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("StripTheSoul:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("masterotaku:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("TheCrach:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("CyberGlitch:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Admentus:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("DarthVitrial:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("BennyAlex98:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("CTCaer:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("Dolphin Community:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
    $HelpDescription.Find("CTT-PS Current Icon:")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10, [Drawing.FontStyle]::Bold)
  }
  elseif ($SelectedNode -eq 'TreeNode: About')
  {
    $Text =  "Custom Texture Tool PS - The Beginning to the End"
    $Text += "{0}{0}"
    $Text += "Just want to say this first, it is not important to read this section. At all. This section exists only to tell the story of why this tool came to exist and the struggle "
    $Text += "that was involved in making it what it is today. If you don't care, then it's safe to just skip it completely and spend your time doing something far more productive."
    $Text += "{0}{0}"
    $Text += "But if you do care, then I have to say I'm touched. Grab yourself a drink and a snack, and get settled in because it's story time..."
    $Text += "{0}{0}"
    $Text += "In what seems like forever ago, this kind of started as a simple batch script to simply generate mipmaps. Basic stuff. I have written batch scripts before because I love to automate "
    $Text += "monotonous tasks, and I've also scripted custom scenarios in Blizzard games dating back to StarCraft/WarCraft III (anyone remember Hydra RaNcHeRz or Wintermaul Wars TE?). I have "
    $Text += "never attempted to learn a programming language so I've always been limited in what I can do, so I never attempted anything major. That is, until this script. If you can even call it 'major'."
    $Text += "{0}{0}"
    $Text += "So Dolphin emulator had this huge issue with the previous texture format when it came to paletted textures. If the texture lookup table changed, then the dumped texture hash "
    $Text += "(Name/ID) also changed. This wasn't a big problem for many games, but it was for Xenoblade Chronicles, and I was heavily invested in the texture pack. Many textures in that game dumped "
    $Text += "100s to even 1000s of times: meaning if you want that texture to be re-textured at all times, you must find every possible hash. One of my fellow contributors to the pack (frozenwings) "
    $Text += "who has evolved into a dear friend of mine made it his mission to find every possible hash for the Europe version of the game. After I got bored of making textures for awhile, I joined "
    $Text += "him in his quest and started dumping the USA version of the game. Nearly 100k textures later for both versions of the game, we realized that like Pokemon, its nearly impossible to "
    $Text += "catch them all."
    $Text += "{0}{0}"
    $Text += "So what does this have to do with this script? Well during that period I worked on a few batch scripts for us that made creating duplicates of those textures a much, much "
    $Text += "simpler task. My script would take a 'base' re-texture, search for all dumps within the folder with that base, and create clones of that base using the dumped names. After "
    $Text += "it was finished, all the dumps were deleted and we were left with a pile of re-textures ready to ship. I think by the end there ended up being near or over 120 base folders "
    $Text += "and often we would find ourselves filling each folder with 100s even 1000s of dumps to clone. By the end of it all, the pack size started climbing into the Gigabytes all the "
    $Text += "while nothing new was really being added. But a lot of good came from this, I did get much better at writing batch scripts and understanding a ton of new concepts."
    $Text += "{0}{0}"
    $Text += "Eventually after wishing upon a star for almost 2 years, degasus took notice and introduced the new texture format that finally eliminated the issue with duplicate paletted textures. We rejoiced "
    $Text += "and revered him as some kind of messiah for making our dreams come true and finally putting an end to our pain. This meant all the work we put into dumping ended up being for naught. "
    $Text += "But I do like to think it made a great example that there was something very wrong with Dolphin in the first place. I had very little to do with this new format outside of testing the "
    $Text += "shit out of it and making the suggestion to flag mipmap textures with an [m] so they can easily be identified. Because I had a lot of free time and actually understood enough that I "
    $Text += "felt I could educate others, I created a post on the forums that explained the new custom texture format, which now exists today as a sticky labelled 'Dolphin Custom Textures Info'. "
    $Text += "{0}{0}"
    $Text += "Some time into that thread, degasus says: @Bighead: As you like scripting, do you think it's worth to have a script which check all textures and warn if{0}"
    $Text += "- the upscaling factor isn't an integer{0}"
    $Text += "- the aspect ratio is changed{0}"
    $Text += "- mipmaps have wrong size{0}"
    $Text += "- mipmaps aren't complete{0}"
    $Text += "- ... "
    $Text += "{0}{0}"
    $Text += "So this is where this tool really began. At first I wasn't really all that confident that I was capable of doing even those simple tasks. The scripts I wrote for Xenoblade dealt more "
    $Text += "with loops and directories and creating copies rather than doing any real math or any actual analysis on image files. I really didn't know much about the specifics of image files in "
    $Text += "general and even today I'm still a noob compared to some of the far more talented people out there. But I did attempt it, and Custom Texture Tool the batch script was born. At first "
    $Text += "all it could do was analyze simple issues with textures and generate mipmaps since I had already written a script to do that using ImageMagick. The initial support for this was very "
    $Text += "basic, it had to delete all mipmaps before generating new ones. (Unfortunately, this basic code remained for a long time.) Next came a new loop to scan folders for textures and create "
    $Text += "a log file of all textures that were found. Simple enough. Actual error checking has to be done now which involves math, which is where batch fails because it can only work with integers, "
    $Text += "and decimals are required for many of the necessary calculations."
    $Text += "{0}{0}"
    $Text += "The first type of error checking was detecting non-integer scaling values for custom textures. The new texture format makes this very easy to calculate, since "
    $Text += "the original texture dimensions are stored in the dumped name and can be extracted. For example, tex1_24x24_0804541083813079_14 may be a texture "
    $Text += "scaled to 150x150, and knowing the original is 24x24, the scaling value can be found: (Custom Width/Original Width) for X scale, (Custom Height/Original Height) "
    $Text += "for Y scale. 150/24 gives the quotient of 6.25, which is not an integer scale and is detected as an issue. Since batch cannot work with decimal values, the math "
    $Text += "ends up being 150x100/24 (multiply dividend by 100), which gives 625. The full decimal value can then be simulated by extracting the last two digits and concatenating "
    $Text += "what remains (6) with a period (.) and those last two digits (25). "
    $Text += "{0}{0}"
    $Text += "Next came checking textures for aspect ratio issues, which is again simple enough with the new custom texture format. The math is nearly identical, only this "
    $Text += "time its (Original or Custom Width/Height). Calculating this for both the original and the custom texture should end up with the same quotient. If they are not "
    $Text += "equal, then the textures have different aspect ratios and it's an issue. The same trickery (multiplying width x 100) is used to find the decimal value internally."
    $Text += "{0}{0}"
    $Text += "Soon I realized that just checking the scaling values was not enough, 5.00x6.00 would pass because they are both integer scales. So error checking for uneven "
    $Text += "scales was implemented. I thought this took care of all issues, until I started running it on multiple packs. Seeing textures with 1.00x1.00 means it is not an HD "
    $Text += "texture, so that was added as an issue. There can also be duplicate textures named from the texture converter in dolphin that have a suffix appended such as: "
    $Text += "tex1_24x24_0804541083813079_14.1 or .2, .3, etc. So count that in too, and while we're at it, copy the found duplicate textures into a folder named '~DuplicateTextures'."
    $Text += "{0}{0}"
    $Text += "Eventually came OptiPNG support. When two users named FreeEmulator and StripTheSoul were discussing this program on the Dolphin forums, and were looking for a batch solution, I figured "
    $Text += "why not add it to the script. This program optimizes the structure of PNG textures to help somewhat reduce their filesize losslessly. Seemed like a good feature, so I added it. The original "
    $Text += "code was awful as there was an entirely separate loop for it, but eventually it was written into the main loop."
    $Text += "{0}{0}"
    $Text += "After all that was done, I released it as v2.0 and figured, okay it's good enough. But OCD eventually takes over, and I thought nope, I can do more. Mipmaps "
    $Text += "had to be deleted before being generated, which is gross and I wanted a much better system. Eventually I completely reworked mipmap handling:{0}"
    $Text += "- Mipmap error checking: detect both missing mipmaps and and bad scales.{0}"
    $Text += "- Calculates what the mipmap dimensions should be.{0}"
    $Text += "- Calculates how many levels the mipmap texture should have.{0}"
    $Text += "- Find how many mipmap levels are actually in the texture folder.{0}"
    $Text += "- Use found mipmaps and generate missing mipmaps.{0}"
    $Text += "- Correctly scale mipmaps when converting textures to a fixed integer scale.{0}"
    $Text += "- Apply a sharpening filter to generated mipmaps.{0}"
    $Text += "- DDS: Combine all found mipmaps into a single texture with internal mipmaps.{0}"
    $Text += "{0}"
    $Text += "Speaking of DDS, along the way I also wanted to add support for that too. I worked on implementing both the new mipmap code and DDS support at the "
    $Text += "same time. It became a nightmare, and took over three weeks to get everything working properly because I'm a noob at this stuff (not constant work of "
    $Text += "course, but lots of time in those weeks). My first intentions were to use ImageMagick for everything and soon realized that it's not going to happen. "
    $Text += "ImageMagick DDS support was terrible and I could not accomplish anything that I wanted other than error checking. I then stumbled onto nvidia's DDS Utilities "
    $Text += "which had much more functionality than ImageMagick for the DDS format, and it allowed merging multiple images as mipmap layers. Everything I wanted. "
    $Text += "{0}{0}"
    $Text += "Actually getting everything to work the way I wanted to soon proved to be an arduous task. I have a good understanding of logic, but I am not a programmer, "
    $Text += "and doing this in batch started to seem hopeless. There were several issues to overcome. The first was that PNG images fed into DDS Utilities must have "
    $Text += "dimensions that are a multiple of 4, there is no auto correction. So, I had to do these calculations myself, and at the time I was really overthinking of how it "
    $Text += "should be done. The first solution I came up with, was to continually subtract 4 from the dimensions, until something less than 4 was hit (0-3). With that, I "
    $Text += "knew how much the texture was off by and could just add the differences to the texture dimensions. But this was SLOW, and you can get bunk dimensions! "
    $Text += "Rethinking it, I came up with a simpler solution: Dimension / 4, if it has decimal, add 1 to dimension. Test again, if fails, add 1 again. This means only a total of "
    $Text += "up to 3 loop iterations, as opposed to potentially 100's depending on the texture resolution. Now, I needed a PNG image with these new dimensions, so a "
    $Text += "temporary image must be generated. Now that it's created, make a DDS file and delete the temporary image. All of this is invisible to the user and happens in milliseconds. "
    $Text += "{0}{0}"
    $Text += "DDS can also have internal mipmaps, and while the master branch of Dolphin does not make use of them, Tino's Dolphin Ishiiruka can use them. Adding "
    $Text += "support for internal mipmaps was not an easy task, especially when trying to detect if a texture currently has them or not. Luckily nvidia tools has the "
    $Text += "'detach' command which can extract all mipmaps. Cool, calculate how many it should have, extract them, count them, and delete them. With the use of the "
    $Text += "'stitch' command, all mipmaps found in the texture pack can now be used as internal mipmaps when generating DDS textures. "
    $Text += "{0}{0}"
    $Text += "Now theres the issue with scaling DDS textures to a new integer scale, and detecting problems with scaling. Some scales will not line up, a texture with "
    $Text += "dimensions 25x26 for example, will not end up with multiple four dimensions using an integer scale of 7. It ends up as 175x182, which are not valid DDS "
    $Text += "dimensions. Using the formula mentioned before, the new DDS dimensions will end up as 176x184, but now the scale will be bad (7.04x7.07). There is "
    $Text += "nothing that can be done about that, so for DDS there are only checks that validate the dimensions (based on the closest width integer scale, 7 in this case), "
    $Text += "and not the actual scale or aspect ratio. "
    $Text += "{0}{0}"
    $Text += "The last obstacle was that textures with transparency should be compressed with DXT5, and textures without transparency should be compressed with DXT1. "
    $Text += "Luckily, ImageMagick contains functions that can test if a PNG or DDS texture has an alpha channel and whether or not it has any transparent pixels. In the batch "
    $Text += "versions of the script, I did not know how to make use of the transparency feature, so all textures with an alpha channel were compressed with DXT5. Of course since "
    $Text += "the PowerShell versions, this is no longer the case. "
    $Text += "{0}{0}"
    $Text += "I started to realize that Batch was far too limited, and I'm always striving for... something more. As mentioned before one of the biggest limitations of Batch is its "
    $Text += "inability to use decimals. Everything must be multiplied by 100 before doing the actual equations to simulate two decimal places. Another big roadblock I hit  "
    $Text += "was paths using ampersands (& symbol). In batch this means 'AND DO', so a folder named 'Bionis Leg & Colony 6' will be seen as: '...Bions Leg' AND DO "
    $Text += "'Colony 6', and batch will say 'WHAT!?' and the script will halt. Using quotes can circumvent this, but when passing a variable containing a path into a "
    $Text += "function as a parameter, the quotes are ignored within the function's actions and the same problem happens. Through experimentation I learned that "
    $Text += "surrounding the value within the function with even more quotes will fix this, but now the path has quotes in it that are not ignored, that need to be "
    $Text += "eliminated with further string manipulation. ARGH! There are many other small annoyances that I came across, but these two things were the biggest roadblocks to progress."
    $Text += "{0}{0}"
    $Text += "Okay so much of the past few paragraphs were copy and pasted from my previous story which was before the PS versions existed, so it's back to manually typing up this most "
    $Text += "likely pointless saga. So anyway, after realizing how weak batch was, I began to translate my code into PowerShell. It actually didn't take very long, maybe three weeks at "
    $Text += "the most. I really liked PowerShell because it was very similar to the scripting language used in WarCraft III. The first thing I did after getting it functional was testing "
    $Text += "the speed of the main loop because Batch loops were incredibly slow. The results were amazing! Analysing the PNG Paper Mario: TTYD pack was almost 5 times faster! The DDS "
    $Text += "pack didn't see the same gains unfortunately, but it was still about 40% faster. The reason is because I still have to rely on ImageMagick to analyze DDS textures, but PNG "
    $Text += "texture information can be retrieved using .NET which is much faster than ImageMagick. "
    $Text += "{0}{0}"
    $Text += "So CTT-PS was born and released. After v1.0, a user on the forums named 'MeleeHD' informed me of a method that another user 'uncleiroh' came up with that involved applying "
    $Text += "a watermark of the texture's name over the texture to easily identify it in-game. I thought this was a great idea, but the solution uncleiroh came up with was somewhat "
    $Text += "convoluted so I set out to see if I could do the same thing with ImageMagick and my script. It didn't take too long, and a new feature was born. Credits to those guys. "
    $Text += "{0}{0}"
    $Text += "After many bug fix versions and general quality of life changes later, Tino came up with a new kind of texture: the material map. This proved to be my next big conquest. Since I have a texture tool that is "
    $Text += "supposed to work with Dolphin textures, adding support for these textures was a top priority. I honestly did not understand much about them, the idea of bump, spec, and nrm "
    $Text += "textures was completely alien to me. And to make it even more complicating, Tino made a tool to combine these textures into a single texture. I attempted to find a way to also "
    $Text += "create these textures on my own, but I just didn't have the know-how. Then it struck me... Tino's tool can already do it, so why not ask him to support command line so his tool "
    $Text += "can also work with my tool? So I did just that, and he was very willing to offer his help and make modifications to his tool. I am still grateful to this day. After many weeks "
    $Text += "of bug testing and many failed implementations, we both eventually got everything right so working with material maps finally became a reality. "
    $Text += "{0}{0}"
    $Text += "Time passes and Dolphin forum goers continue to fill my head with ideas. For example, a Twilight Princess texture pack creator named 'Victor Rosa' had a bunch of mipmaps for "
    $Text += "textures that weren't actually mipmap textures in his pack. I wanted to create an option in my tool to delete these textures, but I did not want my script to actually modify "
    $Text += "texture packs directly. Thus, the 'Advanced Options' were born. A set of options that can specifically modify texture packs directly that are cast aside form the main options. "
    $Text += "Not long after I thought it would be nice to have an advanced option to directly generate new mipmaps. I know the texture pack author 'General_Han_Solo' used my very early "
    $Text += "mipmap generation scripts so I thought hey, if anybody will use this option maybe it will be him. "
    $Text += "{0}{0}"
    $Text += "It wasn't long after that another forum user 'masterotaku' asked if the script could apply a nearest neighbor (point) filter to all textures. The script did not have a feature "
    $Text += "to apply upscaling filters, so I thought why not. I then added support for several generic filters. Later, forum user 'Lumbeeslayer' asks for xBRZ support, so I contacted the "
    $Text += "xBRZ author 'Zenju' to see if he would add command line support to his ScalerTest application. As it turns out, everyone always seems willing to help so xBRZ support was added. "
    $Text += "Later yet, another forum user 'CyberGlitch' mentions the waifu2x filter and how amazing the results can be. So I eventually worked on implementing that as well. He also gave me "
    $Text += "the fantastic idea of what is now known in the script as the 'Seamless Method' when upscaling textures with filters. This method tiles a texture 9 times before applying the filter "
    $Text += "so the texture has adjacent pixels to work with, then the outer 8 tiles are cropped away and you are left with a perfectly seamless texture. "
    $Text += "{0}{0}"
    $Text += "After the upscaling filters, I realized there really isn't much left I can do image-wise. So I decided to implement some ideas that I've had since the beginning but did not have "
    $Text += "the necessary skills to accomplish. One such feature is the ability to combine multiple textures into a single texture, and then split them back up when the combined texture has "
    $Text += "been retextured. I honestly don't know how useful this can be outside of making a sliding puzzle or working on N64 VC games, but I thought nobody else has done this, so why not? "
    $Text += "{0}{0}"
    $Text += "So now I really was out of ideas, and it was time to tackle the final conquest, the one I dreamed about since working on the Batch script: a GUI. I knew it was possible for a long "
    $Text += "time, it was no mystery PowerShell can make use of .NET framework directly as I've already done it on several occasions. The script has had some GUI elements for quite some time, "
    $Text += "albeit very basic elements such as Open File dialogs and the like. But now it was time to make my dream a reality and learn about Windows Forms. Holy shit is there ever a ton of  "
    $Text += "information to process. Remember, I'm not a programmer, so all of this was extremely confusing at first. I've made GUI's in StarCraft 2 maps but this was about 80% more complicating. "
    $Text += "So for a few weeks I hacked away at it in secret, eventually made a reveal, then eventually released it. Sweet, a GUI and it works! Plus I was even able to keep 'Script Mode'. "
    $Text += "{0}{0}"
    $Text += "And that's the end of my story, and I'm most likely reaching the end of this tool. It has already evolved way beyond anything I ever thought I could create. I know it's nothing "
    $Text += "special, but to me personally it is. I have started countless projects over the years, but I have never once saw one through to the end; meaning, reaching a point where I can say "
    $Text += "'Yep, I did good. It's finally done.', nor felt that what I created could actually be useful to anyone. I'm somewhat proud of this tool, and it's gotten to a point where it can even "
    $Text += "reach beyond Dolphin textures with the option 'Allow All Images', meaning anyone could use it for their texture projects with any type of game."
    $Text += "{0}{0}"
    $Text += "If you actually read this far, I have to compliment you on your stamina to sit through and actually read all of this. Unless you just skipped to the end, can't say I blame you.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Custom Texture Tool PS - The Beginning to the End")
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 12, [Drawing.FontStyle]::Bold)
  }
}
#==============================================================================================================================================================================================
#  INITIALIZATION B: STUFF TO DO AFTER CREATING THE GUI
#==============================================================================================================================================================================================
#  Find the ImageMagick executables.
if (SetImageMagick $ImageMagick)
{
  # Change the title of the window to the name of the script + the PowerShell version + the ImageMagick version.
  $host.UI.RawUI.WindowTitle = ($ScriptName + ' - PowerShell v' + $PSVersion + ' - ImageMagick v' + $IMVersion)
}
else
{
  # Change the title bar to say that ImageMagick was not installed.
  $host.UI.RawUI.WindowTitle = ($ScriptName + ' - PowerShell v' + $PSVersion + ' - ImageMagick Not Found!')
}
# Automatically hide the console window if the user wanted.
ShowPowerShellConsole $AlwaysShowConsole

# Show the dialog to the user.
$Dialog.Add_Shown({$Dialog.Activate()})

# The script will hang out here and not proceed until the dialog is closed.
$Dialog.ShowDialog() | Out-Null

# Force closing the help dialog so everything closes in sync.
if ($HelpDialog.Visible)
{
  $HelpDialog.Close()
}
# Either Windows 7 is painfully slow when updating options, or it's just my VM that's slow. 
# Whatever the case, just hide the PS console from the user until it properly shuts down.
ShowPowerShellConsole $false

# Attempt to write all options that may have been changed to the script file.
StoreAllOptions

# Not likely needed since this is the end, but force it closed anyway.
Exit

