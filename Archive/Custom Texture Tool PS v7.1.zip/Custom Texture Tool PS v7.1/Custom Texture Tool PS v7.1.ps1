#==========================================================================================================================================
#  Custom Texture Tool PS v7.1
#  By: Bighead
#==========================================================================================================================================
#  NOTICE TO NEW USERS OR EXISTING USERS OF THE BATCH VERSION OF THIS SCRIPT!!
#==========================================================================================================================================
#
#  It is NOT necessary to configure any options through editing this script. You never need to edit it at all!
#
#  It is instead suggested to use the "Internal Options Menu" that can be found on the Main Menu after running.
#
#  All changes made in the Internal Options Menu update this script itself to permanently store the values you modify!
#
#  Using the new Internal Options Menu is also a lot safer because it prevents entering invalid values.
#
#  If you still wish to configure the options through editing the script you can, but be careful!
#
#==========================================================================================================================================
#  GLOBAL VARIABLES - MAY BE EDITED WITH CAUTION
#==========================================================================================================================================
# Internal Options
$global:IshiirukaTool      = "C:\Program Files (x86)\Ishiiruka-TextureEncoder.0.8\TextureEncoder.exe"
$global:OptiPNGPath        = "C:\Program Files (x86)\optipng-0.7.5-win32\optipng.exe"
$global:TempFolder         = "$env:temp\CTT-PS_Temp"
$global:HideOKTextures     = $true
$global:IgnoreDuplicates   = $false
$global:AllowNotHD         = $true
$global:DDSAutoRepair      = $false
$global:ScaleThreshold     = "0.65"
$global:AspectThreshold    = "0.02"
$global:DDSMipMapType      = "External"
$global:ForceNewMipMaps    = $false
$global:OptiPNGTests       = "3"
$global:CopyNonTextures    = $true
$global:ManualRescale      = $false

# Watermark Options
$global:WM_Length          = "0"
$global:WM_FontFace        = "Courier-New-Bold"
$global:WM_FontSize        = "8"
$global:WM_FontColor       = "#FF0000"
$global:WM_BGColor         = "#00FF00"
$global:WM_WordWrap        = $true

# Tool Paths
$global:ImageMagick        = (Get-ItemProperty -LiteralPath "HKLM:\Software\ImageMagick\Current\" -Name BinPath -ErrorAction SilentlyContinue).BinPath
$global:NvidiaTools        = (Get-ItemProperty -LiteralPath "HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\{64963F0E-03F2-4B59-8D1B-1806545E7092}\" -Name InstallLocation -ErrorAction SilentlyContinue).InstallLocation
#==========================================================================================================================================
#  CONSTANT VARIABLES - DO NOT EDIT
#==========================================================================================================================================
# File extension references. Cleaner than typing the actual file extensions.
New-Variable -Name 'PNG' -Value '.png' -Option Constant
New-Variable -Name 'DDS' -Value '.dds' -Option Constant
New-Variable -Name 'JPG' -Value '.jpg' -Option Constant
New-Variable -Name 'NRM' -Value '.nrm' -Option Constant

# Generic variable to store an empty string.
New-Variable -Name 'nullstr' -Value '' -Option Constant
#==========================================================================================================================================
# TODO
#==========================================================================================================================================
# - Make texture watermark option generate something (dummy texture?) if texture is an Ishiiruka DDS.
# - Bug Tino about Ishiiruka Tool not outputting PNG color textures when converting from DDS.
#==========================================================================================================================================
#  DOCUMENTATION - ALL GLOBAL VARIABLES
#==========================================================================================================================================
# $global:Texture            - hashtable - The most important variable, this stores all information about the texture.
# $global:DDSCompression     - string    - When a DDS textures is created, stores the compression type so other functions can use it.
# $global:ScriptName         - string    - Stores the name of the script.
# $global:ScriptPath         - string    - Stores the full path to the script + the script.
# $global:PSVersion          - integer   - Stores the running version of PowerShell.
# $global:LogIssues          - string    - A compilation of all issues a texture has in a long string.
# $global:PreviousPath       - string    - Used only when updating the log file to check if the path has changed.
# $global:BaseFolder         - string    - The path to the base location of the script.
# $global:LogFile            - string    - The full path to the log file.
# $global:TempFolder         - string    - The path where Custom Texture Tool PS creates temporary files.
# $global:ImageMagick        - string    - The base path where convert, identify, and composite are located.
# $global:IMConvert          - string    - ImageMagick path to convert.exe/magick.exe
# $global:IMIdentify         - string    - ImageMagick path to identify.exe
# $global:IMVersion          - string    - Displays the ImageMagick version. Currently only the branch, meaning v6 or v7 and not the specific version.
# $global:NvidiaTools        - string    - The base path where nvdxt, stitch, and detach are located.
# $global:NVDXT              - string    - DDS Utilities path to nvdxt.exe
# $global:NSTITCH            - string    - DDS Utilities path to stitch.exe
# $global:NDETACH            - string    - DDS Utilities path to detach.exe
# $global:IshiirukaTool      - string    - Ishiiruka Tool path to TextureEncoder.exe
# $global:OptiPNGPath        - string    - OptiPNG path to optipng.exe
# $global:ScanAllTextures    - boolean   - Stores if the user selected any option from Option 1.
# $global:CopyBadTextures    - boolean   - Stores if the user wanted to copy bad textures.
# $global:AutoFixTextures    - boolean   - Stores if the user wanted to auto-fix textures.
# $global:ForceIntScaling    - boolean   - Stores if the user ran the option to force and integer scale.
# $global:StoredScale        - string    - Used only when ManualRescale is enabled to store the scale for the next iteration.
# $global:ForcedScale        - string    - The integer scale the user input to scale all textures.
# $global:ConvertTextures    - boolean   - Stores if the user ran the option to convert textures to another format.
# $global:ConvertedFormat    - string    - Stores the file extension the user chose when converting or rescaling textures.
# $global:OptiPNGTextures    - boolean   - Stores if the user ran the option to run OptiPNG.
# $global:TotalReductionB    - integer   - Stores the total amount of hard drive space recovered from OptiPNG.
# $global:IshiirukaOption    - boolean   - Stores if the user ran the main menu option that creates material maps with Ishiiruka Tool.
# $global:CreateMaterials    - boolean   - Stores if the user ran any option that creates material maps with Ishiiruka Tool.
# $global:CreateWatermark    - boolean   - Stores if the user ran the option to create watermarks on all textures.
# $global:WM_Length          - string    - Watermark text length.
# $global:WM_FontFace        - string    - Watermark font face.
# $global:WM_FontSize        - string    - Watermark font size.
# $global:WM_FontColor       - string    - Watermark font color.
# $global:WM_BGColor         - string    - Watermark background color.
# $global:WM_WordWrap        - boolean   - Watermarks are wrapped to the next line if they would run off the edges.
# $global:GenerateMipMaps    - boolean   - Stores if the user ran the advanced option to generate new mipmaps.
# $global:RemoveBadMipMap    - boolean   - Stores if the user ran the advanced option to delete invalid mipmaps.
# $global:HideOKTextures     - boolean   - Hide OK textures from the log.
# $global:IgnoreDuplicates   - boolean   - Prevent the script from finding duplicate textures.
# $global:AllowNotHD         - boolean   - Forces the script to ignore detecting textures with the original resolution or lower.
# $global:DDSAutoRepair      - boolean   - Option to fix DDS dimensions when converting textures to DDS with option 3.
# $global:DDSMipMapType      - string    - The type of mipmaps the script handles for DDS textures. Values are "Internal", "External", and "Both".
# $global:ForceNewMipMaps    - boolean   - Forces the script to generate new MipMaps from the base texture.
# $global:ManualRescale      - boolean   - Changes option 2 to allow rescaling each texture individually.
# $global:CopyNonTextures    - boolean   - When rescaling/converting a texture pack, this copies files that are not textures into the new pack.
# $global:ScaleThreshold     - string    - Minimum decimal threshold to scale a texture to the next integer scale.
# $global:AspectThreshold    - string    - Maximum decimal threshold of aspect difference between the original and custom texture to auto-fix a texture.
# $global:ConsoleType        - integer   - The type of message to display in ConsoleEndInfo. 0: Error, 1: One Part Message, 2: Two Part Message
# $global:ConsoleMsgA        - string    - The first part of the console message. Displayed in red if ConsoleType is an error.
# $global:ConsoleMsgB        - string    - The second part of the console message, displayed in green.
# $global:LogMessage         - string    - Appended to the end of the line in the log file.
# $global:LogSpecial         - boolean   - If ImageMagick is used to create a DDS textures, this triggers a warning message.
#==========================================================================================================================================
#  DOCUMENTATION - TEXTURE HASH TABLE
#==========================================================================================================================================
#  When a texture is ran through the main loop, a global hash table is created for the current texture. 
#  Many of this script's functions rely on this data and are designed around having this data readily available. 
#  Each iteration of the loop creates a new hash table for the current texture and discards the data from the last one.
#  Below is a list of all information that can be retrieved when a hash table for the current texture has been created.
#
#  $Texture.Name             - string  -  The name of the texture without the extension.
#  $Texture.FullName         - string  -  The name of the texture with the file extension.
#  $Texture.Extension        - string  -  The file extension of the texture file.
#  $Texture.Folder           - string  -  The name of the folder that the current texture is located in.
#  $Texture.Path             - string  -  The path to where the texture is currently located, minus the texture name.
#  $Texture.PathName         - string  -  The full path to the texture including the texture name without the file extension.
#  $Texture.FullPath         - string  -  The full path to the texture including the texture name with the file extension.
#  $Texture.Relative         - string  -  The relative path to the texture, which is the Path minus the BaseFolder (location of the script).
#  $Texture.SplitName[#]*    - string  -  Splits the texture name using the locations of underscores to detect "tex1", dimensions, "m" for MipMap, or "mip_#" for MipMap level.
#  $Texture.SplitPeriod[#]   - string  -  Splits the texture name using the locations of periods to test for Dolphin dupes or Ishiiruka .nrm, .spec, and .bump textures.
#  $Texture.Size             - integer -  The file size of the texture in Bytes.
#  $Texture.Width            - integer -  The width of the custom texture.
#  $Texture.Height           - integer -  The height of the custom texture.
#  $Texture.Aspect           - decimal -  The aspect of the custom texture (Width/Height)
#  $Texture.Dimensions       - string  -  The full dimensions of the custom texture in the form of (Width x Height).
#  $Texture.OldWidth         - integer -  The width of the original texture.
#  $Texture.OldHeight        - integer -  The height of the original texture.
#  $Texture.OldAspect        - decimal -  The aspect of the original texture (OldWidth/OldHeight)
#  $Texture.OldDimensions    - string  -  The full dimensions of the original texture in the form of (OldWidth x OldHeight).
#  $Texture.ScaleWidth       - decimal -  The width scale of the custom texture (Width/OldWidth).
#  $Texture.ScaleHeight      - decimal -  The height scale of the custom texture (Height/OldHeight).
#  $Texture.Scale            - string  -  The full scale of the texture in the form of (ScaleWidth x ScaleHeight).
#  $Texture.IsMipMap         - boolean -  Stores true or false of whether or not the texture is a MipMap texture.
#  $Texture.HasAlphaChannel  - boolean -  Stores true or false of whether or not the texture has an alpha channel.
#  $Texture.HasMaterialMap   - boolean -  Stores true or false of whether or not the texture has a supplied material map (nrm) texture.
#  $Texture.MaterialPath     - string  -  The full path to the texture's supplied material map.
#  $Texture.HasMaterials     - boolean -  Stores true or false of whether or not the texture has supplied materials (bump/spec/nrm) textures.
#
#  * SplitName[0-6] is the texture name broken up into 7 sections to pull data from based on the location of underscores. A list of this data can be found below. 
#
#  SplitName[0]
#  - [tex1]       - Useful. Fails a file if it is not named in the correct texture format.
#  SplitName[1]
#  - [dimensions] - Useful. Allows pulling the width and height of the original texture from the texture name.
#  SplitName[2]
#  - [m]          - Useful. Allows checking if it is a MipMap texture.
#  - [hash]       - Useless. Will hold the texture hash value if the texture is not a MipMap. This script does not need to know anything about the hash.
#  SplitName[3]
#  - [format]     - Useless. If it is a standard texture, it will hold the texture format which this script does not need to know.
#  - [hash]       - Useless. Will hold the texture hash value if the texture is a MipMap texture. This script does not need to know anything about the hash.
#  - [2nd hash]   - Useless. If the texture is a paletted texture, this value will hold the second hash.
#  SplitName[4]
#  - [format]     - Useless. If it is a MipMap or paletted texture, it will hold the texture format which this script does not need to know.
#  - [2nd hash]   - Useless/Rare. If the texture is a paletted MipMap texture, this value will hold the second hash.
#  SplitName[5]
#  - [mip_#]      - Useful. If it is a MipMap texture and a lower MipMap level, this value will hold the level.
#  - [format]     - Useless/Rare. If it is a paletted MipMap texture, it will hold the texture format.
#  SplitName[6]
#  - [mip_#]      - Useful/Rare. If it is a paletted MipMap texture, this value will hold the level.
#
#  SplitName[3/4] are completely useless to this script, as those sections of the texture name will never hold data that the script needs.
#==========================================================================================================================================
#  DOCUMENTATION - MIPMAP HASH TABLE
#==========================================================================================================================================
#  Creates MipMap information based on the input dimensions and the texture currently stored in the global hash table.
#  Only the name/path information is pulled from the texture hash table, the rest of the information is dynamically created from the input dimensions.
#
#  The number of mipmaps [#] in the array is determined by the number of $MipMap.Levels.
#
#  $MipMap.Levels             - integer -  The number of levels calculated from the input dimensions. Also defines the size of the MipMap array.
#  $MipMap.Name[#]*           - string  -  The name of the MipMap without the extension. 
#  $MipMap.FullName[#]*       - string  -  The name of the MipMap with the file extension.
#  $MipMap.FullPath[#]*       - string  -  The full path to the MipMap including the MipMap + file extension.
#  $MipMap.Size[#]*           - integer -  The file size of the MipMap in Bytes. Currently unused in any functions.
#  $MipMap.Width[#]           - string  -  The calculated width of the MipMap based on the input dimensions.
#  $MipMap.Height[#]          - string  -  The calculated height of the MipMap based on the input dimensions.
#  $MipMap.Dimensions[#]      - string  -  The calculated full dimensions of the MipMap in the form of Width x Height.
#  $MipMap.Exists[#]*         - boolean -  Notifies whether or not the mipmap actually exists. 
#  $MipMap.RealWidth[#]*      - string  -  The actual width of the MipMap if it exists.
#  $MipMap.RealHeight[#]*     - string  -  The actual height of the MipMap if it exists.
#  $MipMap.RealDimensions[#]* - string  -  The actual full dimensions of the MipMap in the form of Width x Height.
#  $MipMap.LevelsCounted*     - integer -  The number of MipMap levels found based on the name of the current texture.
#  $MipMap.LevelsMissing*     - integer -  The number of MipMap levels that are missing based on the name of the current texture.
#  $MipMap.BadDimensions*     - integer -  The number of MipMap levels where "Dimensions" don't match up with "RealDimensions"
#
#  * This data is created based on the current texture hash table. All other information is derived from the input dimensions.
#==========================================================================================================================================
#  STRING MANIPULATION FUNCTIONS
#==========================================================================================================================================
#  Counts the number of characters in a string and extends it with empty spaces to the input amount.

function ExtendString([string]$inputstring, [int]$stringlength)
{
	# Count the number of characters in the input string.
	$count = ($inputstring | Measure-Object -Character).Characters

	# Check the number of characters against the desired amount.
	if ($count -lt $stringlength)
	{
		# If the string is to be lengthened, find out by how much.
		$addlength = $stringlength - $count

		# Loop until the string matches the desired number of characters.
		for ($i=1; $i -le $addlength; $i++)
		{
			$inputstring += ' '
		}
	}
	# Return the modified string.
	return $inputstring
}
#==========================================================================================================================================
#  Takes an integer and converts it to a string and also appends a 0 to the front of the string if the integer is less than 10.

function IntToStringDoubleDigit([int]$inputint)
{
	# Check if the input number is less than 10.
	if ($inputint -lt 10)
	{
		# If it is, append a 0 and return as a string.
		return [string]('0' + $inputint)
	}
	# Otherwise just return the integer as a string.
	return [string]$inputint
}	
#==========================================================================================================================================
#  Forces a value into a string with 2 decimal places (x.xx).

function FormatDecimal([string]$inputvalue)
{
	# When math is performed, some countries use commas instead of decimals, so they must be converted.
	if ($inputvalue -like '*,*')
	{
		# If a comma is found, split the value based on its location.
		$CommaSplit = $inputvalue.Split(',', 2)

		# If a 0 is found as a whole number, then eliminate it so another 0 isn't added for the next fix.
		if ($CommaSplit[0] -eq '0')
		{
			$inputvalue = '.' + $CommaSplit[1]
		}
		# In 99% of other cases, replace the comma with a decimal.
		else
		{
			$inputvalue = $CommaSplit[0] + '.' + $CommaSplit[1]
		}
	}
	# Fix the decimal value to have a 0 in front of it if it is less than 1.
	if ([decimal]$inputvalue -lt 1)
	{
		$inputvalue = "0" + $inputvalue
	}
	# Fix the value to hold .00 if it is a whole number.
	$DecimalTest = $inputvalue.Split('.', 2)

	# If it's a whole number, then DecimalTest[1] will not hold anything.
	if (!$DecimalTest[1])
	{
		$inputvalue = $inputvalue + '.00'
	}
	# Fix the value to hold an additional decimal place if the decimal is less than 10.
	else
	{
		# Count the number of characters in the decimal.
		$count = ($DecimalTest[1] | Measure-Object -Character).Characters

		# If there is only a single digit, then add a zero.
		if ($count -eq 1)
		{
			$inputvalue = $inputvalue + "0"
		}
	}
	return $inputvalue
}
#==========================================================================================================================================
#  Takes a texture file extension (.png/.dds/.jpg) and returns it as a 3 letter word (PNG/DDS/JPG).

function ExtensionToText([string]$inputstring)
{
	# Convert ".png" to "PNG".
	if ($inputstring -eq $PNG)
	{
		return 'PNG'
	}
	# Convert ".dds" to "DDS".
	elseif ($inputstring -eq $DDS)
	{
		return 'DDS'
	}
	# Convert ".jpg" to "JPG".
	elseif ($inputstring -eq $JPG)
	{
		return 'JPG'
	}
	# This should never happen. But if it does, simply return the extension as it was. 
	return $inputstring
}
#==========================================================================================================================================
#  Takes a decimal value and returns the value as a string in the form of a percent.

function DecimalToPercent([decimal]$value)
{
	[System.IO.Directory]::GetFiles($BaseFolder, '*', 'AllDirectories').Count
}
#==========================================================================================================================================
#  I didn't write this function, but it's freaking amazing! It copies all text currently on the console screen and returns it!
#  Source: http://blogs.msdn.com/b/PowerShell/archive/2009/01/10/capture-console-screen.aspx

function CopyAllScreenText()
{
	# Check the host name and return an empty string if the host is not the Windows PowerShell console host.
	if ($host.Name -ne 'ConsoleHost')
	{
		return $nullstr
	}
	# Initialize string builder.
	$textBuilder = New-Object System.Text.Stringbuilder

	# Grab the console screen buffer contents using the Host console API.
	$bufferWidth = $host.ui.rawui.BufferSize.Width
	$bufferHeight = $host.ui.rawui.CursorPosition.Y
	$rec = New-Object System.Management.Automation.Host.Rectangle 0,0,($bufferWidth - 1),$bufferHeight
	$buffer = $host.ui.rawui.GetBufferContents($rec)

	# Iterate through the lines in the console buffer.
	for($i = 0; $i -lt $bufferHeight; $i++)
	{
		for($j = 0; $j -lt $bufferWidth; $j++)
		{
			$cell = $buffer[$i,$j]
			$null = $textBuilder.Append($cell.Character)
		}
		$null = $textBuilder.Append("`r")
	}
	return $textBuilder.ToString()
}
#==========================================================================================================================================
#  FOLDER MANIPULATION FUNCTIONS
#==========================================================================================================================================
#  Creates a folder if it does not already exist. Returns the parameter so it can be set to a variable when called.

function CreatePath([string]$inputpath)
{
	# Make sure the path isn't null to avoid errors.
	if ($inputpath -ne $nullstr)
	{
		# Check to see if the path does not exist.
		if (!(Test-Path -LiteralPath $inputpath))
		{
			# Create the path.
			New-Item -ItemType 'directory' -Path $inputpath | Out-Null
		}
	}
	# Return the path so it can be set to a variable when creating.
	return $inputpath
}
#==========================================================================================================================================
#  Removes a file or folder if it exists.

function RemovePath([string]$inputpath)
{
	# Make sure the path isn't null to avoid errors.
	if ($inputpath -ne $nullstr)
	{
		# Check to see if the path exists.
		if (Test-Path -LiteralPath $inputpath)
		{
			# Remove the path.
			Remove-Item -Recurse -Force -LiteralPath $inputpath | Out-Null
		}
	}
}
#==========================================================================================================================================
#  Checks if a path exists. Avoids use of "Test-Path" directly which can generate an error if the tested path is null.

function TestPath([string]$inputpath)
{
	# Make sure the path isn't null to avoid errors.
	if ($inputpath -ne $nullstr)
	{
		# Check to see if the path exists.
		if (Test-Path -LiteralPath $inputpath)
		{
			# Remove the path.
			return $true
		}
	}
	return $false
}
#==========================================================================================================================================
#  DDS DIMENSION CALCULATIONS
#==========================================================================================================================================
#  Sub-function for DDSMultFour to find the nearest multiple of four for a dimension. Also used in MipMap calculations when finding levels and calculating dimensions.

function FindMultFour([int]$inputvalue)
{
	# If the input dimension is 1 or 2 then return that value (allows 1x1,2x2,1x2,2x1 DDS mipmaps).
	if (($inputvalue -eq 1) -or ($inputvalue -eq 2))
	{
		# For some reason DDS Utilities can create textures 1-2 pixels tall or wide which is nice because it allows flooring mipmaps properly to 1x1.
		return $inputvalue
	}
	# Use a modulus of 4 to check for a remainder. A remainder means it was not a multiple of four.
	$tempvalue = $inputvalue % 4

	# We shall count the number of loop iterations. This value will be the amount to add to find a multiple of four.
	$iterations = 0

	# Loop until there is no remainder. Loop is skipped if there wasn't.
	while($tempvalue -ne 0)
	{
		# Add to the number of iterations.
		$iterations ++

		# Add the iterations to the input value and repeat search for remainder.
		$tempvalue = (($inputvalue + $iterations) % 4)
	}
	# Add the total number of loop iterations to the input value which will result in a multiple of four!
	$inputvalue += $iterations

	# Return the new value.
	return $inputvalue
}
#==========================================================================================================================================
#  To use set "DDSMultFour" as a variable named "DDS". This tests if the input dimensions are a multiple of four, and returns a hash table that
#  supplies the corrected Width and Height and the combined dimensions. Data is retrieved with "DDS.Width" "DDS.Height" or "DDS.Dimensions".

function DDSMultFour([int]$inputwidth, [int]$inputheight)
{
	# Create and store the values using a hash table.
	$dds = @{}
	$dds.Width  = FindMultFour $inputwidth
	$dds.Height = FindMultFour $inputheight
	$dds.Dimensions = [string]$dds.Width + 'x' + [string]$dds.Height

	# Return the hash table data.
	return $dds
}
#==========================================================================================================================================
#  TEST COLOR CHANNEL DEPTH
#==========================================================================================================================================
#  Tests each color channel (including alpha) for at least 8-bit depth.

function TestColorChannelDepth($texturepath)
{
	# This function will generate ass-loads of errors if a channel is not in the string, so silence them all.
	$ErrorActionPreference = 'silentlycontinue'

	# Run the "-verbose" command on the texture to find the channel information.
	$Verbose = & $IMIdentify $IMI7 -verbose $texturepath

	# This is far more convoluted than it needs to be, but I suck with regex.
	$R_String = (($Verbose | Select-String -Pattern 'red.*bit') -Split 'red: ') -Split '-bit'
	$G_String = (($Verbose | Select-String -Pattern 'green.*bit') -Split 'green: ') -Split '-bit'
	$B_String = (($Verbose | Select-String -Pattern 'blue.*bit') -Split 'blue: ') -Split '-bit'
	$A_String = (($Verbose | Select-String -Pattern 'alpha.*bit') -Split 'alpha: ') -Split '-bit'

	# Initialize an array to store the depth in each channel.
	$Channel = New-Object int[] 4

	# Search for the channel depth and convert it to an integer. If the channel is not found, set depth to zero.
	if ($R_String[1]) { $Channel[0] = [int]$R_String[1]	} else { $Channel[0] = 0 }
	if ($G_String[1]) { $Channel[1] = [int]$G_String[1]	} else { $Channel[1] = 0 }
	if ($B_String[1]) { $Channel[2] = [int]$B_String[1]	} else { $Channel[2] = 0 }
	if ($A_String[1]) { $Channel[3] = [int]$A_String[1]	} else { $Channel[3] = 0 }

	# Loop through all the channels.
	for($i=0; $i -lt 4; $i++)
	{
		# See if the bit depth falls between 0 and 8, meaning it must be 1-7 to fail.
		if (($Channel[$i] -gt 0) -and ($Channel[$i] -lt 8))
		{
			# If any of the channels failed to be greater than 8 bit, then return false.
			return $false
		}
	}
	# If all channels pass the depth check, then return true.
	return $true
}
#==========================================================================================================================================
#  TEXTURE HASH TABLE - MATERIAL MAP CHECKS
#==========================================================================================================================================
#  Tests if a texture has an already combined material map using partial data from the texture hash table.

function TextureHasCombinedMaterial([hashtable]$texture)
{
	# Initialize the array so it can be modified.
	$MaterialCheck = New-Object bool[] 3

	# The (.nrm) texture must be alone without the (.bump) and (.spec) files.
	$MaterialCheck[0] = (!(TestPath $($texture.PathName + '.nrm' + $texture.Extension)))
	$MaterialCheck[1] = (TestPath $($texture.PathName + '.bump' + $texture.Extension))
	$MaterialCheck[2] = (TestPath $($texture.PathName + '.spec' + $texture.Extension))

	# Loop through each check.
	for($i=0; $i -lt 3; $i++)
	{
		# Test each check to see if one passes.
		if ($MaterialCheck[$i])
		{
			# If a check passes, then exit this function.
			return $false
		}
	}
	return $true
}
#==========================================================================================================================================
#  Tests if a texture has an already combined material map using partial data from the texture hash table.

function TextureHasMaterialTextures([hashtable]$texture)
{
	# Initialize the array so it can be modified.
	$MaterialCheck = New-Object bool[] 3

	# Since "nrm" textures are optional, only check for "spec" and "bump". Ishiiruka Tool will find the "nrm" texture on its own.
	$MaterialCheck[0] = ($texture.Extension -ne $PNG)
	$MaterialCheck[1] = (!(TestPath $($texture.PathName + '.bump.png')))
	$MaterialCheck[2] = (!(TestPath $($texture.PathName + '.spec.png')))

	# Loop through each check.
	for($i=0; $i -lt 3; $i++)
	{
		# Test each check to see if one passes.
		if ($MaterialCheck[$i])
		{
			# If a check passes, then exit this function.
			return $false
		}
	}
	return $true
}
#==========================================================================================================================================
#  TEXTURE HASH TABLE - TEXTURE VALIDATION
#==========================================================================================================================================
#  Copies a corrupt texture to a location and outputs information to the console.

function CopyCorruptTexture([hashtable]$texture)
{
	# Copy corrupt textures to a new folder.
	$CorruptPath = CreatePath ($BaseFolder + '\~CorruptTextures' + $texture.Relative)
	Copy-Item -Recurse -Force -LiteralPath $texture.FullPath $CorruptPath

	# Output that the texture is corrupt.
	Write-Host ' Texture    : ' -NoNewline
	Write-Host ($texture.FullName + ' is corrupt.') -ForegroundColor Red
	Write-Host (' Path       : ' + $texture.Folder + $texture.Relative)
	Write-Host ' Message    : Corrupted texture copied to ' -NoNewline
	Write-Host ('~CorruptTextures' + $texture.Relative) -ForegroundColor Green
	Write-Host '-----------------------------------------------------------------------------------------------------------------------'
}
#==========================================================================================================================================
#  Tests if a path/file is a valid texture when creating the Texture Hash Table, using partial data from the Texture Hash Table.

function ValidateTexture([hashtable]$texture)
{
	# Initialize a variable array "Validate" so all checks can be looped through.
	$Validate = New-Object bool[] 9

	# Check 1-6: All checks must fail for the texture to be valid.
	$Validate[0] = ($texture.SplitName[0] -ne 'tex1')     # Check 1: Check for "tex1" to verify it's a texture from SplitName[slot1].
	$Validate[1] = ($texture.Path -like '*~*')            # Check 2: Check if the path contains a "~" which usually indicates paths generated by this script.
	$Validate[2] = (!($texture.Extension))                # Check 3: Check to see if the file is missing a file extension.
	$Validate[3] = ($texture.SplitPeriod[1] -eq 'nrm')    # Check 4: Make sure it's not a normal map texture.
	$Validate[4] = ($texture.SplitPeriod[1] -eq 'spec')   # Check 5: Make sure it's not a specularity map texture.
	$Validate[5] = ($texture.SplitPeriod[1] -eq 'bump')   # Check 6: Make sure it's not a displacement map texture.

	# Check 7-9: Check for "m" extracted from "mip#" from SplitName[4-6]. There should never be "mip" in the 4th slot, meaning invalid mipmap for non-mipmap textures.
	if ($texture.SplitName[4]) { $Validate[6] = (($texture.SplitName[4]).Substring(0,1) -eq 'm') }
	if ($texture.SplitName[5]) { $Validate[7] = (($texture.SplitName[5]).Substring(0,1) -eq 'm') }
	if ($texture.SplitName[6]) { $Validate[8] = (($texture.SplitName[6]).Substring(0,1) -eq 'm') }

	# Loop through each check to see if the file is not a valid texture.
	for($i=0; $i -lt 9; $i++)
	{
		# Test if the check has passed.
		if ($Validate[$i])
		{
			# Return false because the texture is not valid.
			return $false
		}
	}
	#-----------------------------------------------------------------------------------------------------------------------
	# Check 10A: Test if the file is a valid PNG or JPG. Use PowerShell and .NET because it's faster than ImageMagick.
	#-----------------------------------------------------------------------------------------------------------------------
	if (($texture.Extension -eq $PNG) -or ($texture.Extension -eq $JPG))
	{
		# Attempt to load the file as an image. If it's not an image, hide the error from the console.
		$image = New-Object -ComObject Wia.ImageFile
		$ErrorActionPreference = 'silentlycontinue'
		$image.LoadFile($texture.FullPath)

		# Check the width of the image. If there is no width, then it is corrupt or not a texture.
		if (!($image.Width))
		{
			# Copy the corrupted texture to ~CorruptedTextures and output info to the console.
			CopyCorruptTexture $texture
			return $false
		}
	}
	#-----------------------------------------------------------------------------------------------------------------------
	# Check 10B: If the file is DDS, use ImageMagick to test for validity by generating a temporary image from the texture.
	# This check is not performed on DDS textures with a material map. This is an assumption that the texture was created with
	# Ishiiruka Tool. ImageMagick can not handle color textures that are created with Ishiiruka Tool, so force it to pass.
	#-----------------------------------------------------------------------------------------------------------------------
	elseif ($texture.Extension -eq $DDS)
	{
		# Separating this from the previous check is crucial so it hits all DDS files.
		if ($texture.HasMaterialMap -eq $false)
		{
			# Create a temporary path to attempt to generate a test texture.
			$ValidatePath = CreatePath ($TempFolder + '\Validate')

			# Run ImageMagick and generate a temporary 1x1 texture.
			$ValidateTexture = $TempFolder + '\Validate\' + $texture.Name + $PNG
			& $IMConvert -quiet $texture.FullPath -resize 1x1^! $ValidateTexture >$null 2>&1

			# Remove the temporary path and generated texture.
			RemovePath $ValidatePath

			# If the image was not generated, $lastexitcode set by ImageMagick will be greater than 0.
			if ($lastexitcode -gt 0)
			{
				# Copy the corrupted texture to ~CorruptedTextures and output info the console.
				CopyCorruptTexture $texture
				return $false
			}
		}
	}
	#-----------------------------------------------------------------------------------------------------------------------
	# Check 10C: If the file does not have a valid texture extension, simply return false.
	#-----------------------------------------------------------------------------------------------------------------------
	else
	{
		return $false
	}
	#-----------------------------------------------------------------------------------------------------------------------
	# All checks failed. Return that the texture was good.
	return $true
	#-----------------------------------------------------------------------------------------------------------------------
}
#==========================================================================================================================================
#  TEXTURE HASH TABLE - CREATION
#==========================================================================================================================================
# The global texture hash table that is created every iteration of the main loop.

function CreateTextureInfo($file)
{
	# Initialize the texture hash table.
	$Texture = @{}

	# Create strings referencing texture name/path data.
	$Texture.Name      = $file.BaseName
	$Texture.FullName  = $file.Name
	$Texture.Extension = $file.Extension
	$Texture.Folder    = (Get-Location | Get-Item).Name
	$Texture.Path      = [string]$file.Directory
	$Texture.PathName  = $Texture.Path + '\' + $Texture.Name
	$Texture.FullPath  = $Texture.Path + '\' + $Texture.FullName
	$Texture.Relative  = $Texture.Path.replace($BaseFolder,'')

	# Splits the texture name into up to 7 parts based on the underscores. This allows pulling information from the texture name.
	$Texture.SplitName = $Texture.Name.Split('_',7)

	# Splits the texture name into 2 parts based on any periods to find .spec, .bump, .nrm, or Dolphin dupes.
	$Texture.SplitPeriod = $Texture.Name.Split('.',2)

	# Find if the texture has a material map (nrm only) with it. Must be done before validation as it is part of the validation process.
	$Texture.HasMaterialMap = TextureHasCombinedMaterial $Texture
	
	# If a material map was found, set the path to it.
	if ($Texture.HasMaterialMap)
	{
		$Texture.MaterialPath = $Texture.PathName + $NRM + $Texture.Extension
	}
	# Test the texture for validity (corruption, errors, not an image, etc). If it fails, return null.
	if (!(ValidateTexture $Texture))
	{
		# When null is returned, the main loop will instead try to copy the file if "$CopyNonTextures" is enabled.
		return $null
	}
	# Find if the texture has material textures (bump/spec/nrm) with it.
	$Texture.HasMaterials = TextureHasMaterialTextures $Texture

	# If the texture was successfully validated, set the texture size in Bytes.
	$Texture.Size = ($file | Measure-Object -Property 'length' -Sum).Sum

	# Check for "m" to see if it is a MipMap texture.
	$Texture.IsMipMap = ($Texture.SplitName[2] -eq 'm')

	# Get the original texture width/height by further splitting SplitName[1] by the "x".
	$OldDimensions         = $Texture.SplitName[1].Split('x',2)
	$Texture.OldWidth      = [int]$OldDimensions[0]
	$Texture.OldHeight     = [int]$OldDimensions[1]
	$Texture.OldDimensions = [string]$Texture.OldWidth + 'x' + [string]$Texture.OldHeight

	# Get the aspect of the original texture and correct it to hold two decimal places no matter the value.
	$Texture.OldAspect = [decimal](FormatDecimal ($Texture.OldWidth/$Texture.OldHeight).ToString('#.##'))

	# If PNG or JPG, get the custom texture width and height from the image as a ComObject because it's faster than ImageMagick.
	if ($Texture.Extension -ne $DDS)
	{
		$image = New-Object -ComObject Wia.ImageFile
		$image.LoadFile($Texture.FullPath)
		$Texture.Width  = $image.Width
		$Texture.Height = $image.Height
	}
	# If DDS, get the custom texture width and height using ImageMagick "identify.exe".
	else
	{
		$Texture.Width  = [int](& $IMIdentify $IMI7 -quiet -format '%w' $Texture.FullPath)
		$Texture.Height = [int](& $IMIdentify $IMI7 -quiet -format '%h' $Texture.FullPath)
	}
	$Texture.Dimensions = [string]$Texture.Width + 'x' + [string]$Texture.Height

	# Get the aspect of the custom texture.
	$Texture.Aspect = [decimal](FormatDecimal ($Texture.Width/$Texture.Height).ToString('#.##'))

	# Calculate the custom texture scaling.
	$Texture.ScaleWidth  = [decimal](FormatDecimal ($Texture.Width/$Texture.OldWidth).ToString('#.##'))
	$Texture.ScaleHeight = [decimal](FormatDecimal ($Texture.Height/$Texture.OldHeight).ToString('#.##'))
	$Texture.Scale       = $([string]$Texture.ScaleWidth + 'x' + [string]$Texture.ScaleHeight)

	# Alpha check can not be done on DDS textures created with Ishiiruka Tool, so force true for DDS textures that have an included material map.
	# This is only an assumption, as the DDS color texture may have been created with other tools, but it shouldn't matter.
	if (($Texture.Extension -eq $DDS) -and ($Texture.HasMaterialMap))
	{
		# Force detection of an alpha channel to true (for safety?), although alpha channel check will never be used.
		$Texture.HasAlphaChannel = $true
	}
	# In every other case, test the texture for an alpha channel.
	else
	{
		# Find if the texture has any transparent pixels.
		$OpaqueTexture = & $IMIdentify $IMI7 -quiet -format '%[opaque]' $Texture.FullPath
		$Texture.HasAlphaChannel = ($OpaqueTexture -eq 'false')
	}
	# Return the texture data so it can be set to a global and used basically everywhere in the script.
	return $Texture
}
#==========================================================================================================================================
#  MIPMAP FUNCTIONS - Fun Fact: It was a pain to make these functions work as intended.
#==========================================================================================================================================
#  Sub-function for CalculateMipMapLevels to find the number of MipMap levels based on the dimension.

function FindDimensionLevels([int]$dimension, [string]$format)
{
	# Continue to divide the width or height by 2 until 1 (or lower) is hit.
	while($dimension -gt 1)
	{
		# If dealing with DDS textures, find the nearest multiple of 4 of the current dimension.
		if ($format -eq $DDS)
		{
			$dimension = FindMultFour $dimension
		}
		# Perform the calculation as a decimal to remain as accurate as possible.
		[decimal]$HalvedDimension = ($dimension / 2)

		# Divide the dimension in half, and fix the decimal for other regions.
		$NewDimension = FormatDecimal $HalvedDimension.ToString('#.##')

		# Split the value so the decimal can be dropped (and not rounded).
		$NewDimensionSplit = $NewDimension.Split('.',2)

		# Keep only the integer value for the next iteration.
		$dimension = [int]$NewDimensionSplit[0]

		# Increment the number of levels.
		$Levels ++
	}
	# Return the number of levels calculated.
	return $Levels
}
#==========================================================================================================================================
#  Calculates how many MipMap levels a texture should have based on input dimensions.

function CalculateMipMapLevels([int]$inputwidth, [int]$inputheight, [string]$format)
{
	# Find how many levels both dimensions would have.
	$WidthLevels  = FindDimensionLevels $inputwidth $format
	$HeightLevels = FindDimensionLevels $inputheight $format

	# Compare the levels between width and height and return the greater of the two.
	if ($WidthLevels -gt $HeightLevels)
	{
		return $WidthLevels
	}
	return $HeightLevels
}
#==========================================================================================================================================
#  Loop to calculate a single dimension of a MipMap based on the MipMap's current level.

function CalculateMipMapDimension([int]$level, [int]$dimension, [string]$format)
{
	# Continue the loop until the loop iteration reaches the MipMap level.
	for($i=1; $i -le $level; $i++)
	{
		# Make sure the dimension is not less than or equal to 1. Shouldn't ever happen, but just in case.
		if ($dimension -gt 1)
		{
			# If dealing with DDS textures, find the nearest multiple of 4 of the current dimension.
			if ($format -eq $DDS)
			{
				$dimension = FindMultFour $dimension
			}
			# Perform the calculation as a decimal to remain as accurate as possible.
			[decimal]$HalfDimension = ($dimension / 2)

			# Divide the dimension in half, and fix the decimal for other regions.
			$NewDimension = FormatDecimal ($HalfDimension).ToString('#.##')

			# Split the value so the decimal can be dropped (and not rounded).
			$NewDimensionSplit = $NewDimension.Split('.',2)

			# Keep only the integer value for the next iteration.
			$dimension = [int]$NewDimensionSplit[0]
		}
	}
	# Return the calculated dimension.
	return $dimension
}
#==========================================================================================================================================
#  NO LONGER USED: Extracts all internal mipmaps from a DDS textures into the output path.

function ExtractInternalDDSMipMaps([string]$texturepath, [string]$outputpath)
{
	# Set up data for the texture. This eliminates the need for creating a new hash table for material maps.
	$TextureObject     = Get-ChildItem -Recurse -Force -LiteralPath $texturepath
	$TextureName       = $TextureObject.BaseName
	$TextureFullName   = $TextureObject.Name
	$TextureSplit      = $TextureName.Split('.',2)
	$IsTextureMaterial = ($TextureSplit[1] -eq 'nrm')
	$DetachPathBase    = CreatePath ($TempFolder + '\DetachedTextures')

	# Create a copy of the texture to extract mipmaps from.
	Copy-Item -Recurse -Force -LiteralPath $texturepath $DetachPathBase

	# Extract Internal MipMaps from the texture.
	$DetachTextureName = $DetachPathBase + '\' + $TextureName
	& $NDETACH $DetachTextureName

	# Remove the generated "log.wri" created by nvidia detach.
	RemovePath $($BaseFolder + '\log.wri')

	# Create a folder to backup the main texture with internal mipmaps.
	$DetachTextureFull = $DetachPathBase + '\' + $TextureFullName
	$BackupTexturePath = CreatePath ($TempFolder + '\BackupTexture')
	Move-Item -Force -LiteralPath $DetachTextureFull -Destination $BackupTexturePath

	# Count the number of files that remain in the folder.
	$CountTextures = (Get-ChildItem -Recurse -Force -LiteralPath $DetachPathBase | Where-Object {!$_.PSIsContainer} | Measure-Object).Count

	# Check to see if mipmaps were extracted.
	if ($CountTextures -gt 1)
	{
		# Loop through all files within the folder.
		for($i=0; $i -lt $CountTextures; $i++)
		{
			# If were on the top level, a name without the "mip" suffix must be used.
			if ($i -eq 0)
			{
				$NewMipMapName = $TextureFullName
			}
			# If it's a material map, then add the appropriate "nrm" and "mip" suffix.
			elseif ($IsTextureMaterial)
			{
				$NewMipMapName = $TextureSplit[0] + '_mip' + $i + $NRM + $DDS
			}
			# If it's just a regular mipmap, add only the "mip" suffix.
			else
			{
				$NewMipMapName = $TextureName + '_mip' + $i + $DDS
			}
			# Get the current level as a string and in double digits.
			$Level = IntToStringDoubleDigit $i

			# Create a variable to reference the current mipmap in the loop.
			$CurrentMipMap = $DetachPathBase + '\' + $TextureName + '_' + $Level + $DDS

			# Rename the current mipmap to the new name.
			Rename-Item -Force -LiteralPath $CurrentMipMap $NewMipMapName
		}
	}
	# If the user also wants Internal MipMaps, restore the texture that has them.
	if ($DDSMipMapType -eq 'Both')
	{
		# This will also overwrite the extracted top layer from detach.
		$MovePath = $BackupTexturePath + '\' + $TextureFullName
		Move-Item -Force -LiteralPath $MovePath -Destination $DetachPathBase
	}
	# Loop through all mipmaps in the temporary path.
	foreach($MipMapFile in Get-ChildItem -Recurse -Force -LiteralPath $DetachPathBase)
	{
		# Move all mipmaps to the current texture path.
		$MovePath = [string]$MipMapFile.Directory + '\' + $MipMapFile.Name
		Move-Item -Force -LiteralPath $MovePath -Destination $outputpath
	}
}
#==========================================================================================================================================
#  MIPMAP HASH TABLE
#==========================================================================================================================================
#  Unlike the texture hash table, the MipMap hash table is not global. This allows it to be much more dynamic, in that it can be 
#  created multiple times during a single loop iteration. This allows multiple hash tables to contain separate data from each other.

function CreateMipMapInfo([int]$inputwidth, [int]$inputheight, [string]$format)
{
	# Don't even create data if the current texture is not a mipmap.
	if (!($Texture.IsMipMap))
	{
		# Functions that use this function must know how to handle a null return (mostly used in checks to test for null).
		return $null
	}
	# Initialize the mipmap hash table.
	$mipmap = @{}

	# Store how many mipmap levels the texture should have based on input dimensions.
	$mipmap.Levels = CalculateMipMapLevels $inputwidth $inputheight $format

	# Initialize arrays to contain information about each mipmap. ArraySize must be +1 to start with index[1] instead of [0].
	$ArraySize = $mipmap.Levels + 1
	$mipmap.Name           = New-Object string[] $ArraySize
	$mipmap.FullName       = New-Object string[] $ArraySize
	$mipmap.FullPath       = New-Object string[] $ArraySize
	$mipmap.Width          = New-Object string[] $ArraySize
	$mipmap.Height         = New-Object string[] $ArraySize
	$mipmap.Dimensions     = New-Object string[] $ArraySize
	$mipmap.Exists         = New-Object bool[]   $ArraySize
	$mipmap.RealWidth      = New-Object int[]    $ArraySize
	$mipmap.RealHeight     = New-Object int[]    $ArraySize
	$mipmap.RealDimensions = New-Object string[] $ArraySize
	$mipmap.Size           = New-Object int[]    $ArraySize

	# Store information about each MipMap. Start with index [1] instead of [0] for simplicity.
	# Example: "mipmap.Variable[3]" will reference "tex1_128x128_m_e3487d3b2a9d3e11_14_mip3"
	for($i=1; $i -le $mipmap.Levels; $i++)
	{
		# Set up basic information about MipMap.
		$mipmap.Name[$i]       = $Texture.Name + '_mip' + $i
		$mipmap.FullName[$i]   = $Texture.Name + '_mip' + $i + $Texture.Extension
		$mipmap.FullPath[$i]   = $Texture.PathName + '_mip' + $i + $Texture.Extension
		$mipmap.Width[$i]      = CalculateMipMapDimension $i $inputwidth $format
		$mipmap.Height[$i]     = CalculateMipMapDimension $i $inputheight $format
		$mipmap.Dimensions[$i] = [string]$mipmap.Width[$i] + 'x' + [string]$mipmap.Height[$i]

		# Check to see if the MipMap exists.
		if (TestPath $mipmap.FullPath[$i]) 
		{
			# Store that the MipMap exists.
			$mipmap.Exists[$i] = $true

			# Add the current MipMap to the number of mipmaps found.
			$mipmap.LevelsCounted ++

			# Get the MipMap as an object file to set the file size of the MipMap in Bytes.
			$mipobject = Get-ChildItem -Recurse -Force -LiteralPath $mipmap.FullPath[$i]
			$mipmap.Size[$i] = ($mipobject | Measure-Object -Property 'length' -Sum).Sum

			# If PNG or JPG, get the width and height from the image as a ComObject because it's faster than ImageMagick.
			if (($Texture.Extension -eq $PNG) -or ($Texture.Extension -eq $JPG))
			{
				$image = New-Object -ComObject Wia.ImageFile
				$image.LoadFile($mipmap.FullPath[$i])
				$mipmap.RealWidth[$i]  = $image.Width
				$mipmap.RealHeight[$i] = $image.Height
			}
			# If DDS, get the width and height of the mipmap using ImageMagick "identify.exe".
			elseif ($Texture.Extension -eq $DDS)
			{
				$mipmap.RealWidth[$i]  = [int](& $IMIdentify $IMI7 -quiet -format '%w' $mipmap.FullPath[$i])
				$mipmap.RealHeight[$i] = [int](& $IMIdentify $IMI7 -quiet -format '%h' $mipmap.FullPath[$i])
			}
			$mipmap.RealDimensions[$i] = [string]$mipmap.RealWidth[$i] + 'x' + [string]$mipmap.RealHeight[$i]

			# Compare the calculated dimensions with the real dimensions and count the number that don't match up.
			if ($mipmap.Dimensions[$i] -ne $mipmap.RealDimensions[$i])
			{
				$mipmap.BadDimensions ++
			}
		}
		# If the mipmap does not exist, count the number of mipmaps missing.
		else
		{
			$mipmap.Exists[$i] = $false
			$mipmap.LevelsMissing ++
		}
	}
	# Return the MipMap data so it can be set to a variable.
	return $mipmap
}
#==========================================================================================================================================
#  MIPMAP CREATION - SUB-FUNCTIONS OF TEXTURE CREATION FOR CREATING MIPMAPS
#==========================================================================================================================================
#  Sub-function of "CreateTexture" to create mipmaps for PNG or JPG textures.

function CreateMipMaps([hashtable]$mipmap, [string]$format, [string]$outputpath)
{
	# Loop through all levels.
	for($i=1; $i -le $mipmap.Levels; $i++)
	{
		# Store the dimensions in a format needed by ImageMagick.
		$IMDimensions = $mipmap.Dimensions[$i] + '!'

		# Set where to create the new MipMap.
		$MipMapOutputPath = $outputpath + '\' + $mipmap.Name[$i] + $format

		# Check if the user forced new MipMaps through the internal options, chose the advanced function to force new mipmaps from the main menu, or if the MipMap does not exist.
		if (($ForceNewMipMaps) -or ($GenerateMipMaps) -or (!($mipmap.Exists[$i])))
		{
			# If the MipMap did not exist or the user forced new mipmaps, create it from the top layer with sharpening.
			& $IMConvert $Texture.FullPath -resize $IMDimensions -sharpen '0x0.50' $MipMapOutputPath
		}
		# Check to see if the calculated dimensions match the real dimensions.
		elseif ($mipmap.Dimensions[$i] -eq $mipmap.RealDimensions[$i])
		{
			# Check to see if the user-selected file extension matches the texture file extension.
			if ($format -eq $Texture.Extension)
			{
				# If the dimensions matched up and the file extensions are the same then simply copy it.
				Copy-Item -Recurse -Force -LiteralPath $mipmap.FullPath[$i] $MipMapOutputPath
			}
			# If the dimensions matched up but only the extension is changed.
			else
			{
				# Create the MipMap from the existing MipMap without sharpening.
				& $IMConvert $mipmap.FullPath[$i] -resize $IMDimensions $MipMapOutputPath
			}
		}
		# If the MipMap exists, but the dimensions changed.
		else
		{
			# Create the MipMap from the existing MipMap with sharpening.
			& $IMConvert $mipmap.FullPath[$i] -resize $IMDimensions -sharpen '0x0.50' $MipMapOutputPath
		}
	}
}
#==========================================================================================================================================
#  Sub-function of "CreateTexture" to create mipmaps specifically for DDS textures.

function CreateDDSMipMaps([hashtable]$mipmap, [string]$outputpath)
{
	# Create a temporary path to create the initial mipmaps.
	$TempDDSPath = CreatePath ($TempFolder + '\TempDDSMipMaps\')

	# Loop through all levels.
	for($i=1; $i -le $mipmap.Levels; $i++)
	{
		# Create a hash table with a multiple of 4 version of the MipMap dimensions (just in case).
		$MipMapDDS = DDSMultFour $mipmap.Width[$i] $mipmap.Height[$i]

		# Acts as both a path and a switch to enable generating a temporary MipMap.
		$TempMipMap = $null

		# Check if the user forced new MipMaps through the internal options, chose the advanced function to force new mipmaps from the main menu, or if the MipMap does not exist.
		if (($ForceNewMipMaps) -or ($GenerateMipMaps) -or (!($mipmap.Exists[$i])))
		{
			# Set the texture path to generate mipmaps from to the path of the base texture.
			$TempMipMap = $Texture.FullPath
		}
		# Check to see if the calculated dimensions match the real dimensions.
		elseif ($MipMapDDS.Dimensions -eq $mipmap.RealDimensions[$i])
		{
			# If it exists and the dimensions line up, then use the current MipMap as a base.
			$NvidiaInputPath = $mipmap.FullPath[$i]
		}
		# If it exists but dimensions don't line up. 
		else
		{
			# Create a temporary texture from the existing MipMap to use as the MipMap's base.
			$TempMipMap = $mipmap.FullPath[$i]
		}
		# Check if TempMipMap was set, which means a temporary texture must be generated.
		if ($TempMipMap -ne $null)
		{
			# Create a temporary folder for the temporary MipMap.
			$TempMipMapPath = CreatePath ($TempFolder + '\TempMipMap\')

			# Store the path to the temporary MipMap for DDS Utilities.
			$NvidiaInputPath = $TempMipMapPath + $mipmap.FullName[$i]

			# If the calculated dimensions match the real dimensions, disable sharpening. 
			if ($MipMapDDS.Dimensions -eq $mipmap.RealDimensions[$i])
			{
				$SharpenStrength = '0x0.00'
			}
			# Default enable sharpening the texture.
			else
			{
				$SharpenStrength = '0x0.50'
			}
			# Store the dimensions in a format needed by ImageMagick.
			$IMDimensions = $MipMapDDS.Dimensions + '!'

			# Create the temporary MipMap.
			& $IMConvert $TempMipMap -resize $IMDimensions -sharpen $SharpenStrength $NvidiaInputPath
		}
		# Get the current level as a string and in double digits.
		$Level = IntToStringDoubleDigit $i

		# Set up the output path to where the MipMap will be created.
		$MipMapOutputPath = $TempDDSPath + 'TempDDS_' + $Level + $DDS

		# Create the MipMap from wherever NvidiaInputPath was set to.
		& $NVDXT -file $NvidiaInputPath $DDSQualityLevel -nomipmap $DDSCompressionNT -output $MipMapOutputPath | Out-Null

		# Check if the user wants external mipmaps.
		if (($DDSMipMapType -eq 'External') -or ($DDSMipMapType -eq 'Both'))
		{
			# Copy the generated MipMap to the texture output path rather than move it, as it may be needed later for internal mipmaps.
			$ExternalPath = $outputpath + '\' + $mipmap.Name[$i] + $DDS
			Copy-Item -Recurse -Force -LiteralPath $MipMapOutputPath $ExternalPath
		}
	}
	# Check if the user wants internal mipmaps.
	if (($DDSMipMapType -eq 'Internal') -or ($DDSMipMapType -eq 'Both'))
	{
		# Set up a path to where the initial DDS texture was created in "CreateTexture".
		$DDSCreatePath  = $outputpath + '\' + $Texture.Name + $DDS
		$DDSTargetPath = $TempDDSPath + 'TempDDS_00' + $DDS

		# Use the initial DDS texture as the top layer by moving it to the temp folder and renaming it.
		Move-Item -Force -LiteralPath $DDSCreatePath -destination $DDSTargetPath

		# Combine all MipMap levels into a single texture (all textures generated with the name TempDDS_##) using nvidia stitch.
		$StitchTarget = $TempDDSPath + 'TempDDS'
		& $NSTITCH $StitchTarget

		# Move the newly created texture with all MipMap levels to the texture path.
		$NewTextures = $StitchTarget + $DDS
		Move-Item -Force -LiteralPath $($TempDDSPath + 'TempDDS' + $DDS) -destination $DDSCreatePath
	}
	# Clean up the temporary files and folders.
	RemovePath $TempDDSPath
	RemovePath $TempMipMapPath
}
#==========================================================================================================================================
#  TEXTURE CREATION - MASTER FUNCTION FOR CREATING TEXTURES
#==========================================================================================================================================
#  Creates a texture and all MipMap levels at a location using the information of the texture currently stored in the global hash table.
#  Parameters serve as modifiers to the current texture, allowing to alter the format, width, height, and output path to create the texture.

function CreateTexture([int]$inputwidth, [int]$inputheight, [string]$format, [string]$outputpath)
{
	# Return value that states whether or not the texture was created.
	$TextureCreated = $false

	# Combine the new dimensions into a single value.
	$NewDimensions = [string]$inputwidth + 'x' + [string]$inputheight

	# The full path to where the new texture will be created.
	$NewTexturePath = $outputpath + '\' + $Texture.Name + $format

	#--------------------------------------------------------------------------------------------------------------------------------------
	# Create PNG or JPG texture.
	if ($format -ne $DDS)
	{
		# Check if the texture dimensions and extension are the same as the input values.
		if (($NewDimensions -eq $Texture.Dimensions) -and ($format -eq $Texture.Extension))
		{
			# Rather than create it just copy it because the output would be identical anyway.
			Copy-Item -Recurse -Force -LiteralPath $Texture.FullPath $NewTexturePath
			$TextureCreated = TestPath $NewTexturePath
		}
		# New texture has different specifications so it must be created.
		else
		{
			# Enable sharpening for texture only if $ForceIntScaling is true (otherwise it's zero sharpening).
			if ($ForceIntScaling) { $SharpenStrength = '0x0.50' } else { $SharpenStrength = '0x0.00' }

			# Store the dimensions in a format needed by ImageMagick.
			$IMDimensions = $NewDimensions + '!'

			# Generate the new texture.
			& $IMConvert $Texture.FullPath -resize $IMDimensions -sharpen $SharpenStrength $NewTexturePath
			$TextureCreated = TestPath $NewTexturePath
		}
		# Check if it is a MipMap texture.
		if ($Texture.IsMipMap)
		{
			# If it is, then generate MipMaps.
			$MipMap = CreateMipMapInfo $inputwidth $inputheight $format
			CreateMipMaps $MipMap $format $outputpath
		}
	}
	#--------------------------------------------------------------------------------------------------------------------------------------
	# Create DDS texture.
	else
	{
		# Create a hash table with a multiple of 4 version of the input dimensions.
		$NewDDS = DDSMultFour $inputwidth $inputheight

		# Store the dimensions in a format needed by ImageMagick.
		$IMDimensions = $NewDDS.Dimensions + '!'

		# If the texture has an Alpha Channel, convert the texture to DXT5 and set output quality to the highest setting.
		if ($Texture.HasAlphaChannel)
		{
			$DDSQualityLevel  = '-quality_highest'
			$DDSCompressionNT = '-dxt5'
			$DDSCompressionIM = 'dds:compression=dxt5'
			$global:DDSCompression = 'DXT5'
		}
		# If it does not have an Alpha channel, set the compression type to DXT1c and force normal quality or it can generate artifacts.
		else
		{
			$DDSQualityLevel  = '-quality_normal'
			$DDSCompressionNT = '-dxt1c'
			$DDSCompressionIM = 'dds:compression=dxt1'
			$global:DDSCompression = 'DXT1'
		}
		# Calculate the total number of pixels of both the initial image and the result to find out which generation method to use.
		$TotalPixelsDDS = $NewDDS.Width * $NewDDS.Height
		$TotalPixelsOld = $Texture.Width * $Texture.Height
		$StandardMethod = (($TotalPixelsDDS -le 33554432) -and ($TotalPixelsOld -le 33554432)) # 33554432 is the product of 8192*4096.

		# Method 1: Generate texture with Nvidia Tools if the dimensions do not exceed 8192x4096.
		if ($StandardMethod)
		{
			# Default the texture input path for nvidia tools to the texture location.
			$NvidiaInputPath = $Texture.FullPath

			# NVDXT does not accept images with non-multiple 4 dimensions, so a temporary texture must be created before using DDS Utilities.
			# So generate a temporary texture if the calculated DDS dimensions don't line up with the texture's actual dimensions for whatever reason.
			if ($NewDDS.Dimensions -ne $Texture.Dimensions)
			{
				# Set up the path for the temporary texture.
				$TempTexturePath = CreatePath ($TempFolder + '\TempTextures\')

				# Change Nvidia input path to where the temporary texture will be created.
				$NvidiaInputPath = $TempTexturePath + $Texture.FullName

				# Generate the temporary image using ImageMagick.
				& $IMConvert $Texture.FullPath -resize $IMDimensions $NvidiaInputPath
			}
			# Use DDS Utilities to generate the texture.
			& $NVDXT -file $NvidiaInputPath $DDSQualityLevel -nomipmap $DDSCompressionNT -output $NewTexturePath | Out-Null
			$TextureCreated = TestPath $NewTexturePath
		}
		# Method 2: Generate texture with ImageMagick if the dimensions exceed 8192x4096.
		else
		{
			# Log/Console: Alert that ImageMagick is to be used instead.
			Write-Host ' Notice     : Dimensions exceed 8192x4096. Generating with ImageMagick instead of DDS Utilities.' -Foreground Magenta
			$global:LogSpecial = $true

			# Use ImageMagick to generate the texture.
			& $IMConvert $Texture.FullPath -define $DDSCompressionIM -resize $IMDimensions $NewTexturePath
			$TextureCreated = TestPath $NewTexturePath
		}
		# Check if it is a MipMap texture.
		if ($Texture.IsMipMap)
		{
			# If it is, then generate MipMaps.
			$MipMap = CreateMipMapInfo $NewDDS.Width $NewDDS.Height $DDS
			CreateDDSMipMaps $MipMap $outputpath
		}
		# The temporary texture is no longer needed so remove it if it exists.
		RemovePath $TempTexturePath
	}
	# Return whether or not the texture was created.
	return $TextureCreated
}
#==========================================================================================================================================
#  MISCELLANEOUS TEXTURE FUNCTIONS
#==========================================================================================================================================
#  Used to copy a texture, its MipMaps, and Material Map from the current texture path in the hash table to a destination path.

function CopyTexture([string]$copypath)
{
	# Copy the texture if no conversion is necessary.
	Copy-Item -Recurse -Force -LiteralPath $Texture.FullPath $copypath

	# If the texture has a material map, copy it as well.
	if ($Texture.HasMaterialMap)
	{
		Copy-Item -Recurse -Force -LiteralPath $Texture.MaterialPath $copypath
	}
	# Attempt to create a MipMap hash table.
	$MipMap = CreateMipMapInfo $Texture.Width $Texture.Height $Texture.Extension

	# If the texture is a MipMap, look for lower MipMap levels and copy them too.
	if ($MipMap -ne $null)
	{
		# Loop through all lower levels.
		for($i=1; $i -le $MipMap.Levels; $i++) 
		{
			# If the MipMap level exists, copy it.
			if ($MipMap.Exists[$i])
			{
				Copy-Item -Recurse -Force -LiteralPath $MipMap.FullPath[$i] $copypath
			}
		}
	}
}
#==========================================================================================================================================
#  Checks the input decimal against ScaleThreshold, and increments the integer if the decimal is greater than ScaleThreshold.

function ScaleThresholdCorrection([int]$intvalue, [decimal]$decvalue)
{
	# Convert the input integer "decimal" value into an actual decimal value, and fix the decimal for other regions.
	$decvalue = FormatDecimal ($decvalue / 100).ToString('#.##')

	# See if it is greater than or equal ScaleThreshold.
	if ([decimal]$decvalue -ge [decimal]$ScaleThreshold)
	{
		# If it is, increment the scaling integer.
		$intvalue ++
	}
	# Return the new scale.
	return $intvalue
}
#==========================================================================================================================================
#  MATERIAL MAP CREATION - FUNCTIONS FOR CREATING MATERIAL MAPS WITH ISHIIRUKA TOOL
#==========================================================================================================================================
#  Creates an Ishiiruka material map from an already existing material map. Unlike the other material map function found below, this one 
#  will return whether or not the function ran. This is so both functions do not run and waste precious time...

function CreateMaterialMap_FromMaterial([int]$inputwidth, [int]$inputheight, [string]$format, [string]$outputpath)
{
	# Check for a valid path to Ishiiruka Tool.
	if (!(TestPath $IshiirukaTool))
	{
		# Report that Ishiiruka Tool was not found so nothing can be done.
		write-host ' Notice     : Material map (nrm) exists, but path to Ishiiruka Tool not found!' -ForegroundColor Magenta

		# If the path failed, then exit this function.
		return $false
	}
	# Return value that states whether or not the texture was created.
	$TexturesCreated = $false

	# Store the path to the material map, and get the dimensions of it.
	$MaterialWidth  = [int](& $IMIdentify $IMI7 -quiet -format '%w' $Texture.MaterialPath)
	$MaterialHeight = [int](& $IMIdentify $IMI7 -quiet -format '%h' $Texture.MaterialPath)

	# Check if the texture is a mipmap texture or not.
	if (!($Texture.IsMipMap))
	{
		# Check if the format and dimensions line up.
		if (($Texture.Extension -eq $format) -and ($MaterialWidth -eq $inputwidth) -and ($MaterialHeight -eq $inputheight))
		{
			# If so, simply copy it. We only copy non-mipmaps because of the whole internal vs. external shit that gets old.
			Copy-Item -Recurse -Force -LiteralPath $Texture.FullPath $outputpath
			Copy-Item -Recurse -Force -LiteralPath $Texture.MaterialPath $outputpath

			# Report to the console that the textures were copied.
			Write-Host ' Notice     : Material map copied from existing material map.' -ForegroundColor Green

			# Exit the function now that the work is already done.
			return $true
		}
		# If the above check failed, tell Ishiiruka Tool this is not a mipmap texture.
		$nomipmaps = '-nomipmaps'
	}
	# Check if the user wanted to convert textures to DDS.
	if ($format -eq $DDS)
	{
		# Send the "compress" command to Ishiiruka Tool to create DDS material maps.
		$compress = '-compress'

		# Set the DDS Compression type to 'Ishiiruka'.
		$global:DDSCompression = 'Ishiiruka'
	}
	# Check the dimensions to see if rescaling is necessary.
	if (($MaterialWidth -ne $inputwidth) -or ($MaterialHeight -ne $inputheight))
	{
		# Send the new dimensions to Ishiiruka Tool.
		$IshiirukaWidth  = '-w' + $inputwidth
		$IshiirukaHeight = '-h' + $inputheight
	}
	# Run Ishiiruka Tool with all input parameters.
	& $IshiirukaTool $Texture.MaterialPath $outputpath $nomipmaps $compress $IshiirukaWidth $IshiirukaHeight '-savecolor' '-frommaterial' | Out-Null

	# Paths to check and see if the textures were created.
	$FinalTexture  = $outputpath + '\' + $Texture.Name + $format
	$FinalMaterial = $outputpath + '\' + $Texture.Name + $NRM + $format

	# Test if the textures were created.
	if ((TestPath $FinalTexture) -and (TestPath $FinalMaterial))
	{
		# Report to the console that the texture was created.
		Write-Host ' Notice     : Material map created from existing material map.' -ForegroundColor Green

		# Flag that the texture was created.
		$TexturesCreated = $true
	}
	# Return whether or not the texture was created.
	return $TexturesCreated
}
#==========================================================================================================================================
#  Creates an Ishiiruka material map from "nrm", "spec", and "bump" textures.

function CreateMaterialMap_FromTextures([int]$inputwidth, [int]$inputheight, [string]$format, [string]$outputpath)
{
	# Check for a valid path to Ishiiruka Tool.
	if (!(TestPath $IshiirukaTool))
	{
		# Report that Ishiiruka Tool was not found so nothing can be done.
		Write-Host ' Notice     : Material textures exist, but path to Ishiiruka Tool not found!' -ForegroundColor Magenta

		# If path failed, then exit this function.
		return $false
	}
	# Return value that states whether or not the texture was created.
	$TexturesCreated = $false

	# If new dimensions are specified (with rescale textures option), new materials must be created with these dimensions.
	if (($inputwidth -ne $Texture.Width) -or ($inputheight -ne $Texture.Height))
	{
		# Initialize the arrays so they can be modified.
		$OldMaterial = New-Object string[] 3
		$NewMaterial = New-Object string[] 3

		# Create paths to the original materials.
		$OldMaterial[0] = $Texture.PathName + '.nrm' + $PNG
		$OldMaterial[1] = $Texture.PathName + '.bump' + $PNG
		$OldMaterial[2] = $Texture.PathName + '.spec' + $PNG

		# Create paths to the newly generated materials.
		$TempScaledMaterials = CreatePath ($TempFolder + '\TempScaledMaterials')
		$NewMaterial[0] = $TempScaledMaterials + '\' + $Texture.Name + '.nrm' + $PNG
		$NewMaterial[1] = $TempScaledMaterials + '\' + $Texture.Name + '.bump' + $PNG
		$NewMaterial[2] = $TempScaledMaterials + '\' + $Texture.Name + '.spec' + $PNG

		# Create new dimensions based on the input dimensions.
		$NewDimensions = [string]$inputwidth + 'x' + [string]$inputheight

		# Store the dimensions in a format needed by ImageMagick.
		$IMDimensions = $NewDimensions + '!'

		# Loop through each material.
		for($i=0; $i -lt 3; $i++)
		{
			# Check to see if the original material exists.
			if (TestPath $OldMaterial[$i])
			{
				# If it does, then create a rescaled version of the material.
				& $IMConvert $OldMaterial[$i] -resize $IMDimensions -sharpen '0x0.50' $NewMaterial[$i]
			}
		}
		# Set the path to the temporary color map. 
		$TinoTexturePath = $TempScaledMaterials + "\" + $Texture.Name + $PNG

		# Create the temporary rescaled color map.
		& $IMConvert $($Texture.PathName + $PNG) -resize $IMDimensions -sharpen '0x0.50' $TinoTexturePath
	}
	# In any other case, the base texture can be used.
	else
	{
		# Set the path to the current texture in the main loop.
		$TinoTexturePath = $Texture.FullPath
	}
	# Check if the texture is a mipmap texture or not.
	if (!($Texture.IsMipMap))
	{
		$nomipmaps = '-nomipmaps'
	}
	# Check if the user wanted to convert textures to DDS.
	if ($format -eq $DDS)
	{
		# If they did, then add the compress argument to Ishiiruka Tool. Otherwise this value will be empty.
		$compress = '-compress'

		# Set the DDS Compression type to 'Ishiiruka'.
		$global:DDSCompression = 'Ishiiruka'
	}
	# Create the material map and all mipmaps in the temporary folder.
	& $IshiirukaTool $TinoTexturePath $outputpath $nomipmaps $compress '-savecolor' | Out-Null

	# Cleanup the junk.
	RemovePath $TempScaledMaterials

	# Paths to check and see if the textures were created.
	$FinalTexture  = $outputpath + '\' + $Texture.Name + $format
	$FinalMaterial = $outputpath + '\' + $Texture.Name + $NRM + $format

	# Test if the textures were created.
	if ((TestPath $FinalTexture) -and (TestPath $FinalMaterial))
	{
		# Report to the console that the texture was created.
		Write-Host ' Notice     : Material map created from material (bump/spec/nrm) textures.' -ForegroundColor Green

		# Flag that the texture was created.
		$TexturesCreated = $true
	}
	# Return whether or not the texture was created.
	return $TexturesCreated
}
#==========================================================================================================================================
#  LOG FILE AND CONSOLE - UPDATE BEFORE AND AFTER TEXTURE HAS BEEN PROCESSED
#==========================================================================================================================================
#  Updates the console with texture information before processing the texture in the Main Loop.

function ConsoleStartInfo()
{
	# Manual Rescale has its own information to display, so don't display this if it's enabled.
	if (!$ManualRescale)
	{
		# Writes information about the texture to the console window.
		Write-Host ' Texture    : ' -NoNewline
		Write-Host $Texture.FullName -ForegroundColor Cyan
		Write-Host (' Path       : ' + $Texture.Folder + $Texture.Relative)
		Write-Host (' Dimensions : ' + $Texture.Dimensions + ' : ' + [string]$Texture.Aspect)
		Write-Host (' Scale      : ' + $Texture.Scale)
	}
}
#==========================================================================================================================================
#  Set up the message to display in ConsoleEndInfo which shows after the main loop processes a texture.
#  Parameter $msgtype accepts: 0-Error message, 1-One part message, 2-Two part message

function SetConsoleMessage([int]$msgtype, [string]$msgstart, [string]$msgend)
{
	$global:ConsoleType=$msgtype
	$global:ConsoleMsgA=$msgstart
	$global:ConsoleMsgB=$msgend
}
#==========================================================================================================================================
#  Updates the console with texture information after processing the texture in the Main Loop. 

function ConsoleEndInfo()
{
	# Error Message - Shows the message in format "ERROR : $ConsoleMsgA"
	if ($ConsoleType -eq 0)
	{
		Write-Host (' ERROR      : '  + $ConsoleMsgA) -ForegroundColor Red
	}
	# Standard Message - Shows the message in format "Message : $ConsoleMsgA"
	elseif ($ConsoleType -eq 1)
	{
		Write-Host (' Message    : ' + $ConsoleMsgA)
	}
	# 2-Part Message - Shows the message in format "Message : $ConsoleMsgA $ConsoleMsgB"
	elseif ($ConsoleType -eq 2)
	{
		Write-Host (' Message    : ' + $ConsoleMsgA) -NoNewline
		Write-Host $ConsoleMsgB -ForegroundColor Green
	}
	# Notice Message - Shows a notice message in magenta.
	elseif ($ConsoleType -eq 3)
	{
		Write-Host (' Notice     : '  + $ConsoleMsgA) -ForegroundColor Magenta
	}
	# Reset the message variables to a null value. This prevents text popping up when it's not wanted.
	$global:ConsoleType=$null
	$global:ConsoleMsgA=$null
	$global:ConsoleMsgB=$null
	Write-Host '-----------------------------------------------------------------------------------------------------------------------'
}
#==========================================================================================================================================
#  Creates the log file.

function LogInitialize()
{
	# Set the base log path.
	$global:LogFile=$BaseFolder + '\' + $ScriptName + '.log'

	# If a log file already exists, remove it before starting to add data to it.
	RemovePath $LogFile

	# Log the intro stuff.
	Add-Content -LiteralPath $LogFile -value 'Custom Texture Tool PS - Operation Log '
	Add-Content -LiteralPath $LogFile -value '---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------'

	# Log all (important) enabled options for viewing pleasure as one long string.
	$EnabledOptions = $nullstr
	if ($ScanAllTextures)  { $EnabledOptions += 'Scan Textures, ' }
	if ($CopyBadTextures)  { $EnabledOptions += 'Copy Bad Textures, ' }
	if ($AutoFixTextures)  { $EnabledOptions += 'Repair Bad Textures, ' }
	if ($ForceIntScaling)  { $EnabledOptions += 'Forced Integer Scale (' + $ForcedScale + 'x), ' }
	if ($ConvertTextures)  { $EnabledOptions += 'Convert Texture Format (' + $(ExtensionToText $ConvertedFormat) + '), ' }
	if ($OptiPNGTextures)  { $EnabledOptions += 'OptiPNG Optimization, ' }
	if ($CreateMaterials)  { $EnabledOptions += 'Create Material Maps, ' }
	if ($CreateWatermark)  { $EnabledOptions += 'Create Watermarks, ' }
	if ($GenerateMipMaps)  { $EnabledOptions += 'Generate MipMaps In-Place, ' }
	if ($RemoveBadMipMap)  { $EnabledOptions += 'Remove Invalid MipMaps, ' }
	if ($HideOKTextures)   { $EnabledOptions += 'Hide OK Textures, ' }
	if ($IgnoreDuplicates) { $EnabledOptions += 'Hide Duplicates, ' }
	if ($DDSAutoRepair)    { $EnabledOptions += 'DDS Auto-Repair, ' }
	if ($ForceNewMipMaps)  { $EnabledOptions += 'Force New MipMaps, ' }
	if ($ManualRescale)    { $EnabledOptions += 'Manual Rescale, ' }
	if ($CopyNonTextures)  { $EnabledOptions += 'Copy Non-Textures, ' }
	$EnabledOptions = $EnabledOptions.TrimEnd(', ')

	# Print all enabled options in the log file.
	Add-Content -LiteralPath $LogFile -value ('Enabled Options: ' + $EnabledOptions)
}
#==========================================================================================================================================
#  Updates the log with texture information after processing the texture in the Main Loop.

function AttemptUpdateLogFile()
{
	# Only log the texture if it has issues, if the user does not want to hide OK textures, or if the script is not checking for issues.
	if (($LogIssues -ne 'OK') -or ($HideOKTextures -eq $false) -or ($ScanAllTextures -eq $false))
	{
		# If the path has changed since the last texture, then log the new path for the next texture.
		if ($Texture.Path -ne $PreviousPath)
		{
			Add-Content -LiteralPath $LogFile -value '---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------'
			Add-Content -LiteralPath $LogFile -value $('Path: ' + $Texture.Path)
			Add-Content -LiteralPath $LogFile -value ''
		}
		# Format text for log files using the custom "ExtendString" function.
		$LogName    = ExtendString $Texture.FullName 52
		$LogOldDim  = ExtendString $([string]$Texture.OldWidth + 'x' + [string]$Texture.OldHeight + ':' + [string]$Texture.OldAspect) 14
		$LogNewDim  = ExtendString $([string]$Texture.Width + 'x' + [string]$Texture.Height + ':' + [string]$Texture.Aspect) 14
		$LogScale   = ExtendString $Texture.Scale 11

		# Output formatted text to the log file. Uses the global $LogMessage variable to display additional info.
		$LogOutput  = $LogName + ' [Original] ' + $LogOldDim + ' [Custom] ' + $LogNewDim + ' [Scale] ' + $LogScale + ' [Status] ' + $LogIssues + $LogMessage
		Add-Content -LiteralPath $LogFile -value $LogOutput

		# After the log message has been used, wipe it out so it doesn't display again unless set.
		$global:LogMessage = $null

		# Special alert that ImageMagick was used to generate the texture.
		if ($LogSpecial)
		{
			Add-Content -LiteralPath $LogFile -value 'Notice: Texture dimensions exceeded 8192x4096. Generated with ImageMagick instead of DDS Utilities.'
			$global:LogSpecial = $false
		}
		# Store the current path so when the next texture is analyzed, it is known whether or not the path changed so the log can be updated accordingly.
		$global:PreviousPath = $Texture.Path
	}
}
#==========================================================================================================================================
#  TEXTURE REPAIR AND COPY
#==========================================================================================================================================
#  Try to fix the texture and/or copy the broken texture to a new directory.

function AttemptRepairAndCopy()
{
	# A flag that tells that the texture is currently broken.
	$FixedTexture = $false

	# Find the difference in aspect between the original and custom textures.
	$AspectDif = $Texture.Aspect - $Texture.OldAspect

	# If the aspect is a negative number then reverse it.
	if ($AspectDif -lt 0) { $AspectDif *= -1 }

	# Test if the texture aspect difference is within the aspect fix threshold.
	$ApectPass = ($AspectDif -le [decimal]$AspectThreshold)

	# Attempt to repair the bad texture.
	if (($AutoFixTextures) -and ($ApectPass))
	{
		# Use the width integer scale if it is smaller than the height.
		if ($Texture.ScaleWidth -lt $Texture.ScaleHeight)
		{
			# Set the new integer scale to the width of the texture by splitting the integer from the decimal value.
			$ScaleSplit = $Texture.ScaleWidth.ToString().Split('.',2)
		}
		# Use the height integer scale if it is smaller than the width.
		else
		{
			# Set the new integer scale to the height of the texture by splitting the integer from the decimal value.
			$ScaleSplit = $Texture.ScaleHeight.ToString().Split('.',2)
		}
		# Test if the new scaling value held a decimal value.
		if ($ScaleSplit[1])
		{
			# Send the integer and the decimal (in the form of a whole number) to ScaleThresholdCorrection.
			$NewScale = ScaleThresholdCorrection $ScaleSplit[0] $ScaleSplit[1]
		}
		# Use the new scaling value to determine the new dimensions.
		$NewWidth  = ([int]$Texture.OldWidth * $NewScale)
		$NewHeight = ([int]$Texture.OldHeight * $NewScale)

		# Create the repaired folder location if it does not exist.
		$OutputPath = CreatePath ($BaseFolder + '\~RepairedTextures' + $Texture.Relative)

		# If the texture has an already combined material map, recreate that as well.
		if ($Texture.HasMaterialMap)
		{
			$FixedTexture = CreateMaterialMap_FromMaterial $NewWidth $NewHeight $Texture.Extension $OutputPath
		}
		# If the texture has a bump, spec, and nrm textures, then create a material map from them.
		elseif ($Texture.HasMaterials)
		{
			$FixedTexture = CreateMaterialMap_FromTextures $NewWidth $NewHeight $Texture.Extension $OutputPath
		}
		# Otherwise create the texture normally.
		else
		{
			$FixedTexture = CreateTexture $NewWidth $NewHeight $Texture.Extension $OutputPath
		}
		# If the texture was repaired, report it.
		if ($FixedTexture)
		{
			# Console: Add the logging events.
			SetConsoleMessage 2 'Texture successfully repaired to ' $('~RepairedTextures' + $Texture.Relative)
		}
		# This should never happen, but if the texture failed to be repaired report it.
		else
		{
			# Console: Add the logging events.
			SetConsoleMessage 0 'Texture failed creation and was not repaired!' $nullstr
		}
	}
	# Check if the user wants to copy bad textures, but only copy them if they weren't fixed.
	if (($CopyBadTextures) -and ($FixedTexture -eq $false))
	{
		# Create the broken textures folder if it does not exist and copy the broken texture.
		$OutputPath = CreatePath ($BaseFolder + '\~BrokenTextures' + $Texture.Relative)
		CopyTexture $OutputPath

		# Console: Add the logging events.
		SetConsoleMessage 2 'Texture has been copied to ' $('~BrokenTextures' + $Texture.Relative)
	}
}
#==========================================================================================================================================
#  OPTION 1 - ISSUE DETECTION - ISSUES
#==========================================================================================================================================
#  Issue 0: Check to see if it's actually an HD texture.

function CheckNotHDTexture()
{
	# See if the user wants to detect NotHD textures.
	if (!($AllowNotHD))
	{
		# Test both the width and height.
		if (($Texture.ScaleWidth -le 1) -or ($Texture.ScaleHeight -le 1))
		{
			# Copy NotHD textures to their own folder.
			$OutputPath = CreatePath ($BaseFolder + '\~NotHDTextures' + $Texture.Relative)
			CopyTexture $OutputPath

			# Log/Console: Output that it copied the file.
			SetConsoleMessage 2 'Texture has been copied to ' $('~NotHDTextures' + $Texture.Relative)
			$global:LogIssues = 'NotHD, '

			# Return that the texture had this issue.
			return $true
		}
	}
	# Return that the texture does not have this issue.
	return $false
}
#==========================================================================================================================================
#  Issue 1: Check for Dolphin identified duplicates (ones that end with .1, .2, .3, etc.)

function CheckDolphinDupe()
{
	# Check to see something exists after the period, and that it is an integer (so it doesn't catch "material map" textures).
	if (($Texture.SplitPeriod[1]) -and ($Texture.SplitPeriod[1] -as [int] -is [int]))
	{
		# Copy DolphinDupes to their own folder.
		$OutputPath = CreatePath ($BaseFolder + '\~DolphinDuplicates' + $Texture.Relative)
		CopyTexture $OutputPath

		# Log/Console: Output that it copied the file.
		SetConsoleMessage 2 'Texture has been copied to ' $('~DolphinDuplicates' + $Texture.Relative)
		$global:LogIssues += 'Dolphin Duplicate, '

		# Return that the texture had this issue.
		return $true
	}
	# Return that the texture does not have this issue.
	return $false
}
#==========================================================================================================================================
#  Issue 2: Test for Duplicate Texture.

function CheckDuplicateTexture()
{
	# Only run if the user does not want to hide duplicates.
	if (!($IgnoreDuplicates))
	{
		# Find the texture in the "Duplicates" hash table if it exists.
		if ($Duplicates.ContainsKey($Texture.Name))
		{
			# Copy Duplicates to their own folder.
			$OutputPath = CreatePath ($BaseFolder + '\~DuplicateTextures' + $Texture.Relative)
			CopyTexture $OutputPath

			# Console: Output that it copied the file.
			SetConsoleMessage 2 'Texture copied to ' $('~DuplicateTextures' + $Texture.Relative)

			# Get the value of that texture from the hash table (the size of the texture when added).
			$CheckSize = $Duplicates.Get_Item($Texture.Name)

			# If the sizes match, then it's an exact duplicate.
			if ($CheckSize -eq $Texture.Size)
			{
				# Log: Add the issue to the global issues variable.
				$global:LogIssues += 'Duplicate Texture, '
			}
			# If they don't match report that it is different.
			else
			{
				# Log: Add the issue to the global issues variable.
				$global:LogIssues += 'Duplicate Texture (Different), '
			}
			# Return that the texture had this issue.
			return $true
		}
		# If the texture was not in the Duplicates hash table.
		else
		{
			# Add it to the Duplicates hash table by texture name and store the size as its value.
			$Duplicates.Add($Texture.Name, $Texture.Size)
		}
	}
	# Return that the texture does not have this issue.
	return $false
}
#==========================================================================================================================================
#  Issue 3: Check to see if there are any missing MipMaps.

function CheckMissingMipMaps([hashtable]$mipmap)
{
	# This value is created in the MipMap hash table and stores the number of MipMaps missing.
	if ($mipmap.LevelsMissing)
	{
		# Log/Console: Add the issue to the global issues variable.
		$global:LogIssues += 'MipMaps Missing (x' + $mipmap.LevelsMissing + '), '

		# Return that the texture had this issue.
		return $true
	}
	# Return that the texture does not have this issue.
	return $false
}
#==========================================================================================================================================
#  Issue 4: Check to see if the texture has material textures.

function CheckForMaterialTextures()
{
	# Reference the "HasMaterials" variable.
	if ($Texture.HasMaterials)
	{
		# Log/Console: Add the issue to the global issues variable.
		$global:LogIssues += 'Material Textures, '

		# Return that the texture had this issue.
		return $true
	}
	# Return that the texture does not have this issue.
	return $false
}
#==========================================================================================================================================
#  Issue 5: Check to see if there are any MipMaps with bad scaling values.

function CheckMipMapsScale([hashtable]$mipmap)
{
	# This value was created in the MipMap hash table and stores the number of MipMaps with bad dimensions.
	if ($mipmap.BadDimensions)
	{
		# Log/Console: Add the issue to the global issues variable.
		$global:LogIssues += 'MipMaps Bad Scale (x' + $mipmap.BadDimensions + '), '

		# Return that the texture had this issue.
		return $true
	}
	# Return that the texture does not have this issue.
	return $false
}
#==========================================================================================================================================
#  Issue 6: Check to see if the integer variables match between scales.

function CheckTextureUnevenScale()
{
	# Scaling values should be identical for both width and height.
	if ($Texture.ScaleWidth -ne $Texture.ScaleHeight)
	{
		# Log/Console: Add the issue to the global issues variable.
		$global:LogIssues += 'Uneven Scale, '

		# Return that the texture had this issue.
		return $true
	}
	# Return that the texture does not have this issue.
	return $false
}
#==========================================================================================================================================
#  Issue 7: Check to see if the scale is an integer scale.

function CheckTextureIntegerScale()
{
	# Split the value for both width and height to grab a decimal value if it exists.
	$WidthCheck  = $Texture.ScaleWidth.ToString().Split('.',2)
	$HeightCheck = $Texture.ScaleHeight.ToString().Split('.',2)
	
	# The value should store double zeros if there is no decimal value.
	if ($WidthCheck[1] -ne '00' -or $HeightCheck[1] -ne '00')
	{
		# Log/Console: Add the issue to the global issues variable.
		$global:LogIssues += 'Non-Integer Scale, '

		# Return that the texture had this issue.
		return $true
	}
	# Return that the texture does not have this issue.
	return $false
}
#==========================================================================================================================================
#  Issue 8: Check to see if the aspects match between original and custom.

function CheckTextureAspect()
{
	# Aspects should be identical for both the original and custom texture.
	if (!($Texture.OldAspect -eq $Texture.Aspect))
	{
		# Log/Console: Add the issue to the global issues variable.
		$global:LogIssues += 'Bad Aspect Ratio, '

		# Return that the texture had this issue.
		return $true
	}
	# Return that the texture does not have this issue.
	return $false
}
#==========================================================================================================================================
#  Issue 9: Check DDS dimensions against calculated dimensions to see if they are at the nearest multiple of 4.

function CheckDDSMultFour()
{
	# Set an annoying amount of variables to get the "DDS version" of the dimensions.
	$SplitScaleWidth = $Texture.ScaleWidth.ToString().Split('.',2)

	# Calculate the dimensions using the original texture and the current width scale.
	$CheckWidth = [int]$Texture.OldWidth * [int]$SplitScaleWidth[0]

	# Height scale is not used because if the scales are uneven it would throw off the calculation.
	$CheckHeight = [int]$Texture.OldHeight * [int]$SplitScaleWidth[0]

	# Run the new dimensions through the DDS dimension algorithm to get a hashtable with the "nearest multiple of 4" dimensions.
	$CheckDDS = DDSMultFour $CheckWidth $CheckHeight

	# If the dimensions end up different than the custom texture, then the custom texture is wrong.
	if ($Texture.Dimensions -ne $CheckDDS.Dimensions)
	{
		# Log/Console: Add the issue to the global issues variable.
		$global:LogIssues += 'Bad DDS Dimensions, '

		# Return that the texture had this issue.
		return $true
	}
	# Return that the texture does not have this issue.
	return $false
}
#==========================================================================================================================================
#  Issue 10: Check DDS for missing internal mipmaps.

function CheckDDSInternalMipMaps([hashtable]$mipmap)
{
	# Create a folder to extract MipMaps to.
	$TempPath   = CreatePath ($TempFolder + '\Extracted')
	$DetachPath = $TempPath + "\" + $Texture.Name

	# Create a copy of the texture to extract MipMaps from.
	Copy-Item -Recurse -Force -LiteralPath $Texture.FullPath ($DetachPath + $DDS)

	# Extract MipMaps from the texture to see if it has internal MipMaps.
	& $NDETACH $DetachPath

	# Remove the generated "log.wri" created by nvidia detach.
	RemovePath $($BaseFolder + '\log.wri')

	# Keeps track of the number of MipMaps that were extracted.
	$MipMapsFound = 0

	# Loop through all levels.
	for($i=1; $i -le $mipmap.Levels; $i++)
	{
		# Get the current level as a string and in double digits.
		$Level = IntToStringDoubleDigit $i

		# Check to see if the MipMap exists.
		if (TestPath $($DetachPath + '_' + $Level + $DDS))
		{
			# If it is found, count it.
			$MipMapsFound = $MipMapsFound + 1
		}
	}
	# Remove the temporary directory and all extracted mipmaps.
	RemovePath $TempPath

	# Find how many mipmap levels are missing.
	$CountMissing = $mipmap.Levels - $MipMapsFound

	# Hack: Work-around bug in Nvidia detach that does not extract 1x1 mipmaps if dimensions are uneven.
	if (($Texture.OldWidth -ne $Texture.OldHeight) -and ($CountMissing -eq 1))
	{
		# Hack: Since we can't know if that 1x1 MipMap exists or not, just assume that it is there.
		$CountMissing = 0
	}
	# The log stuff to report missing mipmaps.
	if ($CountMissing -gt 0)
	{
		# Log/Console: Add the issue to the global issues variable.
		$global:LogIssues += 'Internal MipMaps Missing (x' + $CountMissing + '), '

		# Return that the texture had this issue.
		return $true
	}
	# Return that the texture does not have this issue.
	return $false
}
#==========================================================================================================================================
#  OPTION 1 - ISSUE DETECTION - MASTER FUNCTION
#==========================================================================================================================================
#  Checks a texture for all issues and reports to logs.

function CheckTextureForIssues()
{
	# A compilation of all issues in a single string. Default as an empty string.
	$global:LogIssues = $nullstr

	# This is set to true later if the texture should be repaired.
	$RunAutoFix = $false

	# Create a MipMap hash table if it is a MipMap texture (function returns null if it is not).
	$MipMap = CreateMipMapInfo $Texture.Width $Texture.Height $Texture.Extension

	# Set an array to store the state of all issues.
	$TextureIssue = New-Object bool[] 11
	$TextureIssue[0] = CheckNotHDTexture
	$TextureIssue[1] = CheckDolphinDupe
	$TextureIssue[2] = CheckDuplicateTexture
	$TextureIssue[3] = CheckMissingMipMaps $MipMap
	$TextureIssue[4] = CheckForMaterialTextures
	if ($Texture.Extension -ne $DDS)
	{
		$TextureIssue[5] = CheckMipMapsScale $MipMap
		$TextureIssue[6] = CheckTextureUnevenScale
		$TextureIssue[7] = CheckTextureIntegerScale
		$TextureIssue[8] = CheckTextureAspect
	}
	else
	{
		$TextureIssue[9] = CheckDDSMultFour
		$TextureIssue[10] = CheckDDSInternalMipMaps $MipMap
	}
	# --------------------------------------------------------------------------------------------
	# Log/Console: If the texture did not have issues, then the string should be empty.
	if ($LogIssues -eq $nullstr)
	{
		# Texture did not have issues so log that it is OK.
		$global:LogIssues = 'OK'
	}
	# The string was not empty so there were issues.
	else
	{
		# Trim the comma from the final issue set.
		$global:LogIssues = $LogIssues.TrimEnd(', ')
	}
	# Force output of the issues to the console.
	Write-Host (' Status     : ' + $LogIssues)

	# --------------------------------------------------------------------------------------------
	# Repair/Copy: Variable to track if a texture should be repaired or copied.
	$AttemptRepairCopy = $false

	# Set the loop up to check issues 3-10. These issues must PASS to repair/copy the texture.
	for($i=3; $i -lt 11; $i++)
	{
		# Attempt to repair/copy only if the texture has issues 3-10.
		if ($TextureIssue[$i])
		{
			$AttemptRepairCopy = $true
		}
	}
	# Set another loop to check issues 0-2. These issues must FAIL to repair/copy the texture.
	for ($i=0; $i -lt 3; $i++)
	{
		# Cancel repair/copy if it is a NotHD texture, Duplicate, or DolphinDupe.
		if ($TextureIssue[$i])
		{
			$AttemptRepairCopy = $false
		}
	}
	# Check if only the proper issues have passed.
	if ($AttemptRepairCopy)
	{
		# Try to repair or copy the broken texture.
		AttemptRepairAndCopy
	}
}
#==========================================================================================================================================
#  COPY JPG TEXTURES
#==========================================================================================================================================
#  Function exists to reduce duplicate code. When rescaling or converting textures, JPG textures require special attention. 
function CheckCopyJPG([string]$CheckExtension, [string]$OutPutPath)
{
	# We only want to run this on JPG textures.
	if ($CheckExtension -eq $JPG)
	{
		# Do not even try to convert textures with Material Maps to JPG.
		if (($Texture.HasMaterialMap) -or ($Texture.HasMaterials))
		{
			# Log/Console: Add the logging events.
			SetConsoleMessage 3 'Textures with a Material Map are not converted to JPG!' $nullstr
			$global:LogMessage = 'Texture Not Converted to JPG (Texture has Material)'

			# Copy the texture since no conversion is necessary.
			CopyTexture $OutPutPath
			return $true
		}
		# Check if the original texture has an alpha channel
		elseif ($Texture.HasAlphaChannel)
		{
			# Log/Console: Add the logging events.
			SetConsoleMessage 3 'Textures with an alpha channel are not converted to JPG!' $nullstr
			$global:LogMessage = 'Texture Not Converted to JPG (Texture has Alpha Channel)'

			# Copy the texture since no conversion is necessary.
			CopyTexture $OutPutPath
			return $true
		}
	}
	return $false
}
#==========================================================================================================================================
#  OPTION 2 - RESCALE TEXTURES WITH FIXED INTEGER
#==========================================================================================================================================
#  A menu that is displayed when Rescaling textures and "ManualRescale" is enabled.

function ManualRescaleTextureMenu()
{
	# If the user wants to default to skipping textures with 0, set it as the message. Otherwise display the stored integer as default.
	$MenuMsg = $StoredScale
	if ($StoredScale -eq "0")
	{
		$MenuMsg = 'Skip Texture'
	}
	# Write information about the texture to the console window.
	Write-Host ' Texture    : ' -NoNewline
	Write-Host $Texture.FullName -ForegroundColor Cyan
	Write-Host (' Path       : ' + $Texture.Folder + $Texture.Relative)
	Write-Host (' Original   : ' + $Texture.OldDimensions + ' : ' + [string]$Texture.OldAspect)
	Write-Host (' Custom     : ' + $Texture.Dimensions + ' : ' + [string]$Texture.Aspect + ' : (' + $Texture.Scale + ' Scale)')
	Write-Host ''
	Write-Host (' Enter a new scale. (1-100 , 0 = Skip Texture , Default = ' + $MenuMsg + ')') -ForegroundColor Yellow
	Write-Host ''
	$MenuInput = Read-Host '> '
	Write-Host ''
	Write-Host ' Notice     : Rescaling texture with custom scale...'

	# If the user inputs nothing, then set the input to the stored scale.
	if ($MenuInput -eq $nullstr)
	{
		# The most important reason is to catch a stored scale of "0".
		$MenuInput = $StoredScale
	}
	# If the user wants to skip the texture then allow it.
	if ($MenuInput -eq '0')
	{
		# Return true to skip the texture.
		return $true
	}
	# Check that the entered scale is 1-100.
	elseif (([int]$MenuInput -ge 1) -and ([int]$MenuInput -le 100))
	{
		# Store the new scaling value in a global variable.
		$global:ForcedScale = $MenuInput

		# Return false so the texture is not skipped.
		return $false
	}
	# If there is invalid input, then use the stored scale.
	else
	{
		# Store the new scaling value in a global variable.
		$global:ForcedScale = $StoredScale

		# Return false so the texture is not skipped.
		return $false
	}
}
#==========================================================================================================================================
#  This is called if the user forces the script to convert textures to an integer scale.

function RescaleTextureInteger()
{
	# The user preferred to use the texture's file extension rather than convert.
	if ($ConvertedFormat -eq $null)
	{
		# Do not convert the texture when rescaling.
		$RescaleExtension = $Texture.Extension

		# Make sure the directory to create rescaled textures exists.
		$RescaledPath = CreatePath ($BaseFolder + '\~RescaledTextures' + $Texture.Relative)
	}
	# The user  wanted to convert to a specific format.
	else
	{
		# Get the extensions as text.
		$FileType = ExtensionToText $ConvertedFormat

		# Set the type of texture to convert to when rescaling.
		$RescaleExtension = $ConvertedFormat

		# Make sure the directory to create rescaled textures exists.
		$RescaledPath = CreatePath ($BaseFolder + '\~RescaledTextures (' + $FileType + ')' + $Texture.Relative)
	}
	# Check to see if the user wants to convert to JPG.
	if (CheckCopyJPG $RescaleExtension $RescaledPath)
	{
		return
	}
	# If the user wants to rescale textures individually, display a prompt and texture information.
	if ($ManualRescale -eq $true)
	{
		# Run the menu and grab its return value to check if the texture was skipped.
		if (ManualRescaleTextureMenu)
		{
			# Skip the texture if the user wanted to (which copies it instead).
			CopyTexture $RescaledPath
			return
		}
	}
	# Calculate the new dimensions of the texture based on the original dimensions * the forced integer.
	[int]$NewWidth  = $Texture.OldWidth * [int]$ForcedScale
	[int]$NewHeight = $Texture.OldHeight * [int]$ForcedScale

	# If the texture has an already combined material map, recreate that as well.
	if ($Texture.HasMaterialMap)
	{
		$RescaledTexture = CreateMaterialMap_FromMaterial $NewWidth $NewHeight $RescaleExtension $RescaledPath
	}
	# If the texture has a bump, spec, and nrm textures, then create a material map from them.
	elseif ($Texture.HasMaterials)
	{
		$RescaledTexture = CreateMaterialMap_FromTextures $NewWidth $NewHeight $RescaleExtension $RescaledPath
	}
	# Otherwise create the texture normally.
	else
	{
		$RescaledTexture = CreateTexture $NewWidth $NewHeight $RescaleExtension $RescaledPath
	}
	# Log/Console: Report that the texture has been created.
	if ($RescaledTexture)
	{
		# Log/Console: Add the logging events.
		SetConsoleMessage 1 ('Successfully rescaled the texture to ' + $NewWidth + 'x' + $NewHeight + ' (' + $ForcedScale + 'x)!') $nullstr
		$global:LogMessage = ('Texture Rescaled to ' + $NewWidth + 'x' + $NewHeight + ' (' + $ForcedScale + 'x)')
	}
	# Log/Console: If the texture was not created, report an error.
	else
	{
		# Log/Console: Add the logging events.
		SetConsoleMessage 0 'Texture failed creation and was not rescaled!' $nullstr
		$global:LogMessage = 'Texture Failed Creation'
	}
	return
}
#==========================================================================================================================================
#  OPTION 3 - CONVERT TEXTURE FORMAT
#==========================================================================================================================================
#  This is called if the user forces the script to convert textures to a specific format.

function ConvertTextureFormat()
{
	# Store converted textures in their own unique directory.
	$FileType = ExtensionToText $ConvertedFormat
	$ConvertedPath = CreatePath ($BaseFolder + '\~ConvertedTextures (' + $FileType + ')' + $Texture.Relative)

	# Check to see if the user wants to convert to JPG.
	if (CheckCopyJPG $ConvertedFormat $ConvertedPath)
	{
		return
	}
	# If it's a DDS texture and auto correction is enabled, find new dimensions based on the nearest low integer scale.
	if (($DDSAutoRepair) -and ($ConvertedFormat -eq $DDS))
	{
		# Use the width integer scale if it is smaller than the height.
		if ($Texture.ScaleWidth -lt $Texture.ScaleHeight) 
		{
			# Set the new integer scale to the width of the texture by splitting the integer from the decimal value.
			$ScaleSplit = $Texture.ScaleWidth.ToString().Split('.',2)
		}
		# Use the height integer scale if it is smaller than the width.
		else
		{
			# Set the new integer scale to the height of the texture by splitting the integer from the decimal value.
			$ScaleSplit = $Texture.ScaleHeight.ToString().Split('.',2)
		}
		# Test if the scale held a decimal value.
		if ($ScaleSplit[1])
		{
			# Send the integer and the decimal (in the form of a whole number) to ScaleThresholdCorrection.
			$NewScale = ScaleThresholdCorrection $ScaleSplit[0] $ScaleSplit[1]
		}
		# Use the new scaling value to determine the new dimensions.
		$NewWidth  = $Texture.OldWidth * $NewScale
		$NewHeight = $Texture.OldHeight * $NewScale
	}
	# If all that noise up there isn't true, just use the custom texture dimensions.
	else
	{
		$NewWidth  = $Texture.Width
		$NewHeight = $Texture.Height
	}
	# If the texture has an already combined material map, recreate that as well.
	if ($Texture.HasMaterialMap)
	{
		$ConvertedTexture = CreateMaterialMap_FromMaterial $NewWidth $NewHeight $ConvertedFormat $ConvertedPath
	}
	# If the texture has a bump, spec, and nrm textures, then create a material map from them.
	elseif ($Texture.HasMaterials)
	{
		$ConvertedTexture = CreateMaterialMap_FromTextures $NewWidth $NewHeight $ConvertedFormat $ConvertedPath
	}
	# Otherwise create the texture normally.
	else
	{
		$ConvertedTexture = CreateTexture $NewWidth $NewHeight $ConvertedFormat $ConvertedPath
	}
	# Log/Console: Report that the texture has been created.
	if ($ConvertedTexture)
	{
		# Log/Console: If the texture was converted to DDS, log the compression type.
		if ($ConvertedFormat -eq $DDS)
		{
			SetConsoleMessage 1 ('Successfully converted to ' + $FileType + ' Format! (' + $DDSCompression + ')') $nullstr
			$global:LogMessage = ('Texture Converted to ' + $FileType + ' Format (' + $DDSCompression + ')')
		}
		# Log/Console: If the texture was converted to PNG or JPG, just log the format.
		else
		{
			SetConsoleMessage 1 ('Successfully converted to ' + $FileType + ' Format!') $nullstr
			$global:LogMessage = ('Texture Converted to ' + $FileType + ' Format')
		}
	}
	# If the texture was not created, report an error.
	else
	{
		SetConsoleMessage 0 'Texture failed creation and was not converted!' $nullstr
		$global:LogMessage = 'Texture Failed Creation'
	}
	return
}
#==========================================================================================================================================
#  OPTION 4: CREATE MATERIAL MAPS WITH ISHIIRUKA TOOL
#==========================================================================================================================================
#  Creates Ishiiruka material maps from "nrm", "spec", and "bump" textures.

function CreateMaterialsWithIshiirukaTool()
{
	# Check to see if the texture actually has supplied material maps.
	if (!($Texture.HasMaterials))
	{
		# If it does not, report that no material textures were found and exit this function.
		Write-Host ' Message    : No material textures (bump/spec/nrm) exist for this texture.'
		return
	}
	# Get the extension as text for the output folder.
	$FileType = ExtensionToText $ConvertedFormat

	# Set up the path to create material maps to a new folder.
	$CombinedMaterialPath = CreatePath ($BaseFolder + '\~MaterialMaps ' + '(' + $FileType + ')' + $Texture.Relative)

	# Create the material maps.
	$MaterialCreated = CreateMaterialMap_FromTextures $Texture.Width $Texture.Height $ConvertedFormat $CombinedMaterialPath

	# Report if the texture failed creation.
	if (!($MaterialCreated))
	{
		Write-Host ' ERROR      : Material map failed creation!' -ForegroundColor Red
	}
}
#==========================================================================================================================================
#  OPTION 5 - ADD IDENTIFYING WATERMARK TO ALL TEXTURES
#==========================================================================================================================================
#  Creates textures with a watermark using the end of the texture name so they can be more easily identified in-game.

function CreateTextureWatermark()
{
	# Create the output path if it doesn't exist.
	$OutputPath = CreatePath ($BaseFolder + '\~WatermarkTextures' + $Texture.Relative)

	# Set the full texture output path to include the texture name.
	$TexOutputPath = $OutputPath + '\' + $Texture.Name + $PNG

	# LOG/Console: Report to the user if the texture is in DDS format and has a material map.
	if (($Texture.HasMaterialMap) -and ($Texture.Extension -eq $DDS))
	{
		Write-Host ' Notice     : DDS textures created with Ishiiruka Tool will have corrupted pixels or not work at all!' -ForegroundColor Magenta
	}	
	# Check if the user wanted a specific number of characters in the watermark.
	if ($WM_Length -gt 0)
	{
		# Extract characters from the end of the texture name to use as a watermark.
		$Watermark = $Texture.Name.Substring($Texture.Name.Length - $WM_Length, $WM_Length)
	}
	# If the value was 0, the user wanted to use the full name.
	else
	{
		# Use the full texture name as the watermark.
		$Watermark = $Texture.Name
	}
	# Store the width before checks so it can be used if the checks immediately pass.
	$NewWidth = $Texture.Width

	# Check to see if the texture width is less than 256 pixels.
	if ($NewWidth -lt 256)
	{
		# If it failed to be at least 256, calculate a new width and height that equals/exceeds 256 using the lowest possible integer scale.
		$ScaleFactor = 2
		while($NewWidth -lt 256)
		{
			# Each iteration increments the scale by 1x. Loop exits when greater than or equal to 256 is reached.
			$NewWidth  = $Texture.Width * $ScaleFactor
			$NewHeight = $Texture.Height * $ScaleFactor
			$ScaleFactor ++
		}
	}
	# Create the dimensions in a format that ImageMagick can make easy use of.
	$NewDimensions = [string]$NewWidth + 'x' + [string]$NewHeight

	# Store the dimensions in a format needed by ImageMagick.
	$IMDimensions = $NewDimensions + '!'

	# Scale the font to the texture. Use the user selected font size as a multiplier.
	$FontSize = $NewWidth / 128 * $WM_FontSize

	# If word wrap is disabled, simply create a watermark over the texture.
	if (!($WM_WordWrap))
	{
		# Create the texture with a watermark.
		& $IMConvert $Texture.FullPath -resize $IMDimensions -gravity center -font $WM_FontFace -pointsize $FontSize -fill $WM_FontColor -undercolor $WM_BGColor -draw "text 0,0 `'$Watermark`'" $TexOutputPath >$null 2>&1
	}
	# Word wrapping requires a more complex method of applying the watermark. An external caption image file must be created and applied to the texture file.
	else
	{
		# Create a folder for temporary textures.
		$TempTexturePath = CreatePath ($TempFolder + '\TempTexture\')

		# Set the path for the temporary texture and caption.
		$TexturePath = $TempTexturePath + 'tex.png'
		$CaptionPath = $TempTexturePath + 'cap.png'

		# Set the width of the caption using 80% of the texture width.
		$FindNewWidth = $NewWidth * 0.80
		$CaptionWidth = [string]$FindNewWidth + 'x'

		# Create the temporary texture and caption.
		& $IMConvert $Texture.FullPath -resize $IMDimensions $TexturePath >$null 2>&1
		& $IMConvert -gravity center -font $WM_FontFace -pointsize $FontSize -fill $WM_FontColor -background transparent -undercolor $WM_BGColor -size $CaptionWidth caption:$Watermark $CaptionPath >$null 2>&1

		# Test if the texture and caption were created. DDS textures created by Ishiiruka Tool will most likely fail here.
		if ((TestPath $TexturePath) -and (TestPath $CaptionPath))
		{
			# Apply the caption to the texture using the -composite command.
			& $IMConvert $TexturePath $CaptionPath -gravity center -composite $TexOutputPath
		}
		# Clean up the temporary files and folders.
		RemovePath $TempTexturePath
	}
	# LOG/Console: Report to the user that the texture was created.
	if (TestPath $TexOutputPath)
	{
		SetConsoleMessage 1 'Texture with watermark created successfully.' $nullstr
		$global:LogMessage = 'Watermark Texture Created.'
	}
	# LOG/Console: Report to the user that the texture was not created.
	else
	{
		SetConsoleMessage 0 'Texture with watermark failed creation.' $nullstr
		$global:LogMessage = 'Watermark Texture Failed Creation.'
	}
}
#==========================================================================================================================================
#  OPTION 6 - OPTIMIZE TEXTURES WITH OPTIPNG
#==========================================================================================================================================
#  Calculate/store stuff for OptiPNG using a hash table.

function CreateOptiPNGData([string]$InputPath) 
{
	# Initialize the hash table.
	$OptiData = @{}

	# Get the texture as an object so it can be analyzed.
	$OptiObject = Get-ChildItem -Recurse -Force -LiteralPath $InputPath

	# Store the name of the texture.
	$OptiData.Name = $OptiObject.Name

	# Store the size of the texture in Bytes.
	$OptiData.Size = ($OptiObject | Measure-Object -property length -sum).sum

	# Return the hash table.
	return $OptiData
}
#==========================================================================================================================================
#  Optimizes a texture with OptiPNG and returns the reduction in Bytes. Input parameter takes a full path to the texture + file extension.

function OptimizeTexture([string]$InputPath, [int]$optimethod)
{
	# Create information of the image before optimization.
	$OldImage = CreateOptiPNGData $InputPath

	# Create a usable format for the OptiPNG parameter using the global variable "$OptiTests" that stores the number of tests the user selected.
	$OptiTests = '-o' + $OptiPNGTests

	# Method 1: Output the optimized texture to a new folder.
	if ($optimethod -eq 1)
	{
		# Create the directory to output files from OptiPNG.
		$OptimizePath = CreatePath ($BaseFolder + '\~OptimizedTextures' + $Texture.Relative)

		# Run OptiPNG and force it to create a new texture.
		& $OptiPNGPath $OptiTests $InputPath -dir $OptimizePath 2>&1>$null

		# Set the path to check ByteSize to the new texture OptiPNG created.
		$OptiCheckPath = $OptimizePath + '\' + $OldImage.Name
	}
	# Method 2: Optimize the files in-place if the user wished it.
	elseif ($optimethod -eq 2)
	{
		# Run OptiPNG on the current texture in-place.
		& $OptiPNGPath $OptiTests $InputPath 2>&1>$null

		# Set the path to check ByteSize to the current texture.
		$OptiCheckPath = $InputPath
	}	
	# Create information of the image after optimization.
	$NewImage = CreateOptiPNGData $OptiCheckPath

	# Test if each channel of the texture is at least 8-bits.
	$DepthCheck = TestColorChannelDepth $OptiCheckPath

	# If the texture failed the depth check.
	if (!($DepthCheck))
	{
		# Report the texture was less than 8-bits.
		Write-Host  $(' Notice     : Result of ' + $NewImage.Name + ' was less than 8 bpp so it was skipped!') -ForegroundColor Magenta
	}
	# Check if there was actually any reduction in file size and it passed the depth check.
	if (($NewImage.Size -lt $OldImage.Size) -and ($DepthCheck))
	{
		# Calculate the size difference in Bytes.
		$Reduction = $OldImage.Size - $NewImage.Size
	}
	# If there was no reduction....
	else
	{
		# Store that the amount of reduction is zero so it can be returned as 0.
		$Reduction = 0

		# Perform some clean-up if Method 1 was used.
		if ($optimethod -eq 1)
		{
			# Remove the new image if there was no reduction in size
			if (TestPath $OptiCheckPath)
			{
				RemovePath $OptiCheckPath
			}
			# Check to see if the folder that the texture was to be copied to is empty. If it is, remove it.
			if ((Get-ChildItem -Recurse -Force -LiteralPath $OptimizePath | Select-Object -First 1 | Measure-Object).Count -eq 0)
			{
				RemovePath $OptimizePath
			}
		}
	}
	# Store the total reduction in Bytes....
	$global:TotalReductionB += $Reduction

	# ... and return the reduction.
	return $Reduction
}
#==========================================================================================================================================
#  The master function to start optimizing textures.

function OptimizeTexturesWithOptiPNG([int]$optimethod)
{
	# Make sure to only run this on PNG files.
	if ($Texture.Extension -ne $PNG)
	{
		# Log/Console: Add the logging events.
		SetConsoleMessage 1 'Texture not in PNG format' $nullstr
		$global:LogMessage = 'OptiPNG: Texture not in PNG format'
		return
	}
	# Do not run this on textures with material maps.
	elseif ($Texture.HasMaterialMap)
	{
		# Log/Console: Add the logging events.
		SetConsoleMessage 1 'Textures with Material Maps are skipped.' $nullstr
		$global:LogMessage = 'OptiPNG: Skipped (Material Map)'
		return
	}
	# Log/Console: Alert that OptiPNG is about to run.
	Write-Host ' Notice     : Running texture through OptiPNG. This may take some time....'

	# Optimize the base texture and store the amount of reduction.
	$ReductionB = OptimizeTexture $Texture.FullPath $optimethod

	# Attempt to create a MipMap hash table.
	$MipMap = CreateMipMapInfo $Texture.Width $Texture.Height $Texture.Extension

	# If the texture is a MipMap, look for MipMap levels and optimize them too.
	if ($MipMap -ne $null)
	{
		# Loop through all lower levels.
		for($i=1; $i -le $MipMap.Levels; $i++)
		{
			# If the MipMap level exists, optimize it and store any reduction to the total texture reduction.
			if ($MipMap.Exists[$i])
			{
				# The size in bytes of the top layer and all lower mipmap levels are added together.
				$ReductionB += OptimizeTexture $MipMap.FullPath[$i] $optimethod
			}
		}
	}
	# Log/Console: Check to see if there was actually any reduction between the original and custom textures. 
	if ($ReductionB -gt 0)
	{
		# Log/Console: Display the reduced size in Bytes if it's less than 1 KB.
		if ($ReductionB -lt 1024)
		{
			SetConsoleMessage 2 'Texture reduced by ' $([string]$ReductionB + ' Bytes')
			$global:LogMessage = $('OptiPNG: Texture reduced by ' + $ReductionB + ' Bytes')
		}
		# Log/Console: Display the size in KB if its over or equal to 1 KB.
		else
		{
			$ReductionKB = FormatDecimal ($ReductionB/1024).ToString('#.##')
			SetConsoleMessage 2 'Texture reduced by ' $([string]$ReductionKB + ' KB')
			$global:LogMessage = $('OptiPNG: Texture reduced by ' + $ReductionKB + ' KB')
		}
	}
	# Log/Console: If there was no reduction then the texture was already optimized.
	else
	{
		SetConsoleMessage 1 'Texture already optimized' $nullstr
		$global:LogMessage = 'OptiPNG: Texture already optimized'
	}
}
#==========================================================================================================================================
#  The final OptiPNG calculations and logging which is ran from the main loop when finished.

function FinalizeOptiPNG()
{
	Write-Host ''
	Add-Content -LiteralPath $LogFile -value ''
	# If the Total Reduction is greater than 1 MB.
	if ($TotalReductionB -ge 1048576)
	{
		[decimal]$TotalReductionMB = ([decimal]$TotalReductionB/1024/1024).ToString('#.##')
		Write-Host ' Total Reduction With OptiPNG: ' -NoNewLine
		Write-Host ($TotalReductionMB.ToString() + ' MB') -ForeGroundColor Green
		Add-Content -LiteralPath $LogFile -value ('Total Reduction With OptiPNG: ' + $TotalReductionMB.ToString() + ' MB')
	}
	# If the Total Reduction is greater than 1 KB.
	elseif ($TotalReductionB -ge 1024)
	{
		[decimal]$TotalReductionKB = ([decimal]$TotalReductionB/1024).ToString('#.##')
		Write-Host ' Total Reduction With OptiPNG: ' -NoNewLine
		Write-Host ($TotalReductionKB.ToString() + ' KB') -ForeGroundColor Green
		Add-Content -LiteralPath $LogFile -value ('Total Reduction With OptiPNG: ' + $TotalReductionKB.ToString() + ' KB')
	}
	# Display in Bytes.
	else
	{
		Write-Host ' Total Reduction With OptiPNG: ' -NoNewLine
		Write-Host ($TotalReductionB.ToString() + ' B') -ForeGroundColor Green
		Add-Content -LiteralPath $LogFile -value ('Total Reduction With OptiPNG: ' + $TotalReductionB.ToString() + ' B')
	}
}
#==========================================================================================================================================
#  OPTION 7 - CREATE UPSCALED TEXTURES
#==========================================================================================================================================
function CreateUpscaledTextures()
{
	# Only run this function on textures with the original dimensions that are in PNG format.
	if (($Texture.Dimensions -ne $Texture.OldDimensions) -or ($Texture.Extension -ne $PNG))
	{
		# Log/Console: Add the logging events.
		SetConsoleMessage 1 'Texture was either not an original texture or not in PNG format!' $nullstr
		$global:LogMessage = 'Not Original/PNG'
		return
	}
	# Make sure the directory to create rescaled textures exists.
	$UpscaledPath = CreatePath ($BaseFolder + '\~FilteredTextures' + $Texture.Relative)
	$UpscaledTexture = $UpscaledPath + '\' + $Texture.Name + $PNG

	# Calculate the new dimensions of the texture based on the original dimensions * the upscale integer.
	$NewWidth  = $Texture.OldWidth * [int]$UpscaleAmount
	$NewHeight = $Texture.OldHeight * [int]$UpscaleAmount
	$NewScale = ([int]$UpscaleAmount * 100).ToString() + '%'

	# Rescale the texture and apply the filter set by the user.
	& $IMConvert $Texture.FullPath -filter $UpscaleFilter -resize $NewScale $UpscaledTexture

	# Log/Console: Report that the texture has been created.
	if (TestPath $UpscaledTexture)
	{
		# Log/Console: Add the logging events.
		SetConsoleMessage 1 $('Successfully upscaled the filtered texture to ' + $NewWidth + 'x' + $NewHeight + '!') $nullstr
		$global:LogMessage = $('Texture Upscaled and Filtered to ' + $NewWidth + 'x' + $NewHeight)
	}
	# Log/Console: If the texture was not created, report an error.
	else
	{
		# Log/Console: Add the logging events.
		SetConsoleMessage 0 'Texture failed creation and was not upscaled!' $nullstr
		$global:LogMessage = 'Texture Failed Creation'
	}
	return
}
#==========================================================================================================================================
#  OPTION 8 - ADVANCED FUNCTIONS
#==========================================================================================================================================
#  Advanced Option 1: Generates new mipmaps within the texture pack itself.

function ForceGenerateNewMipMaps ()
{
	# Do not even run any code here if the texture is not a MipMap or it is has a material map.
	if (($Texture.IsMipMap) -and ($Texture.HasMaterialMap -eq $false))
	{
		# Create MipMap information based on the current texture.
		$MipMap = CreateMipMapInfo $Texture.Width $Texture.Height $Texture.Extension

		# Loop through all levels and remove any existing MipMaps.
		for($i=1; $i -le $MipMap.Levels; $i++)
		{
			# My RemovePath function tests if a path exists before trying to remove it, so exploit that functionality here.
			RemovePath $MipMap.FullPath[$i]
		}
		# Create a temporary folder to generate the MipMaps to.
		$TempMipMapPath = CreatePath ($TempFolder + '\TempMipMaps')

		# PNG and JPG textures use the standard CreateMipMaps function.
		if ($Texture.Extension -ne $DDS)
		{
			CreateMipMaps $MipMap $Texture.Extension $TempMipMapPath
		}
		# DDS textures require a more complicated method.
		else
		{
			CreateDDSMipMaps $MipMap $TempMipMapPath
		}
		# Loop through all MipMaps in the temp MipMap directory.
		foreach($subfile in Get-ChildItem -Recurse -Force -LiteralPath $TempMipMapPath)
		{
			# Move all MipMaps to the current texture path.
			$MovePath = [string]$subfile.Directory + '\' + $subfile.Name
			Move-Item -Force -LiteralPath $MovePath -destination $Texture.Path
		}
	}
}
#==========================================================================================================================================
#  Advanced Option 2: Create material maps in the texture pack directly from bump/spec/nrm files.

function CreateMaterialsInPlace()
{
	# Check to see if the texture actually has supplied material maps.
	if (!($Texture.HasMaterials))
	{
		# If it does not, report that no material textures were found and exit this function.
		Write-Host ' Message    : No material textures (bump/spec/nrm) exist for this texture.'
		return
	}
	# Get the extension as text for the output folder.
	$FileType = ExtensionToText $ConvertedFormat

	# Set up the path to create material maps to a new folder.
	$TempMaterialPath = CreatePath ($TempFolder + '\TempMaterials')

	# Attempt to create the material map.
	if (CreateMaterialMap_FromTextures $Texture.Width $Texture.Height $ConvertedFormat $TempMaterialPath)
	{
		# Remove the old material textures.
		RemovePath $Texture.FullPath
		RemovePath $($Texture.Path + '\' + $Texture.Name + '.nrm' + $PNG)
		RemovePath $($Texture.Path + '\' + $Texture.Name + '.bump' + $PNG)
		RemovePath $($Texture.Path + '\' + $Texture.Name + '.spec' + $PNG)
	}
	# Report if the texture failed creation.
	else
	{
		Write-Host ' ERROR      : Material map failed creation!' -ForegroundColor Red
	}
	# Loop through all Material Maps in the temp materials directory.
	foreach($subfile in Get-ChildItem -Recurse -Force -LiteralPath $TempMaterialPath)
	{
		# Move all Material Maps to the current texture path.
		$MovePath = [string]$subfile.Directory + '\' + $subfile.Name
		Move-Item -Force -LiteralPath $MovePath -destination $Texture.Path
	}
}
#==========================================================================================================================================
#  Advanced Option 3: Finds invalid mipmaps for textures and removes them.

function RemoveInvalidMipMaps ()
{
	# Tracks if any Mipmaps were deleted or not.
	$DeletedMipMaps = $false

	# We only want to work with textures that are not mipmap textures.
	if ($Texture.IsMipMap)
	{
		# Exit the function if its not a mipmap texture.
		return
	}
	# Count the number of bad MipMaps.
	$InvalidMipMaps = 0

	# Loop through all textures in the current directory.
	foreach($subfile in Get-ChildItem -Recurse -Force -LiteralPath $Texture.Path)
	{
		# Check to see if the texture name is similar to the current loop texture.
		if ($subfile.BaseName -like $Texture.Name + '*')
		{
			# Split the texture name into 6 slots.
			$subfileSplit = $subfile.BaseName.Split('_.',6)

			# Loop through slot 5 (detects non-mipmaps) and slot 6 (detects paletted non-mipmaps).
			for ($x=4; $x -lt 6; $x++)
			{
				# Are we deep enough yet? If it exists, then check the first letter for "m" (which is extracted from "mip").
				if (($subfileSplit[$x]) -and ($subfileSplit[$x].Substring(0,1) -eq 'm'))
				{
					# Balls deep. If it passes, remove the file.
					RemovePath $($Texture.Path + '\' + $subfile)

					# Console: Update the console with the texture that was removed.
					Write-Host (' Removed    : ' + $subfile) -ForegroundColor Green

					# Track that MipMaps were deleted and count how many.
					$DeletedMipMaps = $true
					$InvalidMipMaps ++
				}
			}
		}
	}
	# Check to see if MipMaps were deleted.
	if ($DeletedMipMaps)
	{
		# Log: Since the console information is taken care of when the MipMap was deleted, only update the Log information with the number of deleted mipmaps.
		$global:LogMessage = $('Removed ' + $InvalidMipMaps + ' Invalid MipMaps')
	}
	# No MipMaps were deleted.
	else
	{
		# Log/Console: Because no MipMaps were removed, update both the console and log saying that the texture is ok.
		SetConsoleMessage 1 'No invalid MipMaps were found.' $nullstr
		$global:LogMessage = 'OK'
	}
}
#==========================================================================================================================================
#  Advanced Option 4: Performed in function OptimizeTexturesWithOptiPNG
#==========================================================================================================================================
#  Advanced Option 5: Repairs textures that could have broken by OptiPNG that have less than 8-bit depth on each channel.

function RepairOptiPNGTexture()
{
	# We only want to work with textures that are in PNG format and fail the depth check.
	if (($Texture.Extension -ne $PNG) -or (TestColorChannelDepth $Texture.FullPath))
	{
		# If the texture is not PNG or passes the depth check then end the function.
		return
	}
	# Set up the paths.
	$TempPath    = CreatePath ($TempFolder + '\Repaired\')
	$TempTexture = $TempPath + $Texture.FullName

	# Create the texture in the temporary directory.
	& $IMConvert $Texture.FullPath -define png:color-type=6 PNG32:$TempTexture

	# Remove the old texture.
	RemovePath $Texture.FullPath

	# Move the temp texture to the texture path.
	Move-Item -Force -LiteralPath $TempTexture -destination $Texture.FullPath

	# Console: 
	Write-Host ' Message    : Repair attempted on texture. Please test in-game!' -ForegroundColor Green
}
#==========================================================================================================================================
#  MASTER LOOP - COPY NON-TEXTURES
#==========================================================================================================================================
#  Set of conditions to check whether or not to copy a "non-texture file" when using Options 5 or 6.

function CheckNonTexture($file)
{
	# Set up the series of checks in a variable array.
	$Check = New-Object bool[] 8
	$TexCheck = $file.BaseName.Split('_',2)              # - Split the file name to check for "tex1".
	$Check[0] = ($TexCheck[0] -ne 'tex1')                # - Verify that it is not a texture (lower mipmap levels sneak through).
	$Check[1] = ($ForceIntScaling -or $ConvertTextures)  # - Verify that either Option 5 or 6 was used.
	$Check[2] = (!($file.PSIsContainer))                 # - Verify that is a file and not a folder.
	$Check[3] = ($file.DirectoryName -notlike '*~*')     # - Verify that the file is not in a generated directory.
	$Check[4] = ($file.Extension -ne '.log')             # - Verify that it is not this script's log file (.txt files can still pass).
	$Check[5] = ($file.Extension -ne '.ps1')             # - Verify that it is not a PowerShell script.
	$Check[6] = ($file.Extension -ne '.bat')             # - Verify that it is not a Batch script (maybe I shouldn't block this?).
	$Check[7] = ($file.Name -ne 'thumbs.db')             # - Verify that it's not a Windows thumbnail database file.

	# Loop through each check to see if the file should not be copied.
	for($i=0; $i -lt 8; $i++)
	{
		# Test if the check has failed.
		if (!($Check[$i]))
		{
			# Return false so the file will not be copied.
			return $false
		}
	}
	# If all conditions passed then copy the file.
	return $true
}
#==========================================================================================================================================
#  Copies a "non-texture file" if it passes all the checks in the above function.

function AttemptCopyNonTexture($file)
{
	# Perform rigorous testing to verify the file should be copied.
	if (!(CheckNonTexture $file))
	{
		# End the function, do not copy the file. If it gets beyond this point, the file is copied.
		return
	}
	# Check to see if Rescale Textures was enabled (which references the current output folder).
	if ($ForceIntScaling)
	{
		# Checks if the user did not force converting to a certain format (PNG/DDS/JPG).
		if ($ConvertedFormat -eq $null)
		{
			# If a format was not forced, simply use the folder name "RescaledTextures".
			$TempPath = '\~RescaledTextures'
		}
		# If the user forced to convert to a certain format (PNG/DDS/JPG).
		else
		{
			# If a format was forced, include the format in the folder name.
			$FileType = ExtensionToText $ConvertedFormat
			$TempPath = '\~RescaledTextures (' + $FileType + ')'
		}
	}
	# Check to see if Convert Texture Format was enabled (which references the current output folder).
	elseif ($ConvertTextures)
	{
		# Include the format in the output folder.
		$FileType = ExtensionToText $ConvertedFormat
		$TempPath = '\~ConvertedTextures (' + $FileType + ')'
	}
	# Create the folder structure of where the file should go and copy it to that location.
	$Relative = $file.DirectoryName.replace($BaseFolder,'')
	$NTFolder = (Get-Location | Get-Item).Name
	$FullPath = [string]$file.Directory + '\' + $file
	$CopyPath = CreatePath ($BaseFolder + $TempPath + $Relative)
	Copy-Item -Recurse -Force -LiteralPath $FullPath $CopyPath

	# Log/Console: Display that the file has been copied.
	Write-Host ' File       : ' -NoNewline
	Write-Host $file -ForegroundColor Red
	Write-Host (' Path       : ' + $NTFolder + $Relative)
	Write-Host ' Message    : Non-texture file copied to ' -NoNewline
	Write-Host ($TempPath + $Relative) -ForegroundColor Green
	Write-Host '-----------------------------------------------------------------------------------------------------------------------'
}
#==========================================================================================================================================
#  MASTER LOOP - TITLE BAR PROGRESS
#==========================================================================================================================================
#  Counts the number of textures in a pack. This number is approximate (not exact) as it counts all PNG, DDS, and JPG files with "tex1".

function CountTexturesInPack()
{
	$TotalFiles = 0
	# Loop through all folders to check for texture files.
	foreach ($folder in Get-ChildItem -Recurse -Force)
	{
		# Make sure were in a folder and it not a folder generated with this script.
		if (($folder.PSisContainer) -and ($folder.FullName -notlike '*~*'))
		{
			# Combine the number of PNG, DDS, and JPG files that are found into a single integer.
			$TotalFiles += ([System.IO.Directory]::GetFiles($folder.FullName, 'tex1*.png').Count)
			$TotalFiles += ([System.IO.Directory]::GetFiles($folder.FullName, 'tex1*.dds').Count)
			$TotalFiles += ([System.IO.Directory]::GetFiles($folder.FullName, 'tex1*.jpg').Count)
		}
	}
	# Return the number of image files found.
	return [int]$TotalFiles 
}
#==========================================================================================================================================
#  Updates the title bar with progress.

function UpdateTitleBarPercent([int]$CurrentInt, [int]$TotalFiles)
{
	# Find the absolute value and convert it to a string.
	$Percent = ($CurrentInt / $TotalFiles).ToString()

	# Count the number of characters in the string.
	$CountChar = ($Percent | Measure-Object -Character).Characters

	# When it reaches 100%, we need a special case to catch it.
	if ($Percent -eq '1')
	{
		$Percent = 100
	}
	# When we hit the perfect value (such as 0.5), there will only be a single character to extract.
	elseif ($CountChar -lt 4)
	{
		# Because there was only one character, append a 0 to the end (to make 0.5 into 0.50 which becomes 50).
		$Percent = [int]($Percent.SubString(2,1) + '0')
	}
	# In any other case, extract 2 characters.
	else
	{
		# Convert to an integer to hide starting 0's (0.05 becomes 5 instead of 05).
		$Percent = [int]$Percent.SubString(2,2)
	}
	# Update the title bar with the current percent of progress.
	$host.UI.RawUI.WindowTitle = ($ScriptName + ' - Current Task: ' + $CurrentInt + '/' + $TotalFiles + ' (' + $Percent + '%)')
}
#==========================================================================================================================================
#  MASTER LOOP - THE MASTER LOOP
#==========================================================================================================================================
#  All external functions are ran through this loop in some form. It is executed from the main menu (found near the bottom of this script).

function MasterLoop()
{
	# Output that the loop is about to start to the PS window.
	Clear-Host
	Write-Host '-----------------------------------------------------------------------------------------------------------------------'
	Write-Host ' Processing textures ...'
	Write-Host '-----------------------------------------------------------------------------------------------------------------------'

	# Force the title bar to display that the length of time is being calculated.
	$host.UI.RawUI.WindowTitle = ($ScriptName + ' - Current Task: Calculating...')

	# Create the log file.
	LogInitialize

	# Create an empty hash table to store files that may be duplicates.
	$Duplicates = @{}

	# Count the number of files in the directory to calculate the completion percentage.
	$CurrentInt = 0
	$TotalFiles = CountTexturesInPack

	# After the calculations, force the title bar to display file 0 and 0% before executing the loop.
	$host.UI.RawUI.WindowTitle = ($ScriptName + ' - Current Task: 0/' + $TotalFiles + ' (0%)')

	# Loop through all folders and sub-folders to attempt to find texture files.
	foreach($file in Get-ChildItem -Recurse -Force)
	{
		# Creates texture data in the form of a global hash table. Returns "null" if it is not a valid texture file.
		$global:Texture = CreateTextureInfo $file

		# Proceed only if there is valid texture data.
		if ($Texture -ne $null)
		{
			# Console: Show information about the texture before doing work.
			ConsoleStartInfo

			# If option 1 is used, scan all textures for errors.
			if ($ScanAllTextures) { CheckTextureForIssues }

			# If the script is forced to convert textures to an integer scale.
			if ($ForceIntScaling) { RescaleTextureInteger }

			# If the script is forced to convert to another format.
			if ($ConvertTextures) { ConvertTextureFormat }

			# If the script is forced to build material maps using Ishiiruka Tool.
			if ($CreateMaterials) { CreateMaterialsWithIshiirukaTool }

			# If the script is forced to create watermarks on all textures.
			if ($CreateWatermark) { CreateTextureWatermark }

			# If the script is forced to optimize PNG textures with OptiPNG.
			if ($OptiPNGTextures) { OptimizeTexturesWithOptiPNG 1 }

			# If the script is forced to create up-scaled textures.
			if ($UpscaleTextures) { CreateUpscaledTextures }

			# If the script is forced to create new mipmaps within the texture pack.
			if ($GenerateMipMaps) { ForceGenerateNewMipMaps }

			# If the script is forced to generate materials in-place from bump/spec/nrm textures.
			if ($MaterialInPlace) { CreateMaterialsInPlace }

			# If the script is forced to find and delete invalid mipmaps.
			if ($RemoveBadMipMap) { RemoveInvalidMipMaps }

			# If the script is forced run OptiPNG on textures in place.
			if ($OptimizeInPlace) { OptimizeTexturesWithOptiPNG 2 }

			# If the script is forced to find textures less than 8bpp and repair them.
			if ($FixBrokeOptiPNG) { RepairOptiPNGTexture }

			# Console: Show more information about the texture after doing work.
			ConsoleEndInfo

			# Log: Attempt to update the log file with texture information.
			AttemptUpdateLogFile
		}
		# The file is not a valid texture.
		elseif ($CopyNonTextures)
		{
			# Attempt to copy the file to a newly generated pack.
			AttemptCopyNonTexture $file
		}
		# Check to update the title bar with % completion. Skip textures in folders with a ~, and validate the extension is an image.
		# Although $TotalFiles is approximate, the checks performed here are identical so $CurrentInt should equal $TotalFiles when the loop is finished.
		if (($file.FullName -notlike '*~*') -and (($file.Name -like 'tex1*.png') -or ($file.Name -like 'tex1*.dds') -or ($file.Name -like 'tex1*.jpg')))
		{
			# Update the title bar to display the % completion.
			$CurrentInt += 1
			UpdateTitleBarPercent $CurrentInt $TotalFiles
		}
	}
	# Log: Log one final bar in the log.
	Add-Content -LiteralPath $LogFile -value '---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------'

	# Completely remove the Temp folder and any remnants that my have been left stray.
	RemovePath $TempFolder

	# Log/Console: If OptiPNG was chosen then do the final calculations.
	if ($OptiPNGTextures)
	{
		FinalizeOptiPNG
	}
	# Console: All files have been processed so wrap it up.
	Write-Host ''
	Write-Host ' Finished! Press any key to continue.'

	# Pause the script and wait for user input.
	[void][System.Console]::ReadKey($true)

	# Force the title bar to hide the progress.
	$host.UI.RawUI.WindowTitle = ($ScriptName + ' - PowerShell v' + $PSVersion + ' - ImageMagick v' + $IMVersion)
}
#==========================================================================================================================================
#  EVERYTHING MENU RELATED BELOW HERE
#==========================================================================================================================================
#  Yes that's right, beyond this point there is only menu code which makes up about half of the freaking script. Menus in the PS version
#  of Custom Texture Tool are meant to be much more powerful than the batch script version. Internal options can now be changed through
#  menus and saved to the script file so users no longer have to edit it. ReadMe is now built into the script. Users can enter an option
#  followed by a ? to learn more about that option. "Menu progression", a phrase I'll coin to mean a menu that rolls into another menu,
#  is now a lot smarter in that it can retain everything on the screen from previous menus, but refresh the current menu to either update
#  or display new information (although I'm mostly just refreshing the menu to remove any "Invalid Input" messages).
#==========================================================================================================================================
#  GUI FUNCTIONS TO GET A FILE OR FOLDER PATH
#==========================================================================================================================================
function Get-FileName([string]$location, [string]$filename)
{
	[System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms') | Out-Null
	$OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
	$OpenFileDialog.InitialDirectory = $location
	$OpenFileDialog.Filter = "|" + $filename
	# Powershell versions below 3 run in multi-thread apartment mode (MTA), which bugs out the menu if "ShowHelp" isn't set to true.
	$OpenFileDialog.ShowHelp = ($PSVersion -lt 3)
	$OpenFileDialog.ShowDialog() | Out-Null
	$OpenFileDialog.FileName
}
#==========================================================================================================================================
function Get-Folder([string]$description)
{
	[System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms') | Out-Null
	$FolderBrowserDialog = New-Object System.Windows.Forms.FolderBrowserDialog
	$FolderBrowserDialog.ShowNewFolderButton = $false
	$FolderBrowserDialog.Description = $description
	$FolderBrowserDialog.ShowDialog() | Out-Null
	$FolderBrowserDialog.SelectedPath
}
#==========================================================================================================================================
#  UPDATE SCRIPT FUNCTION
#==========================================================================================================================================
function UpdateScript($FindText, $ReplaceWith)
{
	# Find text that matches the Replace text and replace it.
	$UpdateContent = [System.IO.File]::ReadAllText($ScriptPath).Replace($FindText, $ReplaceWith)

	# Write the changes to the script file.
	[System.IO.File]::WriteAllText($ScriptPath, $UpdateContent)
}
#==========================================================================================================================================
#  INVALID MENU-INPUT FUNCTION
#==========================================================================================================================================
function InvalidInput($inputtype)
{
	# If an input option is incorrect.
	if ($inputtype -eq 'option')
	{
		Write-Host ''
		Write-Host ' ERROR:' -ForegroundColor Red -NoNewLine
		Write-Host ' Invalid input. Please enter a valid option. Press any key to continue.'
	}
	# If a typed value is incorrect.
	elseif ($inputtype -eq 'value')
	{
		Write-Host ''
		Write-Host ' ERROR:' -ForegroundColor Red -NoNewLine
		Write-Host ' Invalid input value. Please make sure the entered value is correct. Press any key to continue.'
	}
	# If an entered path to a file is incorrect or empty.
	elseif ($inputtype -eq 'file')
	{
		Write-Host ''
		Write-Host ' ERROR:' -ForegroundColor Red -NoNewLine
		Write-Host ' Invalid file selection. Please choose the correct file to set the path. Press any key to continue.'
	}
	# If an entered path is incorrect or empty.
	elseif ($inputtype -eq 'path')
	{
		Write-Host ''
		Write-Host ' ERROR:' -ForegroundColor Red -NoNewLine
		Write-Host ' Invalid path. Please make sure the selected path is correct. Press any key to continue.'
	}
	# Pause the script and wait for user input.
	[void][System.Console]::ReadKey($true)
}
#==========================================================================================================================================
#  IMAGEMAGICK - SEARCH AND SELECTION
#==========================================================================================================================================
function SetImageMagick([string]$MagickPath)
{
	# Test the path chosen by the registry to see if ImageMagick v7 is installed.
	if (TestPath ($MagickPath + '\magick.exe'))
	{
		# If ImageMagick v7 is found, set all executable variables to magick.exe.
		$global:IMConvert   = $MagickPath + '\magick.exe'
		$global:IMIdentify  = $MagickPath + '\magick.exe'
		$global:IMVersion   = '7'
		# ImageMagick v7 now uses a symbolic link to identify.
		$global:IMI7 = 'identify'
		return $true
	}
	# Test the path chosen by the registry to see if ImageMagick v6 is installed.
	elseif (TestPath ($MagickPath + '\convert.exe'))
	{
		# If ImageMagick v6 is found, set the executables to variables.
		$global:IMConvert   = $MagickPath + '\convert.exe'
		$global:IMIdentify  = $MagickPath + '\identify.exe'
		$global:IMVersion   = '6'
		# This is only needed for v7 so default to an empty string.
		$global:IMI7 = ''
		return $true
	}
	return $false
}
#==========================================================================================================================================
function SelectImageMagick()
{
	# Work-around for PowerShell v2 since the "Open Folder" dialog won't work here because of MTA.
	if ($PSVersion -lt 3)
	{
		# Prompt the user to enter a new input path.
		Write-Host ''
		Write-Host '-----------------------------------------------------------------------------------------------------------------------'
		Write-Host ' Enter a new path to ImageMagick. The path must contain' -NoNewLine
		Write-Host ' convert.exe' -ForegroundColor Yellow -NoNewLine
		Write-Host ' or' -NoNewLine
		Write-Host ' magick.exe' -ForegroundColor Yellow -NoNewLine
		Write-Host ' to succeed.'
		Write-Host ''
		Write-Host ' PowerShell should allow pasting a value by right clicking the console window.'
		Write-Host ''
		$MagickPath = Read-Host '> '
	}
	# In PowerShell v3 and beyond, simply show the "Open Folder" dialog.
	else
	{
		# Prompt the user for a new input path.
		Write-Host ''
		Write-Host '-----------------------------------------------------------------------------------------------------------------------'
		Write-Host ' Select a new path to ImageMagick. The path must contain' -NoNewLine
		Write-Host ' convert.exe' -ForegroundColor Yellow -NoNewLine
		Write-Host ' or' -NoNewLine
		Write-Host ' magick.exe' -ForegroundColor Yellow -NoNewLine
		Write-Host ' to succeed.'
		Write-Host ''

		# Display an "Open Folder" menu to get the path.
		$MagickPath = Get-Folder 'Select a new path to ImageMagick. The path must contain "convert.exe" or "magick.exe" to succeed.'
	}
	# Attempt to use enter/selected path to set the location for ImageMagick.
	if (($MagickPath) -and (SetImageMagick $MagickPath))
	{
		# Update the script with the new paths.
		$OldImageMagick = $ImageMagick
		$global:ImageMagick = $MagickPath
		$ReplaceOnce = '$global:ImageMagick        = ' + '(Get-ItemProperty -LiteralPath "HKLM:\Software\ImageMagick\Current\" -Name BinPath -ErrorAction SilentlyContinue).BinPath'
		$ReplaceText = '$global:ImageMagick        = ' + '"' + $OldImageMagick + '"'
		$ReplaceWith = '$global:ImageMagick        = ' + '"' + $ImageMagick + '"'
		UpdateScript $ReplaceOnce $ReplaceWith
		UpdateScript $ReplaceText $ReplaceWith

		# Alert that it worked.
		Write-Host ' New path to ImageMagick succeeded!' -ForegroundColor Green
		Write-Host ''
		Write-Host ' Press any key to start the script.'

		# Pause the script and wait for user input.
		[void][System.Console]::ReadKey($true)
		return $true
	}
	# See if the user didn't input anything.
	elseif (!$MagickPath)
	{
		# Special error just for ImageMagick.
		Write-Host ' ERROR:'  -ForegroundColor Red -NoNewLine
		Write-Host ' A path was not selected. How do you expect to find ImageMagick?'
		Write-Host ''
		Write-Host ' Press any key to continue.'
	}	
	# The path did not exist.
	else
	{
		# Special error just for ImageMagick.
		Write-Host ' ERROR:'  -ForegroundColor Red -NoNewLine
		Write-Host ' The entered path does not contain the ImageMagick executable' -NoNewLine
		Write-Host ' convert.exe' -ForegroundColor Yellow -NoNewLine
		Write-Host ' or' -NoNewLine
		Write-Host ' magick.exe' -ForegroundColor Yellow -NoNewLine
		Write-Host '.'
		Write-Host ''
		Write-Host ' Press any key to continue.'
	}
	# Pause the script and wait for user input.
	[void][System.Console]::ReadKey($true)
	return $false
}
#==========================================================================================================================================
function FindImageMagick()
{
	# Test the path chosen by the registry to see if ImageMagick is installed.
	if (SetImageMagick $ImageMagick)
	{
		return $true
	}
	# If the path was not found, show a menu to select ImageMagick.
	do
	{
		Clear-Host
		Write-Host '-----------------------------------------------------------------------------------------------------------------------'
		Write-Host (' ' + $ScriptName) -ForegroundColor Yellow
		Write-Host '-----------------------------------------------------------------------------------------------------------------------'
		Write-Host ''
		Write-Host ' ERROR: '  -ForegroundColor Red -NoNewLine
		Write-Host 'IMAGEMAGICK WAS NOT FOUND!'
		Write-Host ''
		Write-Host ' Windows does not have native support for writing images in PowerShell, so it is required that you install ImageMagick'
		Write-Host ' in order to use this Texture Tool. If you already have ImageMagick installed, but the script failed to find the path' 
		Write-Host ' to where it was installed, you can attempt to input the path here or edit the script to manually add the path.'
		Write-Host ''
		Write-Host ' Get ImageMagick v6 at ' -NoNewLine
		Write-Host 'http://www.imagemagick.org/' -ForegroundColor Cyan
		Write-Host ''
		Write-Host '-----------------------------------------------------------------------------------------------------------------------'
		Write-Host ''
		Write-Host ' Here a new path to ImageMagick can be selected. The path must contain ' -NoNewLine
		Write-Host 'convert.exe' -ForegroundColor Yellow -NoNewLine
		Write-Host ' or ' -NoNewLine
		Write-Host 'magick.exe' -ForegroundColor Yellow -NoNewLine
		Write-Host ' to succeed.'
		Write-Host ''
		Write-Host ' (1:) Select path to ImageMagick'
		Write-Host ' (2:) Open ImageMagick Download Page'
		Write-Host ' (3:) Close Custom Texture Tool PS'
		Write-Host ''
		$MenuInput = Read-Host '> '
		if ($MenuInput)
		{
			switch -wildcard ($MenuInput)
			{
				'1' { if (SelectImageMagick) {return $true} }
				'2'	{ Start-Process -FilePath "http://imagemagick.org/script/binary-releases.php" }
				'3' { Write-Host '' ; Write-Host 'Peace!' }
				default { InvalidInput 'option' }
			}
		}
	} while ((!$MenuInput) -or ($MenuInput -ne '3'))
	return $false
}
#==========================================================================================================================================
#  INTERNAL OPTIONS MENU HELP
#==========================================================================================================================================
function InternalOptionsHelp([string]$InputValue)
{
	Write-Host ''
	Write-Host '-----------------------------------------------------------------------------------------------------------------------'
	Write-Host ''
	if ($InputValue -eq '1?')
	{

		Write-Host ' Path to Ishiiruka Tool' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' The path to the texture encoder by Tino that can combine "spec", "bump", and "nrm" textures into a Material Map. This'
		Write-Host ' tool is also needed to work with already combined Material Maps (meaning the "nrm" file created from the previously'
		Write-Host ' mentioned textures). If a pack contains Material Maps or Material Textures, an option is selected to convert textures'
		Write-Host ' to another format, and this tool is not found, then these textures will not be converted.'
		Write-Host ''
		Write-Host ' It is important to set the path to this tool if you want to work with Material Map or Material Textures.'
	}
	elseif ($InputValue -eq '2?')
	{
		Write-Host ' Path to OptiPNG - Used with Option 4 - Optimize Textures with OptiPNG' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' This is the path to OptiPNG which is completely optional. OptiPNG attempts to recompress PNG files in order to reduce'
		Write-Host ' their file size by running a number of different "tests" and going with the best results. The number of tests can be'
		Write-Host ' configured below in the "Texture Pack Generation Options" section.'
	}
	elseif ($InputValue -eq '3?')
	{
		Write-Host ' Temporary Folder - Used when generating temporary textures.' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' When temporary textures need to be generated, this is the folder they will be created. Temporary files will always' 
		Write-Host ' be deleted when they are no longer needed, and are wiped out on every execution/completion of one of the scripts' 
		Write-Host ' options. The default location is "\AppData\Local\Temp\CTT-PS_Temp", but can be changed to anywhere. This is useful' 
		Write-Host ' if a user has trouble creating content in the AppData folder, or just simply wants to relocate the Temp folder.'
		Write-Host ''
		Write-Host ' It is important that you locate this path to a folder that contains nothing important! When the script is started, an'
		Write-Host ' option is finished processing, or when the script is closed, this folder and all of its contents are deleted!'
	}
	elseif ($InputValue -eq '4?')
	{
		Write-Host ' Hide OK Textures - Used with Option 1 - Scan Textures For Issues' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' Textures are checked for issues when using an option under Scan Textures For Issues. By default, all textures that'
		Write-Host ' are processed are printed in the log file. If a texture does not have any issues, it is flagged "OK". If this variable'
		Write-Host ' is true, then "OK" textures will not be printed in the log file. This is useful if you only want to see which textures'
		Write-Host ' have issues that need fixed if you wish to fix textures manually or if the repair function does not work.'
	}
	elseif ($InputValue -eq '5?')
	{
		Write-Host ' Ignore Duplicate Textures - Used with Option 1 - Scan Textures For Issues' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' This option disables the script from finding duplicate textures and printing them to log files. This option does not'
		Write-Host ' affect "Dolphin Duplicates" because they are an entirely different kind of duplicate texture. It can be useful to hide'
		Write-Host ' duplicates to prevent log spam if a pack contains "Optional Textures" that has many textures with the same name/hash.'
	}
	elseif ($InputValue -eq '6?')
	{
		Write-Host ' Allow NotHD Textures - Used with Option 1 - Scan Textures For Issues' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' When error checking textures, custom texture dimensions are checked to see if they are higher than the dimensions of'
		Write-Host ' the original texture. If this option is set to true, then this check is disabled and these textures get treated as HD'
		Write-Host ' textures and pass the check. If it is false, then it will catch textures that might actually be an original texture.'
		Write-Host ''
		Write-Host ' Setting this option to true is useful when you want to utilize textures with the original dimensions.' -ForegroundColor Green
		Write-Host ' Setting this option to false is useful when you are trying to find textures that are not HD textures.' -ForegroundColor Green
	}
	elseif ($InputValue -eq '7?')
	{
		Write-Host ' DDS Auto-Repair - Used exclusively with Option 3 - Convert Textures to Another Format' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' If true, dimensions will be calculated by multiplying the' -NoNewLine
		Write-Host ' original dimensions * lowest integer scale' -ForegroundColor Cyan -NoNewLine
		Write-Host ' between width'
		Write-Host ' and height. This means if a texture is scaled to 5.97x6.02, the lowest integer scale between width and height is 5 so'
		Write-Host ' dimensions end up as' -NoNewLine
		Write-Host ' original dimensions * 5' -ForegroundColor Cyan -NoNewLine
		Write-Host '. The value set in Scale-Fix Threshold affects if the scaling integer is'
		Write-Host ' rounded up based on the decimal value. Using the same example, ScaleThreshold<=0.97, 5.97 becomes 6, so the DDS'
		Write-Host ' dimensions end up as' -NoNewLine
		Write-Host ' original dimensions * 6' -ForegroundColor Cyan -NoNewLine
		Write-Host '.'
		Write-Host ''
		Write-Host ' If false, generated DDS texture dimensions will instead be scaled up to the' -NoNewLine
		Write-Host ' nearest multiple of 4' -ForegroundColor Cyan -NoNewLine
		Write-Host ', meaning a texture'
		Write-Host ' with dimensions 123x125 becomes 124x128 although 124x124 may be correct. This matches the behavior of other programs'
		Write-Host ' such as Aorta and The Compressonator, but this script can still generate 1x1 and 2x2 MipMaps (which they cant).'
		Write-Host ''
		Write-Host ' Example: DDSAutoRepair=true  original=24x24 custom=75x75 (scale 3.12) dds=72x72' -ForegroundColor Green
		Write-Host ' Example: DDSAutoRepair=false original=24x24 custom=75x75 (scale 3.12) dds=76x76' -ForegroundColor Green
		Write-Host ''
		Write-Host ' Setting this option to true is useful when trying to get the most accurate dimensions.' -ForegroundColor Green
		Write-Host ' Setting this option to false is useful when textures have very low scaling values or mismatched aspect ratios.' -ForegroundColor Green
	}
	elseif ($InputValue -eq '8?')
	{
		Write-Host ' Scale-Fix Threshold - Used When Repairing Textures or Converting to DDS' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' This value applies when attempting to repair texture scaling, or when converting textures to DDS with Option 6 when'
		Write-Host ' DDS Auto-Repair is enabled. This sets a minimum decimal value to auto-fix textures to the next highest integer scale.'
		Write-Host ' The value that is entered takes an integer from 0-99, but it is read internally as 0.00-0.99.'
		Write-Host ''
		Write-Host ' Example: Scale-Fix Threshold = 0.45 would up-scale 4.45-4.99 to 5x scale, but downscale 4.44 to 4x scale.' -ForegroundColor Green
		Write-Host ' Example: Scale-Fix Threshold = 0.98 would up-scale 6.98-6.99 to 7x scale, but downscale 6.98 to 6x scale.' -ForegroundColor Green
	}
	elseif ($InputValue -eq '9?')
	{
		Write-Host ' Aspect-Fix Threshold - Used When Repairing Textures' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' Sets a minimum limit of aspect difference between the original and custom texture. This option takes an integer value'
		Write-Host ' from 0-100, but is read internally as 0.00-1.00. Aspect is calculated from dividing the width by the height, and both'
		Write-Host ' the original and custom texture should have identical aspects. The value of Aspect-Fix Threshold is compared against'
		Write-Host ' the original texture aspect minus the custom texture aspect, and it is not suggested to use a value above 0.10.'
		Write-Host ''
		Write-Host ' Example: original=240x64=3.75 custom=752x200=3.76, 3.76-3.75=0.01, Minimum Aspect-Fix Threshold=0.01 to Auto-Repair' -ForegroundColor Green
		Write-Host ' Example: original=200x32=6.25 custom=800x130=6.15, 6.25-6.15=0.10, Minimum Aspect-Fix Threshold=0.10 to Auto-Repair' -ForegroundColor Green
	}
	elseif ($InputValue -eq 'a?')
	{
		Write-Host ' OptiPNG Tests - Used When Optimizing Textures With OptiPNG (PNG Only)' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' Sets the number of tests that OptiPNG runs on textures in an attempt to optimize them. The more tests that are ran,'
		Write-Host ' the higher the chance of getting a smaller tester. But each tests significanly increases the time it takes for OptiPNG'
		Write-Host ' to optimize a texture. It is not suggested to go above 5 tests which is usually overkill in itself.'
	}
	elseif ($InputValue -eq 'b?')
	{
		Write-Host ' DDS MipMap Type - Used When Generating DDS MipMaps With Any Option' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' Whenever the script works with DDS MipMaps, this option specifies which types of MipMaps to deal with.'
		Write-Host ''
		Write-Host ' - Option 1-#: Type of MipMaps to check for issues and generate when repairing.'
		Write-Host ' - Option 2/3: Type of MipMaps to generate for textures if DDS is selected as the convert type.'
		Write-Host ' - Option 4-2: Type of MipMaps to generate for material maps if DDS is selected as the convert type.'
		Write-Host ''
		Write-Host ' External MipMaps can be used by any version of Dolphin, and is the best option for compatibility.'
		Write-Host ' Internal MipMaps can only be used by Dolphin Ishiiruka and not with the Master branch of Dolphin.'
		Write-Host ' There is also the option to generate both types for maximum compatibility, but obviously this takes more disc space.'
	}
	elseif ($InputValue -eq 'c?')
	{
		Write-Host ' Force New MipMaps - Used When Generating MipMaps With Any Option' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' When the script generates MipMaps when (converting, repairing, rescaling), it will scan for external MipMaps included' 
		Write-Host ' with the pack (_mip1, _mip2, _mip3, etc) to use as a base for the newly generated MipMaps. When this option is set to'
		Write-Host ' true, the script will ignore included MipMaps and generate new MipMaps from the top level (base texture with "m" flag'
		Write-Host ' minus the mip# suffix). Setting this option to true is useful when rescaling a pack with a fixed integer scale and the'
		Write-Host ' pack contains textures with scales that exceed or dip below the integer set. Setting this option to false is useful'
		Write-Host ' when a pack includes MipMaps with correct scaling values, and/or uses dynamic MipMaps (MipMaps with different images).'
		Write-Host ''
		Write-Host ' Example: Pack contains [m] textures - 2048x2048 (16x scale) and 512x512 (2x scale).' -ForegroundColor Green
		Write-Host ''
		Write-Host ' Rescaling at 4x using included MipMaps will create nice MipMaps for 2048x2048 texture because they are scaled down but' -ForegroundColor Green
		Write-Host ' very blurry MipMaps for 512x512 texture because they are scaled up. Setting this option to true will instead generate' -ForegroundColor Green
		Write-Host ' new MipMaps using the 2048x2048 texture and 512x512 textures as a base which will still force the 512x512 to scale the' -ForegroundColor Green
		Write-Host ' first few layers of its MipMaps up, but with significantly greater quality.' -ForegroundColor Green
	}
	elseif ($InputValue -eq 'd?')
	{
		Write-Host ' Copy Non-Textures - Used with Option 2 (Rescaling/Converting) and Option 3 (Converting)' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' When generating a pack using "Rescale Textures at Fixed Integer" or "Convert Textures to Another Format", files that'
		Write-Host ' are not textures will be copied into the same directory of the newly created pack in' -NoNewLine
		Write-Host ' ~ConvertedTextures' -ForegroundColor Cyan -NoNewLine
		Write-Host '. This Option'
		Write-Host ' is useful when converting a pack into another format as it preserves all files and not just textures.'
		Write-Host ''
		Write-Host ' Example: A directory such as C:\Pack\Environment\Area01 contains textures and contains ReadMe.txt.' -ForegroundColor Green
		Write-Host ' When the pack is converted to DDS, ReadMe.txt will be copied to C:\Pack\~ConvertedTextures\Environment\Area01.' -ForegroundColor Green
	}
	elseif ($InputValue -eq 'e?')
	{
		Write-Host ' Manual Rescale - Used exclusively with Option 2 - Rescale Textures at Fixed Integer (1-16)' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' Changes the behavior of rescaling textures with Option 2. This option allows rescaling each texture individually with'
		Write-Host ' a different integer scale chosen by the user. A prompt will appear to enter a default scale, followed by additional'
		Write-Host ' prompts to enter a scaling value for each texture. Very large scaling values from 1-100 are allowed to be set in this'
		Write-Host ' mode, so choose the values reasonably. If a scale is not entered for the current texture, it will scale the texture'
		Write-Host ' using the default value that was entered when selecting Option 2. The default value chosen is always visible.'
	}
	elseif ($InputValue -eq '0?')
	{
		Write-Host ' Uh, this option exits this menu and returns to the main menu.'
	}
	elseif ($InputValue -eq '??')
	{
		Write-Host '                                     OMFG YOU JUST FOUND AN EASTER EGG!' -ForegroundColor Green
		Write-Host ''
		Write-Host ''
		Write-Host '                                                  _,,gg,,_              ' -ForegroundColor Cyan
		Write-Host '                                               ,a888P88Y888a,           ' -ForegroundColor Magenta
		Write-Host '                                             ,d"8"8",YY,"8"8"b,         ' -ForegroundColor Yellow
		Write-Host '                                           d",P"d" d" `b `b`Y,"b,       ' -ForegroundColor Green
		Write-Host '                                         ,P",P",P  8   8  Y,`Y,"Y,      ' -ForegroundColor Red
 		Write-Host '                                        ,P ,P` d`  8   8  `b `Y, Y,     ' -ForegroundColor Magenta
		Write-Host '                                       ,P ,P_,,8gg8gg8ggg8g8,,_Y, Y,    ' -ForegroundColor Cyan
		Write-Host '                                       ,8P"""""""``      ``"""""""Y8,   ' -ForegroundColor Cyan
		Write-Host '                                       d`/~\    /~\    /~\    /~\  `b   ' -ForegroundColor Green
		Write-Host '                                       8/   \  /   \  /   \  /   \  8   ' -ForegroundColor Yellow
		Write-Host '                                       8 ,8, \/ ,8, \/ ,8, \/ ,8, \/8   ' -ForegroundColor Green
		Write-Host '                                       8 "Y" /\ "Y" /\ "Y" /\ "Y" /\8   ' -ForegroundColor Yellow
		Write-Host '                                       8\   /  \   /  \   /  \   /  8   ' -ForegroundColor Green
		Write-Host '                                       8 \_/    \_/    \_/    \_/   8   ' -ForegroundColor Yellow
		Write-Host '                                       8                            8   ' -ForegroundColor Green
		Write-Host '                                       Y""""YYYaaaa,,,,,,aaaaPPP""""P   ' -ForegroundColor Cyan
		Write-Host '                                       `b ag,   ``""""""""``   ,ga d`   ' -ForegroundColor Cyan
		Write-Host '                                        `YP "b,  ,aa,  ,aa,  ,d" YP`    ' -ForegroundColor Magenta
		Write-Host '                                          "Y,_"Ya,_)8  8(_,aP"_,P"      ' -ForegroundColor Yellow
		Write-Host '                                            `"Ya_"""    """_aP"`        ' -ForegroundColor Red
		Write-Host '                                               `""YYbbddPP""`           ' -ForegroundColor Cyan
		Write-Host ''
	}
	Write-Host ''
	Write-Host ' Press any key to continue...'
	Write-Host ''
	Write-Host '-----------------------------------------------------------------------------------------------------------------------'
	[void][System.Console]::ReadKey($true)
}
#==========================================================================================================================================
#  WATERMARK MENU HELP
#==========================================================================================================================================
function WatermarkMenuHelp([string]$InputValue)
{
	Write-Host ''
	Write-Host '-----------------------------------------------------------------------------------------------------------------------'
	Write-Host ''
	if ($InputValue -eq '1?')
	{

		Write-Host ' Text Length' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' This defines how many characters to pull from the end of the texture name to display on the texture as a watermark. If'
		Write-Host ' a value of 0 is entered, then it will use the entire name of the texture.'
	}
	elseif ($InputValue -eq '2?')
	{
		Write-Host ' Font Face' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' Defines the font that will be used for the watermark.'
	}
	elseif ($InputValue -eq '3?')
	{
		Write-Host ' Font Size' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' Defines the size of the font that will be used for the watermark. This is not the fonts actual size, it is instead a'
		Write-Host ' multiplier used to scale the font using the formula "NewWidth / 128 * FontSize". This ensures that the font remains'
		Write-Host ' a constant size across all texture.'
	}
	elseif ($InputValue -eq '4?')
	{
		Write-Host ' Font Color' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' Simply defines the color of the font used for the watermark. Color is represented as a six digit hex value. Refer to'
		Write-Host ' a Hex/HTML color chart for a list of colors that can be used.'
	}
	elseif ($InputValue -eq '5?')
	{
		Write-Host ' Font BG Color' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' Defines the color of the background that surrounds the font used for the watermark. Color is represented as a six'
		Write-Host ' digit hex value. Refer to a Hex/HTML color chart for a list of colors that can be used.'
	}
	elseif ($InputValue -eq '6?')
	{
		Write-Host ' Word Wrap' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' If the watermark is too long to scale to the texture, this option creates a new line for the texture name. This makes'
		Write-Host ' sure the watermark is fully contained and does not run off the edges (left to right only).'
	}
	elseif ($InputValue -eq '7?')
	{
		Write-Host ' Begin Watermark Generation' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' Starts the main loop to start adding watermarks to textures.'
	}
	Write-Host ''
	Write-Host ' Press any key to continue...'
	Write-Host ''
	Write-Host '-----------------------------------------------------------------------------------------------------------------------'
	[void][System.Console]::ReadKey($true)
}
#==========================================================================================================================================
#  SCAN TEXTURES FOR ISSUES HELP
#==========================================================================================================================================
function ScanTexturesMenuHelp([string]$InputValue)
{
	Write-Host ''
	Write-Host '-----------------------------------------------------------------------------------------------------------------------'
	Write-Host ''
	if ($InputValue -eq '1?')
	{
		Write-Host ' Check Textures For Issues' -ForegroundColor Yellow
		Write-Host ' Options: Hide OK Textures, DDS MipMap Type' -ForegroundColor Green
		Write-Host ''
		Write-Host ' This option scans textures for issues and creates a log file that lists each texture issue. It displays the texture'
		Write-Host ' path, the dimensions / aspect of both the original and the custom texture, the scale of the custom texture, and any'
		Write-Host ' issues with the custom texture. It supports detecting the following issues:'
		Write-Host ''
		Write-Host ' NotHD Texture     ' -ForegroundColor Yellow -NoNewLine
		Write-Host ' A texture with the original dimensions. NotHD are also copied to folder' -NoNewLine
		Write-Host ' ~NotHDTextures' -ForegroundColor Cyan -NoNewLine
		Write-Host '.'
		Write-Host ' Dolphin Duplicate ' -ForegroundColor Yellow -NoNewLine
		Write-Host ' Dolphin named duplicates with .1, .2, etc. These textures are copied to folder' -NoNewLine
		Write-Host ' ~DolphinDuplicates' -ForegroundColor Cyan -NoNewLine
		Write-Host '.'
		Write-Host ' Duplicate Texture ' -ForegroundColor Yellow -NoNewLine
		Write-Host ' Duplicate textures within the pack. Duplicates are copied to folder' -NoNewLine
		Write-Host ' ~DuplicateTextures' -ForegroundColor Cyan -NoNewLine
		Write-Host '.'
		Write-Host ' Uneven Scale      ' -ForegroundColor Yellow -NoNewLine
		Write-Host ' Width and height were not scaled with the same factor.'
		Write-Host ' Non-Integer Scale ' -ForegroundColor Yellow -NoNewLine
		Write-Host ' The texture width or height was not scaled with an integer scale.'
		Write-Host ' Bad Aspect Ratio  ' -ForegroundColor Yellow -NoNewLine
		Write-Host ' The original and custom textures have a different aspect ratio.'
		Write-Host ' MipMaps Missing   ' -ForegroundColor Yellow -NoNewLine
		Write-Host ' Detects any missing mipmap levels for mipmap [m] textures and lists the number of them missing.'
		Write-Host ' MipMaps Bad Scale ' -ForegroundColor Yellow -NoNewLine
		Write-Host ' Detects bad mipmap scales for [m] textures and lists the number of them.'
		Write-Host ' Material Textures ' -ForegroundColor Yellow -NoNewLine
		Write-Host ' Texture contains material textures (bump/spec/nrm). Repairing will create a material map.'
		Write-Host ' Bad DDS Dimensions' -ForegroundColor Yellow -NoNewLine
		Write-Host ' When DDS texture dimensions do not match the best possible calculated dimensions.'
	}
	elseif ($InputValue -eq '2?')
	{
		Write-Host ' Copy Textures With Issues' -ForegroundColor Yellow
		Write-Host ' Options: Hide OK Textures, DDS MipMap Type' -ForegroundColor Green
		Write-Host ''
		Write-Host ' This option also performs error checking, and copies any textures with "issues" to a directory within the texture pack'
		Write-Host ' folder named' -NoNewLine
		Write-Host ' ~BrokenTextures' -ForegroundColor Cyan -NoNewLine
		Write-Host '.'
	}
	elseif ($InputValue -eq '3?')
	{
		Write-Host ' Repair Textures With Issues' -ForegroundColor Yellow
		Write-Host ' Options: Hide OK Textures, DDS MipMap Type, Force New MipMaps, Scale-Fix Threshold, Aspect-Fix Threshold' -ForegroundColor Green
		Write-Host ''
		Write-Host ' This option also performs error checking, and attempts to repair any textures with "issues" to a directory within the' 
		Write-Host ' texture pack folder named' -NoNewLine
		Write-Host ' ~RepairedTextures' -ForegroundColor Cyan -NoNewLine
		Write-Host '. Issues that can be fixed with this option are: Uneven Scale, Bad Width,'
		Write-Host ' Bad Height, Bad Aspect Ratio, Bad MipMap Scale, and Missing MipMaps.'
	}
	elseif ($InputValue -eq '4?')
	{
		Write-Host ' Repair/Copy Textures With Issues' -ForegroundColor Yellow
		Write-Host ' Options: Hide OK Textures, DDS MipMap Type, Force New MipMaps, Scale-Fix Threshold, Aspect-Fix Threshold' -ForegroundColor Green
		Write-Host ''
		Write-Host ' Simply combines the functionality of Options 1-3. If a texture cannot be repaired, then it is copied instead.'
	}
	Write-Host ''
	Write-Host ' Press any key to continue...'
	Write-Host ''
	Write-Host '-----------------------------------------------------------------------------------------------------------------------'
	[void][System.Console]::ReadKey($true)
}
#==========================================================================================================================================
#  MAIN MENU HELP
#==========================================================================================================================================
function AdvancedFunctionsHelp([string]$InputValue)
{
	Write-Host ''
	Write-Host '-----------------------------------------------------------------------------------------------------------------------'
	Write-Host ''
	if ($InputValue -eq '1?')
	{
		Write-Host ' Generate New MipMaps (In-Place)' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' Generates MipMaps for all textures within the texture pack itself. This option destroys any MipMap levels that are'
		Write-Host ' found and replaces them with new ones generated from the top layer, so care should be taken when using this option.'
		Write-Host ' This option does not preserve dynamic MipMaps (varying MipMap images). If a texture pack is using dynamic MipMaps,'
		Write-Host ' use "Scan Textures For Issues", and choose to repair them. Or, rescale/convert the texture pack to another format.'
		Write-Host ' Using these options to generate MipMaps will preserve dynamic MipMaps, unless the "Force New MipMaps" option is set'
		Write-Host ' to "True" within the Internal Options Menu.'
		Write-Host ''
		Write-Host ' To be clear, this option is useful only as a shortcut to generate brand new MipMaps within the texture pack, rather'
		Write-Host ' than create copies of the textures in the generated folders this script creates with a "~" symbol. It should also be'
		Write-Host ' noted that this option bypasses the scan for issues, so incorrect textures may be created with incorrect MipMaps.'
	}
	elseif ($InputValue -eq '2?')
	{
		Write-Host ' Create Material Maps With Ishiiruka Tool (In-Place)' -ForegroundColor Yellow
		Write-Host ' Options: Path to Ishiiruka Tool' -ForegroundColor Green
		Write-Host ''
		Write-Host ' Searches for color textures that include accompanying bump/spec/nrm textures and generates material maps. This option'
		Write-Host ' is not very safe as it will destroy the original bump/spec/nrm textures. If you wish to generate a pack but preserve'
		Write-Host ' these textures, then it is recommended to instead use the option "Convert Textures to Another Format".'
	}
	elseif ($InputValue -eq '3?')
	{
		Write-Host ' Remove Invalid MipMaps From the Pack' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' Scans a texture pack for textures that contain MipMap levels that are not an actual MipMap [m] texture, and deletes'
		Write-Host ' these invalid levels. These MipMaps will be deleted from the actual texture pack, so it is suggested to back up the'
		Write-Host ' texture pack before making use of this option.'
		Write-Host ''
		Write-Host ' Example: tex1_32x32_d0f9034aa0ff4873_14 is not a MipMap texture, but contains MipMap levels...' -ForegroundColor Green
		Write-Host ''
		Write-Host ' tex1_32x32_d0f9034aa0ff4873_14_mip1' -ForegroundColor Green
		Write-Host ' tex1_32x32_d0f9034aa0ff4873_14_mip2' -ForegroundColor Green
		Write-Host ' tex1_32x32_d0f9034aa0ff4873_14_mip3' -ForegroundColor Green
		Write-Host ''
		Write-Host ' Because this is not a MipMap texture, these MipMap levels will be removed.' -ForegroundColor Green
	}
	elseif ($InputValue -eq '4?')
	{
		Write-Host ' Optimize Textures With OptiPNG (In-Place, PNG Only)' -ForegroundColor Yellow
		Write-Host ' Options: Path to OptiPNG, OptiPNG Tests' -ForegroundColor Green
		Write-Host ''
		Write-Host ' OptiPNG attempts to recompresses PNG files in order to shrink their file size by running a number of different tests'
		Write-Host ' and going with the best results. This script sets the number of OptiPNG tests to 3 by default, but can be configured'
		Write-Host ' in the Internal Options menu. There is a limit of 1-20 tests, as each test will significantly increase the time it'
		Write-Host ' takes to optimize a texture. This option creates the texture in the place of the original texture.'
	}
	elseif ($InputValue -eq '5?')
	{
		Write-Host ' Fix Textures Potentially Broken By OptiPNG' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' OptiPNG tends to store PNG data in a way that is unrecognizable by Dolphin if the bit depth is below 8 on any color'
		Write-Host ' channel. This option checks for any textures that have less than 8bpp in any channel and recreates the texture using'
		Write-Host ' ImageMagick. This will not increase the depth of each channel, so subsequent runs will also regenerate the texture.'
		Write-Host ''	
		Write-Host ' This option is also capable of false positives, meaning a texture that was not actually optimized by OptiPNG will be'
		Write-Host ' "repaired" even if it would work in Dolphin. A bypass has been added to the script to no longer attempt to optimize' 
		Write-Host ' these textures when running OptiPNG. In time this option will lose its usefulness (if it hasnt already).'
	}
	Write-Host ''
	Write-Host ' Press any key to continue...'
	Write-Host ''
	Write-Host '-----------------------------------------------------------------------------------------------------------------------'
	[void][System.Console]::ReadKey($true)
}
#==========================================================================================================================================
#  MAIN MENU HELP
#==========================================================================================================================================
function MainMenuHelp([string]$InputValue)
{
	Write-Host ''
	Write-Host '-----------------------------------------------------------------------------------------------------------------------'
	Write-Host ''
	if ($InputValue -eq '0?')
	{
		Write-Host ' Internal Options Menu' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' Enters the menu to configure internal options. More information on these options can be found there.'
	}
	elseif ($InputValue -eq '1?')
	{
		Write-Host ' Scan Textures For Issues' -ForegroundColor Yellow
		Write-Host ' Options: Hide OK Textures, DDS MipMap Type, Force New MipMaps, Scale-Fix Threshold, Aspect-Fix Threshold' -ForegroundColor Green
		Write-Host ''
		Write-Host ' Opens the sub-menu to scan textures for errors. More information on each option can be found there.'
	}
	elseif ($InputValue -eq '2?')
	{
		Write-Host ' Rescale Textures at Fixed Integer (1-16)' -ForegroundColor Yellow
		Write-Host ' Options: Manual Rescale, DDS MipMap Type, Force New MipMaps, Copy Non-Textures' -ForegroundColor Green
		Write-Host ''
		Write-Host ' Creates a copy of the texture pack at a set integer scale from 1-16 to a folder within the texture pack folder named'
		Write-Host ' ~RescaledTextures.' -ForegroundColor Cyan -NoNewLine
		Write-Host ' Textures can be created as PNG, DDS, or JPG. Creating DDS textures requires a valid path to Nvidia'
		Write-Host ' DDS Utilities. JPG textures are only created if the source texture does not have an alpha channel. It should be noted'
		Write-Host ' that this option will not work well for packs with very low scaling values or intentionally bad aspect ratios.'
		Write-Host ''
		Write-Host ' Enabling' -NoNewLine
		Write-Host ' ManualRescale' -ForegroundColor Yellow -NoNewLine
		Write-Host ' changes how this option works. When set to true, a default scaling value is instead chosen and'
		Write-Host ' a prompt appears for each texture to rescale them individually from 1-100. If 0 is entered as the scale, the texture'
		Write-Host ' is effectively skipped. It is also possible to enter 0 as a default option to set "Skip Texture" as the default when'
		Write-Host ' no value is entered during the prompt. It is not suggested to use ManualRescale on an entire texture pack.'
	}
	elseif ($InputValue -eq '3?')
	{
		Write-Host ' Convert Textures to Another Format' -ForegroundColor Yellow
		Write-Host ' Options: DDS Auto-Repair, DDS MipMap Type, Force New MipMaps, Copy Non-Textures' -ForegroundColor Green
		Write-Host ''
		Write-Host ' Requires Nvidia DDS Utilities to convert textures to DDS. If it is not found, a prompt will ask you to locate it.'
		Write-Host ''
		Write-Host ' This option performs a 1:1 conversion of all textures to another format, which are created in a directory within the'
		Write-Host ' texture pack folder named' -NoNewLine
		Write-Host ' ~ConvertedTextures' -ForegroundColor Cyan -NoNewLine
		Write-Host '. Although its not very useful to convert DDS or JPG to PNG since it is'
		Write-Host ' going from a lossy format to a lossless one, the option is provided just in case. It should also be noted that when'
		Write-Host ' a texture is not converted for any reason, it will instead be copied to the newly generated pack.'
	}
	elseif ($InputValue -eq '4?')
	{
		Write-Host ' Create Material Maps with Ishiiruka Tool' -ForegroundColor Yellow
		Write-Host ' Options: Path to Ishiiruka Tool' -ForegroundColor Green
		Write-Host ''
		Write-Host ' Requires Ishiiruka Tool to handle textures. If it is not found, a prompt will ask you to locate it.'
		Write-Host ''
		Write-Host ' Searches all folders for color textures that have accompanying bump/spec/nrm textures. Textures that are found with'
		Write-Host ' these materials will have a combined nrm texture generated for them in a folder named' -NoNewLine
		Write-Host ' ~MaterialMaps' -ForegroundColor Cyan -NoNewLine
		Write-Host '.'
	}
	elseif ($InputValue -eq '5?')
	{
		Write-Host ' Add Identifying Watermark to All Textures' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' Generates all textures with a watermark using the texture name. Textures will be created in' -NoNewLine
		Write-Host ' ~WatermarkTextures' -ForegroundColor Cyan -NoNewLine
		Write-Host '.'
		Write-Host ' The purpose of this option is to be able to easily identify where textures are located when loaded into a game. All'
		Write-Host ' textures will be created with a minimum width of 256 pixels so the text is easily readable. Several options are'
		Write-Host ' available to configure the output. Text Length is the number of characters that are included in the watermark starting'
		Write-Host ' backwards from the texture name, and a value of 0 will use the entire texture name. The Font Face can be configured'
		Write-Host ' from a list of some of the 9 most popular fonts. Font Size is not the actual size of the font in the conventional'
		Write-Host ' sense, but is instead used as a multiplier as fonts are scaled to the size of the texture so they remain consistent.'
		Write-Host ' Font Color and Font BG Color use a six digit color hex value which allows configuration of the fonts color and'
		Write-Host ' background color. Word Wrap forces all text to remain on the texture, and wraps when the text exceeds 80% of the'
		Write-Host ' textures generated width.'
	}
	elseif ($InputValue -eq '6?')
	{
		Write-Host ' Optimize Textures with OptiPNG (PNG Only)' -ForegroundColor Yellow
		Write-Host ' Options: Path to OptiPNG, OptiPNG Tests' -ForegroundColor Green
		Write-Host ''
		Write-Host ' OptiPNG attempts to recompresses PNG files in order to shrink their file size by running a number of different tests'
		Write-Host ' and going with the best results. This script sets the number of OptiPNG tests to 3 by default, but can be configured'
		Write-Host ' in the Internal Options menu. There is a limit of 1-20 tests, as each test will significantly increase the time it'
		Write-Host ' takes to optimize a texture. Using this option will be create textures in the folder' -NoNewLine
		Write-Host ' ~OptimizedTextures' -ForegroundColor Cyan -NoNewLine
		Write-Host '.'
	}
	elseif ($InputValue -eq '7?')
	{
		Write-Host ' Apply Upscaling Filter to Base Textures' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' This option allows upscaling and applying a filter to textures that are dumped by Dolphin. This option does not work'
		Write-Host ' on textures with a resolution higher than the dimensions of the original texture. Its not a replacement for actual'
		Write-Host ' retexturing, as the results are not fantastic, and it should only be used in special circumstances. Textures created'
		Write-Host ' with this option are output to a folder named' -NoNewLine
		Write-Host ' ~FilteredTextures' -ForegroundColor Cyan -NoNewLine
		Write-Host '.'
	}
	elseif ($InputValue -eq '8?')
	{
		Write-Host ' Advanced Functions Menu' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' Opens a new set of options, some of them being similar to the ones found on the Main Menu. The main difference is'
		Write-Host ' that these options modify your texture pack directly, so they must be used with cation. It is strongly suggested to'
		Write-Host ' create a backup of your texture pack before using these options in case you do not get the desired effect!'
	}
	elseif ($InputValue -eq 'x?')
	{
		Write-Host ' Exits the script and closes the PowerShell Console.'
	}
	# Secret option to allow selecting the path to ImageMagick while the script is running.
	elseif ($InputValue -eq '??')
	{
		Write-Host ' IMAGEMAGICK PATH SELECTION' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' NOTE:' -ForegroundColor Red -NoNewLine
		Write-Host ' Setting the path with this option will remove the script`s ability to pull future versions from the registry!'
		SelectImageMagick
		$host.UI.RawUI.WindowTitle = ($ScriptName + ' - PowerShell v' + $PSVersion + ' - ImageMagick v' + $IMVersion)
		return
	}
	Write-Host ''
	Write-Host ' Press any key to continue...'
	Write-Host ''
	Write-Host '-----------------------------------------------------------------------------------------------------------------------'
	[void][System.Console]::ReadKey($true)
}
#==========================================================================================================================================
#  PATH SUCCEEDED FUNCTION
#==========================================================================================================================================
function PathSucceeded([string]$toolsucceeded)
{
	Write-Host ''
	Write-Host (' New path to ' + $toolsucceeded + ' succeeded!') -ForegroundColor Green
	Start-Sleep -m 1100
}
#==========================================================================================================================================
#  INTERNAL OPTION: ISHIIRUKA TOOL PATH MENU
#==========================================================================================================================================
function IshiirukaToolPathMenu([bool]$CheckPath)
{
	# When running this from a menu option, check if we really need to update the path.
	if ($CheckPath)
	{
		# Running from a menu option requires a return state. Default it to false.
		$ReturnState = $false
		if (!(TestPath $IshiirukaTool))
		{
			# Display this tidbit that only appears if ran from a menu option.
			$ScreenText = CopyAllScreenText
			Clear-Host
			Write-Host $ScreenText
			Write-Host '-----------------------------------------------------------------------------------------------------------------------'
			Write-Host ' NOTICE: ' -ForegroundColor Cyan -NoNewLine
			Write-Host 'The path to Ishiiruka Tool was not found!'
		}
		# If the path is already valid, we can simply return true to end this function.
		else
		{
			return $true
		}
	}
	# No matter how this menu was ran, show the prompt to select a new path.
	Write-Host '-----------------------------------------------------------------------------------------------------------------------'
	Write-Host ' Choose a new path for Ishiiruka Tool. The path must point to ' -NoNewLine
	Write-Host 'TextureEncoder.exe' -ForegroundColor Yellow -NoNewLine
	Write-Host '.'

	# Display an "Open File" menu to get the path.
	$EncoderCheckPath = Get-FileName 'C:\' 'TextureEncoder.exe'

	# Ugh avoid an error by performing this fucking check.
	if ($EncoderCheckPath -ne '')
	{
		# This check is for PowerShell v2 work-around since a filter can't be applied to select only "TextureEncoder.exe".
		$CheckText = $EncoderCheckPath.Substring($EncoderCheckPath.Length - 18, 18)
	}
	# Make sure the selected file is actually the Ishiiruka Tool executable.
	if ($CheckText -ne 'TextureEncoder.exe')
	{
		# Display an error message.
		InvalidInput 'file'

		# Return state if running from a menu option.
		$ReturnState = $false
	}
	# Check to see if a file was selected from the Open menu and test if that path exists.
	elseif (($EncoderCheckPath -ne '') -and (TestPath $EncoderCheckPath))
	{
		$OldEncoderPath = $IshiirukaTool
		$global:IshiirukaTool = $EncoderCheckPath
		$ReplaceText = '$global:IshiirukaTool      = ' + '"' + $OldEncoderPath + '"'
		$ReplaceWith = '$global:IshiirukaTool      = ' + '"' + $IshiirukaTool + '"'
		UpdateScript $ReplaceText $ReplaceWith

		# Alert the user that the new path was valid.
		PathSucceeded 'Ishiiruka Tool'

		# Return state if running from a menu option.
		$ReturnState = $true
	}
	# Catch running this from a menu option and return the ReturnState.
	if ($CheckPath) 
	{
		return $ReturnState
	}
}
#==========================================================================================================================================
#  INTERNAL OPTION: OPTIPNG PATH MENU
#==========================================================================================================================================
function OptiPNGPathMenu([bool]$CheckPath)
{
	# When running this from a menu option, check if we really need to update the path.
	if ($CheckPath)
	{
		# Running from a menu option requires a return state. Default it to false.
		$ReturnState = $false
		if (!(TestPath $OptiPNGPath))
		{
			# Display this tidbit that only appears if ran from a menu option.
			$ScreenText = CopyAllScreenText
			Clear-Host
			Write-Host $ScreenText
			Write-Host '-----------------------------------------------------------------------------------------------------------------------'
			Write-Host ' NOTICE: ' -ForegroundColor Cyan -NoNewLine
			Write-Host 'The path to OptiPNG was not found!'
		}
		# If the path is already valid, we can simply return true to end this function.
		else
		{
			return $true
		}
	}
	# No matter how this menu was ran, show the prompt to select a new path.
	Write-Host '-----------------------------------------------------------------------------------------------------------------------'
	Write-Host ' Choose a new path for OptiPNG. The path must point to ' -NoNewLine
	Write-Host 'optipng.exe' -ForegroundColor Yellow -NoNewLine
	Write-Host '.'

	# Display an "Open File" menu to get the path.
	$OptiCheckPath = Get-FileName 'C:\' 'optipng.exe'

	# Ugh avoid an error by performing this fucking check.
	if ($OptiCheckPath -ne '')
	{
		# This check is for PowerShell v2 work-around since a filter can't be applied to select only "optipng.exe".
		$CheckText = $OptiCheckPath.Substring($OptiCheckPath.Length - 11, 11)
	}
	# Make sure the selected file is actually the OptiPNG executable.
	if ($CheckText -ne 'optipng.exe')
	{
		# Display an error message.
		InvalidInput 'file'

		# Return state if running from a menu option.
		$ReturnState = $false
	}
	# Check to see if a file was selected from the Open menu and test if that path exists.
	elseif (($OptiCheckPath -ne '') -and (TestPath $OptiCheckPath))
	{
		$OldOptiPNGPath = $OptiPNGPath
		$global:OptiPNGPath = $OptiCheckPath
		$ReplaceText = '$global:OptiPNGPath        = ' + '"' + $OldOptiPNGPath + '"'
		$ReplaceWith = '$global:OptiPNGPath        = ' + '"' + $OptiPNGPath + '"'
		UpdateScript $ReplaceText $ReplaceWith

		# Alert the user that the new path was valid.
		PathSucceeded 'OptiPNG'

		# Return state if running from a menu option.
		$ReturnState = $true
	}
	# Catch running this from a menu option and return the ReturnState.
	if ($CheckPath) 
	{
		return $ReturnState
	}
}
#==========================================================================================================================================
#  INTERNAL OPTION: TEMP FOLDER PATH MENU
#==========================================================================================================================================
function TempFolderPathMenu()
{
	# Work-around for PowerShell v2 since the "Open Folder" dialog won't work here because of MTA.
	if ($PSVersion -lt 3)
	{
		# Prompt the user to enter a new input path.
		Write-Host '-----------------------------------------------------------------------------------------------------------------------'
		Write-Host ' Enter a new path to the "Temporary Folder". The path must be valid to succeed.' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' PowerShell should allow pasting a value by right clicking the console window.'
		Write-Host ''
		$TempDirectory = Read-Host '> '
	}
	# In PowerShell v3 and beyond, simply show the "Open Folder" dialog.
	else
	{
		# Prompt the user for a new input path.
		Write-Host '-----------------------------------------------------------------------------------------------------------------------'
		Write-Host ' Select a new "Temporary Folder" path. The path must be valid to succeed.' -ForegroundColor Yellow

		# Display an "Open Folder" menu to get the path.
		$TempDirectory = Get-Folder 'Select a new path for where Custom Texture Tool will create temporary files. Note that this path and all files it contains are destroyed every time the script is ran!'
	}
	# Check to see if a folder was selected from the Open menu and test if that path exists.
	if (($TempDirectory -ne '') -and (TestPath $TempDirectory))
	{
		$OldTempFolder = $TempFolder
		$global:TempFolder = $TempDirectory
		$ReplaceText = '$global:TempFolder         = ' + '"' + $OldTempFolder + '"'
		$ReplaceWith = '$global:TempFolder         = ' + '"' + $TempFolder + '"'
		$ReplaceOnce = '$global:TempFolder         = ' + '"$env:temp\CTT-PS_Temp"'
		UpdateScript $ReplaceText $ReplaceWith
		UpdateScript $ReplaceOnce $ReplaceWith

		# Alert the user that the new path was valid.
		PathSucceeded 'the Temporary Folder'
	}
	# If the path was not valid.
	else
	{
		# Display an error message.
		InvalidInput 'path'
	}
}
#==========================================================================================================================================
#  INTERNAL OPTION: UPDATE BOOLEAN VARIABLE
#==========================================================================================================================================
function UpdateOptionState([string]$VarName)
{
	# Get the value of the variable by checking the value by name using the string parameter.
	$VarValue = (Get-Variable -Name $VarName -ValueOnly)

	# Set up the variable name to replace in the script based on the $VarName parameter.
	$TextTrue  = '$global:' + (ExtendString $VarName 19) + '= ' + '$true'
	$TextFalse = '$global:' + (ExtendString $VarName 19) + '= ' + '$false'

	# Check if the option is true.
	if ($VarValue)
	{
		# Replace the true text with false text.
		UpdateScript $TextTrue $TextFalse
	}
	# Or if it is false.
	else 
	{
		# Replace the false text with true text.
		UpdateScript $TextFalse $TextTrue
	}
	# Update the variable with the reversed state.
	Set-Variable -Name $VarName -Value (!($VarValue)) -Scope 'Global'
}
#==========================================================================================================================================
#  INTERNAL OPTION: DDS MIPMAP TYPE MENU
#==========================================================================================================================================
function DDSMipMapTypeMenu()
{
	# Prompt the user for a new repair type.
	Write-Host '-----------------------------------------------------------------------------------------------------------------------'
	Write-Host ' Choose the type of DDS MipMaps that this script should handle.' -ForegroundColor Yellow
	Write-Host ''
	Write-Host ' (1:) External'
	Write-Host ' (2:) Internal'
	Write-Host ' (3:) Both'
	Write-Host ''
	$MenuInput = Read-Host '> '

	# Store the old value to compare and update.
	$OldDDSMipMapType = $DDSMipMapType

	switch -exact ($MenuInput)
	{
		'1' { $global:DDSMipMapType = 'External' }
		'2'	{ $global:DDSMipMapType = 'Internal' }
		'3' { $global:DDSMipMapType = 'Both' }
		default { InvalidInput 'option' }
	}
	# If the variable was updated then permanently save the changes to the script.
	if ($OldDDSMipMapType -ne $DDSMipMapType)
	{
		$ReplaceText = '$global:DDSMipMapType      = ' + '"' + $OldDDSMipMapType + '"'
		$ReplaceWith = '$global:DDSMipMapType      = ' + '"' + $DDSMipMapType + '"'
		UpdateScript $ReplaceText $ReplaceWith
	}
}
#==========================================================================================================================================
#  INTERNAL OPTION: SCALE/ASPECT-FIX THRESHOLD MENU
#==========================================================================================================================================
function UpdateThresholdState([string]$VarName)
{
	# Prompt the user for a new fix threshold.
	Write-Host '-----------------------------------------------------------------------------------------------------------------------'
	Write-Host (' Enter a new value for ' + $VarName + '. Valid values are (0-99).') -ForegroundColor Yellow
	Write-Host ''
	$MenuInput = Read-Host '> '

	# Test if the input value is an integer between 0 and 99.
	if ($MenuInput -match '^[1-9]?[0-9]$')
	{
		# Store the old value to compare and update.
		$OldThreshold = $(Get-Variable -Name $VarName -ValueOnly)

		# If the input value is between 0 and 9, then fix the input for single digits.
		if ($MenuInput -match '^\d$')
		{
			Set-Variable -Name $VarName -Value ('0.0' + $MenuInput) -Scope 'Global'
		}
		# If the input value is between 10 and 99, just convert to decimal.
		elseif ($MenuInput -match '^[1-9]\d$')
		{
			Set-Variable -Name $VarName -Value ('0.' + $MenuInput) -Scope 'Global'
		}
		# Check the threshold again to see if it was updated.
		$NewThreshold = $(Get-Variable -Name $VarName -ValueOnly)

		# If the variable was updated then permanently save the changes to the script.
		if ($OldThreshold -ne $NewThreshold)
		{
			$ReplaceText = '$global:' + (ExtendString $VarName 19) + '= "' + $OldThreshold + '"'
			$ReplaceWith = '$global:' + (ExtendString $VarName 19) + '= "' + $NewThreshold + '"'
			UpdateScript $ReplaceText $ReplaceWith
		}
	}
	# Invalid input so show an error.
	else
	{
		InvalidInput 'value'
	}
}
#==========================================================================================================================================
#  INTERNAL OPTION: OPTIPNG TESTS
#==========================================================================================================================================
function OptiPNGTestsMenu()
{
	Write-Host ''
	Write-Host '-----------------------------------------------------------------------------------------------------------------------'
	Write-Host ' Set the number of optimization tests for OptiPNG. (Max:20)' -ForegroundColor Yellow
	Write-Host ''
	$MenuInput = Read-Host '> '

	# Prevent more than 20 tests to protect users from themselves.
	if ($MenuInput -match '^([1-9]|1\d|20)$')
	{
		$OldOptiPNGTests = $OptiPNGTests
		$global:OptiPNGTests = $MenuInput
		$ReplaceText = '$global:OptiPNGTests       = ' + '"' + $OldOptiPNGTests + '"'
		$ReplaceWith = '$global:OptiPNGTests       = ' + '"' + $OptiPNGTests + '"'
		UpdateScript $ReplaceText $ReplaceWith
	}
	# The input was invalid.
	else
	{
		InvalidInput "value"
	}
}
#==========================================================================================================================================
#  INTERNAL OPTIONS MENU
#==========================================================================================================================================
function InternalOptionsMenu()
{
	do
	{
		Clear-Host
		Write-Host '-----------------------------------------------------------------------------------------------------------------------'
		Write-Host ' Internal Options Menu' -ForegroundColor Yellow
		Write-Host '-----------------------------------------------------------------------------------------------------------------------'
		Write-Host ''
		Write-Host ' Allows configuration of the scripts options through command input. Changes made are permanently stored.'
		Write-Host ' To learn more about an option, enter a' -NoNewLine
		Write-Host ' ?' -ForegroundColor Green -NoNewLine
		Write-Host ' after the input value (Example:' -NoNewLine
		Write-Host ' 1?' -ForegroundColor Green -NoNewLine
		Write-Host ')'
		Write-Host ''
		Write-Host '-----------------------------------------------------------------------------------------------------------------------'
		Write-Host 'Menu Options' -ForegroundColor Yellow
		Write-Host ' (0:) Return to Main Menu'
		Write-Host 'Paths Options' -ForegroundColor Yellow
		Write-Host (' (1:) Ishiiruka Tool       = ' + $IshiirukaTool)
		Write-Host (' (2:) OptiPNG Path         = ' + $OptiPNGPath)
		Write-Host (' (3:) Temp Folder          = ' + $TempFolder)
		Write-Host 'Error Checking Options' -ForegroundColor Yellow
		Write-Host (' (4:) Hide OK Textures     = ' + $HideOKTextures)
		Write-Host (' (5:) Ignore Duplicates    = ' + $IgnoreDuplicates)
		Write-Host (' (6:) Allow NotHD Textures = ' + $AllowNotHD)
		Write-Host 'Texture Repair Options' -ForegroundColor Yellow
		Write-Host (' (7:) DDS Auto-Repair      = ' + $DDSAutoRepair)
		Write-Host (' (8:) Scale-Fix Threshold  = ' + $ScaleThreshold)
		Write-Host (' (9:) Aspect-Fix Threshold = ' + $AspectThreshold)
		Write-Host (' (A:) OptiPNG Tests        = ' + $OptiPNGTests)
		Write-Host 'MipMap Generation Options' -ForegroundColor Yellow
		Write-Host (' (B:) DDS MipMap Type      = ' + $DDSMipMapType)
		Write-Host (' (C:) Force New MipMaps    = ' + $ForceNewMipMaps)
		Write-Host 'Texture Pack Generation Options' -ForegroundColor Yellow
		Write-Host (' (D:) Copy Non-Textures    = ' + $CopyNonTextures)
		Write-Host (' (E:) Manual Rescale       = ' + $ManualRescale)
		Write-Host ''
		$MenuInput = Read-Host '> '
		if ($MenuInput)
		{
			switch -wildcard ($MenuInput)
			{
				'1' { IshiirukaToolPathMenu $false }
				'2'	{ OptiPNGPathMenu $false }
				'3' { TempFolderPathMenu }
				'4' { UpdateOptionState 'HideOKTextures' }
				'5' { UpdateOptionState 'IgnoreDuplicates' }
				'6' { UpdateOptionState 'AllowNotHD' }
				'7' { UpdateOptionState 'DDSAutoRepair' }
				'8' { UpdateThresholdState 'ScaleThreshold' }
				'9' { UpdateThresholdState 'AspectThreshold' }
				'a' { OptiPNGTestsMenu }
				'b' { DDSMipMapTypeMenu }
				'c' { UpdateOptionState 'ForceNewMipMaps' }
				'd' { UpdateOptionState 'CopyNonTextures' }
				'e' { UpdateOptionState 'ManualRescale'}
				'0' { break }
				'*`?' { InternalOptionsHelp $MenuInput }
				default { InvalidInput 'option' }
			}
		}
	} while ((!$MenuInput) -or ($MenuInput -ne '0'))
}
#==========================================================================================================================================
#  MAIN MENU - OPTION 1 MENU - SCAN TEXTURES FOR ISSUES
#==========================================================================================================================================
function ScanTexturesMenu()
{
	$ScreenText = CopyAllScreenText
	do
	{
		Clear-Host
		Write-Host $ScreenText
		Write-Host '-----------------------------------------------------------------------------------------------------------------------'
		Write-Host ' Choose how the script will handle textures with issues.' -ForegroundColor Yellow
		Write-Host ' To learn more about an option, enter a' -NoNewLine
		Write-Host ' ?' -ForegroundColor Green -NoNewLine
		Write-Host ' after the input value (Example:' -NoNewLine
		Write-Host ' 1?' -ForegroundColor Green -NoNewLine
		Write-Host ')'
		Write-Host ''
		Write-Host ' (1:) Only Scan/Log Issues'
		Write-Host ' (2:) Copy Textures With Issues'
		Write-Host ' (3:) Repair Textures With Issues'
		Write-Host ' (4:) Repair/Copy Textures With Issues'
		Write-Host ' (B:) Back to Main Menu'
		Write-Host ''
		$MenuInput = Read-Host '> '
		if ($MenuInput)
		{
			switch -wildcard ($MenuInput)
			{
				'1' { $global:ScanAllTextures = $true }
				'2' { $global:ScanAllTextures = $global:CopyBadTextures = $true }
				'3' { $global:ScanAllTextures = $global:AutoFixTextures = $true }
				'4' { $global:ScanAllTextures = $global:CopyBadTextures = $global:AutoFixTextures = $true }
				'b' { return $false }
				'*`?' { ScanTexturesMenuHelp $MenuInput }
				default { InvalidInput 'option' }
			}
		}
	} while ((!$MenuInput) -or ($MenuInput -notmatch '^[1-4b]$'))
	return $true
}
#==========================================================================================================================================
#  MAIN MENU - OPTION 2 MENU - RESCALE
#==========================================================================================================================================
function RescaleMenu()
{
	$ScreenText = CopyAllScreenText
	do
	{
		Clear-Host
		Write-Host $ScreenText
		Write-Host '-----------------------------------------------------------------------------------------------------------------------'
		Write-Host ' Enter an integer scale from (1-16) to rescale all textures.' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' This value will be used to determine the new dimensions of all textures by'
		Write-Host ' multiplying the dimensions of the original textures by the entered amount.'
		Write-Host ''
		Write-Host ' It is also possible to enter the letter "B" to return back to the Main Menu.'
		Write-Host ''
		$MenuInput = Read-Host '> '
		# Regular expression to match 1-16.
		if ($MenuInput -match '^([1-9]|1[0-6])$')
		{
			$global:ForcedScale = $MenuInput
		}
		elseif ($MenuInput -eq 'b')
		{
			return $false
		}
		else
		{
			InvalidInput 'value'
		}
	} while ((!$MenuInput) -or ($MenuInput -notmatch '^([1-9]|1[0-6]|b)$'))
	return $true
}
#==========================================================================================================================================
function ManualRescaleMenu()
{
	$ScreenText = CopyAllScreenText
	do
	{
		Clear-Host
		Write-Host $ScreenText
		Write-Host '-----------------------------------------------------------------------------------------------------------------------'
		Write-Host ' Manual Rescale Detected' -ForegroundColor Green
		Write-Host '-----------------------------------------------------------------------------------------------------------------------'
		Write-Host ' Enter a default integer scale from (1-16) to rescale textures.' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' Or enter 0 to set the default setting to skip the current texture.'
		Write-Host ''
		Write-Host ' It is also possible to enter the letter "B" to return back to the Main Menu.'
		Write-Host ''
		$MenuInput = Read-Host '> '
		# Regular expression to match 0-16.
		if ($MenuInput -match '^(\d|1[0-6])$')
		{
			$global:ForcedScale = $global:StoredScale = $MenuInput
		}
		elseif ($MenuInput -eq 'b')
		{
			return $false
		}
		else
		{
			InvalidInput 'value'
		}
	} while ((!$MenuInput) -or ($MenuInput -notmatch '^(\d|1[0-6]|b)$'))
	return $true
}
#==========================================================================================================================================
#  MAIN MENU - OPTION 2/3 MENU - VERIFY DDS UTILITIES IS INSTALLED AND ALLOW SETTING THE PATH
#==========================================================================================================================================
function CheckDDSUtilities()
{
	# Check if DDS Utilities is not installed.
	if (!(TestPath $NVDXT))
	{
		$ScreenText = CopyAllScreenText
		Clear-Host
		Write-Host $ScreenText
		Write-Host '-----------------------------------------------------------------------------------------------------------------------'
		Write-Host ' NOTICE:'  -ForegroundColor Cyan -NoNewLine
		Write-Host ' Nvidia DDS Utilities was not found!'
		Write-Host '-----------------------------------------------------------------------------------------------------------------------'
		Write-Host ''
		# Work-around for PowerShell v2 since the "Open Folder" dialog won't work here because of MTA.
		if ($PSVersion -lt 3)
		{
			Write-Host ' Enter a new path to Nvidia DDS Utilities below. The path must contain' -NoNewLine
			Write-Host ' nvdxt.exe'-ForegroundColor Yellow -NoNewLine
			Write-Host ' to succeed.'
			Write-Host ''
			Write-Host ' PowerShell should allow pasting a value by right clicking the console window.'
			Write-Host ''
			$NewDDSPath = Read-Host '> '
		}
		# In PowerShell v3 and beyond, simply show the "Open Folder" dialog.
		else
		{
			Write-Host ' Select a new path to Nvidia DDS Utilities below. The path must contain' -NoNewLine
			Write-Host ' nvdxt.exe'-ForegroundColor Yellow -NoNewLine
			Write-Host ' to succeed.'
			$NewDDSPath = Get-Folder 'Select the path to nvidia DDS Utilities. The past must contain "nvdxt.exe" to succeed!'
		}
		# Use the selected folder to check for the path to the main nvidia tool.
		$TestDDSPath = $NewDDSPath + '\nvdxt.exe'

		# Check to see if the selected path exists.
		if (($NewDDSPath -ne "") -and (TestPath $TestDDSPath))
		{
			# Alert the user that it successful.
			Write-Host ''
			Write-Host ' New path to DDS Utilities succeeded!' -ForegroundColor Green
			Write-Host ''
			Write-Host ' Press any key to continue.'

			# Set the new path to the global variables.
			$global:NVDXT   = $NewDDSPath + '\nvdxt.exe'
			$global:NSTITCH = $NewDDSPath + '\stitch.exe'
			$global:NDETACH = $NewDDSPath + '\detach.exe'

			# Store the old path so the script can be updated.
			$OldNvidiaTools = $NvidiaTools
			$global:NvidiaTools = $NewDDSPath
			$ReplaceOnce = '$global:NvidiaTools        = ' + '(Get-ItemProperty -LiteralPath "HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\{64963F0E-03F2-4B59-8D1B-1806545E7092}\" -Name InstallLocation -ErrorAction SilentlyContinue).InstallLocation'
			$ReplaceText = '$global:NvidiaTools        = ' + '"' + $OldNvidiaTools + '"'
			$ReplaceWith = '$global:NvidiaTools        = ' + '"' + $NvidiaTools + '"'
			UpdateScript $ReplaceOnce $ReplaceWith
			UpdateScript $ReplaceText $ReplaceWith

			# Pause the script and wait for user input.
			[void][System.Console]::ReadKey($true)

			# Signal to exit the menu.
			return $true
		}
		# The path was invalid.
		InvalidInput 'path'
		return $false
	}
	# If DDS Utilities is found just return true.
	return $true
}
#==========================================================================================================================================
#  MAIN MENU - OPTION 2/3 MENU - FILE TYPE
#==========================================================================================================================================
function FileTypeMenu([bool]$ShowMore)
{
	$ScreenText = CopyAllScreenText
	do
	{
		Clear-Host
		Write-Host $ScreenText
		Write-Host '-----------------------------------------------------------------------------------------------------------------------'
		Write-Host ' Choose a format to generate textures:' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' (1:) PNG'
		Write-Host ' (2:) DDS'
		Write-Host ' (3:) JPG'
		if ($ShowMore) 
		{
			Write-Host ' (4:) Use Texture File Extension'
		}
		Write-Host ' (B:) Back to Main Menu'
		Write-Host ''
		$MenuInput = Read-Host '> '
		if ($MenuInput)
		{
			switch -exact ($MenuInput)
			{
				'1' { $global:ConvertedFormat = $PNG }
				'2' { if (CheckDDSUtilities) { $global:ConvertedFormat = $DDS } else { return $false } }
				'3' { $global:ConvertedFormat = $JPG  }
				'4' { if ($ShowMore) { $global:ConvertedFormat = $null } else { $MenuInput = $null ; InvalidInput 'option' } }
				'b' { return $false }
				default { InvalidInput 'option' }
			}
		}
	} while ((!$MenuInput) -or ($MenuInput -notmatch '^[1-4b]$'))
	return $true
}
#==========================================================================================================================================
#  MAIN MENU - OPTION 4 MENU - ISHIIRUKA FILE TYPE
#==========================================================================================================================================
function IshiirukaFileTypeMenu()
{
	# Make sure the user located Ishiiruka Tool.
	if (IshiirukaToolPathMenu $true)
	{
		$ScreenText = CopyAllScreenText
		do
		{
			Clear-Host
			Write-Host $ScreenText
			Write-Host '-----------------------------------------------------------------------------------------------------------------------'
			Write-Host ''
			Write-Host ' Note:' -ForegroundColor Red -NoNewLine
			Write-Host ' This option is only useful if your pack is already done, and all you need is to add material maps. If you need'
			Write-Host ' to convert an entire texture pack, its probably better to use' -NoNewLine
			Write-Host ' Option 3: Convert Textures to Another Format' -NoNewLine -ForegroundColor Cyan
			Write-Host '. Material'
			Write-Host ' maps will still be created from NRM, SPEC, and BUMP textures during the conversion, and lone NRM files are converted.'
			Write-Host ''
			Write-Host '-----------------------------------------------------------------------------------------------------------------------'
			Write-Host ' Choose the format to create material maps:' -ForegroundColor Yellow
			Write-Host ''
			Write-Host ' (1:) PNG'
			Write-Host ' (2:) DDS'
			Write-Host ' (B:) Back to Main Menu'
			Write-Host ''
			$MenuInput = Read-Host '> '
			if ($MenuInput)
			{
				switch -exact ($MenuInput)
				{
					'1' { $global:ConvertedFormat = $PNG }
					'2' { $global:ConvertedFormat = $DDS }
					'b' { return $false }
					default { InvalidInput 'option' }
				}
			}
		} while ((!$MenuInput) -or ($MenuInput -notmatch '^[1-2b]$'))
		return $true
	}
	# If the path to Ishiiruka Tool failed return to the main menu.
	return $false
}
#==========================================================================================================================================
#  MAIN MENU - OPTION 5 MENUS - WATERMARKS
#==========================================================================================================================================
function WatermarkLengthMenu()
{
	Write-Host ''
	Write-Host ' Enter the number of characters that will define the length of the watermark. (Valid: 6-22)' -ForegroundColor Yellow
	Write-Host ' You may also enter the value "0" without quotes to use the entire name of the texture.'
	Write-Host ''
	$MenuInput = Read-Host '> '

	# Make sure the entered value is 0 or between 6-22 using a regular expression.
	if ($MenuInput -match '^(0|[6-9]|1\d|2[0-2])$')
	{
		$OldWM_Length = $WM_Length
		$global:WM_Length = $MenuInput
		$ReplaceText = '$global:WM_Length          = ' + '"' + $OldWM_Length + '"'
		$ReplaceWith = '$global:WM_Length          = ' + '"' + $WM_Length + '"'
		UpdateScript $ReplaceText $ReplaceWith
	}
	# The input was invalid.
	else
	{
		InvalidInput 'value'
	}
}
#==========================================================================================================================================
function WatermarkUpdateFont([string]$FontFace)
{
	# Child function to update the script with the new font.
	$OldWM_FontFace = $WM_FontFace
	$global:WM_FontFace = $FontFace
	$ReplaceText = '$global:WM_FontFace        = ' + '"' + $OldWM_FontFace + '"'
	$ReplaceWith = '$global:WM_FontFace        = ' + '"' + $WM_FontFace + '"'
	UpdateScript $ReplaceText $ReplaceWith
}
#==========================================================================================================================================
function WatermarkSetFontFaceMenu()
{
	Write-Host ''
	Write-Host ' Select the font to use when creating the watermark.' -ForegroundColor Yellow
	Write-Host ''
	Write-Host ' (1:) Arial'
	Write-Host ' (2:) Comic Sans MS'
	Write-Host ' (3:) Courier New'
	Write-Host ' (4:) Georgia'
	Write-Host ' (5:) Lucida Console'
	Write-Host ' (6:) Sylfaen'
	Write-Host ' (7:) Times New Roman'
	Write-Host ' (8:) Trebuchet MS'
	Write-Host ' (9:) Verdana'
	Write-Host ''
	$MenuInput = Read-Host '> '
	switch -exact ($MenuInput)
	{
		'1' { WatermarkUpdateFont 'Arial-Bold' }
		'2' { WatermarkUpdateFont 'Comic-Sans-MS-Bold' }
		'3' { WatermarkUpdateFont 'Courier-New-Bold' }
		'4' { WatermarkUpdateFont 'Georgia-Bold' }
		'5' { WatermarkUpdateFont 'Lucida-Console' }
		'6' { WatermarkUpdateFont 'Sylfaen' }
		'7' { WatermarkUpdateFont 'Times-New-Roman-Bold' }
		'8' { WatermarkUpdateFont 'Trebuchet-MS-Bold' }
		'9' { WatermarkUpdateFont 'Verdana-Bold' }
		default { InvalidInput 'option' }
	}
}
#==========================================================================================================================================
function WatermarkSetFontSizeMenu()
{
	Write-Host ''
	Write-Host ' Enter the desired size of the font. Font size scales to the texture. (Valid: 1-20)' -ForegroundColor Yellow
	Write-Host ''
	$MenuInput = Read-Host '> '
	# Make sure the entered value is between 1-20 using a regular expression.
	if ($MenuInput -match '^([1-9]|1\d|20)$')
	{
		$OldWM_FontSize = $WM_FontSize
		$global:WM_FontSize = $MenuInput
		$ReplaceText = '$global:WM_FontSize        = ' + '"' + $OldWM_FontSize + '"'
		$ReplaceWith = '$global:WM_FontSize        = ' + '"' + $WM_FontSize + '"'
		UpdateScript $ReplaceText $ReplaceWith
	}
	# The input was invalid.
	else
	{
		InvalidInput 'value'
	}
}
#==========================================================================================================================================
function WatermarkSetColorMenu([string]$VarName, [string]$ColorType)
{
	Write-Host ''
	Write-Host (' Enter a six digit hex value for the ' + $ColorType + ' color of the font.') -ForegroundColor Yellow
	Write-Host ' Refer to an HTML/hex color chart for a large list of colors.'
	Write-Host ''
	$MenuInput = Read-Host '> '

	# Force any letters to uppercase.
	$MenuInput = $MenuInput.ToUpper()

	# Make sure the entered value is a valid hexadecimal value using a regular expression.
	if ($MenuInput -match '^([\dA-F]{6})$')
	{
		$OldColor = $(Get-Variable -Name $VarName -ValueOnly)
		$NewColor = '#' + $MenuInput
		Set-Variable -Name $VarName -Value $NewColor -Scope 'Global'
		$ReplaceText = '$global:' + $(ExtendString $VarName 19) + '= "' + $OldColor + '"'
		$ReplaceWith = '$global:' + $(ExtendString $VarName 19) + '= "' + $NewColor + '"'
		UpdateScript $ReplaceText $ReplaceWith
	}
	# The input was invalid.
	else
	{
		InvalidInput 'value'
	}
}
#==========================================================================================================================================
function WatermarkMenu()
{
	$ScreenText = CopyAllScreenText
	do
	{
		Clear-Host
		Write-Host $ScreenText
		Write-Host '-----------------------------------------------------------------------------------------------------------------------'
		Write-Host ' Configure the output of texture watermarks. Changes made here are permanently stored.' -ForegroundColor Yellow
		Write-Host ' To learn more about an option, enter a' -NoNewLine
		Write-Host ' ?' -ForegroundColor Green -NoNewLine
		Write-Host ' after the input value (Example:' -NoNewLine
		Write-Host ' 1?' -ForegroundColor Green -NoNewLine
		Write-Host ')'
		Write-Host ''
		Write-Host ' (B:) Back to Main Menu'
		Write-Host (' (1:) Text Length   = ' + $WM_Length)
		Write-Host (' (2:) Font Face     = ' + $WM_FontFace)
		Write-Host (' (3:) Font Size     = ' + $WM_FontSize)
		Write-Host (' (4:) Font Color    = ' + $WM_FontColor.Substring(1,6))
		Write-Host (' (5:) Font BG Color = ' + $WM_BGColor.Substring(1,6))
		Write-Host (' (6:) Word Wrap     = ' + $WM_WordWrap)
		Write-Host ' (7:) Begin Watermark Generation'
		Write-Host ''
		$MenuInput = Read-Host '> '
		if ($MenuInput)
		{
			switch -wildcard ($MenuInput)
			{
				'1' { WatermarkLengthMenu }
				'2'	{ WatermarkSetFontFaceMenu }
				'3' { WatermarkSetFontSizeMenu }
				'4' { WatermarkSetColorMenu 'WM_FontColor' 'text' }
				'5' { WatermarkSetColorMenu 'WM_BGColor' 'background' }
				'6' { UpdateOptionState 'WM_WordWrap' }
				'7' { return $true }
				'b' { return $false }
				'*`?' { WatermarkMenuHelp $MenuInput }
				default { InvalidInput 'option' }
			}
		}
	} while ((!$MenuInput) -or ($MenuInput -notmatch '^[7b]$'))
}
#==========================================================================================================================================
#  MAIN MENU - OPTION 7 MENUS - UPSCALE
#==========================================================================================================================================
function UpscaleMenu()
{
	$ScreenText = CopyAllScreenText
	do
	{
		Clear-Host
		Write-Host $ScreenText
		Write-Host '-----------------------------------------------------------------------------------------------------------------------'
		Write-Host ' Enter an integer scale from (2-16) to upscale all textures.' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' This value will be used to determine the new dimensions of all textures by multiplying the dimensions of the original'
		Write-Host ' textures by the entered amount. This option only works on the original textures with the original dimensions (meaning'
		Write-Host ' it does not work on HD retextures). It should be noted that this option is NOT a replacement for actual retexturing,'
		Write-Host ' as the results are not that great. This script and this option should only be used in special case scenarios.'
		Write-Host ''
		Write-Host ' It is also possible to enter the letter "B" to return back to the Main Menu.'
		Write-Host ''
		$MenuInput = Read-Host '> '
		# Regular expression to match 1-16.
		if ($MenuInput -match '^([2-9]|1[0-6])$')
		{
			$global:UpscaleAmount = $MenuInput
		}
		elseif ($MenuInput -eq 'b')
		{
			return $false
		}
		else
		{
			InvalidInput 'value'
		}
	} while ((!$MenuInput) -or ($MenuInput -notmatch '^([2-9]|1[0-6]|b)$'))
	return $true
}
#==========================================================================================================================================
function UpscaleFilterMenu()
{
	$ScreenText = CopyAllScreenText
	do
	{
		Clear-Host
		Write-Host $ScreenText
		Write-Host '-----------------------------------------------------------------------------------------------------------------------'
		Write-Host ''
		Write-Host ' Select the filter that will be applied to all textures.' -ForegroundColor Yellow
		Write-Host ''
		Write-Host ' (0:) Back to Main Menu'
		Write-Host ' (1:) Point'
		Write-Host ' (2:) Cubic'
		Write-Host ' (3:) Lanczos'
		Write-Host ' (4:) Hermite'	
		Write-Host ' (5:) Catrom'
		Write-Host ' (6:) Mitchell'
		Write-Host ' (7:) Box'
		Write-Host ' (8:) Triangle'
		Write-Host ' (9:) Quadratic'
		Write-Host ' (A:) Blackman'
		Write-Host ' (B:) Hanning'
		Write-Host ' (C:) Hamming'
		Write-Host ' (D:) Kaiser'
		Write-Host ' (E:) Bartlett'	
		Write-Host ' (F:) Parzen'
		Write-Host ' (G:) Welsh'
		Write-Host ' (H:) Bohman'
		Write-Host ''
		$MenuInput = Read-Host '> '
		switch -exact ($MenuInput)
		{
			'0' { return $false }
			'1' { $global:UpscaleFilter = 'point' }
			'2' { $global:UpscaleFilter = 'cubic' }
			'3' { $global:UpscaleFilter = 'lanczos' }		
			'4' { $global:UpscaleFilter = 'hermite' }
			'5' { $global:UpscaleFilter = 'catrom' }
			'6' { $global:UpscaleFilter = 'mitchell' }
			'7' { $global:UpscaleFilter = 'box' }
			'8' { $global:UpscaleFilter = 'triangle' }
			'9' { $global:UpscaleFilter = 'quadratic' }
			'a' { $global:UpscaleFilter = 'blackman' }
			'b' { $global:UpscaleFilter = 'hanning' }
			'c' { $global:UpscaleFilter = 'hamming' }		
			'd' { $global:UpscaleFilter = 'kaiser' }
			'e' { $global:UpscaleFilter = 'bartlett' }
			'f' { $global:UpscaleFilter = 'parzen' }
			'g' { $global:UpscaleFilter = 'welsh' }
			'h' { $global:UpscaleFilter = 'bohman' }
			default { InvalidInput 'option' }
		}
	} while ((!$MenuInput) -or ($MenuInput -notmatch '^[\da-hA-H]$'))
	return $true
}
#==========================================================================================================================================
#  MAIN MENU - ADVANCED FUNCTIONS
#==========================================================================================================================================
function Advanced_01_GenerateMipMaps()
{
	$global:GenerateMipMaps = $true
}
#==========================================================================================================================================
function Advanced_02_CreateMaterialMaps()
{
	# The options that are ran are set through the Scan Textures Menu.
	if (IshiirukaFileTypeMenu)
	{
		$global:MaterialInPlace = $true
	}
}
#==========================================================================================================================================
function Advanced_03_RemoveBadMipMaps()
{
	$global:RemoveBadMipMap = $true
}
#==========================================================================================================================================
function Advanced_04_OptiPNGTextures()
{
	# The options that are ran are set through the Scan Textures Menu.
	if (OptiPNGPathMenu $true)
	{
		$global:OptimizeInPlace = $true
	}
}
#==========================================================================================================================================
function Advanced_05_FixBrokeOptiPNG()
{
	$global:FixBrokeOptiPNG = $true
}
#==========================================================================================================================================
function AdvancedFunctionsMenu()
{
	do
	{
		Clear-Host
		Write-Host '-----------------------------------------------------------------------------------------------------------------------'
		Write-Host ' Advanced Functions Menu' -ForegroundColor Yellow
		Write-Host '-----------------------------------------------------------------------------------------------------------------------'
		Write-Host ''
		Write-Host ' Warning:' -ForegroundColor Red -NoNewLine
		Write-Host ' These options modify your texture pack directly so use with caution!'
		Write-Host ' It is highly suggested to make a backup of the texture pack before using these options.'
		Write-Host ''
		Write-Host ' To learn more about an option, enter a' -NoNewLine
		Write-Host ' ?' -ForegroundColor Green -NoNewLine
		Write-Host ' after the input value (Example: ' -NoNewLine
		Write-Host '1?' -ForegroundColor Green -NoNewLine
		Write-Host ')'
		Write-Host ''
		Write-Host '-----------------------------------------------------------------------------------------------------------------------'
		Write-Host ''
		Write-Host ' (1:) Generate New MipMaps (In-Place)'
		Write-Host ' (2:) Create Material Maps With Ishiiruka Tool (In-Place)'
		Write-Host ' (3:) Remove Invalid MipMaps From the Pack'
		Write-Host ' (4:) Optimize Textures With OptiPNG (In-Place, PNG Only)'
		Write-Host ' (5:) Fix Textures Potentially Broken By OptiPNG'
		Write-Host ' (B:) Return to Main Menu'
		Write-Host ''
		$MenuInput = Read-Host '> '
		if ($MenuInput)
		{
			switch -wildcard ($MenuInput)
			{
				'1' { Advanced_01_GenerateMipMaps }
				'2'	{ Advanced_02_CreateMaterialMaps }
				'3' { Advanced_03_RemoveBadMipMaps }
				'4' { Advanced_04_OptiPNGTextures }
				'5' { Advanced_05_FixBrokeOptiPNG }
				'b' { return $false }
				'*`?' { AdvancedFunctionsHelp $MenuInput }
				default { InvalidInput 'option' }
			}
		}
	} while ((!$MenuInput) -or ($MenuInput -notmatch '^[1-5b]$'))
	return $true
}
#==========================================================================================================================================
#  MAIN MENU - SUB FUNCTIONS TO DISPLAY ADDITIONAL MENUS, SET OPTIONS, AND EXECUTE THE MASTER LOOP
#  MENUS RETURN THE VALUE OF WHETHER OR NOT TO START THE MASTER LOOP DEPENDING ON WHAT OPTIONS WERE SELECTED
#==========================================================================================================================================
function MainOption_01_ScanTextures()
{
	# The options that are ran are set through the Scan Textures Menu.
	if (ScanTexturesMenu)
	{
		MasterLoop
	}
}
#==========================================================================================================================================
function MainOption_02_RescaleTextures()
{
	# If ManualRescale is false, show the standard Rescale Menu.
	if (!$ManualRescale -and (RescaleMenu))
	{
		$RescaleSet = $true
	}
	# If ManualRescale is true, show the Manual Rescale Menu instead.
	elseif ($ManualRescale -and (ManualRescaleMenu))
	{
		$RescaleSet = $true
	}
	# If a rescale value was successfully set, show the conversion menu.
	if ($RescaleSet -and (FileTypeMenu $true))
	{
		$global:ForceIntScaling = $true
		MasterLoop
	}
}
#==========================================================================================================================================
function MainOption_03_ConvertTextures()
{
	if (FileTypeMenu $false)
	{
		$global:ConvertTextures = $true
		MasterLoop
	}
}
#==========================================================================================================================================
function MainOption_04_CreateMaterialMaps()
{
	if (IshiirukaFileTypeMenu)
	{
		$global:CreateMaterials = $true
		MasterLoop
	}
}
#==========================================================================================================================================
function MainOption_05_AddWatermarks()
{
	if (WatermarkMenu)
	{
		$global:CreateWatermark = $true
		MasterLoop
	}
}
#==========================================================================================================================================
function MainOption_06_OptiPNGTextures()
{
	if (OptiPNGPathMenu $true)
	{
		$global:OptiPNGTextures = $true
		MasterLoop
	}
}
#==========================================================================================================================================
function MainOption_07_UpscalingFilter()
{
	if ((UpscaleMenu) -and (UpscaleFilterMenu))
	{
		$global:UpscaleTextures = $true
		MasterLoop
	}	
}
#==========================================================================================================================================
function MainOption_08_AdvancedFunctions()
{
	# The options that are ran are set through the Advanced Functions Menu.
	if (AdvancedFunctionsMenu)
	{
		MasterLoop
	}
}
#==========================================================================================================================================
function ResetGlobalVars()
{
	$global:LogIssues = ''
	$global:TotalReductionB = 0
	$global:ScanAllTextures = $false
	$global:CopyBadTextures = $false
	$global:AutoFixTextures = $false
	$global:ForceIntScaling = $false
	$global:ConvertTextures = $false
	$global:CreateMaterials = $false
	$global:CreateWatermark = $false
	$global:OptiPNGTextures = $false
	$global:UpscaleTextures = $false
	$global:GenerateMipMaps = $false
	$global:MaterialInPlace = $false
	$global:RemoveBadMipMap = $false
	$global:OptimizeInPlace = $false
	$global:FixBrokeOptiPNG = $false
	$global:ConvertedFormat = $null
}
#==========================================================================================================================================
#  MAIN MENU - THE ACTUAL MENU
#==========================================================================================================================================
function InitMainMenu()
{
	do
	{
		Clear-Host
		Write-Host '-----------------------------------------------------------------------------------------------------------------------'
		Write-Host (' ' + $ScriptName + ' - Main Menu') -ForegroundColor Yellow
		Write-Host '-----------------------------------------------------------------------------------------------------------------------'
		Write-Host ''
		Write-Host ' Enter a value from the menu list and press' -NoNewLine
		Write-Host ' Enter' -ForegroundColor Green -NoNewLine
		Write-Host ' to execute that option.'
		Write-Host ' To learn more about an option, enter a' -NoNewLine
		Write-Host ' ?' -ForegroundColor Green -NoNewLine
		Write-Host ' after the input value (Example:' -NoNewLine
		Write-Host ' 1?' -ForegroundColor Green -NoNewLine
		Write-Host ')'
		Write-Host ''
		Write-Host '-----------------------------------------------------------------------------------------------------------------------'
		Write-Host ''
		Write-Host ' (0:) Internal Options'
		Write-Host ' (1:) Scan Textures For Issues'
		Write-Host ' (2:) Rescale Textures at Fixed Integer (1-16)'
		Write-Host ' (3:) Convert Textures to Another Format'
		Write-Host ' (4:) Create Material Maps With Ishiiruka Tool'
		Write-Host ' (5:) Add Identifying Watermark to All Textures'
		Write-Host ' (6:) Optimize Textures With OptiPNG (PNG Only)'
		Write-Host ' (7:) Apply Upscaling Filter to Base Textures'
		Write-Host ' (8:) Open Advanced Functions Menu'
		Write-Host ' (X:) Exit'
		Write-Host ''
		$MenuInput = Read-Host '> '
		if ($MenuInput)
		{
			switch -wildcard ($MenuInput)
			{
				'0' { InternalOptionsMenu }
				'1' { MainOption_01_ScanTextures }
				'2' { MainOption_02_RescaleTextures }
				'3' { MainOption_03_ConvertTextures }
				'4' { MainOption_04_CreateMaterialMaps }
				'5' { MainOption_05_AddWatermarks }
				'6' { MainOption_06_OptiPNGTextures }
				'7' { MainOption_07_UpscalingFilter }
				'8' { MainOption_08_AdvancedFunctions }
				'x' { break }
				'*`?' { MainMenuHelp $MenuInput }
				default	{ InvalidInput 'option' }
			}
		}
		ResetGlobalVars
	} while ((!$MenuInput) -or ($MenuInput -ne 'x'))
}
#==========================================================================================================================================
#  TEMPORARY FOLDER TEST
#==========================================================================================================================================
function TestTempFolder()
{
	# Set up the paths to attempt to create a test document.
	$TestWritePath = $TempFolder + '\test.txt'
	CreatePath $TempFolder | Out-Null

	# Attempt to create a text document.
	Add-Content -path $TestWritePath -value "test"

	# Test the path to see if it exists.
	if (!(TestPath $TestWritePath))
	{
		# Output an error message to alert the user the Temp Folder is not a valid location.
		Write-Host '-----------------------------------------------------------------------------------------------------------------------'
		Write-Host (' ' + $ScriptName) -ForegroundColor Yellow
		Write-Host '-----------------------------------------------------------------------------------------------------------------------'
		Write-Host ''
		Write-Host ' NOTICE:'  -ForegroundColor Red -NoNewLine
		write-host ' FAILED TO WRITE TO TEMP FOLDER'
		write-host ''
		write-host ' Temp Folder will be automatically relocated to "C:\CTT-PS_Temp"'
		write-host ' The path may be changed within the scripts "Internal Options".'
		write-host ''
		write-host ' Press any key to start the script.'

		# Store the old path so the script can be updated.
		$OldTempFolder = $TempFolder

		# Update the global variable with the new path.
		$global:TempFolder = "C:\CTT-PS_Temp"

		# Permanently save the changes to the script.
		$ReplaceText = '$global:TempFolder         = ' + '"' + $OldTempFolder + '"'
		$ReplaceWith = '$global:TempFolder         = ' + '"' + $TempFolder + '"'
		UpdateScript $ReplaceText $ReplaceWith

		# An ugly work-around to replace the default value for the first time. This is only done once and becomes redundant after it has been changed.
		$ReplaceOnce = '$global:TempFolder         = ' + '"$env:temp\CTT-PS_Temp"'
		UpdateScript $ReplaceOnce $ReplaceWith

		# Pause the script and wait for user input.
		[void][System.Console]::ReadKey($true)
	}
	# The file was successfully created.
	else
	{
		# Destroy the Temp Folder.
		RemovePath $TempFolder
	}
}
#==========================================================================================================================================
#  SCRIPT INITIALIZATION
#==========================================================================================================================================
# Get the folder the script is in.
$global:BaseFolder = Split-Path -Parent $MyInvocation.MyCommand.Definition

# Get the name of the script and the path to the script.
$global:ScriptName = $MyInvocation.MyCommand.Name.Replace('.ps1','')
$global:ScriptPath = $MyInvocation.MyCommand.Path

# Store the current version of PowerShell as a single number (ex: "5.0.10240.16384" simply becomes "5")
$global:PSSplit   = $PSVersionTable.PSVersion.ToString().Split(".",2)
$global:PSVersion = [int]$PSSplit[0]

# Function that tests if the temporary folder can be written to. Defaults the folder to "C:\CTT-PS_Temp" if it can't.
TestTempFolder

# Set the paths to all DDS Utilities.
if ($NvidiaTools)
{
	$global:NVDXT   = $NvidiaTools + '\nvdxt.exe'
	$global:NSTITCH = $NvidiaTools + '\stitch.exe'
	$global:NDETACH = $NvidiaTools + '\detach.exe'
}
# Set all global variables to their default state. This most likely isn't necessary, but it can't hurt either.
ResetGlobalVars

# Force the PowerShell console window size (fixes PowerShell v2 and allows more lines for all PS versions).
$host.UI.RawUI.BufferSize = New-Object System.Management.Automation.Host.Size(120,20000)
$host.UI.RawUI.WindowSize = New-Object System.Management.Automation.Host.Size(120,50)

# Find the ImageMagick executables. 
if (FindImageMagick)
{
	# Change the title of the window to the name of the script + the PowerShell version + the ImageMagick version.
	$host.UI.RawUI.WindowTitle = ($ScriptName + ' - PowerShell v' + $PSVersion + ' - ImageMagick v' + $IMVersion)

	# If ImageMagick is found, fire up the Main Menu.
	InitMainMenu
}
#==========================================================================================================================================
#  SCRIPT END
#==========================================================================================================================================