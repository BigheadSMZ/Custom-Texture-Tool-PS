#==============================================================================================================================================================================================
$ScriptName = 'Custom Texture Tool PS v27.x t01' 
#  By: Bighead
#==============================================================================================================================================================================================
#  Windows 7/PowerShell v2 Fix
#==============================================================================================================================================================================================
# A long standing issue with this script was that PowerShell v2 would run in "Multi-Thread Apartment" mode, which bugs out .NET Open File dialogs and Open Folder dialogs.
# Before a work-around was used if PowerShell v2 was found that involved setting the dialog property "ShowHelp" to $false, but this only worked with "Open File" dialogs, so
# when dealing with entering folder paths such as the "Temp Folder", PowerShell v2 users would have to manually type the path. Since the script now has a GUI, a proper fix
# had to be found. The fix is simple: if MTA is found, force STA and restart the script. After this new instance of the script is closed, then exit the PowerShell console.
#==============================================================================================================================================================================================
if ([Threading.Thread]::CurrentThread.GetApartmentState() -eq 'MTA')
{
  $ScriptPath = ($MyInvocation.MyCommand.Definition).ToString()
  PowerShell -STA -File $ScriptPath
  Exit
}
#==============================================================================================================================================================================================
#  LOAD MICROSOFT .NET FRAMEWORK ASSEMBLIES
#==============================================================================================================================================================================================
Add-Type -AssemblyName 'System.Windows.Forms'
Add-Type -AssemblyName 'System.Drawing'
#==============================================================================================================================================================================================
#  CONSTANT VARIABLES: IMAGE FILE EXTENSIONS
#==============================================================================================================================================================================================
New-Variable -Name 'PNG' -Value '.png' -Option Constant
New-Variable -Name 'DDS' -Value '.dds' -Option Constant
New-Variable -Name 'JPG' -Value '.jpg' -Option Constant
#==============================================================================================================================================================================================
#  GLOBAL VARIABLES - THEY MUST BEGIN ON LINE 32 AND REMAIN IN THIS ORDER OR THE SCRIPT WILL FAIL TO UPDATE THEM WHEN IT IS CLOSED! (Reference: See function "StoreAllOptions")
#==============================================================================================================================================================================================
$global:EnableStoring      = $true
$global:StoreInputFolder   = $false
$global:StoreOutputFolder  = $false
$global:SavedInputFolder   = ""
$global:SavedOutputFolder  = ""
$global:CurrentOptions     = "Standard"
$global:StoredStandard     = "0"
$global:StoredAdvanced     = "0"
$global:AllowAllImages     = $false
$global:DDSCreatorTool     = "ImageMagick"
$global:DDSBlkCompress     = "DXT1/DXT5"
$global:DDSFlagRemoval     = "New & Base"
$global:FallbackCompress   = "DXT1/DXT5"
$global:ForceNewMipMaps    = $false
$global:MipMapTopLevelBase = $false
$global:ExternalDDSMipMaps = $false
$global:MaxMipMapEnabled   = $false
$global:MaxMipMapLevels    = "2"
$global:DisableTopMost     = $true
$global:AlwaysShowConsole  = $true
$global:AutoCenterConsole  = $true
$global:DisablePSXButton   = $true
$global:ConsoleColors      = $true
$global:CreateLogFile      = $true
$global:ForceCreateMipMaps = $false
$global:RepairTextures     = $false
$global:CopyBadTextures    = $false
$global:HideOKTextures     = $false
$global:IgnoreDuplicates   = $false
$global:AllowNotHD         = $true
$global:ScaleThreshold     = "0.65"
$global:AspectThreshold    = "0.05"
$global:ConvertFormat      = $PNG
$global:ConvertRepair      = $false
$global:CopyNonTextures    = $true
$global:RescaleFormat      = $PNG
$global:RescaleFactor      = "4.00"
$global:RescaleScaling     = "Always"
$global:ManualRescale      = $false
$global:IshiirukaFormat    = $PNG
$global:InPlaceMaterial    = $false
$global:WM_Length          = "0"
$global:WM_FontFace        = "Courier-New-Bold"
$global:WM_FontSize        = "8"
$global:WM_FontColor       = "#FF0000"
$global:WM_BGColor         = "#00FF00"
$global:OptiPNGTests       = "3"
$global:InPlaceOptiPNG     = $false
$global:FilterSelected     = "Point"
$global:FilterNewScale     = "4"
$global:SeamlessMethod     = "Opaque"
$global:UpscaleFormat      = $PNG
$global:Waifu2xCMode       = "Noise_Scale"
$global:Waifu2xNoise       = "2"
$global:Waifu2xOpenCL      = $false
$global:Waifu2xModel       = "anime_style_art_rgb"
$global:Waifu2xNoGPU       = $false
$global:TextureRows        = "2"
$global:TextureColumns     = "2"
$global:CTextureRows       = "2"
$global:CTextureColumns    = "2"
$global:CombinedName       = "CombinedTexture"
$global:ImageMagick        = (Get-ItemProperty -LiteralPath "HKLM:\Software\ImageMagick\Current\" -Name BinPath -ErrorAction SilentlyContinue).BinPath
$global:DDSUtilities       = "C:\Program Files (x86)\NVIDIA Corporation\DDS Utilities\nvdxt.exe"
$global:Compressonator     = "C:\Program Files\Compressonator\CompressonatorCLI.exe"
$global:IshiirukaTool      = "C:\Program Files (x86)\Ishiiruka-TextureEncoder.0.9.7\TextureEncoder.exe"
$global:OptiPNGPath        = "C:\Program Files (x86)\optipng-0.7.6-win32\optipng.exe"
$global:ScalerTestPath     = "C:\Program Files (x86)\ScalerTest\ScalerTest.exe"
$global:Waifu2xPath        = "C:\Program Files (x86)\waifu2x-caffe\waifu2x-caffe-cui.exe"
$global:TexConvTool        = "C:\Program Files (x86)\DirectXTex\texconv.exe"
$global:TempFolder         = "$env:temp\CTT-PS_Temp"
$global:HidePathURLs       = $false
$global:BackgroundColor    = "Default"
$global:SelectionPath      = ($pwd).path
#==============================================================================================================================================================================================
#  DOCUMENTATION: ALL GLOBAL VARIABLES
#==============================================================================================================================================================================================
#  * Note that all variables in this section that are listed as "integer" or "decimal" are actually stored as strings!
#  * The same goes for "extension". These are also strings, but specifically refers to the constant variables that define image file extensions.
#
#  $global:EnableStoring         - boolean   - Enables writing updated variables to the script file if the user changed any values.
#  $global:StoreInputFolder      - boolean   - Flags whether or not to store the most recently selected Texture Path on exit.
#  $global:StoreOutputFolder     - boolean   - Flags whether or not to store the most recently selected Output Path on exit. 
#  $global:SavedInputFolder      - string    - If "StoreInputFolder" was flagged, stores the most recent path and overrides "$MasterInputPath" on startup.
#  $global:SavedOutputFolder     - string    - If "SavedOutputFolder" was flagged, stores the most recent path and overrides "$MasterOutputPath" on startup.
#  $global:CurrentOptions        - string    - Stores the most recently used options, either "Standard" or "Advanced", and displays them on startup.
#  $global:StoredStandard        - integer   - Stores the most recently used Standard option and selects it on startup.
#  $global:StoredAdvanced        - integer   - Stores the most recently used Advanced option and selects it on startup.
#  $global:AllowAllImages        - boolean   - Forces the script to validate all images instead of only Dolphin "tex1" images.
#  $global:DDSCreatorTool        - boolean   - Allows selecting the tool to create DDS textures.
#  $global:DDSBlkCompress        - string    - Allows selecting the type of block compression when creating DDS textures.
#  $global:DDSFlagRemoval        - boolean   - When textures are created with "User Defined" compression, this option can remove flags from texture folders.
#  $global:FallbackCompress      - string    - If "User Defined" is selected as the compression type, this stores the fallback compression to use if a texture .
#  $global:ForceNewMipMaps       - boolean   - Flags whether or not to generate new mipmaps from the top layer rather than use included mipmaps as a base.
#  $global:MipMapTopLevelBase    - boolean   - Forces the script to use the top mipmap level to generate missing mipmaps rather than use the lowest level in the mipmap chain.
#  $global:ExternalDDSMipMaps    - boolean   - Forces generating external mipmaps for DDS textures. Internal is the default.
#  $global:MaxMipMapEnabled      - boolean   - Enables or disables forcing the number of mipmaps that are generated.
#  $global:MaxMipMapLevels       - integer   - The number of mipmaps that were forced.
#  $global:DisableTopMost        - boolean   - Disables CTT-PS from showing over all other open windows.
#  $global:AlwaysShowConsole     - boolean   - Toggles the visibility of the PowerShell console.
#  $global:AutoCenterConsole     - boolean   - Hidden option, not on GUI. Toggles the method to auto-center the console on startup.
#  $global:DisablePSXButton      - boolean   - Toggles the ability to click the PowerShell "X" button.
#  $global:ConsoleColors         - boolean   - Show additional colors in the console window when processing textures.
#  $global:CreateLogFile         - boolean   - Enables the log file. Has the potential to begin the Armageddon.
#  $global:RepairTextures        - boolean   - Flags whether or not to repair textures using "Scan Dolphin Textures For Issues".
#  $global:CopyBadTextures       - boolean   - Flags whether or not to copy bad textures if they were not repaired using "Scan Dolphin Textures For Issues".
#  $global:HideOKTextures        - boolean   - Flags whether or not to hide textures without issues from the log when using "Scan Dolphin Textures For Issues".
#  $global:IgnoreDuplicates      - boolean   - Flags whether or not to ignore duplicate file names when using "Scan Dolphin Textures For Issues".
#  $global:AllowNotHD            - boolean   - Flags whether or not to allow textures with the original resolution to pass error checking using "Scan Dolphin Textures For Issues".
#  $global:ScaleThreshold        - decimal   - Value which controls when to upscale a texture to the next highest integer scale when repairing using the decimal value.
#  $global:AspectThreshold       - decimal   - Value which controls the amount of aspect difference between the original and custom texture before repairing.
#  $global:ConvertFormat         - extension - The output format of the rescaled texture. PNG, DDS, or JPG when using "Convert Textures to Another Format." Can also hold $null to use existing extension.
#  $global:ConvertRepair         - boolean   - Enables a method to auto-repair textures when converting to get the most accurate dimensions.
#  $global:CopyNonTextures       - boolean   - Flags whether or not to create copies of non-texture files in the newly generated pack.
#  $global:RescaleFormat         - extension - The output format of the rescaled texture. PNG, DDS, or JPG.
#  $global:RescaleFactor         - integer   - The value to upscale the texture when using "Rescale Textures With New Scaling Factor".
#  $global:RescaleScaling        - string    - Defines which textures will be rescaled, allowing only upscaling, downscaling, or both.
#  $global:ManualRescale         - boolean   - Toggles "Manual Rescale Mode" which allows scaling each texture individually with insane values.
#  $global:IshiirukaFormat       - extension - The output format when creating material maps with "Create Material Maps WIth Ishiiruka Tool". PNG or DDS.
#  $global:InPlaceMaterial       - boolean   - Create material maps in-place instead of the output folder.
#  $global:WM_Length             - integer   - The number of characters to use in a watermark. Entering 0 means "use the whole name". Minimum of 6 is forced.
#  $global:WM_FontFace           - string    - The font used for the watermark. Naming scheme must match what ImageMagick expects.
#  $global:WM_FontSize           - integer   - The relative size of the font expanded across the texture.
#  $global:WM_FontColor          - string    - The color of the font using HTML notation. 
#  $global:WM_BGColor            - string    - The color displayed behind the font using HTML notation. 
#  $global:OptiPNGTests          - integer   - The number of tests OptiPNG performs in attempts to reduce texture size.
#  $global:InPlaceOptiPNG        - boolean   - Create optimized textures in-place instead of the output folder.
#  $global:FilterSelected        - string    - The selected upscaling filter that is used in "Apply Upscaling Filter to All Textures".
#  $global:FilterNewScale        - integer   - The value to upscale the texture using the selected filter.
#  $global:SeamlessMethod        - string    - Controls which textures get the seamless method: opaque, all, or none.
#  $global:UpscaleFormat         - extension - The output format when applying upscaling filters.
#  $global:Waifu2xCMode          - string    - The conversion mode when using waifu2x. Can be noise, scale, or noise_scale.
#  $global:Waifu2xNoise          - integer   - The amount of noise reduction to apply if "noise" is selected in the conversion mode.
#  $global:Waifu2xOpenCL         - boolean   - Enables OpenCL with waifu2x-CPP. Can not be used with "Waifu2xNoGPU".
#  $global:Waifu2xModel          - string    - Stores the selected waifu2x model that is used for upscaling.
#  $global:Waifu2xNoGPU          - boolean   - Disables the GPU using any version of waifu2x. Can not be used with "Waifu2xOpenCL".
#  $global:TextureRows           - integer   - Stores the default number of rows when using "Combine Multiple Textures".
#  $global:TextureColumns        - integer   - Stores the default number of columns when using "Combine Multiple Textures".
#  $global:CTextureRows          - integer   - Stores the default number of rows when using "Split Combined Multi-Texture".
#  $global:CTextureColumns       - integer   - Stores the default number of columns when using "Split Combined Multi-Texture".
#  $global:CombinedName          - string    - The output name of the combined texture when using "Combine Multiple Textures".
#  $global:ImageMagick           - string    - The path to ImageMagick. Script by default pulls this value from the registry, but can be set to any path.
#  $global:DDSUtilities          - string    - The path to nvdxt.exe.
#  $global:Compressonator        - string    - The path to CompressonatorCLI.exe.
#  $global:IshiirukaTool         - string    - The path to Ishiiruka Tool.
#  $global:OptiPNGPath           - string    - The path to OptiPNG.
#  $global:ScalerTestPath        - string    - The path to xBRZ ScalerTest.
#  $global:Waifu2xPath           - string    - The path to waifu2x, caffe or CPP.
#  $global:TexConvTool           - string    - The path to texconv.exe.
#  $global:TempFolder            - string    - The path to create temporary folders.
#  $global:SelectionPath         - string    - Stores the path to where textures are selected from when using Combine Multiple Textures.
#==============================================================================================================================================================================================
#  * An attempt to gather all globals scattered throughout the script into a single location with explanations of their functionality.
#
#  $global:Texture               - hashtable - The most important variable, this stores all information about the texture.
#  $global:ScriptName            - string    - Stores the name of the script.
#  $global:ScriptPath            - string    - Stores the full path to the script + the script.
#  $global:TitleBarMessage       - string    - Stores the current operation to display on the scripts title bar.
#  $global:PSVersion             - integer   - Stores the running version of PowerShell.
#  $global:MasterInputPath       - string    - The path where the script looks for textures.
#  $global:MasterOutputPath      - string    - The path where the script outputs generated textures.
#  $global:PreviousPath          - string    - Used only when updating the log file to check if the path has changed.
#  $global:BaseFolder            - string    - The path to the base location of the script.
#  $global:LogFile               - string    - The full path to the log file.
#  $global:ImageMagickVersion    - integer   - Stores the version of ImageMagick found, either '6' or '7'. If not found, stores '0'.
#  $global:MasterOperation       - string    - Stores the "Standard" or "Advanced" option that was selected from the main menu.
#  $global:AutoTextRescale       - string    - Renames "RescaledTextures" to the value specified by the user from the GUI.
#  $global:AutoTextConvert       - string    - Renames "ConvertedTextures" to the value specified by the user from the GUI.
#  $global:TotalReductionB       - integer   - Stores the total amount of hard drive space recovered from OptiPNG.
#  $global:FilterSelected        - string    - Stores the filter that was selected when upscaling textures.
#  $global:IshiirukaFormat       - string    - Stores the file extension the user chose when creating material maps.
#  $global:Duplicates            - hashtable - All textures names are added during a "Scan Textures" loop. Each loop the hash table is checked to see if it already exists.  
#  $global:CountProcessed        - integer   - Stores the total number of textures processed by the main loop.
#  $global:CountIssues           - integer   - Stores the number of textures that had issues.
#  $global:CountCopied           - integer   - Stores the number of textures that were copied.
#  $global:CountRepaired         - integer   - Stores the number of textures that were repaired.
#  $global:CountOptimized        - integer   - Stores the number of textures optimized with OptiPNG.
#  $global:CountMipMapped        - integer   - Stores the number of textures that had mipmaps created for them using "Generate New MipMaps".
#  $global:CountInvalidMips      - integer   - Stores the number of textures that had invalid mipmaps removed.
#  $global:CountSlicedAlpha      - integer   - Stores the number of textures that had their alpha channel removed.
#  $global:ConsoleType           - integer   - The type of message to display in ConsoleUpdateLoopEnd. 0: Error, 1: One Part Message, 2: Two Part Message
#  $global:ConsoleMsgA           - string    - The first part of the console message. Displayed in red if ConsoleType is an error.
#  $global:ConsoleMsgB           - string    - The second part of the console message, displayed in green.
#  $global:LogMessage            - string    - Appended to the end of the line in the log file.
#  $global:TextureArray          - string    - A 2 dimensional array that stores the texture in the row/column when using combine textures.
#  $global:CTextureArray         - string    - A 2 dimensional array that stores the texture in the row/column when using split textures.
#  $global:CombinedTexture       - string    - The path to the texture to when using Split Combined Multi-Texture.
#  $global:CTTDataFile           - string    - The path to a CTT file when using Split Combined Multi-Texture.
#  $global:YesNoChoice           - boolean   - If the user hits escape to cancel the main loop, a confirm dialog pops up. This is the answer the user chose.
#  $global:UpdateTempFolder      - boolean   - If the TempFolder path was changed, this variable allows the new value to be written to the script when closed.
#  $global:UpdateImageMagick     - boolean   - If the ImageMagick path was changed, this variable allows the new value to be written to the script when closed.
#==============================================================================================================================================================================================
#  GLOBAL VARIABLES: RESET GLOBAL VARIABLES
#==============================================================================================================================================================================================
#  When the main loop is finished, these variables are reset to their default values. This is also executed once on init.

function ResetGlobalVars()
{
  $global:MasterOperation     = ''      # The current operation that is taking place in the main loop.
  $global:LogMessage          = ''      # What to display in the log after a loop iteration is complete.
  $global:PreviousPath        = ''      # Stores the path of the previous loop iteration so it can be accessed in the current iteration. Used for logging.
  $global:Duplicates          = @{}     # Hash table which stores file names that may be duplicate textures during a Scan Textures loop.
  $global:CountIssues         = 0       # The total number of textures that had issues after a Scan Textures loop is complete.
  $global:CountProcessed      = 0       # The total number of textures processed when the main loop finishes.
  $global:CountCopied         = 0       # The total number of bad textures copied when a Scan Textures loop is complete.
  $global:CountRepaired       = 0       # The total number of bad textures repaired when a Scan Textures loop is complete.
  $global:CountMipMapped      = 0       # The total number of textures that had mipmaps generated with Generate New MipMaps.
  $global:CountInvalidMips    = 0       # The total number of textures that had invalid mipmaps with Remove Invalid MipMaps.
  $global:CountSlicedAlpha    = 0       # The total number of textures that had their alpha channel removed with Remove Alpha Channel From Opaque Textures.
  $global:CountOptimized      = 0       # The total number of textures that were optimized with OptiPNG.
  $global:TotalReductionB     = 0       # The total amount of hard drive space recovered using OptiPNG in Bytes.
  $global:TitleBarMessage     = ''      # Message that is displayed on the title bar.
}
#============================================================================================================================================================================================== 
#  GLOBAL VARIABLES/UPDATE SCRIPT: OVERWRITE ALL OPTIONS WHEN SCRIPT IS CLOSED
#==============================================================================================================================================================================================
#  A sub-function of "StoreAllOptions" to overwrite the value in the script with the one stored in RAM.

function OverwriteOption([int]$Index, [string]$VarType, [string]$VarName, [bool]$Condition = $true)
{
  # Prevent ugly "if" statements in "StoreAllOptions" by directly supporting a condition because some paths should not always be updated.
  if ($Condition)
  {
    # Get the content of the script by searching for the index of the line.
    $CurrentLine = $Content | Select-Object -Index $Index

    # Get the value of the variable by name.
    $VarValue = Get-Variable -Name $VarName -ValueOnly

    # Update the value, which is a different process based on the type.
    switch ($VarType)
    {
      # Set up the text that will replace the old value.
      'text' { $NewText = '$global:' + (ExtendString -InputString $VarName -Length 19) + '= "' + $VarValue + '"' }
      'bool' { $NewText = '$global:' + (ExtendString -InputString $VarName -Length 19) + '= $' + $VarValue.ToString().ToLower() }
      'fext' { $NewText = '$global:' + (ExtendString -InputString $VarName -Length 19) + '= $' + (ExtensionToText -FileExt $VarValue) }
    }
    # Update the script with the new value.
    $global:Content[$Index] = $Content[$Index].Replace($CurrentLine, $NewText)
  }
}
#==============================================================================================================================================================================================
#  Stores the selected input/output folders if they actually exist. These must be updated even if "EnableStoring" is disabled. 

function UpdateStoredFolderVars()
{
  # Update the texture path if the user wishes to store them.
  if (($StoreInputFolder) -and (TestPath -LiteralPath $MasterInputPath))
  {
    $global:SavedInputFolder = $MasterInputPath
  }
  # If not, or the path is invalid, then reset the folder.
  else
  {
    $global:SavedInputFolder = ""
  }
  # Update the output path if the user wishes to store them. Remove the "~CTT_Generated" part of it, the script adds that on init and we don't want it there twice.
  if (($StoreOutputFolder) -and (TestPath -LiteralPath $MasterOutputPath.Replace('\~CTT_Generated','')))
  {
    $global:SavedOutputFolder = $MasterOutputPath.Replace('\~CTT_Generated','')
  }
  # If not, or the path is invalid, then reset the folder.
  else
  {
    $global:SavedOutputFolder = ""
  }
}
#============================================================================================================================================================================================== 
#  Replace the old values with the current values. The indexes fed to "OverwriteOption" must match the current line that the option is on minus 1.
#  You may ask yourself, why the hell am I doing it this way? Couldn't I just loop through all lines and not worry about which line an option falls on?
#  The answer is yes, and that's how I used to do it. But it is slow! Very fucking slow. Like 5x slower than this way. The GUI will hang until all options 
#  are finished updating, so we need it to be as fast as possible because people are impatient! I know I am, and I want speed over easier code.

function StoreAllOptions()
{
  # Grab all text from the script file and store each line in an array.
  $global:Content = Get-Content -LiteralPath $ScriptPath

  # Update the variables that control the stored paths.
  UpdateStoredFolderVars

  # The variables that control storing always need to be updated.
  # text = string value ; bool = boolean ; fext = file extension
  OverwriteOption -Index 31 -VarType 'bool' -VarName 'EnableStoring'
  OverwriteOption -Index 32 -VarType 'bool' -VarName 'StoreInputFolder'
  OverwriteOption -Index 33 -VarType 'bool' -VarName 'StoreOutputFolder'
  OverwriteOption -Index 34 -VarType 'text' -VarName 'SavedInputFolder'
  OverwriteOption -Index 35 -VarType 'text' -VarName 'SavedOutputFolder'

  # Only write the rest of the options if the user did not disable storing them.
  if ($EnableStoring)
  {
    OverwriteOption -Index 36 -VarType 'text' -VarName 'CurrentOptions'
    OverwriteOption -Index 37 -VarType 'text' -VarName 'StoredStandard'
    OverwriteOption -Index 38 -VarType 'text' -VarName 'StoredAdvanced'
    OverwriteOption -Index 39 -VarType 'bool' -VarName 'AllowAllImages'
    OverwriteOption -Index 40 -VarType 'text' -VarName 'DDSCreatorTool'
    OverwriteOption -Index 41 -VarType 'text' -VarName 'DDSBlkCompress'
    OverwriteOption -Index 42 -VarType 'text' -VarName 'DDSFlagRemoval'
    OverwriteOption -Index 43 -VarType 'text' -VarName 'FallbackCompress'
    OverwriteOption -Index 44 -VarType 'bool' -VarName 'ForceNewMipMaps'
    OverwriteOption -Index 45 -VarType 'bool' -VarName 'MipMapTopLevelBase'
    OverwriteOption -Index 46 -VarType 'bool' -VarName 'ExternalDDSMipMaps'
    OverwriteOption -Index 47 -VarType 'bool' -VarName 'MaxMipMapEnabled'
    OverwriteOption -Index 48 -VarType 'text' -VarName 'MaxMipMapLevels'
    OverwriteOption -Index 49 -VarType 'bool' -VarName 'DisableTopMost'
    OverwriteOption -Index 50 -VarType 'bool' -VarName 'AlwaysShowConsole'
    OverwriteOption -Index 51 -VarType 'bool' -VarName 'AutoCenterConsole'
    OverwriteOption -Index 52 -VarType 'bool' -VarName 'DisablePSXButton'
    OverwriteOption -Index 53 -VarType 'bool' -VarName 'ConsoleColors'
    OverwriteOption -Index 54 -VarType 'bool' -VarName 'CreateLogFile'
    OverwriteOption -Index 55 -VarType 'bool' -VarName 'ForceCreateMipMaps'
    OverwriteOption -Index 56 -VarType 'bool' -VarName 'RepairTextures'
    OverwriteOption -Index 57 -VarType 'bool' -VarName 'CopyBadTextures'
    OverwriteOption -Index 58 -VarType 'bool' -VarName 'HideOKTextures'
    OverwriteOption -Index 59 -VarType 'bool' -VarName 'IgnoreDuplicates'
    OverwriteOption -Index 60 -VarType 'bool' -VarName 'AllowNotHD'
    OverwriteOption -Index 61 -VarType 'text' -VarName 'ScaleThreshold'
    OverwriteOption -Index 62 -VarType 'text' -VarName 'AspectThreshold'
    OverwriteOption -Index 63 -VarType 'fext' -VarName 'ConvertFormat'
    OverwriteOption -Index 64 -VarType 'bool' -VarName 'ConvertRepair'
    OverwriteOption -Index 65 -VarType 'bool' -VarName 'CopyNonTextures'
    OverwriteOption -Index 66 -VarType 'fext' -VarName 'RescaleFormat'
    OverwriteOption -Index 67 -VarType 'text' -VarName 'RescaleFactor'
    OverwriteOption -Index 68 -VarType 'text' -VarName 'RescaleScaling'
    OverwriteOption -Index 69 -VarType 'bool' -VarName 'ManualRescale'
    OverwriteOption -Index 70 -VarType 'fext' -VarName 'IshiirukaFormat'
    OverwriteOption -Index 71 -VarType 'bool' -VarName 'InPlaceMaterial'
    OverwriteOption -Index 72 -VarType 'text' -VarName 'WM_Length'
    OverwriteOption -Index 73 -VarType 'text' -VarName 'WM_FontFace'
    OverwriteOption -Index 74 -VarType 'text' -VarName 'WM_FontSize'
    OverwriteOption -Index 75 -VarType 'text' -VarName 'WM_FontColor'
    OverwriteOption -Index 76 -VarType 'text' -VarName 'WM_BGColor'
    OverwriteOption -Index 77 -VarType 'text' -VarName 'OptiPNGTests'
    OverwriteOption -Index 78 -VarType 'bool' -VarName 'InPlaceOptiPNG'
    OverwriteOption -Index 79 -VarType 'text' -VarName 'FilterSelected'
    OverwriteOption -Index 80 -VarType 'text' -VarName 'FilterNewScale'
    OverwriteOption -Index 81 -VarType 'text' -VarName 'SeamlessMethod'
    OverwriteOption -Index 82 -VarType 'fext' -VarName 'UpscaleFormat'
    OverwriteOption -Index 83 -VarType 'text' -VarName 'Waifu2xCMode'
    OverwriteOption -Index 84 -VarType 'text' -VarName 'Waifu2xNoise'
    OverwriteOption -Index 85 -VarType 'bool' -VarName 'Waifu2xOpenCL'
    OverwriteOption -Index 86 -VarType 'text' -VarName 'Waifu2xModel'
    OverwriteOption -Index 87 -VarType 'bool' -VarName 'Waifu2xNoGPU'
    OverwriteOption -Index 88 -VarType 'text' -VarName 'TextureRows'
    OverwriteOption -Index 89 -VarType 'text' -VarName 'TextureColumns'
    OverwriteOption -Index 90 -VarType 'text' -VarName 'CTextureRows'
    OverwriteOption -Index 91 -VarType 'text' -VarName 'CTextureColumns'
    OverwriteOption -Index 92 -VarType 'text' -VarName 'CombinedName'
    OverwriteOption -Index 93 -VarType 'text' -VarName 'ImageMagick' -Condition $UpdateImageMagick
    OverwriteOption -Index 94 -VarType 'text' -VarName 'DDSUtilities'
    OverwriteOption -Index 95 -VarType 'text' -VarName 'Compressonator'
    OverwriteOption -Index 96 -VarType 'text' -VarName 'IshiirukaTool'
    OverwriteOption -Index 97 -VarType 'text' -VarName 'OptiPNGPath'
    OverwriteOption -Index 98 -VarType 'text' -VarName 'ScalerTestPath'
    OverwriteOption -Index 99 -VarType 'text' -VarName 'Waifu2xPath'
    OverwriteOption -Index 100 -VarType 'text' -VarName 'TexConvTool'
    OverwriteOption -Index 101 -VarType 'text' -VarName 'TempFolder' -Condition $UpdateTempFolder
    OverwriteOption -Index 102 -VarType 'bool' -VarName 'HidePathURLs'
    OverwriteOption -Index 103 -VarType 'text' -VarName 'BackgroundColor'
  }
  # Write the changes to the script file.
  Set-Content -LiteralPath $ScriptPath -Value $Content
}
#==============================================================================================================================================================================================
#  GLOBAL VARIABLES/UPDATE SCRIPT: UPDATE ALL GUI VALUES
#==============================================================================================================================================================================================
#  Update all GUI check boxes, combo boxes, text boxes, etc. on the GUI with the current values stored in memory. This is done any time
#  all options are updated at once: either importing options from another CTT-PS or restoring the default values to all options.

function RefreshGUI()
{
  # ----------------------------------------------------------------------------------------------------------------------------------------------------------
  # Texture/Output Path
  $StoreInputCheck.Checked        = $StoreInputFolder
  $StoreOutputCheck.Checked       = $StoreOutputFolder
  # ----------------------------------------------------------------------------------------------------------------------------------------------------------
  # Options: Tool Paths
  $CompressonatorTextBox.Text     = $Compressonator
  $IshiiPathTextBoxA.Text         = $IshiirukaTool
  $IshiiPathTextBoxB.Text         = $IshiirukaTool
  $OptiPathTextBoxA.Text          = $OptiPNGPath
  $OptiPathTextBoxB.Text          = $OptiPNGPath
  $xBRZPathTextBox.Text           = $ScalerTestPath
  $Waifu2xPathTextBox.Text        = $Waifu2xPath
  $TexConvToolTextBox.Text        = $TexConvTool
  $TempPathTextBox.Text           = $TempFolder
  $HideURLCheck.Checked           = $HidePathURLs
  # ----------------------------------------------------------------------------------------------------------------------------------------------------------
  # Options: Global Options
  $AllowAllImagesCheck.Checked    = $AllowAllImages
  $DisableLogCheck.Checked        = $CreateLogFile
  $DDSBCCombo.SelectedItem        = $DDSBlkCompress
  $DDSFlagsCombo.SelectedItem     = $DDSFlagRemoval
  $DDSFBCCombo.SelectedItem       = $FallbackCompress
  $DDSCreatorCombo.SelectedItem   = $DDSCreatorTool
  # ----------------------------------------------------------------------------------------------------------------------------------------------------------
  # Options: MipMap Options
  $ForceNewMipsCheck.Checked      = $ForceNewMipMaps
  $FinalMipMapCheck.Checked       = $MipMapTopLevelBase
  $DDSMipMapCheck.Checked         = $ExternalDDSMipMaps
  $MaxMipMapCheck.Checked         = $MaxMipMapEnabled
  $MaxMipMapNumBox.Value          = $MaxMipMapLevels
  # ----------------------------------------------------------------------------------------------------------------------------------------------------------
  # Options: CTT-PS Options
  $EnableStoredCheck.Checked      = $EnableStoring
  $TopMostCheck.Checked           = $DisableTopMost
  $HideConsoleCheck.Checked       = $AlwaysShowConsole
  $AutoCenterCheck.Checked        = $AutoCenterConsole
  $DisableXButtonCheck.Checked    = $DisablePSXButton
  $ConsoleColorsCheck.Checked     = $ConsoleColors
  # ----------------------------------------------------------------------------------------------------------------------------------------------------------
  # Standard: Scan Textures Options
  $S_RepairCheck.Checked          = $RepairTextures
  $S_CopyBadCheck.Checked         = $CopyBadTextures
  $S_HideOKCheck.Checked          = $HideOKTextures
  $S_IgnoreDupesCheck.Checked     = $IgnoreDuplicates
  $S_AllowNotHDCheck.Checked      = $AllowNotHD
  $S_ScaleFixNumBox.Value         = $ScaleThreshold
  $S_AspectFixNumBox.Value        = $AspectThreshold
  # ----------------------------------------------------------------------------------------------------------------------------------------------------------
  # Standard: Convert Textures Options
  $C_FormatCombo.SelectedItem     = ExtensionToText -FileExt $ConvertFormat
  $C_CopyNonCheck.Checked         = $CopyNonTextures
  $C_AutoRepairCheck.Checked      = $ConvertRepair
  $C_ScaleFixNumBox.Value         = $ScaleThreshold
  # ----------------------------------------------------------------------------------------------------------------------------------------------------------
  # Standard: Rescale Textures Options
  $R_FactorNumBox.Value           = $RescaleFactor
  $R_FormatCombo.SelectedItem     = ExtensionToText -FileExt $RescaleFormat
  $R_CopyNonCheck.Checked         = $CopyNonTextures
  $R_ScalingCombo.SelectedItem    = $RescaleScaling
  $R_ManualCheck.Checked          = $ManualRescale
  # ----------------------------------------------------------------------------------------------------------------------------------------------------------
  # Standard: Add Identifying Watermark
  $W_TextLengthNumBox.Value       = $WM_Length
  $W_FontSizeNumBox.Value         = $WM_FontSize
  $W_FGColorButton.Text           = $WM_FontColor
  $W_FGColorButton.BackColor      = $WM_FontColor
  $W_BGColorButton.Text           = $WM_BGColor
  $W_BGColorButton.BackColor      = $WM_BGColor
  $W_FontFaceCombo.SelectedItem   = $WM_FontFace
  # ----------------------------------------------------------------------------------------------------------------------------------------------------------
  # Standard: Create Material Maps
  $M_FormatCombo.SelectedItem     = ExtensionToText -FileExt $IshiirukaFormat
  $M_InPlaceCheck.Checked         = $InPlaceMaterial
  # ----------------------------------------------------------------------------------------------------------------------------------------------------------
  # Standard: Optimize with OptiPNG
  $O_TestsNumBox.Value            = $OptiPNGTests
  $O_InPlaceCheck.Checked         = $InPlaceOptiPNG
  # ----------------------------------------------------------------------------------------------------------------------------------------------------------
  # Standard: Apply Upscaling Filter
  $U_FilterCombo.SelectedItem     = $FilterSelected
  $U_FactorNumBox.Value           = $FilterNewScale
  $U_SeamlessCombo.SelectedItem   = $SeamlessMethod
  $U_FormatCombo.SelectedItem     = ExtensionToText -FileExt $UpscaleFormat
  $U_WF2XModeCombo.SelectedItem   = $Waifu2xCMode
  $U_WF2XNoiseBox.Value           = $Waifu2xNoise
  $U_WF2XModelCombo.SelectedItem  = GUI_FlipWaifu2xModelName -ModelName $Waifu2xModel
  $U_WF2XGPUCheck.Checked         = $Waifu2xNoGPU
  $U_WF2XOpenCLCheck.Checked      = $Waifu2xOpenCL
  # ----------------------------------------------------------------------------------------------------------------------------------------------------------
  # Advanced: Remove Invalid MipMaps
  $X_HideOKCheck.Checked          = $HideOKTextures
  # ----------------------------------------------------------------------------------------------------------------------------------------------------------
  # Advanced: Remove Alpha Channel
  $Y_HideOKCheck.Checked          = $HideOKTextures
  # ----------------------------------------------------------------------------------------------------------------------------------------------------------
  # Advanced: Combine Multiple Textures
  $CombineRowsNumBox.Value        = $TextureRows
  $CombineColumnsNumBox.Value     = $TextureColumns
  $CombineNameTextBox.Text        = $CombinedName + $PNG
  # ----------------------------------------------------------------------------------------------------------------------------------------------------------
  # Advanced: Split Multi-Texture
  $SplitRowsNumBox.Value          = $CTextureRows
  $SplitColumnsNumBox.Value       = $CTextureColumns
}
#==============================================================================================================================================================================================
#  GLOBAL VARIABLES/UPDATE SCRIPT: IMPORT OPTIONS SETTINGS
#==============================================================================================================================================================================================
#  Sub-function of "ImportStoredOptions" that handles each individual option.

function ImportOption([int]$Index, [string]$VarType, [string]$VarName)
{
  # Get the content of the script by searching for the index of the line.
  $CurrentLine = $Content | Select-Object -Index $Index

  # Check to see if the current line contains the variable name.
  if ($CurrentLine -like ('$global:' + (ExtendString -InputString $VarName -Length 19) + '= *'))
  {
    # Depending on the type of value being imported, there are 4 very different methods of getting the value.
    # There's a lot of confusing string concatenation/replacement going on down there. Good luck deciphering it.
    switch ($VarType)
    {
      # Remove everything on the current line up to the variable name, then trim away the final quotation mark.
      'text'  { $TextStart = '$global:' + (ExtendString -InputString $varname -Length 19) + '= '
                $TextValue = $CurrentLine.Replace($TextStart,'')
                $FullValue = $TextValue.Trim('"')
              }
      # Remove everything on the current line up to the variable name, then convert the boolean text into an actual boolean.
      'bool'  { $TextStart = '$global:' + (ExtendString -InputString $varname -Length 19) + '= $'
                $TextValue = $CurrentLine.Replace($TextStart,'')
                $FullValue = [System.Convert]::ToBoolean($TextValue)
              }
      # Crop start text, grab the 3 letter word version of the file extension, and store it in a variable using the ".ext" format by pulling the value using the name.
      'fext'  { $TextStart = '$global:' + (ExtendString -InputString $varname -Length 19) + '= $'
                $TextValue = $CurrentLine.Replace($TextStart,'')
                $FullValue = Get-Variable -Name $TextValue -ValueOnly
              }
      # Hell I don't even remember what I'm doing here or how I did it. Let's just hope future changes don't break it.
      'temp'  { $TextStart = '$global:' + (ExtendString -InputString $varname -Length 19) + '= '
                $TextValue = $CurrentLine.Replace($TextStart,'')
                $FullValue = $ExecutionContext.InvokeCommand.ExpandString($TextValue).Trim('"')
              }
    }
    # Update the variable with the new value.
    Set-Variable -Name $VarName -Value $FullValue -Scope 'Global'
  }
}
#==============================================================================================================================================================================================
#  Imports all stored options from another version of CTT-PS and writes them to the script. As long as variable names don't change, it retains compatibility with all versions.

function ImportStoredOptions()
{
  # Get the path to the desktop for the hell of it.
  $DesktopPath = [Environment]::GetFolderPath("Desktop")

  # Display an "Open File" menu to get the path.
  $TextureToolPath = Get-FileName -Path $DesktopPath -Description 'PowerShell Script' -FileName '*.ps1'

  # Test if a file was actually selected.
  if (TestPath -LiteralPath $TextureToolPath)
  {
    # To properly get the extension of the selected file, retrieve it with Get-ChildItem.
    $TextureTool = Get-ChildItem -LiteralPath $TextureToolPath

    # Check if the file is a PowerShell script.
    if ($TextureTool.Extension -eq '.ps1')
    {
      # Temporarily disable the GUI.
      $MainDialog.Enabled = $false

      # Grab all text from the script file.
      $global:Content = Get-Content -LiteralPath $TextureToolPath

      # The FirstLine is the... first line that the first importable variable falls on, minus one.
      # The FinalLine is last line containing an importable variable, minus one.
      $FirstLine = 31
      $FinalLine = 103

      # Loop through all relevant lines from first to finish.
      for($i = $FirstLine; $i -le $FinalLine; $i++)
      {
        # Replace the current values with the imported script values. 
        # Index is the current state of the loop. It is used to reference the current line.
        # text = string value ; bool = boolean ; fext = file extension ; temp = temp folder
        ImportOption -Index $i -VarType 'bool' -VarName 'EnableStoring'
        ImportOption -Index $i -VarType 'bool' -VarName 'StoreInputFolder'
        ImportOption -Index $i -VarType 'bool' -VarName 'StoreOutputFolder'
        ImportOption -Index $i -VarType 'text' -VarName 'SavedInputFolder'
        ImportOption -Index $i -VarType 'text' -VarName 'SavedOutputFolder'
        ImportOption -Index $i -VarType 'text' -VarName 'CurrentOptions'
        ImportOption -Index $i -VarType 'text' -VarName 'StoredStandard'
        ImportOption -Index $i -VarType 'text' -VarName 'StoredAdvanced'
        ImportOption -Index $i -VarType 'bool' -VarName 'AllowAllImages'
        ImportOption -Index $i -VarType 'text' -VarName 'DDSCreatorTool'
        ImportOption -Index $i -VarType 'text' -VarName 'DDSBlkCompress'
        ImportOption -Index $i -VarType 'text' -VarName 'DDSFlagRemoval'
        ImportOption -Index $i -VarType 'text' -VarName 'FallbackCompress'
        ImportOption -Index $i -VarType 'bool' -VarName 'ForceNewMipMaps'
        ImportOption -Index $i -VarType 'bool' -VarName 'MipMapTopLevelBase'
        ImportOption -Index $i -VarType 'bool' -VarName 'ExternalDDSMipMaps'
        ImportOption -Index $i -VarType 'bool' -VarName 'MaxMipMapEnabled'
        ImportOption -Index $i -VarType 'text' -VarName 'MaxMipMapLevels'
        ImportOption -Index $i -VarType 'bool' -VarName 'DisableTopMost'
        ImportOption -Index $i -VarType 'bool' -VarName 'AlwaysShowConsole'
        ImportOption -Index $i -VarType 'bool' -VarName 'AutoCenterConsole'
        ImportOption -Index $i -VarType 'bool' -VarName 'DisablePSXButton'
        ImportOption -Index $i -VarType 'bool' -VarName 'ConsoleColors'
        ImportOption -Index $i -VarType 'bool' -VarName 'CreateLogFile'
        ImportOption -Index $i -VarType 'bool' -VarName 'ForceCreateMipMaps'
        ImportOption -Index $i -VarType 'bool' -VarName 'RepairTextures'
        ImportOption -Index $i -VarType 'bool' -VarName 'CopyBadTextures'
        ImportOption -Index $i -VarType 'bool' -VarName 'HideOKTextures'
        ImportOption -Index $i -VarType 'bool' -VarName 'IgnoreDuplicates'
        ImportOption -Index $i -VarType 'bool' -VarName 'AllowNotHD'
        ImportOption -Index $i -VarType 'text' -VarName 'ScaleThreshold'
        ImportOption -Index $i -VarType 'text' -VarName 'AspectThreshold'
        ImportOption -Index $i -VarType 'fext' -VarName 'ConvertFormat'
        ImportOption -Index $i -VarType 'bool' -VarName 'ConvertRepair'
        ImportOption -Index $i -VarType 'bool' -VarName 'CopyNonTextures'
        ImportOption -Index $i -VarType 'fext' -VarName 'RescaleFormat'
        ImportOption -Index $i -VarType 'text' -VarName 'RescaleFactor'
        ImportOption -Index $i -VarType 'text' -VarName 'RescaleScaling'
        ImportOption -Index $i -VarType 'bool' -VarName 'ManualRescale'
        ImportOption -Index $i -VarType 'fext' -VarName 'IshiirukaFormat'
        ImportOption -Index $i -VarType 'bool' -VarName 'InPlaceMaterial'
        ImportOption -Index $i -VarType 'text' -VarName 'WM_Length'
        ImportOption -Index $i -VarType 'text' -VarName 'WM_FontFace'
        ImportOption -Index $i -VarType 'text' -VarName 'WM_FontSize'
        ImportOption -Index $i -VarType 'text' -VarName 'WM_FontColor'
        ImportOption -Index $i -VarType 'text' -VarName 'WM_BGColor'
        ImportOption -Index $i -VarType 'text' -VarName 'OptiPNGTests'
        ImportOption -Index $i -VarType 'bool' -VarName 'InPlaceOptiPNG'
        ImportOption -Index $i -VarType 'text' -VarName 'FilterSelected'
        ImportOption -Index $i -VarType 'text' -VarName 'FilterNewScale'
        ImportOption -Index $i -VarType 'text' -VarName 'SeamlessMethod'
        ImportOption -Index $i -VarType 'fext' -VarName 'UpscaleFormat'
        ImportOption -Index $i -VarType 'text' -VarName 'Waifu2xCMode'
        ImportOption -Index $i -VarType 'text' -VarName 'Waifu2xNoise'
        ImportOption -Index $i -VarType 'bool' -VarName 'Waifu2xOpenCL'
        ImportOption -Index $i -VarType 'text' -VarName 'Waifu2xModel'
        ImportOption -Index $i -VarType 'bool' -VarName 'Waifu2xNoGPU'
        ImportOption -Index $i -VarType 'text' -VarName 'TextureRows'
        ImportOption -Index $i -VarType 'text' -VarName 'TextureColumns'
        ImportOption -Index $i -VarType 'text' -VarName 'CTextureRows'
        ImportOption -Index $i -VarType 'text' -VarName 'CTextureColumns'
        ImportOption -Index $i -VarType 'text' -VarName 'CombinedName'
        ImportOption -Index $i -VarType 'text' -VarName 'Compressonator'
        ImportOption -Index $i -VarType 'text' -VarName 'DDSUtilities'
        ImportOption -Index $i -VarType 'text' -VarName 'IshiirukaTool'
        ImportOption -Index $i -VarType 'text' -VarName 'OptiPNGPath'
        ImportOption -Index $i -VarType 'text' -VarName 'ScalerTestPath'
        ImportOption -Index $i -VarType 'text' -VarName 'Waifu2xPath'
        ImportOption -Index $i -VarType 'text' -VarName 'TexConvTool'
        ImportOption -Index $i -VarType 'temp' -VarName 'TempFolder'
        ImportOption -Index $i -VarType 'bool' -VarName 'HidePathURLs'
        ImportOption -Index $i -VarType 'text' -VarName 'BackgroundColor'
      }
      # There is a lot text in the script to store in RAM, so clean that shit up.
      $global:Content = $null

      # Update everything on the GUI.
      RefreshGUI

      # Show a confirmation dialog after the operation has finished.
      ShowOKDialog -OffsetX 36 -OffsetY 18 -DisplayText 'All options have been successfully imported!'

      # Enable the dialog.
      $MainDialog.Enabled = $true
    }
  }
}
#==============================================================================================================================================================================================
#  GLOBAL VARIABLES/UPDATE SCRIPT: RESTORE DEFAULTS
#==============================================================================================================================================================================================
function RestoreDefaultOptions()
{
  # Display a Yes/No dialog.
  if (ShowYesNoDialog -OffsetX 12 -OffsetY 16 -DisplayText '   Are you sure you wish to restore all default values?')
  {
    # Set all variables to their default values.
    $global:EnableStoring      = $true
    $global:StoreInputFolder   = $false
    $global:StoreOutputFolder  = $false
    $global:SavedInputFolder   = ""
    $global:SavedOutputFolder  = ""
    $global:AllowAllImages     = $false
    $global:DDSCreatorTool     = "ImageMagick"
    $global:DDSBlkCompress     = "DXT1/DXT5"
    $global:DDSFlagRemoval     = "New & Base"
    $global:FallbackCompress   = "DXT1/DXT5"
    $global:ForceNewMipMaps    = $false
    $global:MipMapTopLevelBase = $false
    $global:ExternalDDSMipMaps = $false
    $global:MaxMipMapEnabled   = $false
    $global:MaxMipMapLevels    = "2"
    $global:DisableTopMost     = $true
    $global:AlwaysShowConsole  = $true
    $global:AutoCenterConsole  = $true
    $global:DisablePSXButton   = $true
    $global:ConsoleColors      = $true
    $global:CreateLogFile      = $true
    $global:ForceCreateMipMaps = $false
    $global:RepairTextures     = $false
    $global:CopyBadTextures    = $false
    $global:HideOKTextures     = $false
    $global:IgnoreDuplicates   = $false
    $global:AllowNotHD         = $true
    $global:ScaleThreshold     = "0.65"
    $global:AspectThreshold    = "0.05"
    $global:ConvertFormat      = $PNG
    $global:ConvertRepair      = $false
    $global:CopyNonTextures    = $true
    $global:RescaleFormat      = $PNG
    $global:RescaleFactor      = "4.00"
    $global:RescaleScaling     = "Always"
    $global:ManualRescale      = $false
    $global:IshiirukaFormat    = $PNG
    $global:InPlaceMaterial    = $false
    $global:WM_Length          = "0"
    $global:WM_FontFace        = "Courier-New-Bold"
    $global:WM_FontSize        = "8"
    $global:WM_FontColor       = "#FF0000"
    $global:WM_BGColor         = "#00FF00"
    $global:OptiPNGTests       = "3"
    $global:InPlaceOptiPNG     = $false
    $global:FilterSelected     = "Point"
    $global:FilterNewScale     = "4"
    $global:SeamlessMethod     = "Opaque"
    $global:UpscaleFormat      = $PNG
    $global:Waifu2xCMode       = "Noise_Scale"
    $global:Waifu2xNoise       = "2"
    $global:Waifu2xOpenCL      = $false
    $global:Waifu2xModel       = "anime_style_art_rgb"
    $global:Waifu2xNoGPU       = $false
    $global:TextureRows        = "2"
    $global:TextureColumns     = "2"
    $global:CTextureRows       = "2"
    $global:CTextureColumns    = "2"
    $global:CombinedName       = "CombinedTexture"
    $global:HidePathURLs       = $false
    $global:BackgroundColor    = "Default"

    # Update everything on the GUI.
    RefreshGUI
  }
}
#==============================================================================================================================================================================================
#  DEBUG
#==============================================================================================================================================================================================
$Debug = $false
#==============================================================================================================================================================================================
#  Debugging is relatively new, and I don't know if I'll care enough to implement more.

function DebugMessage([string]$Message)
{
  if ($Debug)
  {
    Write-Host ''
    Write-Host ('DEBUG: ' + $Message)
  }
}
#==============================================================================================================================================================================================
#  Because PowerShell v2 does not support the "pause" command and I need my pauses to troubleshoot...

function Halt()
{
  Write-Host Paused. Press any key to continue...
  [void][System.Console]::ReadKey($true)
}
#==============================================================================================================================================================================================
#  IMPORTED CODE: SET POWERSHELL CONSOLE POSITION
#==============================================================================================================================================================================================
#  Like all amazing code, I didn't write it but it's awesome. It lets you position the window for a running process, in this case I use it for the PS window.
#  Source: https://gallery.technet.microsoft.com/scriptcenter/Set-the-position-and-size-54853527

function Set-ConsoleWindow {
  [OutputType('System.Automation.WindowInfo')]
  [cmdletbinding()]
  Param (
    [parameter(ValueFromPipelineByPropertyName=$True)]
    $ProcessName,
    [int]$X,
    [int]$Y,
    [int]$Width,
    [int]$Height,
    [switch]$Passthru
  )
  Begin {
    Try {
      [void][Window]
    } Catch {
      Add-Type @"
      using System;
      using System.Runtime.InteropServices;
      public class Window {
        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
        [DllImport("User32.dll")]
        public extern static bool MoveWindow(IntPtr handle, int x, int y, int width, int height, bool redraw);
      }
      public struct RECT
      {
        public int Left;        // x position of upper-left corner
        public int Top;         // y position of upper-left corner
        public int Right;       // x position of lower-right corner
        public int Bottom;      // y position of lower-right corner
      }
"@
    }
  }
  Process {
    $Rectangle = New-Object RECT
    $Handle = (Get-Process -Name $ProcessName).MainWindowHandle
    $Return = [Window]::GetWindowRect($Handle,[ref]$Rectangle)
    if (-NOT $PSBoundParameters.ContainsKey('Width')) {            
      $Width = $Rectangle.Right - $Rectangle.Left            
    }
    if (-NOT $PSBoundParameters.ContainsKey('Height')) {
      $Height = $Rectangle.Bottom - $Rectangle.Top
    }
    if ($Return) {
      $Return = [Window]::MoveWindow($Handle, $x, $y, $Width, $Height,$True)
    }
    if ($PSBoundParameters.ContainsKey('Passthru')) {
      $Rectangle = New-Object RECT
      $Return = [Window]::GetWindowRect($Handle,[ref]$Rectangle)
      if ($Return) {
        $Height = $Rectangle.Bottom - $Rectangle.Top
        $Width = $Rectangle.Right - $Rectangle.Left
        $Size = New-Object System.Management.Automation.Host.Size -ArgumentList $Width, $Height
        $TopLeft = New-Object System.Management.Automation.Host.Coordinates -ArgumentList $Rectangle.Left, $Rectangle.Top
        $BottomRight = New-Object System.Management.Automation.Host.Coordinates -ArgumentList $Rectangle.Right, $Rectangle.Bottom
        if ($Rectangle.Top -lt 0 -AND $Rectangle.LEft -lt 0) {
          Write-Warning "Window is minimized! Coordinates will not be accurate."
        }
        $Object = [pscustomobject]@{
          ProcessName = $ProcessName
          Size = $Size
          TopLeft = $TopLeft
          BottomRight = $BottomRight
        }
        $Object.PSTypeNames.insert(0,'System.Automation.WindowInfo')
        $Object            
      }
    }
  }
}
#==============================================================================================================================================================================================
#  IMPORTED CODE: SET POWERSHELL CONSOLE ICON
#==============================================================================================================================================================================================
# Source: https://gallery.technet.microsoft.com/scriptcenter/9d476461-899f-4c98-9d63-03b99596c2c3
# Source: https://stackoverflow.com/questions/22040398/powershell-change-taskbar-icon-of-running-console-application

function Set-ConsoleIcon($Icon)
{
  $consoleHandle  = Invoke-Win32 "kernel32.dll" ([intPtr]) "GetConsoleWindow"
  $parameterTypes = @([intPtr], [int], [int], [int])
  $parameters     = @($consoleHandle, 128, 0, [int]$Icon.Handle)
  Invoke-Win32 "user32.dll" ([int]) "SendMessage" $parameterTypes $parameters | Out-Null
}
function Invoke-Win32([string]$dllName, [type]$returnType, [string]$methodName, [type[]]$parameterTypes, [object[]]$parameters)
{
  # Begin to build the dynamic assembly.
  $domain = [AppDomain]::CurrentDomain
  $name = New-Object Reflection.AssemblyName 'PInvokeAssembly'
  $assembly = $domain.DefineDynamicAssembly($name, 'Run')
  $module = $assembly.DefineDynamicModule('PInvokeModule')
  $type = $module.DefineType('PInvokeType', "Public,BeforeFieldInit")

  # Go through all of the parameters passed to us. As we do this, we clone the user's inputs into another array that we will use for the P/Invoke call.
  $inputParameters = @()
  $refParameters = @()

  for($counter = 1; $counter -le $parameterTypes.Length; $counter++)
  {
    # If an item is a PSReference, then the user wants an [out] parameter.
    if($parameterTypes[$counter - 1] -eq [Ref])
    {
      # Remember which parameters are used for [Out] parameters.
      $refParameters += $counter

      # On the cloned array, we replace the PSReference type with the .Net reference type that represents the value of the PSReference, and the value with the value held by the PSReference.
      $parameterTypes[$counter - 1] = $parameters[$counter - 1].Value.GetType().MakeByRefType()
      $inputParameters += $parameters[$counter - 1].Value
    }
    else
    {
      # Otherwise, just add their actual parameter to the input array.
      $inputParameters += $parameters[$counter - 1]
    }
  }
  # Define the actual P/Invoke method, adding the [Out] attribute for any parameters that were originally [Ref] parameters.
  $method = $type.DefineMethod($methodName, 'Public,HideBySig,Static,PinvokeImpl', $returnType, $parameterTypes)
  foreach($refParameter in $refParameters)
  {
    $method.DefineParameter($refParameter, "Out", $null)
  }
  # Apply the P/Invoke constructor
  $ctor = [Runtime.InteropServices.DllImportAttribute].GetConstructor([string])
  $attr = New-Object Reflection.Emit.CustomAttributeBuilder $ctor, $dllName
  $method.SetCustomAttribute($attr)

  # Create the temporary type, and invoke the method.
  $realType = $type.CreateType()
  $realType.InvokeMember($methodName, 'Public,Static,InvokeMethod', $null, $null, $inputParameters)

  # Finally, go through all of the reference parameters, and update the values of the PSReference objects that the user passed in.
  foreach($refParameter in $refParameters)
  {
    $parameters[$refParameter - 1].Value = $inputParameters[$refParameter - 1]
  }
}
#==============================================================================================================================================================================================
#  IMPORTED CODE: DISABLE POWERSHELL "X" BUTTON
#==============================================================================================================================================================================================
# Disables the PowerShell "X" button which forces users to close the script with the GUI.
# Source: http://poshcode.org/4059

$DisableX = @"
using System;
using System.Runtime.InteropServices;

namespace CloseButtonToggle {
  internal static class WinAPI {
    [DllImport("kernel32.dll")]
    internal static extern IntPtr GetConsoleWindow();

    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    internal static extern bool DeleteMenu(IntPtr hMenu, uint uPosition, uint uFlags);

    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    internal static extern bool DrawMenuBar(IntPtr hWnd);
     
    [DllImport("user32.dll")]
    internal static extern IntPtr GetSystemMenu(IntPtr hWnd, [MarshalAs(UnmanagedType.Bool)]bool bRevert);

    const uint SC_CLOSE     = 0xf060;
    const uint MF_BYCOMMAND = 0;

    internal static void ChangeCurrentState(bool state) {
      IntPtr hMenu = GetSystemMenu(GetConsoleWindow(), state);
      DeleteMenu(hMenu, SC_CLOSE, MF_BYCOMMAND);
      DrawMenuBar(GetConsoleWindow());
    }
  }
  public static class Status {
    public static void Disable() {
      WinAPI.ChangeCurrentState(false);
    }
    public static void Enable() {
      WinAPI.ChangeCurrentState(true);
    }
  }
}
"@
# Do the thing that needs to be done to allows me to actually make use of this code.
Add-Type -TypeDefinition $DisableX -Language CSharp

# May as well make a function that controls the state of the button.
function PowershellButtonX([bool]$Disabled)
{
  if ($Disabled)
  {
    [CloseButtonToggle.Status]::Disable()
  }
  else
  {
    [CloseButtonToggle.Status]::Enable()
  }
}
#==============================================================================================================================================================================================
#  IMPORTED CODE: SHOW / HIDE POWERSHELL CONSOLE
#==============================================================================================================================================================================================
# Awesome function that can show or hide the PowerShell console window.
# Source: http://powershell.cz/2013/04/04/hide-and-show-console-window-from-gui/

$HidePSConsole = @"
[DllImport("Kernel32.dll")]
public static extern IntPtr GetConsoleWindow();
[DllImport("user32.dll")]
public static extern bool ShowWindow(IntPtr hWnd, Int32 nCmdShow);
"@
Add-Type -Namespace Console -Name Window -MemberDefinition $HidePSConsole

# Function that shows or hides the console window.
function ShowPowerShellConsole([bool]$ShowConsole)
{
  if ($ShowConsole)
  {
    [Console.Window]::ShowWindow([Console.Window]::GetConsoleWindow(), 5) | Out-Null
  }
  else
  {
    [Console.Window]::ShowWindow([Console.Window]::GetConsoleWindow(), 0) | Out-Null
  }
}
#==============================================================================================================================================================================================
#  EXTERNAL TOOLS: IMAGEMAGICK
#==============================================================================================================================================================================================
#  Finds which version of ImageMagick is installed and updates the title bar. Used for Initialization.

function FindImageMagick()
{
  # Test the path chosen by the registry to see if ImageMagick v7 is installed.
  if (TestPath -LiteralPath ($ImageMagick + '\magick.exe'))
  {
    # Store the version of ImageMagick found.
    $global:ImageMagickVersion = 7

    # Change the title of the window to the name of the script + the PowerShell version + the ImageMagick version.
    $host.UI.RawUI.WindowTitle = ($ScriptName + ' - PowerShell v' + $PSVersion + ' - ImageMagick v7')
  }
  # Test the path chosen by the registry to see if ImageMagick v6 is installed.
  elseif (TestPath -LiteralPath ($ImageMagick + '\convert.exe'))
  {
    # Store the version of ImageMagick found.
    $global:ImageMagickVersion = 6

    # Change the title of the window to the name of the script + the PowerShell version + the ImageMagick version.
    $host.UI.RawUI.WindowTitle = ($ScriptName + ' - PowerShell v' + $PSVersion + ' - ImageMagick v6')
  }
  # ImageMagick installation was not found.
  else
  {
    # Store that ImageMagick was not set. This prevents running the Master Loop.
    $global:ImageMagickVersion = 0

    # Change the title bar to say that ImageMagick was not installed.
    $host.UI.RawUI.WindowTitle = ($ScriptName + ' - PowerShell v' + $PSVersion + ' - ImageMagick Not Found!')
  }
}
#==============================================================================================================================================================================================
#  Calls forth ImageMagick to convert an image. All arguments passed to ImageMagick come in a string array.

function Magick-Convert([string]$Image, [string[]]$Arguments, [string]$Output)
{
  # Check for version 7 of ImageMagick.
  if ($ImageMagickVersion -eq 7)
  {
    # Version 7 uses "magick.exe".
    & ($ImageMagick + '\magick.exe') -quiet $Image $Arguments $Output
  }
  # If it's not found use version 6.
  else
  {
    # Version 6 uses "convert.exe".
    & ($ImageMagick + '\convert.exe') -quiet $Image $Arguments $Output
  }
}
#==============================================================================================================================================================================================
#  Calls ImageMagick identify to get characteristics from the image.

function Magick-Identify([string]$Image, [string[]]$Arguments)
{
  # Check for version 7 of ImageMagick.
  if ($ImageMagickVersion -eq 7)
  {
    # Here "magick.exe" and a symbolic link to "identify" can be used.
    return (& ($ImageMagick + '\magick.exe') 'identify' $Arguments $Image)
  }
  # For version 6, call the identify executable and return the value.
  return (& ($ImageMagick + '\identify.exe') $Arguments $Image)
}
#==============================================================================================================================================================================================
#  Calls ImageMagick montage to combine a collection of images.

function Magick-Montage([string[]]$Collection, [string[]]$Arguments, [string]$Output)
{
  # Check for version 7 of ImageMagick.
  if ($ImageMagickVersion -eq 7)
  {
    # Here "magick.exe" and a symbolic link to "montage" can be used.
    & ($ImageMagick + '\magick.exe') 'montage' -quiet $Arguments $Collection $Output | Out-Null
  }
  # If it's not found use version 6.
  else
  {
    # For version 6, call the montage executable and return the value.
    & ($ImageMagick + '\montage.exe') -quiet $Arguments $Collection $Output | Out-Null
  }
}
#==============================================================================================================================================================================================
#  Applies an upscaling filter with ImageMagick. Requires the PNG color type to be manually set (or pulled from the hash table).

function Magick-UpscaleFilter([string]$Image, [string]$Filter, [string]$UpscaleFactor, [string]$ColorType, [string]$Output)
{
  # ImageMagick takes the size in the form of a percentage so calculate that now.
  $NewScale = ([int]$UpscaleFactor * 100).ToString() + '%'

  # Always force the output to to PNG format. I will always feed this function a PNG image, but just to make it fail safe...
  $Output = $Output.Substring(0, $Output.Length - 4) + $PNG

  # Set up the PNG color type of the output image.
  $PNGColorType = 'png:color-type=' + $ColorType

  # Rescale the texture and apply the filter set by the user.
  Magick-Convert -Image $Image -Arguments @('-filter', $Filter, '-resize', $NewScale, '-define', $PNGColorType) -Output $Output | Out-Null
}
#==============================================================================================================================================================================================
#  EXTERNAL TOOLS: NVIDIA DDS UTILITIES
#==============================================================================================================================================================================================
#  Calls nvidia nvdxt.exe to create a DDS texture.

function DDSUtility-NVDXT([string]$Image, [string[]]$Arguments, [string]$Output)
{
  & $DDSUtilities -file $Image $Arguments -output $Output
}
#==============================================================================================================================================================================================
#  EXTERNAL TOOLS: AMD COMPRESSONATOR
#==============================================================================================================================================================================================
#  Calls AMD CompressonatorCLI.exe to create a DDS texture.

function CompressonatorCLI([string]$Image, [string[]]$Arguments, [string]$Output)
{
  & $Compressonator $Arguments $Image $Output
}
#==============================================================================================================================================================================================
#  EXTERNAL TOOLS: MICROSOFT TEXCONV
#==============================================================================================================================================================================================
#  Calls Microsoft texconv.exe to create a DDS texture.

function RunTexConvTool([string]$Image, [string[]]$Arguments, [string]$OutputPath)
{
  & $TexConvTool $Image $Arguments -o $OutputPath
}
#==============================================================================================================================================================================================
#  EXTERNAL TOOLS: ISHIIRUKA TOOL
#==============================================================================================================================================================================================
#  Calls Ishiiruka Tool to create material map textures.

function Ishiiruka-Tool([string]$Image, [string[]]$Arguments, [string]$OutputPath)
{
  & $IshiirukaTool $Image $OutputPath $Arguments | Out-Null
}
#==============================================================================================================================================================================================
#  EXTERNAL TOOLS: OPTIPNG
#==============================================================================================================================================================================================
#  Optimizes a texture with OptiPNG.

function OptiPNG-Optimize([string]$Image, [string]$Tests, [string]$Output)
{
  & $OptiPNGPath ('-o' + $Tests) $Image -dir $Output 2>&1>$null
}
#==============================================================================================================================================================================================
#  EXTERNAL TOOLS: xBRZ SCALER TEST
#==============================================================================================================================================================================================
#  A complicated method to watch for a xBRZ Scaler Test pop-up warning that alerts the user the sRGB profile is incorrect. The pop-up causes the
#  script to halt, which defeats the automation of it.

function NewThread_ScalerTest_FindWindow()
{
  $Job =  { 
    # Use pinvoke to find the current window, set the current window, and grab the current window.
    $PInvoke = @'
    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    public static extern bool SetForegroundWindow(IntPtr hWnd);

    [DllImport("user32.dll")]
    public static extern IntPtr GetForegroundWindow();
'@
    # Assemblies must be added/re-added since this is a new PowerShell instance separate from the script.
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -MemberDefinition $PInvoke -Namespace WindowProperties -Name Methods 

    # Loop with a variable that will never become true.
    while(!$NeverTrue)
    {
      # Grab the handle of ScalerTest.
      $ScalerProcess = (Get-Process | Where-Object {$_.MainWindowTitle -like "*xBRZ*"}).MainWindowHandle

      # Make sure the process has been found.
      if ($ScalerProcess -ne $null)
      {
        # Set the ScalerTest window to the foreground.
        [WindowProperties.Methods]::SetForegroundWindow($ScalerProcess)

        # Grab the handle of the currently active window.
        $CurrentWindow = [WindowProperties.Methods]::GetForegroundWindow()

        # Verify the active window is the ScalerTest window.
        if ($CurrentWindow -eq $ScalerProcess)
        {
          # Hit the Enter key to close the window.
          [System.Windows.Forms.SendKeys]::SendWait('{ENTER}')

          # Immediately end the loop after the deed.
          break
        }
      }
      # Wait for a bit until the next iteration.
      Start-Sleep -m 500
    }
  }
  # Start the job and set it to a global variable so it can be stopped later.
  $global:WatchScalerTest = Start-Job -ScriptBlock $Job
}
#==============================================================================================================================================================================================
#  Calls xBRZ ScalerTest.exe to upscale a texture by the UpscaleFactor.

function xBRZ-ScalerTest([string]$Image, [string]$UpscaleFactor, [string]$Output)
{
  # Set the strength for xBRZ in the way ScalerTest expects to see it.
  $xBRZLevel = ('-' + $UpscaleFactor + 'xBRZ')

  # Watch for a ScalerTest window popping up in a separate thread.
  NewThread_ScalerTest_FindWindow

  # Upscale the texture using xBRZ.
  & $ScalerTestPath $xBRZLevel $Image $Output | Out-Null

  # Remove the current job that is watching for a ScalerTest window.
  Stop-Job -Job $WatchScalerTest
  Remove-Job -Job $WatchScalerTest
}
#==============================================================================================================================================================================================
#  EXTERNAL TOOLS: WAIFU2X
#==============================================================================================================================================================================================
#  Calls xBRZ ScalerTest.exe to upscale a texture by the UpscaleFactor.

function Waifu2x-Upscale([string]$Image, [string]$UpscaleFactor, [string]$Output)
{
  # Get the Waifu2x directory because CPP needs to run from here.
  $WaifuDir = [string](Get-ChildItem -LiteralPath $Waifu2xPath).Directory

  # Waifu2x-CPP only wants to run from its install location, and Waif2x-Caffe needs to be here to grab the model, so push to the containing folder.
  Push-Location -LiteralPath $WaifuDir

  # Apply waifu2x to the image. All of these variables that serve as arguments are set with the GUI (see function "GUI_Start_UpscaleFilterTextures").
  & $Waifu2xPath -i $Image -m $Waifu2xCMode.ToLower() --scale_ratio $UpscaleFactor --noise_level $Waifu2xNoise $wf2xModelA $wf2xModelB $wf2xOpenCL $wf2xNoGpuA $wf2xNoGpuB -o $Output

  # Return to the previous directory.
  Pop-Location
}
#==============================================================================================================================================================================================
#  MISCELLANEOUS: GUI FUNCTIONS TO GET A FILE OR FOLDER PATH
#==============================================================================================================================================================================================
#  Creates an "Open File" dialog that searches for a file name (or an array of file names) and returns the selected file.

function Get-FileName([string]$Path, [string[]]$Description, [string[]]$FileName)
{
  $OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
  $OpenFileDialog.InitialDirectory = $Path

  # If more than 1 application is provided, loop through all of them and add them to the string.
  for($i = 0; $i -lt $FileName.Count; $i++)
  {
    $FilterString += $Description[$i] + '|' + $FileName[$i] + '|'
  }
  # Trim the last "|" from the string or we'll get an error message.
  $OpenFileDialog.Filter = $FilterString.TrimEnd('|')
  $OpenFileDialog.ShowDialog() | Out-Null
  return $OpenFileDialog.FileName
}
#==============================================================================================================================================================================================
#  Creates a "Folder Browser" dialog that returns a selected path.

function Get-Folder([string]$Message)
{
  $FolderBrowserDialog = New-Object System.Windows.Forms.FolderBrowserDialog
  $FolderBrowserDialog.ShowNewFolderButton = $false
  $FolderBrowserDialog.Description = $Message
  $FolderBrowserDialog.ShowDialog() | Out-Null
  return $FolderBrowserDialog.SelectedPath
}
#==============================================================================================================================================================================================
#  MISCELLANEOUS: PATH/FILE MANIPULATION FUNCTIONS
#==============================================================================================================================================================================================
#  Creates a folder if it does not already exist. Returns the parameter so it can be set to a variable when called.

function CreatePath([string]$LiteralPath)
{
  # Make sure the path isn't null to avoid errors.
  if ($LiteralPath -ne '')
  {
    # Check to see if the path does not exist.
    if (!(Test-Path -LiteralPath $LiteralPath))
    {
      # Create the path.
      New-Item -Path $LiteralPath -ItemType Directory | Out-Null
    }
  }
  # Return the path so it can be set to a variable when creating.
  return $LiteralPath
}
#==============================================================================================================================================================================================
#  Removes a file or folder if it exists.

function RemovePath([string]$LiteralPath)
{
  # Make sure the path isn't null to avoid errors.
  if ($LiteralPath -ne '')
  {
    # Check to see if the path exists.
    if (Test-Path -LiteralPath $LiteralPath)
    {
      # Remove the path.
      Remove-Item -LiteralPath $LiteralPath -Recurse -Force | Out-Null
    }
  }
}
#==============================================================================================================================================================================================
#  Checks if a path exists. Avoids use of "Test-Path" directly which can generate an error if the tested path is null.

function TestPath([string]$LiteralPath)
{
  # Make sure the path isn't null to avoid errors.
  if ($LiteralPath -ne '')
  {
    # Check to see if the path exists.
    if (Test-Path -LiteralPath $LiteralPath)
    {
      # Remove the path.
      return $true
    }
  }
  return $false
}
#==============================================================================================================================================================================================
#  MISCELLANEOUS: STRING MANIPULATION FUNCTIONS
#==============================================================================================================================================================================================
#  Counts the number of characters in a string and extends it with empty spaces to the input amount.

function ExtendString([string]$InputString, [int]$Length)
{
  # Count the number of characters in the input string.
  $Count = ($InputString | Measure-Object -Character).Characters

  # Check the number of characters against the desired amount.
  if ($Count -lt $Length)
  {
    # If the string is to be lengthened, find out by how much.
    $AddLength = $Length - $Count

    # Loop until the string matches the desired number of characters.
    for ($i=1; $i -le $AddLength; $i++)
    {
      $InputString += ' '
    }
  }
  # Return the modified string.
  return $InputString
}
#==============================================================================================================================================================================================
#  Takes an integer and converts it to a string and also appends a 0 to the front of the string if the integer is less than 10.

function IntToStringDoubleDigit([int]$Value)
{
  # Check if the input number is less than 10.
  if ($Value -lt 10)
  {
    # If it is, append a 0 and return as a string.
    return ('0' + $Value.ToString())
  }
  # Otherwise just return the integer as a string.
  return $Value.ToString()
}
#==============================================================================================================================================================================================
#  Forces any numeric value into a string with a whole number and two decimal places.

function FormatDecimal([string]$Value)
{
  # Some countries use commas instead of periods for decimals.
  if ($Value -like '*,*')
  {
    # If a comma is found, replace it with a period.
    $Value = $Value.Replace(',','.')
  }
  # Now split on the period. This will be used to fix any values with a leading 0 (such as 01.25) or a missing 0 (such as .25).
  $PeriodSplit = $Value.Split('.', 2)

  # Powershell trickery: convert the integer part of the string into an actual integer, then back into a string. This will remove any leading 0s, or make it 0 if a number was not found.
  $IntValue = ([int]$PeriodSplit[0]).ToString()
  $DecValue = $PeriodSplit[1]

  # How the decimal value will be formatted depends on the number of characters available in the decimal value.
  $DecimalPlaces = (($DecValue | Measure-Object -Character).Characters).ToString()

  # A switch works well here because the range is 0-2, anything beyond, and nothing negative.
  switch ($DecimalPlaces)
  {
    '0'     { $FixedValue = $IntValue + '.00' }                                 # If a decimal value was not provided, append two 0s.
    '1'     { $FixedValue = $IntValue + '.' + $DecValue + '0' }           # If there is only a single digit, then append a single zero.
    '2'     { $FixedValue = $IntValue + '.' + $DecValue }                 # If there are exactly 2 characters, just use the current value.
    default { $FixedValue = $IntValue + '.' + $DecValue.Substring(0,2) }  # If the decimal has more than 2 characters, keep only the first 2 characters.
  }
  # Return the new value.
  return $FixedValue
}
#==============================================================================================================================================================================================
#  Takes a file extension (.png/.dds/.jpg) and returns it as a 3 letter word (PNG/DDS/JPG).

function ExtensionToText([string]$FileExt)
{
  # Allow returning "null" as text if string is empty. Only used in "OverwriteOption" function.
  if ($FileExt -eq '')
  {
    return 'null'
  }
  # Trim the period and force the string to uppercase.
  return $FileExt.TrimStart('.').ToUpper()
}
#==============================================================================================================================================================================================
#  MISCELLANEOUS: TEST ALL BOOLEANS IN A COLLECTION OF BOOLEANS
#==============================================================================================================================================================================================
#  Tests all boolean values in an array. All values must be "true" to return true otherwise it returns "false".

function TestBooleanArray([bool[]]$Array)
{
  # Loop through each check.
  foreach($Check in $Array)
  {
    # Test if the check has passed.
    if (!$Check)
    {
      # If any check fails return false.
      return $false
    }
  }
  # If all checks pass return true.
  return $true
}
#==============================================================================================================================================================================================
#  POWERSHELL CONSOLE FUNCTIONS: MORE CONSOLE COLORS
#==============================================================================================================================================================================================
#  Alternative Write-Host that can conditionally add color rather than being forced like regular Write-Host. Used with $ConsoleColors (a.k.a. "More Console Colors" option).

function Write_Host([string]$Message, [string]$ForegroundColor, [switch]$NoNewLine)
{
  # If color was specified and color is enabled.
  if (($ForegroundColor -ne '') -and ($ConsoleColors))
  {
    Write-Host $Message -ForegroundColor $ForegroundColor -NoNewLine:$NoNewLine
  }
  # If color was disabled or no color was provided.
  else
  {
    Write-Host $Message -NoNewLine:$NoNewLine
  }
}
#==============================================================================================================================================================================================
#  POWERSHELL CONSOLE FUNCTIONS: UPDATE THE POWERSHELL WINDOW WITH INFORMATION
#==============================================================================================================================================================================================
#  Console: Updates the console with texture information before processing the texture in the Main Loop.

function ConsoleUpdateLoopStart()
{
  # Manual Rescale has its own information to display, so don't display this if it's enabled.
  if (!$ManualRescale)
  {
    # Writes information about the texture to the console window.
    Write_Host ' Texture    : ' -ForegroundColor Yellow -NoNewLine
    Write-Host ($Texture.FullName + ' (' + $Texture.ImageFormat + ')') -ForegroundColor Cyan
    Write_Host ' Path       : ' -ForegroundColor Yellow -NoNewLine
    Write-Host ((Get-Item -LiteralPath $MasterInputPath).Name + $Texture.Relative)
    Write_Host ' Dimensions : ' -ForegroundColor Yellow -NoNewLine
    Write-Host ($Texture.Dimensions + ' : ' + $Texture.Aspect.ToString())
    Write_Host ' Scale      : ' -ForegroundColor Yellow -NoNewLine
    Write-Host $Texture.FullScale
  }
}
#==============================================================================================================================================================================================
#  Console: Set up the message to display in "ConsoleUpdateLoopEnd" which shows after the main loop processes a texture.

function SetConsoleMessage([string]$MsgType, [string]$Message, [string]$EndMessage)
{
  $global:ConsoleType = $MsgType
  $global:ConsoleMsgA = $Message
  $global:ConsoleMsgB = $EndMessage
}
#==============================================================================================================================================================================================
#  Console: Updates the console with texture information after processing the texture in the Main Loop. 

function ConsoleUpdateLoopEnd()
{
  # There are four types of messages that can be displayed. If "ConsoleType" is empty none of them will display.
  switch ($ConsoleType)
  {
    # Warning Message - All red "warning" with red text.
    '0' { Write-Host (' Warning    : ' + $ConsoleMsgA) -ForegroundColor Red }
    # Normal Message - Yellow "message", white text.
    '1' { Write_Host ' Message    : ' -ForegroundColor Yellow -NoNewLine ; Write-host $ConsoleMsgA }
    # 2-Part Message - Yellow "message", half white/half green text.
    '2' { Write_Host ' Message    : ' -ForegroundColor Yellow -NoNewLine ; Write-Host $ConsoleMsgA -NoNewLine ; Write-Host $ConsoleMsgB -ForegroundColor Green }
    # Notice Message - Magenta "notice", white text.
    '3' { Write_Host ' Notice     : ' -ForegroundColor Magenta -NoNewLine ; Write-Host $ConsoleMsgA }
  }
  # Reset the message variables to a null value to prevent text popping up when it's not wanted.
  $global:ConsoleType = $null
  $global:ConsoleMsgA = $null
  $global:ConsoleMsgB = $null

  # Create a text bar to separate individual texture information.
  Write_Host '-----------------------------------------------------------------------------------------------------------------------' -ForegroundColor Gray
}
#==============================================================================================================================================================================================
#  LOG FILE FUNCTIONS: CREATE AND WRITE TO THE LOG FILE
#==============================================================================================================================================================================================
#  Log: Creates the log file.

function AttemptCreateLogFile()
{
  # If the user disabled creating the log file then do not create it.
  if ($CreateLogFile)
  {
    # Set the base log path.
    $global:LogFile = $BaseFolder + '\' + $ScriptName + '.log'

    # If a log file already exists, remove it before starting to add data to it.
    RemovePath -LiteralPath $LogFile

    # Log the intro stuff.
    Add-Content -LiteralPath $LogFile -value '---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------'
    Add-Content -LiteralPath $LogFile -value 'Custom Texture Tool PS - Operation Log '
    Add-Content -LiteralPath $LogFile -value '---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------'

    # Log the operation and all enabled sub-options.
    $OptionSelected = ''
    $EnabledOptions = ''

    # Log the master option that was selected.
    switch ($MasterOperation)
    {
      'ScanAllTextures' { $OptionSelected = 'Scan Dolphin Textures For Issues' }
      'ConvertTextures' { $OptionSelected = 'Convert Textures to Another Format (' + (ExtensionToText -FileExt $ConvertFormat) + ')' }
      'ForceIntScaling' { $OptionSelected = 'Rescale Textures With New Scaling Factor (' + $RescaleFactor + 'x)' }
      'CreateWatermark' { $OptionSelected = 'Add Identifying Watermark to All Textures' }
      'CreateMaterials' { $OptionSelected = 'Create Material Maps With Ishiiruka Tool' }
      'MaterialInPlace' { $OptionSelected = 'Create Material Maps With Ishiiruka Tool (In-Place)' }
      'OptiPNGTextures' { $OptionSelected = 'Optimize PNG Textures With OptiPNG' }
      'OptimizeInPlace' { $OptionSelected = 'Optimize PNG Textures With OptiPNG (In-Place)' }
      'UpscaleTextures' { $OptionSelected = 'Apply Upscaling Filter to All Textures (' + $UpscaleFilter + ')' }
      'GenerateMipMaps' { $OptionSelected = 'Generate New MipMaps' }
      'RemoveBadMipMap' { $OptionSelected = 'Remove Invalid MipMaps' }
      'DetachDDSMipMap' { $OptionSelected = 'Extract Internal DDS MipMaps' }
      'AlphaChannelFix' { $OptionSelected = 'Remove Alpha Channel From Opaque Textures' }
    }
    # Log all enabled sub-options.
    if ($RepairTextures)   { $EnabledOptions += 'Attempt Repairs, ' }
    if ($CopyBadTextures)  { $EnabledOptions += 'Copy Bad Textures, ' }
    if ($HideOKTextures)   { $EnabledOptions += 'Hide OK Textures, ' }
    if ($IgnoreDuplicates) { $EnabledOptions += 'Ignore Duplicates, ' }
    if ($AllowNotHD)       { $EnabledOptions += 'Allow NotHD Textures, ' }
    if ($CopyNonTextures)  { $EnabledOptions += 'Copy Non-Textures, ' }
    if ($ForceNewMipMaps)  { $EnabledOptions += 'Force New MipMaps, ' }
    if ($ManualRescale)    { $EnabledOptions += 'Manual Rescale, ' }
    if ($ConvertRepair)    { $EnabledOptions += 'Auto-Repair Dimensions, ' }
    if ($AllowAllImages)   { $EnabledOptions += 'Allow All Images, ' }

    # The last logged option will leave behind a trailing comma so trim it.
    $EnabledOptions = $EnabledOptions.TrimEnd(', ')

    # Print all enabled options in the log file.
    Add-Content -LiteralPath $LogFile -value ('Operation Selected : ' + $OptionSelected)
    Add-Content -LiteralPath $LogFile -value ('Enabled Sub-Options: ' + $EnabledOptions)
  }
}
#==============================================================================================================================================================================================
#  Log: Updates the log with texture information after processing the texture in the Main Loop.

function AttemptUpdateLogFile()
{
  # Log the texture if the user did not disable the log, and it holds a message other than 'OK'. Only log 'OK' textures when the user chooses not to hide them.
  if (($CreateLogFile) -and (($LogMessage -ne 'OK') -or (!$HideOKTextures)))
  {
    # If the path has changed since the last texture, then log the new path for the next texture.
    if ($Texture.Path -ne $PreviousPath)
    {
      Add-Content -LiteralPath $LogFile -value '---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------'
      Add-Content -LiteralPath $LogFile -value ('Path: ' + $Texture.Path)
      Add-Content -LiteralPath $LogFile -value ''
    }
    # Format text for log files using the custom "ExtendString" function.
    $LogName    = ExtendString -InputString $Texture.FullName -Length 52
    $LogOldDim  = ExtendString -InputString ($Texture.OldWidth.ToString() + 'x' + $Texture.OldHeight.ToString() + ':' + $Texture.OldAspect.ToString()) -Length 14
    $LogNewDim  = ExtendString -InputString ($Texture.Width.ToString() + 'x' + $Texture.Height.ToString() + ':' + $Texture.Aspect.ToString()) -Length 14
    $LogScale   = ExtendString -InputString $Texture.FullScale -Length 11

    # Output formatted text to the log file. Uses the global $LogMessage variable to display additional info.
    $LogOutput  = $LogName + ' [Original] ' + $LogOldDim + ' [Custom] ' + $LogNewDim + ' [Scale] ' + $LogScale + ' [Status] ' + $LogMessage
    Add-Content -LiteralPath $LogFile -value $LogOutput

    # After the log message has been used, wipe it out so it doesn't display again unless set.
    $global:LogMessage = $null

    # Store the current path so when the next texture is analyzed, it is known whether or not the path changed so the log can be updated accordingly.
    $global:PreviousPath = $Texture.Path
  }
}
#==============================================================================================================================================================================================
#  POWERSHELL CONSOLE + LOG FILE FINAL UPDATE: FIRES WHEN THE MASTER LOOP ENDS
#==============================================================================================================================================================================================
#  Sub-function of "ConsoleAndLogFinalUpdate". Appends a line of text to the log file if it's not disabled.

function TryUpdateLog([string]$Text)
{
  # Do not append text if the log file is disabled. 
  if ($CreateLogFile)
  {
    # Uh, add the line of text to the log file?
    Add-Content -LiteralPath $LogFile -value $Text
  }
}
#==============================================================================================================================================================================================
#  Sub-function of "ConsoleAndLogFinalUpdate" to show additional information if the selected option is "Scan All Textures".

function ConsoleAndLogFinal_ScanTextures()
{
  # Report the number of issues.
  if ($CountIssues -gt 0)
  {
    Write_Host (' Total Textures w/ Issues : ') -ForegroundColor Cyan -NoNewLine
    Write-Host $CountIssues.ToString()
    TryUpdateLog -Text ('Total Texture Issues   : ' + $CountIssues)
  }
  #  Report a special message if there were no issues.
  else
  {
    Write-Host (' No texture issues were detected!')
    TryUpdateLog -Text ('No texture issues were detected!')
  }
  # If the user attempted to repair textures.
  if ($RepairTextures)
  {
    # Report the number of copied textures.
    if ($CountCopied -gt 0)
    {
      Write_Host (' Total Textures Copied    : ') -ForegroundColor Cyan -NoNewLine
      Write-Host $CountCopied.ToString()
      TryUpdateLog -Text ('Total Textures Copied  : ' + $CountCopied)
    }
    # Report the number of repaired textures.
    if ($CountRepaired -gt 0)
    {
      Write_Host (' Total Textures Repaired  : ') -ForegroundColor Cyan -NoNewLine
      Write-Host $CountRepaired.ToString()
      TryUpdateLog -Text ('Total Textures Repaired: ' + $CountRepaired)
    }
  }
  # Create one last dividing bar.
  Write_Host '-----------------------------------------------------------------------------------------------------------------------' -ForegroundColor Gray
  TryUpdateLog -Text '---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------'
}
#==============================================================================================================================================================================================
#  Sub-function of "ConsoleAndLogFinalUpdate" to show additional information if the selected option is "Optimize Textures With OptiPNG".

function ConsoleAndLogFinal_OptiPNGTextures()
{
  # Report the total number of textures optimized.
  Write_Host (' Total Textures Optimized     : ') -ForegroundColor Cyan -NoNewLine
  Write-Host $CountOptimized.ToString()
  TryUpdateLog -Text ('Total Textures Optimized     : ' + $CountOptimized)

  # If the Total Reduction is greater than 1 MB.
  if ($TotalReductionB -ge 1048576)
  {
    $TotalReductionMB = FormatDecimal -Value ([decimal]($TotalReductionB/1024/1024))
    Write_Host (' Total Reduction With OptiPNG : ') -ForegroundColor Cyan -NoNewLine
    Write-Host ($TotalReductionMB + ' MB')
    TryUpdateLog -Text ('Total Reduction With OptiPNG : ' + $TotalReductionMB + ' MB')
  }
  # If the Total Reduction is greater than 1 KB.
  elseif ($TotalReductionB -ge 1024)
  {
    $TotalReductionKB = FormatDecimal -Value ([decimal]($TotalReductionB/1024))
    Write_Host (' Total Reduction With OptiPNG : ') -ForegroundColor Cyan -NoNewLine
    Write-Host ($TotalReductionKB + ' KB')
    TryUpdateLog -Text ('Total Reduction With OptiPNG : ' + $TotalReductionKB + ' KB')
  }
  # Display in Bytes.
  else
  {
    Write_Host (' Total Reduction With OptiPNG : ') -ForegroundColor Cyan -NoNewLine
    Write-Host ($TotalReductionB.ToString() + ' Bytes')
    TryUpdateLog -Text ('Total Reduction With OptiPNG : ' + $TotalReductionB.ToString() + ' Bytes')
  }
  # Create one last dividing bar.
  Write_Host '-----------------------------------------------------------------------------------------------------------------------' -ForegroundColor Gray
  TryUpdateLog -Text '---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------'
}
#==============================================================================================================================================================================================
#  Sub-function of "ConsoleAndLogFinalUpdate". Generic function that displays either the number of textures in the count, or a message indicating the count was zero.

function ConsoleAndLogFinal_Universal([int]$TexCount, [string]$MsgA, [string]$MsgB)
{
  # Check to see if the corresponding count is greater than 0.
  if ($TexCount -gt 0)
  {
    # If it is, display the count in both the console and the log.
    Write_Host (' Total Textures ' + $MsgA + ' : ') -ForegroundColor Cyan -NoNewLine
    Write-Host $TexCount.ToString()
    TryUpdateLog -Text ('Total Textures ' + $MsgA + ' : ' + $TexCount)
  }
  else
  {
    # If not, display the alternate message that states the count was 0.
    Write-Host (' ' + $MsgB)
    TryUpdateLog -Text $MsgB
  }
  # Create a bar between texture information in both console and log.
  Write_Host '-----------------------------------------------------------------------------------------------------------------------' -ForegroundColor Gray
  TryUpdateLog -Text '---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------'
}
#==============================================================================================================================================================================================
#  Displays additional information for certain operations in the console after the Master Loop has finished.

function ConsoleAndLogFinalUpdate()
{
  # Log a bar for the hell of it.
  TryUpdateLog -Text '---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------'

  # If any of the below options are enabled, display additional information.
  switch ($MasterOperation)
  {
    'ScanAllTextures' { ConsoleAndLogFinal_ScanTextures }
    'OptiPNGTextures' { ConsoleAndLogFinal_OptiPNGTextures }
    'OptimizeInPlace' { ConsoleAndLogFinal_OptiPNGTextures }
    'GenerateMipMaps' { ConsoleAndLogFinal_Universal -TexCount $CountMipMapped -MsgA 'MipMapped' -MsgB 'No textures required mipmaps!' }
    'RemoveBadMipMap' { ConsoleAndLogFinal_Universal -TexCount $CountInvalidMips -MsgA 'With Invalid MipMaps' -MsgB 'No textures with invalid mipmaps were found!' }
    'AlphaChannelFix' { ConsoleAndLogFinal_Universal -TexCount $CountSlicedAlpha -MsgA 'With Removed Alpha Channel' -MsgB 'No textures with an unnecessary alpha channel were found!' }
  }
  # Create one last empty space.
  Write-Host ''
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: TEXTURE VALIDATION
#==============================================================================================================================================================================================
#  Sub-function of ValidateTexture. Copies a corrupt texture to a location and outputs information to the console.

function CopyCorruptTexture([hashtable]$TextureInfo)
{
  # Output that the texture is corrupt.
  Write_Host ' Texture    : ' -ForegroundColor Yellow -NoNewLine
  Write-Host ($TextureInfo.FullName + ' is corrupt.') -ForegroundColor Red
  Write_Host ' Path       : ' -ForegroundColor Yellow -NoNewLine
  Write-Host ((Get-Item -LiteralPath $MasterInputPath).Name + $TextureInfo.Relative)
  Write_Host ' Message    : ' -ForegroundColor Yellow -NoNewLine
  Write-Host 'Texture copied to ' -NoNewLine
  Write-Host ('CorruptTextures' + $TextureInfo.Relative) -ForegroundColor Green
  Write_Host '-----------------------------------------------------------------------------------------------------------------------' -ForegroundColor Gray

  # Copy corrupt textures to a new folder.
  $CorruptPath = CreatePath -LiteralPath ($MasterOutputPath + '\CorruptTextures' + $TextureInfo.Relative)
  Copy-Item -LiteralPath $TextureInfo.FullPath -Destination $CorruptPath -Force
}
#==============================================================================================================================================================================================
#  Gets the block compression type of a texture with a DX10 header by reading the DXGI_FORMAT flag.
#  Reference: https://msdn.microsoft.com/en-us/library/windows/desktop/bb173059(v=vs.85).aspx

function GetDX10BlockCompression([int]$DXGI_FORMAT)
{
  # Return the basic compression type. No need to know whether it is typeless, unorm, or unorm srgb.
  switch ($DXGI_FORMAT)
  {
    # This only covers a small spectrum of DDS formats, but these are the ones I'm most concerned with.
    70 { return 'DXT1' } # DXGI_FORMAT_BC1_TYPELESS
    71 { return 'DXT1' } # DXGI_FORMAT_BC1_UNORM
    72 { return 'DXT1' } # DXGI_FORMAT_BC1_UNORM_SRGB
    73 { return 'DXT3' } # DXGI_FORMAT_BC2_TYPELESS
    74 { return 'DXT3' } # DXGI_FORMAT_BC2_UNORM
    75 { return 'DXT3' } # DXGI_FORMAT_BC2_UNORM_SRGB
    76 { return 'DXT5' } # DXGI_FORMAT_BC3_TYPELESS
    77 { return 'DXT5' } # DXGI_FORMAT_BC3_UNORM
    78 { return 'DXT5' } # DXGI_FORMAT_BC3_UNORM_SRGB
    97 { return 'BC7'  } # DXGI_FORMAT_BC7_TYPELESS
    98 { return 'BC7'  } # DXGI_FORMAT_BC7_UNORM
    99 { return 'BC7'  } # DXGI_FORMAT_BC7_UNORM_SRGB

    # Obviously the rest are not all ARGB32 formats (B8G8R8A8 is the DXGI equivalent for A8R8G8B8), but treat them as such.
    # TODO: Possibly implement support for other formats, although I don't think it should matter much.
    default { return 'ARGB32' }
  }
}
#==============================================================================================================================================================================================
#  Checks the mipmap flag (Byte[28]) of a DDS header. Changes it from a 0 to a 1 if the value found is 0.

function DDSHeaderFix_MipMapFlag([int]$MipMapFlag)
{
  # Some writers may write a 0 for no mipmaps.
  if ($MipMapFlag -eq 0)
  {
    # This is incorrect, and should be at least 1.
    return 1
  }
  # If it's not 0, just return whatever it is.
  return $MipMapFlag
}
#==============================================================================================================================================================================================
#  This is a really stupid (bug?) I found. Some DDS writers (Compressonator) set the DDPF_ALPHAPIXELS flag when the image has alpha, but this flag seems
#  to require valid data set in the dwRGBAlphaBitMask section of the pixel format header. When this flag is set, some programs (TexConv) can't read the 
#  image. So while were here, fix that byte if any possible value comes up that shows that it is there.

function DDSHeaderFix_DDPF_ALPHAPIXELS([int]$PixelFormatFlag, [int]$PixelFormatValue, [string]$PixelFormatAMask)
{
  # Values of "1" and "3" are technically correct, but FourCC "4" should always be present making the minimum "5". A value of "7" may come up if the
  # flag DDPF_Alpha is set. I have not seen a DDS texture ever have this flag set, so I don't know if this will be a problem. Also check the bitmask
  # section of the header to see if there is valid data (which this flag is supposed to represent). I think anyway, I'm mostly just making guesses
  # here based on observations. What I'm doing could be wrong, but from my testing this "fixes" any image that programs deemed "broken".
  if ((($PixelFormatValue -eq 5) -or ($PixelFormatValue -eq 7)) -and ($PixelFormatAMask -eq '00-00-00-00'))
  {
    # Subtract 1 which effectively removes the flag.
    return ($PixelFormatFlag - 1)
  }
  # Return the value because it's already fine.
  return $PixelFormatFlag
}
#==============================================================================================================================================================================================
#  This may apply to other textures, but all textures created by Ishiiruka Tool have this issue so I dub it the "Ishiiruka Fix". Ishiiruka textures have an issue with the pixel format
#  header flags. Ishiiruka Tool is setting the "DDPF_RGB" flag, but the header does not have valid data in any of the bitmask bytes. Check for this by grabbing the pixel format flags,
#  and checking for data in the bitmasks. I don't know if Tino is setting this flag on purpose, so for now only try to fix the texture if it does not have a material map.

function DDSHeaderFix_IshiirukaTexture([hashtable]$TextureInfo, [int]$PixelFormatFlag, [int]$RGBFlag, [string]$RedBitMask, [string]$GreenBitMask, [string]$BlueBitMask)
{
  # The Ishiiruka color texture is missing the material map, and its not a material map itself.
  if ((!$TextureInfo.HasMaterialMap) -and ($TextureInfo.FullName -notlike '*.nrm*') -and ($TextureInfo.FullName -notlike '*.mat*'))
  {
    # If the flag is set, it will be a hex value of 40 or higher. Also check for data in the bitmask fields. 
    if (([int]$RGBFlag -ge 40) -and ($RedBitMask -eq $GreenBitMask -eq $BlueBitMask -eq '00-00-00-00'))
    {
      # Alert the user the texture was repaired.
      Write_Host ' Notice     :' -ForegroundColor Magenta -NoNewLine
      Write-Host (' Repaired bad flags in PixelFormat header (Ishiiruka DDS Color Texture?).')

      # Subtract 64 decimal/base10 (40 in hex/base16) from the byte which basically removes the DDPF_RGB flag.
      return $PixelFormatFlag - 64
    }
  }
  # Return the value because it's already fine.
  return $PixelFormatFlag
}
#==============================================================================================================================================================================================
#  Sub-function of ValidateTexture. Tests an image for validity by reading its header. This function was originally used just to verify the first few bytes, but now it also
#  automatically fixes various issues that can be found in DDS textures. One such issue is Compressonator sets the DDPF_ALPHAPIXELS flag in the pixel format header which
#  makes the image unreadable by TexConv. This function removes that flag when the image is read. It also fixes an issue with Ishiiruka DDS color textures which also sets a
#  flag in the pixel format header. This flag is DDPF_RGB which makes the image unreadable by almost all programs so it is also removed. More info can be found below. 

function ValidateImageHeader([hashtable]$TextureInfo)
{
  # Get the image as a byte array.
  $ByteArray = [System.IO.File]::ReadAllBytes($TextureInfo.FullPath)

  # Get the first 8 bytes of the image from the byte array.
  $HeaderBytes = [System.BitConverter]::ToString($ByteArray[0..7])

  # Verify the PNG file type.
  if (($TextureInfo.Extension -eq $PNG) -and ($HeaderBytes -eq '89-50-4E-47-0D-0A-1A-0A'))
  {
    return $true
  }
  # JPG is forced true for now until I come up with a solution (which I may never care to).
  elseif ($TextureInfo.Extension -eq $JPG)
  {
    return $true
  }
  # The DDS format is much more complicated.
  elseif (($TextureInfo.Extension -eq $DDS) -and ($HeaderBytes -eq '44-44-53-20-7C-00-00-00'))
  {
    # Bad headers will generate powershell warnings. The user does not need to know this info, and neither do I, so hide it.
    $ErrorActionPreference = 'silentlycontinue'

    # The DDS header from bytes 85-88 should hold the FOURCC value to identify the compression format or if it has a DX10 header.
    # DXT1: 44-58-54-31, DXT3: 44-58-54-31, DXT5: 44-58-54-35, DX10: 44-58-31-30
    $DDSFourCC = [System.BitConverter]::ToString($ByteArray[84..87])
    $DDSFourCC = [string]::Join('',($DDSFourCC.Split('-') | foreach { [char][byte]([System.Convert]::ToInt16($_, 16)) }))

    # Check for an uncompressed DDS texture.
    if ($DDSFourCC -eq '')
    {
      # For now just blindly support them.
      return $true
    }
    # Check for any DXT texture.
    elseif ($DDSFourCC -like 'DXT*')
    {
      # Store the value of these bytes. If they are different at the end, rewrite the texture.
      $OldByte28 = $ByteArray[28]
      $OldByte80 = $ByteArray[80]

      # If the mipmap byte reads 0, make it 1. I'm not sure why, but some programs always expect to see at least 1 mipmap even if there are no mipmaps.
      $ByteArray[28] = DDSHeaderFix_MipMapFlag -MipMapFlag $ByteArray[28]

      # Get the pixel format flags set at Byte[80], and get the value of the Alpha Bitmask section.
      $PixelFormatValue = [System.BitConverter]::ToString($ByteArray[80]).SubString(1,1)
      $PixelFormatAMask = [System.BitConverter]::ToString($ByteArray[104..107])

      # Some stupid issue I found. Read the function for more details.
      $ByteArray[80] = DDSHeaderFix_DDPF_ALPHAPIXELS -PixelFormatFlag $ByteArray[80] -PixelFormatValue $PixelFormatValue -PixelFormatAMask $PixelFormatAMask

      # Get the flag, and check if there is actually valid data in any of the bitmask sections of the header.
      $RGBFlag  = [System.BitConverter]::ToString($ByteArray[80])
      $RBitMask = [System.BitConverter]::ToString($ByteArray[92..95])
      $GBitMask = [System.BitConverter]::ToString($ByteArray[96..99])
      $BBitMask = [System.BitConverter]::ToString($ByteArray[100..103])

      # A fix for an age old bug with Ishiiruka DDS textures.
      $ByteArray[80] = DDSHeaderFix_IshiirukaTexture -TextureInfo $TextureInfo -PixelFormatFlag $ByteArray[80] -RGBFlag $RGBFlag -RedBitMask $RBitMask -GreenBitMask $GBitMask -BlueBitMask $BBitMask

      # If the header changed at all, rewrite the texture with changes. 
      if (($ByteArray[28] -ne $OldByte28) -or ($ByteArray[80] -ne $OldByte80))
      {
        # Overwrite the old file with the corrected header.
        [System.IO.File]::WriteAllBytes($TextureInfo.FullPath, $ByteArray)
      }
      # We're done here, the texture should be good.
      return $true
    }
    # Check for a DX10 header file.
    elseif ($DDSFourCC -eq 'DX10')
    {
      # Get the block compression type found at Byte[128] and convert it to base 10 so it matches a value from this chart: 
      # https://msdn.microsoft.com/en-us/library/windows/desktop/bb173059(v=vs.85).aspx
      $DX10BCFlag = [System.Convert]::ToInt32([System.BitConverter]::ToString($ByteArray[128]), 16)

      # Check to see if the value falls within the range of the BC7 compression types.
      if (($DX10BCFlag -ge 97) -or ($DX10BCFlag -le 99))
      {
        # BC7 textures should have no issues with the rest of the header so just return true.
        return $true
      }
      # Check to see if the value falls within the range of the BC1-BC3 compression types.
      elseif (($DX10BCFlag -ge 70) -or ($DX10BCFlag -le 78))
      {
        # Get the compression type which should be DXT1, DXT3, or DXT5.
        $NewFourCC = GetDX10BlockCompression -DXGI_FORMAT $DX10BCFlag

        # Convert the letters into bytes and write them into the byte array. This replaces the 'DX10' FourCC header value with 'DXT#'.
        $ByteArray[84] = [byte][char]($NewFourCC.SubString(0,1))
        $ByteArray[85] = [byte][char]($NewFourCC.SubString(1,1))
        $ByteArray[86] = [byte][char]($NewFourCC.SubString(2,1))
        $ByteArray[87] = [byte][char]($NewFourCC.SubString(3,1))

        # The new byte array should be the same size as the original array, minus 20 (which is the size of the DX10 extended header in bytes).
        $NewByteArrayLength = $ByteArray.Length - 20

        # Create a new byte array which will hold the new image data.
        $NewByteArray = New-Object Byte[] $NewByteArrayLength

        # Copy the header that now contains the updated FourCC.
        [System.Array]::Copy($ByteArray, 0, $NewByteArray, 0, 128)

        # Copy the pixel data past the point of the DDS header.
        [System.Array]::Copy($ByteArray, 148, $NewByteArray, 128, ($NewByteArrayLength - 128))

        # Alert the user the header was converted.
        Write_Host ' Notice     :' -ForegroundColor Magenta -NoNewLine
        Write-Host (' Found DX10 DDS header and automatically converted to DX9 DDS header.')

        # Overwrite the old file with the corrected header.
        [System.IO.File]::WriteAllBytes($TextureInfo.FullPath, $NewByteArray)
      }
      # We're done here, the texture should be good.
      return $true
    }
  }
  # If we got here, the header is not valid, so the texture is corrupt.
  CopyCorruptTexture $TextureInfo
  return $false
}
#==============================================================================================================================================================================================
#  Sub-function of ValidateTexture. Tests the extension of the texture to see if it is PNG, DDS, or JPG.

function ValidateExtension([hashtable]$TextureInfo)
{
  # Create an array with valid extensions.
  $ExtCheck = @($PNG,$DDS,$JPG)

  # Make sure the texture has a valid extension.
  if ($ExtCheck -contains $TextureInfo.Extension)
  {
    # Yay a valid image file.
    return $true
  }
  # It's not an image or it has no extension.
  return $false
}
#==============================================================================================================================================================================================
#  Sub-function of ValidateTexture. Checks to see if the texture has a valid file name + extension. 

function ValidateTextureName([hashtable]$TextureInfo)
{
  # See if the name contains a mipmap identifier.
  if ($TextureInfo.Name -like '*_mip*')
  {
    # The texture is a mipmap so fail validation.
    return $false
  }
  # Check to see if it is a Dolphin texture.
  if ($TextureInfo.DolphinFormat)
  {
    # Create an array with every type of material.
    $MatCheck = 'nrm','mat','bump','spec','lum'

    # Splits the texture name into 2 parts based on any periods found.
    $SplitPeriod = $TextureInfo.Name.Split('.',2)

    # See if the name contains a material identifier.
    if ($MatCheck -contains $SplitPeriod[1])
    {
      # The texture is a material map so fail validation.
      return $false
    }
    # The file name and extension passes all validity checks.
    return $true
  }
  # It's not a Dolphin texture. If AllowAllImages is enabled then force the texture to pass validation.
  return $AllowAllImages
}
#==============================================================================================================================================================================================
#  Tests if a path/file is a valid texture when creating the Texture Hash Table, using partial data from the Texture Hash Table.
#  I don't really like multiple conditions with the same return, I'd rather check all conditions at once. But this way allows it to fail early so it's faster.

function ValidateTexture([hashtable]$TextureInfo)
{
  # Make sure the texture has a valid extension.
  if (!(ValidateExtension $TextureInfo)) { return $false }

  # Validate the image header.
  if (!(ValidateImageHeader $TextureInfo)) { return $false }

  # Validate the name of the texture.
  if (!(ValidateTextureName $TextureInfo)) { return $false }

  # If we made it this far it's a valid texture.
  return $true
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: IMAGE INFORMATION HASH TABLE
#==============================================================================================================================================================================================
#  Based on a function I found online to test an image for transparency. Discussion of my PowerShell conversion below: 
#  http://stackoverflow.com/questions/42153408/interopservices-marshal-copy-always-zero-in-powershell-script-converted-from-c-s

function IsAlphaBitMap([string]$ImagePath)
{
  # Get the image as a Bitmap.
  $BitMap = New-Object System.Drawing.BitMap($ImagePath)

  # Check PixelFormat as a bit mask flag. 
  if (($BitMap.PixelFormat.value__ -band [System.Drawing.Imaging.PixelFormat]::Alpha) -eq 0)
  {
    # If there is no alpha then leave now.
    return $false
  }
  # For PowerShell v2 the bit shift needs to be manually calculated. PS v3+ can do: { $pixelBytes = [System.Drawing.Image]::GetPixelFormatSize($BitMap.PixelFormat) -shr 3 }
  $pixelBytes = [System.Math]::Floor([System.Drawing.Image]::GetPixelFormatSize($BitMap.PixelFormat) * [System.Math]::Pow(2,-3))

  # Do not support paletted images with less than 8bpp.
  if (!$pixelBytes) { return $false }

  # Convert the bitmap into BitmapData.
  $Rect    = New-Object System.Drawing.Rectangle(0, 0, $BitMap.Width, $BitMap.Height)
  $BmpData = [System.Drawing.Imaging.BitmapData]$BitMap.LockBits($Rect, [System.Drawing.Imaging.ImageLockMode]::ReadWrite, $BitMap.PixelFormat)

  # Create a Byte array to hold the image info.
  $Bytes = New-Object Byte[] ($BmpData.Height * $BmpData.Stride)

  # Copy all Bytes from the image into the Byte array.
  [System.Runtime.InteropServices.Marshal]::Copy($BmpData.Scan0, $Bytes, 0, $Bytes.Length)

  # Now that we're done with the image, dispose of the Bitmap so it doesn't get locked.
  $BitMap.Dispose()

  # Loop through each alpha Byte to see if there is transparency.
  for($p = $pixelBytes - 1 ; $p -lt $Bytes.Length ; $p += $pixelBytes)
  {
    # If the alpha Byte is not 255 the pixel contains transparency.
    if ($Bytes[$p] -ne 255)
    {
      # Return that the image has transparency.
      return $true
    }
  }
  # The image did not have any transparent pixels.
  return $false
}
#==============================================================================================================================================================================================
#  Gets various properties of an image file. Properties are: ImageFormat, Width, Height, Dimensions, Extension, Gray, Alpha, Transparent, and MipMaps.

function GetImageInfo([string]$ImagePath, [bool]$HasMaterial=$false)
{
  # Create a hash table to store the dimensions.
  $ImageData = @{}

  # Extract the extension from the end of the image path. Store it because I may need it someday.
  $ImageData.Extension = $ImagePath.Substring($ImagePath.Length - 4, 4)

  # Read the image as a byte array.
  $ByteArray = [System.IO.File]::ReadAllBytes($ImagePath)

  # Get the width/height of PNG images.
  if ($ImageData.Extension -eq $PNG)
  {
    # Store that the texture is in PNG format.
    $ImageData.ImageFormat = 'PNG'

    # Also convert the byte array into a readable string.
    $ArrayText = [System.Text.Encoding]::ASCII.GetString($ByteArray)

    # Read value 17-20 for width and 21-24 for height. Remove all dashes from the byte array.
    $HexWidth  = ([System.BitConverter]::ToString($ByteArray[16..19])).Replace('-','')
    $HexHeight = ([System.BitConverter]::ToString($ByteArray[20..23])).Replace('-','')

    # Convert the hex value to decimal.
    $ImageData.Width   = [System.Convert]::ToInt32($HexWidth,16)
    $ImageData.Height  = [System.Convert]::ToInt32($HexHeight,16)
    $ImageData.MipMaps = CountExternalMipMaps -ImagePath $ImagePath

    # Read the color type from the header.
    $ColorType = [System.BitConverter]::ToString($ByteArray[25])

    # See if the texture has an alpha channel.
    switch($ColorType)
    {
      # If the color type is Gray or RGB, check for the tRNS chunk to see if it has 1-Bit Alpha.
      '00'  { $ImageData.Gray  = $true
              $ImageData.Alpha = ($ArrayText -like '*tRNS*')
            }
      '02'  { $ImageData.Gray  = $false
              $ImageData.Alpha = ($ArrayText -like '*tRNS*')
            }
      # If it's an indexed texture, search for the "tRNS" chunk to know if it has 1-Bit Alpha.
      '03'  { $ImageData.Gray  = $false
              $ImageData.Alpha = ($ArrayText -like '*tRNS*')
            }
      # If the color type is GrayA or RGBA, we don't know if there's transparency or not so test for it.
      '04'  { $ImageData.Gray  = $true
              $ImageData.Alpha = (IsAlphaBitMap -ImagePath $ImagePath)
            }
      '06'  { $ImageData.Gray  = $false
              $ImageData.Alpha = (IsAlphaBitMap -ImagePath $ImagePath)
            }
    }
  }
  # Get the width/height of DDS images.
  elseif ($ImageData.Extension -eq $DDS)
  {
    # Get the width, height, and number of mipmaps. DDS headers are little endian so they must be read backwards.
    $HexWidth   = ([System.BitConverter]::ToString($ByteArray[19..16])).Replace('-','')
    $HexHeight  = ([System.BitConverter]::ToString($ByteArray[15..12])).Replace('-','')
    $HexMipMaps = ([System.BitConverter]::ToString($ByteArray[28]))

    # Convert the hex value to decimal.
    $ImageData.Width   = [System.Convert]::ToInt32($HexWidth,16)
    $ImageData.Height  = [System.Convert]::ToInt32($HexHeight,16)
    $ImageData.MipMaps = [System.Convert]::ToInt32($HexMipMaps,16)

    # The DDS header from bytes 84-87 should hold the FOURCC value to identify the compression format or if it has a DX10 header.
    # DXT1: 44-58-54-31, DXT3: 44-58-54-31, DXT5: 44-58-54-35, DX10: 44-58-31-30
    $DDSFourCC = [System.BitConverter]::ToString($ByteArray[84..87])

    # Now we have the FOURCC value. Split the value by the dashes (-) and convert to ASCII characters.
    $DDSFourCC = $DDSFourCC.Split('-') | foreach { [char][byte]([System.Convert]::ToInt16($_, 16)) }

    # An array of letters is not very useful, so concatenate all values into a single string.
    $DDSFourCC = [string]::Join('', $DDSFourCC)

    # Check for an uncompressed DDS texture.
    if ($DDSFourCC -eq '')
    {
      # For now just blindly support them.
      $ImageData.ImageFormat = 'ARGB32'
    }
    # Check for any DXT texture.
    elseif ($DDSFourCC -like 'DXT*')
    {
      # We can just straight up use the FourCC value to get the block compression.
      $ImageData.ImageFormat = $DDSFourCC
    }
    # Check for a DX10 header file.
    elseif ($DDSFourCC -eq 'DX10')
    {
      # Get the value found at byte 128 (this holds the block compression type).
      $DX10BCFlagHex = [System.BitConverter]::ToString($ByteArray[128])

      # Convert the hex value to decimal so it matches a value found from this chart:
      # https://msdn.microsoft.com/en-us/library/windows/desktop/bb173059(v=vs.85).aspx
      $DX10BCFlag = [System.Convert]::ToInt32($DX10BCFlagHex,16)

      # Get the block compression type from a compiled list.
      $ImageData.ImageFormat = GetDX10BlockCompression -DXGI_FORMAT $DX10BCFlag
    }
    # Ishiiruka DDS color textures and BC7 textures can not be analyzed with ImageMagick.
    if ((!$HasMaterial) -and ($ImageData.ImageFormat -ne 'BC7'))
    {
      # Determine whether or not there is transparency using ImageMagick.
      $ImageData.Gray  = $false
      $ImageData.Alpha = ((Magick-Identify -Image $ImagePath -Arguments @('-format','%[opaque]')) -eq 'False')
    }
    # DDS Ishiiruka textures can not be analyzed with ImageMagick.
    else
    {
      # Force these values to avoid errors. Ishiiruka textures do not make use of them (yet?).
      $ImageData.Gray  = $false
      $ImageData.Alpha = $true
    }
  }
  # For JPEG use .NET Framework since JPEG format is a fucking mess.
  elseif ($ImageData.Extension -eq $JPG)
  {
    # Store that the texture is in JPG format.
    $ImageData.ImageFormat = 'JPG'

    # Get the image as an object.
    $ImageObject = New-Object System.Drawing.Bitmap $ImagePath

    # Get the dimensions.
    $ImageData.Width   = $ImageObject.Width
    $ImageData.Height  = $ImageObject.Height
    $ImageData.MipMaps = CountExternalMipMaps -ImagePath $ImagePath

    # Force these values since they won't change (except maybe gray but I don't care enough).
    $ImageData.Gray  = $false
    $ImageData.Alpha = $false

    # Remove hook to the image.
    $ImageObject.Dispose()
  }
  # Also store the entire dimensions.
  $ImageData.Dimensions = $ImageData.Width.ToString() + 'x' + $ImageData.Height.ToString()

  # Return the image data.
  return $ImageData
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: MATERIAL MAP HASH TABLE
#==============================================================================================================================================================================================
#  Get various information about material maps.

function GetMaterialMapInfo([hashtable]$TextureInfo)
{
  # Create and store the values using a hash table.
  $MatMapData = @{}

  # Store whether or not the color texture is one of those Ishiiruka textures.
  $MatMapData.ColorIsLum = ($TextureInfo.Name -like '*_lum')

  # Whether or not it's a (_lum) texture decides on the base name to use.
  switch ($MatMapData.ColorIsLum)
  {
    # Remove the '_lum' from the name because material maps do not have '_lum' in them.
    $true  { $MatMapBase = $TextureInfo.PathName.Substring(0, $TextureInfo.PathName.Length - 4) }
    # If it's not a '_lum' just use the base color texture path and name without modification.
    $false { $MatMapBase = $TextureInfo.PathName }
  }
  # Test to see if any combined material maps or materials exist.
  $mat_Exists  = (TestPath -LiteralPath ($MatMapBase + '.mat' + $TextureInfo.Extension))
  $nrm_Exists  = (TestPath -LiteralPath ($MatMapBase + '.nrm' + $TextureInfo.Extension))
  $bump_Exists = (TestPath -LiteralPath ($MatMapBase + '.bump' + $PNG))
  $spec_Exists = (TestPath -LiteralPath ($MatMapBase + '.spec' + $PNG))
  $lum_Exists  = (TestPath -LiteralPath ($MatMapBase + '.lum' + $PNG))

  # Try to find a material map with ".mat" extension.
  if ($mat_Exists)
  {
    $MatMapData.HasMaterialMap = $true
    $MatMapData.MaterialMapType = '.mat'
  }
  # Test for the old "nrm" material map. It must exist alone without a bump, spec, and lum texture. 
  elseif (($nrm_Exists) -and (!$bump_Exists) -and (!$spec_Exists) -and (!$lum_Exists))
  {
    # This does not verify that it is not a "normal map", but it is a good approximation if other materials are not present.
    $MatMapData.HasMaterialMap = $true
    $MatMapData.MaterialMapType = '.nrm'
  }
  # Undefined variables read as "false".
  else
  {
    # But I like to define them anyway.
    $MatMapData.HasMaterialMap = $false
    $MatMapData.MaterialMapType = ''
  }
  # Set the path to the material map.
  $MatMapData.MaterialMapPath = ($MatMapBase + $MatMapData.MaterialMapType + $TextureInfo.Extension)

  # Only build material maps from PNG. Fail if color texture is "_lum" type. Since "nrm" and "lum" textures are optional, only check for bump/spec.
  $MatMapData.HasMaterials = (($TextureInfo.Extension -eq $PNG) -and (!$MatMapData.ColorIsLum) -and ($bump_Exists) -and ($spec_Exists))

  # Return the material map data.
  return $MatMapData
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: PNG INFO HASH TABLE
#==============================================================================================================================================================================================
#  Returns the PNG color type and bit depth from an image hash table (mostly "$Texture") so ImageMagick knows what type of PNG image to create.

function GetPNGInfo([hashtable]$TextureInfo)
{
  # I do love me some hash tables.
  $PNGData = @{}

  # Check to see if it is a grayscale texture.
  if ($TextureInfo.IsGrayScale)
  {
    # If it has transparency, create a 16-bit GrayA image. Otherwise create an 8-bit Gray image.
    switch ($TextureInfo.HasAlphaPixels)
    {
      $true   { $PNGData.ColorType  = '4'
                $PNGData.ColorSpace = 'GrayA'
                $PNGData.BitDepth   = '16'
              }
      $false  { $PNGData.ColorType  = '0'
                $PNGData.ColorSpace = 'Gray'
                $PNGData.BitDepth   = '8'
              }
    }
  }
  # The texture contains colors. Lots of pretty colors.
  else
  {
    # If it has transparency, create a 32-bit RGBA image. Otherwise create an 24-bit RGB image.
    switch ($TextureInfo.HasAlphaPixels)
    {
      $true   { $PNGData.ColorType  = '6'
                $PNGData.ColorSpace = 'RGBA'
                $PNGData.BitDepth   = '32'
              }
      $false  { $PNGData.ColorType  = '2'
                $PNGData.ColorSpace = 'RGB'
                $PNGData.BitDepth   = '24'
              }
    }
  }
  # Return the generated data.
  return $PNGData
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: SET DDS BLOCK COMPRESSION FROM FLAGS
#==============================================================================================================================================================================================
#  If a texture or folder contains part of a format name, and the user selected "Defined" as the compression format, find the defined value.

function GetDefinedDDSBlockCompression([string]$ImagePath, [bool]$HasAlpha)
{
  # Check the entire path for the compression format. This allows setting in per texture or per folder.
  switch -wildcard ($ImagePath)
  {
    # Selectively choose DXT1 for opaque textures, and DXT5 for textures with transparency.
    '*_DXTC*'   { switch ($HasAlpha)
                  {
                    $true  { return 'DXT5' }
                    $false { return 'DXT1' }
                  }
                }
    # This is just an alias for DXTC, unfortunately an "or" does not work in a switch.
    '*_DXTN*'   { switch ($HasAlpha)
                  {
                    $true  { return 'DXT5' }
                    $false { return 'DXT1' }
                  }
                }
    # If DXT5 is found, create all textures using DXT5 whether they have transparency or not.
    '*_BC3*'    { return 'DXT5' }
    '*_DXT5*'   { return 'DXT5' }

    # BC7 is a newer format but can offer superior quality over older compression formats.
    '*_BC7*'    { return 'BC7' }

    # ARGB32 is an uncompressed DDS texture.
    '*_ARGB32*' { return 'ARGB32' }

    # The texture path did not have a flag, so use the fallback compression set.
    default     { if ($FallbackCompress -eq 'DXT1/DXT5')
                  {
                    # Select DXT1 or DXT5 based on whether or not the texture has alpha.
                    switch ($HasAlpha)
                    {
                      $true  { return 'DXT5' }
                      $false { return 'DXT1' }
                    }
                  }
                  # If DXT5, BC7, or ARGB32 is set, simply return which one was selected.
                  else
                  {
                    return $FallbackCompress
                  }
                }
  }
}
#==============================================================================================================================================================================================
#  If a texture is to be converted to DDS, this sets the type of block compression. The compression can be forced using the "Defined" option.

function SetDDSBlockCompressionType([string]$ImagePath, [bool]$HasAlpha)
{
  # The variable "$DDSBlkCompress" references the item that is selected from the GUI labelled "DDS Compression".
  switch ($DDSBlkCompress)
  {
    # Selectively choose DXT1 for opaque textures, and DXT5 for textures with transparency.
    'DXT1/DXT5'     { switch ($HasAlpha)
                      {
                        $true  { return 'DXT5' }
                        $false { return 'DXT1' }
                      }
                    }
    # If the user wants to define textures individually, find the format to convert the texture.
    'User Defined'  { return (GetDefinedDDSBlockCompression -ImagePath $ImagePath -HasAlpha $HasAlpha)}

    # We can just return the value if it's DXT5, BC7, or ARGB32.
    default         { return $DDSBlkCompress }
  }
}
#==============================================================================================================================================================================================
#  DOCUMENTATION: TEXTURE HASH TABLE
#==============================================================================================================================================================================================
#  When a texture is ran through the main loop, a global hash table is created for the current texture called "$Texture". Many of this script's functions rely on this global hash table 
#  and are designed around having its data readily available. Each iteration of the loop creates a new hash table for the current texture and discards the data from the last one.
#  Eventually this hash table and all supporting functions was rewritten to be more dynamic, in that it can be created for any image file at any time.
#  Below is a list of all information that can be retrieved when a hash table for the current texture has been created.
#
#  $Texture.Name                 - string    -  The name of the texture without the extension.
#  $Texture.FullName             - string    -  The name of the texture with the file extension.
#  $Texture.Extension            - string    -  The file extension of the texture file.
#  $Texture.Path                 - string    -  The path to where the texture is currently located, minus the texture name.
#  $Texture.PathName             - string    -  The full path to the texture including the texture name without the file extension.
#  $Texture.FullPath             - string    -  The full path to the texture including the texture name with the file extension.
#  $Texture.Relative             - string    -  The relative path to the texture, which is the Path minus the MasterInputPath (location of the script).
#  $Texture.ImageFormat          - string    -  Mostly for DDS textures, holds the block compression type (DXT1/DXT3/DXT5/BC7). For PNG and JPG images it will hold (PNG/JPG).
#  $Texture.DolphinFormat        - boolean   -  Stores true or false whether or not the texture is in Dolphin's texture format (starts with "tex1").
#  $Texture.Size                 - integer   -  The file size of the texture in Bytes.
#  $Texture.Width                - integer   -  The width of the custom texture.
#  $Texture.Height               - integer   -  The height of the custom texture.
#  $Texture.Aspect               - decimal   -  The aspect of the custom texture (Width/Height)
#  $Texture.Dimensions           - string    -  The full dimensions of the custom texture in the form of (Width x Height).
#  $Texture.OldWidth             - integer   -  The width of the original texture.
#  $Texture.OldHeight            - integer   -  The height of the original texture.
#  $Texture.OldAspect            - decimal   -  The aspect of the original texture (OldWidth/OldHeight)
#  $Texture.OldDimensions        - string    -  The full dimensions of the original texture in the form of (OldWidth x OldHeight).
#  $Texture.ScaleWidth           - decimal   -  The width scale of the custom texture (Width/OldWidth).
#  $Texture.ScaleHeight          - decimal   -  The height scale of the custom texture (Height/OldHeight).
#  $Texture.FullScale            - string    -  The full scale of the texture in the form of "ScaleWidth x ScaleHeight" (but no spaces in between).
#  $Texture.IsMipMap             - boolean   -  Stores true or false of whether or not the texture is a MipMap texture.
#  $Texture.IsGrayScale          - boolean   -  Stores true or false of whether or not the texture is a grayscale texture.
#  $Texture.HasAlphaPixels       - boolean   -  Stores true or false of whether or not the texture has any transparent pixels.
#  $Texture.HasMaterialMap       - boolean   -  Stores true or false of whether or not the texture has a supplied material map (nrm) texture.
#  $Texture.ColorIsLum           - boolean   -  Stores whether or not the color texture has the Ishiiruka (_lum) suffix.
#  $Texture.MaterialMapPath      - string    -  The full path to the texture's supplied material map.
#  $Texture.HasMaterials         - boolean   -  Stores true or false of whether or not the texture has supplied materials (bump/spec/lum/nrm) textures.
#  $Texture.MaterialMapType      - string    -  If the texture has a material map store the file extension.
#  $Texture.PNGColorType         - string    -  If the texture is to be converted to PNG, stores the type of PNG (0, 2, 4, or 6).
#  $Texture.PNGColorSpace        - string    -  If the texture is to be converted to PNG, stores the color space (Gray, GrayA, RGB, or RGBA).
#  $Texture.PNGBitDepth          - string    -  If the texture is to be converted to PNG, stores the bit depth (8, 16, 24, or 32).
#  $Texture.DDSCompression       - string    -  If the texture is to be converted to DDS, stores the compression type. DXT1-Opaque, DXT5-Transparency
#  $Texture.DDSQualityLevel      - string    -  If the texture is to be converted to DDS, stores which quality level to feed DDS Utilities.
#==============================================================================================================================================================================================
#  TEXTURE CREATION: TEXTURE HASH TABLE
#==============================================================================================================================================================================================
#  The global texture hash table that is created every iteration of the main loop. The BypassTildeCheck allows images in paths containing "~" to pass validation. This is basically just
#  a trash work-around to allow textures in the ~CTT_Generated folder to be viewed in the Basic Image Viewer, since that function relies on texture info. The parameter is optional, and
#  defaults to false. The $File parameter is not an explicit type for the reason texture info can be created from all kinds of types (strings, directories, objects, etc).

function CreateTextureInfo($File, [bool]$BypassTildeCheck = $false)
{
  # Initialize the texture hash table.
  $TextureInfo = @{}

  # Get the path to the texture.
  $TextureInfo.Path = [string]$File.Directory

  # To greatly speed up skipping generated folders with lots of files, immediately fail if a tilde is found (unless the check is bypassed).
  if (($TextureInfo.Path -like '*~*') -and (!$BypassTildeCheck)) { return $null }

  # Create strings referencing texture name/path data.
  $TextureInfo.Name      = $File.BaseName
  $TextureInfo.FullName  = $File.Name
  $TextureInfo.Extension = $File.Extension
  $TextureInfo.PathName  = $TextureInfo.Path + '\' + $TextureInfo.Name
  $TextureInfo.FullPath  = $TextureInfo.Path + '\' + $TextureInfo.FullName
  $TextureInfo.Relative  = $TextureInfo.Path.Replace($MasterInputPath,'')

  # Stores if the current texture is in the format Dolphin uses.
  $TextureInfo.DolphinFormat = ($TextureInfo.Name -like 'tex1_*')

  # Get all the various material map information from a hash table.
  $MatMapInfo = GetMaterialMapInfo $TextureInfo

  # Copy all data from the MatMapInfo hash table into the TextureInfo hash table.
  $TextureInfo.HasMaterials    = $MatMapInfo.HasMaterials
  $TextureInfo.HasMaterialMap  = $MatMapInfo.HasMaterialMap
  $TextureInfo.MaterialMapPath = $MatMapInfo.MaterialMapPath
  $TextureInfo.MaterialMapType = $MatMapInfo.MaterialMapType
  $TextureInfo.ColorIsLum      = $MatMapInfo.ColorIsLum

  # Test the texture for validity (corruption, errors, not an image, etc). If it fails, return null.
  if (!(ValidateTexture $TextureInfo)) {return $null}

  # If the texture was successfully validated, set the texture size in Bytes.
  $TextureInfo.Size = ($File | Measure-Object -Property 'length' -Sum).Sum

  # Check for "m" to see if it is a MipMap texture.
  $TextureInfo.IsMipMap = ($TextureInfo.Name -like '*_m_*')

  # Get the details of the texture as a hash table that contains stuff like dimensions, alpha, transparency, and grayscale.
  $ImageInfo = GetImageInfo -ImagePath $TextureInfo.FullPath -HasMaterial $TextureInfo.HasMaterialMap

  # Stores the number of mipmaps found. Counted for PNG/JPG textures, pulled from the header for DDS textures.
  $TextureInfo.MipMaps = $ImageInfo.MipMaps

  # Mostly for DDS textures, holds the block compression type (DXT1/DXT3/DXT5/BC7/ARGB32). For PNG and JPG images it will hold (PNG/JPG).
  $TextureInfo.ImageFormat = $ImageInfo.ImageFormat

  # Get the custom texture width, height, combined dimensions, and aspect.
  $TextureInfo.Width      = $ImageInfo.Width
  $TextureInfo.Height     = $ImageInfo.Height
  $TextureInfo.Dimensions = $TextureInfo.Width.ToString() + 'x' + $TextureInfo.Height.ToString()
  $TextureInfo.Aspect     = [decimal](FormatDecimal -Value ($TextureInfo.Width/$TextureInfo.Height))

  # Store whether or not the custom texture is grayscale and actually contains transparent pixels.
  $TextureInfo.IsGrayScale    = $ImageInfo.Gray
  $TextureInfo.HasAlphaPixels = $ImageInfo.Alpha

  # If it's a Dolphin texture (meaning the name starts with "tex1_"), the original dimensions can be retrieved from the name.
  if ($TextureInfo.DolphinFormat)
  {
    # Get the original texture width/height by splitting the texture name by "_" and "x".
    $OldDimensions         = $TextureInfo.Name.Split('_x',5)
    $TextureInfo.OldWidth      = [int]$OldDimensions[2]
    $TextureInfo.OldHeight     = [int]$OldDimensions[3]
    $TextureInfo.OldDimensions = $TextureInfo.OldWidth.ToString() + 'x' + $TextureInfo.OldHeight.ToString()
    $TextureInfo.OldAspect     = [decimal](FormatDecimal -Value ($TextureInfo.OldWidth/$TextureInfo.OldHeight))
  }
  # If not a Dolphin texture (meaning "AllowAllImages" is enabled), the original dimensions can't be retrieved.
  else
  {
    # Set the "original" dimensions to the texture's "current" dimensions.
    $TextureInfo.OldWidth      = $TextureInfo.Width
    $TextureInfo.OldHeight     = $TextureInfo.Height
    $TextureInfo.OldDimensions = $TextureInfo.Dimensions
    $TextureInfo.OldAspect     = $TextureInfo.Aspect
  }
  # Calculate the custom texture scaling compared to the original texture.
  $TextureInfo.ScaleWidth  = [decimal](FormatDecimal -Value ($TextureInfo.Width/$TextureInfo.OldWidth))
  $TextureInfo.ScaleHeight = [decimal](FormatDecimal -Value ($TextureInfo.Height/$TextureInfo.OldHeight))
  $TextureInfo.FullScale   = ($TextureInfo.ScaleWidth.ToString() + 'x' + $TextureInfo.ScaleHeight.ToString())

  # Get info about the texture as if it were a PNG image.
  $PNGData = GetPNGInfo $TextureInfo

  # Copy all PNG hash table shit into the texture hash table.
  $TextureInfo.PNGColorType  = $PNGData.ColorType
  $TextureInfo.PNGColorSpace = $PNGData.ColorSpace
  $TextureInfo.PNGBitDepth   = $PNGData.BitDepth

  # Set the compression format for DDS textures.
  $TextureInfo.DDSCompression  = (SetDDSBlockCompressionType -ImagePath $TextureInfo.FullPath -HasAlpha $TextureInfo.HasAlphaPixels)

  # Return the texture data so it can be set to a global and used basically everywhere in the script.
  return $TextureInfo
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: MISCELLANEOUS MIPMAP FUNCTIONS
#==============================================================================================================================================================================================
#  Calculates how many MipMap levels a texture should have based on the input dimension.

function CalculateMipMapLevels([int]$Dimension)
{
  # Continue to divide the width or height by 2 until 1 (or lower) is hit.
  while($Dimension -gt 1)
  {
    # Perform the calculation as a decimal to remain as accurate as possible.
    $HalvedDimension = [decimal]($Dimension / 2)

    # Divide the dimension in half, and fix the decimal for other regions.
    $NewDimension = FormatDecimal -Value $HalvedDimension

    # Split the value so the decimal can be dropped (and not rounded).
    $NewDimensionSplit = $NewDimension.ToString().Split('.',2)

    # Keep only the integer value for the next iteration.
    $Dimension = [int]$NewDimensionSplit[0]

    # Increment the number of levels.
    $Levels ++
  }
  # Return the number of levels calculated.
  return $Levels
}
#==============================================================================================================================================================================================
#  Loop to calculate a single dimension of a MipMap based on the MipMap's current level.

function CalculateMipMapDimension([int]$Level, [int]$Dimension)
{
  # Continue the loop until the loop iteration reaches the MipMap level.
  for($i=1; $i -le $Level; $i++)
  {
    # Make sure the dimension is not less than or equal to 1. Less than 1 shouldn't ever happen, but just in case.
    if ($Dimension -gt 1)
    {
      # Perform the calculation as a decimal to remain as accurate as possible.
      $HalvedDimension = [decimal]($Dimension / 2)

      # Divide the dimension in half, and fix the decimal for other regions.
      $NewDimension = FormatDecimal -Value $HalvedDimension

      # Split the value so the decimal can be dropped (and not rounded).
      $NewDimensionSplit = $NewDimension.ToString().Split('.',2)

      # Keep only the integer value for the next iteration.
      $Dimension = [int]$NewDimensionSplit[0]
    }
  }
  # Return the calculated dimension.
  return $Dimension
}
#==============================================================================================================================================================================================
#  Detects if a texture has custom mipmaps provided. SearchType type takes: Internal, External, or Both

function TextureHasCustomMipMaps([string]$ImagePath, [string]$SearchType)
{
  # Get the image as an object and get the path it is located in.
  $ImageFile = Get-Item -LiteralPath $ImagePath
  $Directory = [string]$ImageFile.Directory

  # Search for external mipmaps if the search type is "External" or "Both".
  if ($SearchType -ne 'Internal')
  {
    # Create a name with the mip suffix and a wildcard.
    $MipMapNameCheck = $ImageFile.BaseName + '_mip*'

    # Search for external mipmaps in the image directory.
    foreach($MipMap in Get-ChildItem -LiteralPath $Directory)
    {
      # See if an image matches the name of a mipmap.
      if ($Mipmap.BaseName -like $MipMapNameCheck)
      {
        # There is at least one mipmap so return true.
        return $true
      }
    }
  }
  # If it's a DDS file, and looking for internal mipmaps, read the header to see if it has internal mipmaps.
  if (($SearchType -ne 'External') -and ($ImageFile.Extension -eq $DDS))
  {
    # Get the image as a byte array.
    $ByteArray = [System.IO.File]::ReadAllBytes($ImagePath)

    # Get the value of the mipmap flag.
    if ($ByteArray[28] -gt 1)
    {
      # If it's greater than 1, there are mipmaps.
      return $true
    }
  }
  # Looks like there are not any mipmaps.
  return $false
}
#==============================================================================================================================================================================================
function CountExternalMipMaps([string]$ImagePath)
{
  # Get the image as an object and get the path it is located in.
  $ImageFile = Get-Item -LiteralPath $ImagePath
  $Directory = [string]$ImageFile.Directory

  # The counter variable.
  $MipMapCount = 1

  # Create a name with the mip suffix and a wildcard.
  $MipMapNameCheck = $ImageFile.BaseName + '_mip*'

  # Search for external mipmaps in the image directory.
  foreach($MipMap in Get-ChildItem -LiteralPath $Directory)
  {
    # See if an image matches the name of a mipmap.
    if ($Mipmap.BaseName -like $MipMapNameCheck)
    {
      # There is at least one mipmap so return true.
      $MipMapCount += 1
    }
  }
  # Looks like there are not any mipmaps.
  return $MipMapCount
}
#==============================================================================================================================================================================================
#  DOCUMENTATION: MIPMAP HASH TABLE
#==============================================================================================================================================================================================
#  Creates MipMap information based on the input dimensions and the texture currently stored in the global hash table.
#  Only the name/path information is pulled from the texture hash table, the rest of the information is dynamically created from the input dimensions.
#
#  The number of mipmaps [#] in the array is determined by the number of $MipMap.Levels.
#
#  $MipMap.Levels             - integer -  The number of levels calculated from the input dimensions. Also defines the size of the MipMap array.
#  $MipMap.Name[#]*           - string  -  The name of the MipMap without the extension. 
#  $MipMap.FullName[#]*       - string  -  The name of the MipMap with the file extension.
#  $MipMap.FullPath[#]*       - string  -  The full path to the MipMap including the MipMap + file extension.
#  $MipMap.Size[#]*           - integer -  The file size of the MipMap in Bytes. Currently unused in any functions.
#  $MipMap.Width[#]           - string  -  The calculated width of the MipMap based on the input dimensions.
#  $MipMap.Height[#]          - string  -  The calculated height of the MipMap based on the input dimensions.
#  $MipMap.Dimensions[#]      - string  -  The calculated full dimensions of the MipMap in the form of Width x Height.
#  $MipMap.Exists[#]*         - boolean -  Notifies whether or not the mipmap actually exists. 
#  $MipMap.RealWidth[#]*      - string  -  The actual width of the MipMap if it exists.
#  $MipMap.RealHeight[#]*     - string  -  The actual height of the MipMap if it exists.
#  $MipMap.RealDimensions[#]* - string  -  The actual full dimensions of the MipMap in the form of Width x Height.
#  $MipMap.LevelsCounted*     - integer -  The number of MipMap levels found based on the name of the current texture.
#  $MipMap.LevelsMissing*     - integer -  The number of MipMap levels that are missing based on the name of the current texture.
#  $MipMap.BadDimensions*     - integer -  The number of MipMap levels where "Dimensions" don't match up with "RealDimensions"
#  $MipMap.Final*             - integer -  The index of the final mipmap in the chain of mipmaps provided with the texture pack.
#
#  * This data is created based on the current texture hash table. All other information is derived from the input dimensions.
#==============================================================================================================================================================================================
#  TEXTURE CREATION: MIPMAP HASH TABLE
#==============================================================================================================================================================================================

function CreateMipMapInfo([hashtable]$TextureInfo, [int]$Width, [int]$Height)
{
  # Initialize the MipMap hash table.
  $MipMapInfo = @{}

  # Store how many MipMap levels the texture should have based on the largest dimension.
  $MipMapInfo.Levels = CalculateMipMapLevels -Dimension ([System.Math]::Max($Width, $Height))

  # For now assume that no mipmaps exist, and that none are missing (sounds like a catch 22).
  $MipMapInfo.LevelsCounted = 0
  $MipMapInfo.LevelsMissing = 0

  # Initialize an array to store information about each individual MipMap. ArraySize must be (+1) to start with index[1] instead of [0].
  $ArraySize = ($MipMapInfo.Levels + 1)
  $MipMapInfo.Name           = New-Object string[] $ArraySize
  $MipMapInfo.FullName       = New-Object string[] $ArraySize
  $MipMapInfo.FullPath       = New-Object string[] $ArraySize
  $MipMapInfo.Width          = New-Object int[]    $ArraySize
  $MipMapInfo.Height         = New-Object int[]    $ArraySize
  $MipMapInfo.Dimensions     = New-Object string[] $ArraySize
  $MipMapInfo.Exists         = New-Object bool[]   $ArraySize
  $MipMapInfo.RealWidth      = New-Object int[]    $ArraySize
  $MipMapInfo.RealHeight     = New-Object int[]    $ArraySize
  $MipMapInfo.RealDimensions = New-Object string[] $ArraySize
  $MipMapInfo.Size           = New-Object int[]    $ArraySize

  # Store information about each MipMap. Start with index [1] instead of [0] for the sake of simplicity.
  # This means that $MipMapInfo[0] will never contain anything, so there is no reason to ever reference it.
  # Example: "mipmap.Variable[3]" will reference "tex1_128x128_m_e3487d3b2a9d3e11_14_mip3"
  for($i = 1; $i -le $MipMapInfo.Levels; $i++)
  {
    # Set up basic information about MipMap.
    $MipMapInfo.Name[$i]       = $TextureInfo.Name + '_mip' + $i
    $MipMapInfo.FullName[$i]   = $TextureInfo.Name + '_mip' + $i + $TextureInfo.Extension
    $MipMapInfo.FullPath[$i]   = $TextureInfo.PathName + '_mip' + $i + $TextureInfo.Extension
    $MipMapInfo.Width[$i]      = CalculateMipMapDimension -Level $i -Dimension $Width
    $MipMapInfo.Height[$i]     = CalculateMipMapDimension -Level $i -Dimension $Height
    $MipMapInfo.Dimensions[$i] = [string]$MipMapInfo.Width[$i] + 'x' + [string]$MipMapInfo.Height[$i]

    # Check to see if the MipMap exists.
    if (TestPath -LiteralPath $MipMapInfo.FullPath[$i]) 
    {
      # Store that the MipMap exists.
      $MipMapInfo.Exists[$i] = $true

      # Add the current MipMap to the number of mipmaps found.
      $MipMapInfo.LevelsCounted ++

      # Get the MipMap as an object to set the file size of the MipMap in Bytes.
      $MipMapObject = Get-Item -LiteralPath $MipMapInfo.FullPath[$i]
      $MipMapInfo.Size[$i] = ($MipMapObject | Measure-Object -Property 'length' -Sum).Sum

      # Get the dimensions of the texture as a hash table.
      $MipDimensions = GetImageInfo -ImagePath $MipMapInfo.FullPath[$i]

      # Get the dimensions of the MipMap file.
      $MipMapInfo.RealWidth[$i]      = $MipDimensions.Width
      $MipMapInfo.RealHeight[$i]     = $MipDimensions.Height
      $MipMapInfo.RealDimensions[$i] = [string]$MipMapInfo.RealWidth[$i] + 'x' + [string]$MipMapInfo.RealHeight[$i]

      # Compare the calculated dimensions with the real dimensions and count the number that don't match up.
      if ($MipMapInfo.Dimensions[$i] -ne $MipMapInfo.RealDimensions[$i])
      {
        # This is only used when scanning textures for issues in function "CheckMipMapsScale".
        $MipMapInfo.BadDimensions ++
      }
    }
    # If the mipmap does not exist, count the number of mipmaps missing.
    else
    {
      # The number of missing levels is only used when scanning textures for issues in function "CheckMissingMipMaps".
      $MipMapInfo.Exists[$i] = $false
      $MipMapInfo.LevelsMissing ++
    }
  }
  # Stores the index of the last mipmap in the chain if the user provided custom mipmaps.
  $MipMapInfo.Final = 0

  # A loop to search for the last available mipmap in the chain. Searches for custom mipmaps provided by the user and finds where the chain
  # ends. If a mipmap is missing from the chain, the previous mipmap is detected as the "final mipmap". For example, if mip1, mip2, mip3, mip5,
  # mip6, and mip7 exist (mip4 is missing), then mip3 will be set as the last mipmap in the chain and mip5+ will be ignored.
  for($i = 1; $i -le $MipMapInfo.Levels; $i++)
  {
    # Check to see if the current mipmap exists.
    if ($MipMapInfo.Exists[$i])
    {
      # If it does, set the current mipmap's index as the final mipmap in the chain.
      $MipMapInfo.Final = $i
    }
    # The mipmap did not exist.
    else
    {
      # End the loop to preserve the final mipmap found in the chain.
      break
    }
  }
  # Return the MipMap data so it can be set to a variable.
  return $MipMapInfo
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: MIPMAP HASH TABLE - GETTING THE PROPER MIPMAP HASH TABLE
#==============================================================================================================================================================================================
#  Extends the functionality of "CreateMipMapInfo". The priority for the created hash table goes to a DDS texture with internal mipmaps. The internal mipmaps are extracted and stored in a 
#  temporary folder. These mipmaps must be manually cleaned when no longer needed (destroy function)! If no internal mipmaps exist, then create mipmap info from the base texture.

function CreateMipMapInfoPlus([hashtable]$TextureInfo, [int]$Width, [int]$Height)
{
  # If the custom texture is a DDS texture with internal mipmaps, prefer these over all other mipmaps as a base.
  # When the user forces new mipmaps, there is no point in extracting them because they will not be used.
  if (($TextureInfo.Extension -eq $DDS) -and (!$ForceNewMipMaps))
  {
    # Create a folder to extract internal MipMaps to.
    $DDSExtractedMipMapPath = CreatePath -LiteralPath ($TempFolder + '\ExternalDDSMipMaps\')

    # Extract MipMaps from the texture to see if it has internal MipMaps.
    ExtractInternalDDSMipMaps -ImagePath $TextureInfo.FullPath -OutputPath $DDSExtractedMipMapPath

    # Count the number of files that remain in the folder, and subtract 1 to compensate for the top level.
    $DDSLevelsCounted = ([System.IO.Directory]::GetFiles($DDSExtractedMipMapPath).Count) - 1

    # Check to see if there are actually any internal mipmaps to be found.
    if ($DDSLevelsCounted -gt 0)
    {
      # Mipmaps were found so create an entirely new texture hash table based on the temporary texture + mipmaps.
      $NewDDSTextureFile = $DDSExtractedMipMapPath + $TextureInfo.FullName
      $NewDDSTextureInfo = CreateTextureInfo -File (Get-Item -LiteralPath $NewDDSTextureFile)

      # Create a mipmap hash table based on the temporary texture.
      return (CreateMipMapInfo -TextureInfo $NewDDSTextureInfo -Width $Width -Height $Height)
    }
  }
  # If it's not a DDS texture, DDS Utilities was not found, or new mipmaps were forced, simply create a hash table from the current texture.
  return (CreateMipMapInfo -TextureInfo $TextureInfo -Width $Width -Height $Height)
}
#==============================================================================================================================================================================================
#  Cleans out any temporary DDS mipmaps that were extracted with the above function.

function DestroyMipMapInfoPlus()
{
  RemovePath -LiteralPath ($TempFolder + '\ExternalDDSMipMaps\')
}
#==============================================================================================================================================================================================
#  DOCUMENTATION: TEXTURE CREATION FUNCTIONS
#==============================================================================================================================================================================================
#  There are a lot of texture creation functions, and all of them link back to a single function. The master function is "CreateTexture". The texture hash table it takes is created from the
#  function "CreateTextureInfo". This allows it to take any texture hash table created with "CreateTextureInfo" rather than confine it to the global hash table "$Texture" which is created in
#  the "MasterLoop" function. Input Width/Height serve as modifiers to the output dimensions. The Format parameter overrides the output format. The Output Path basically explains itself.
#
#  * CreateTexture [hashtable]Texture [int]InputWidth [int]InputHeight [string]Format [string]OutputPath
#
#  Contained within "CreateTexture" is a function that has a common specific use. This function is "CreateStandardTexture", and it can be used when all attributes of the input texture and
#  and resulting texture have nothing to do with Ishiiruka Textures. It ignores material maps, so material map textures will be skipped. It can not handle DDS color textures created by
#  by Ishiiruka Tool. There are specific functions for handling Ishiiruka Textures, in those cases "CreateTexture" will automatically handle when to use them.
#
#  * CreateStandardTexture [hashtable]Texture [int]InputWidth [int]InputHeight [string]Format [string]OutputPath
#
#  There are three Material Map functions that can be called in "CreateTexture". Any of these can be called externally from CreateTexture to fit a specific situation relating to materials. 
#  Function "CreateMaterialMap_FromMaterial" creates a new material map from an existing material map. Dimensions and Format serve as modifiers to the resulting texture.
#  Function "CreateMaterialMap_FromTextures" creates a new material map from bump/spec/nrm/lum textures. Dimensions and Format serve as modifiers to the resulting texture.
#  Function "ConvertMaterialMap_DolphinFormat" converts textures created with Ishiiruka Tool, into a texture created from ImageMagick. Material maps are not created.
#
#  * CreateMaterialMap_FromMaterial   [hashtable]Texture [int]InputWidth [int]InputHeight [string]Format [string]OutputPath
#  * CreateMaterialMap_FromTextures   [hashtable]Texture [int]InputWidth [int]InputHeight [string]Format [string]OutputPath
#  * ConvertMaterialMap_DolphinFormat [hashtable]Texture [int]InputWidth [int]InputHeight [string]Format [string]OutputPath
#
#  All other texture creation functions from this section of the script should probably not be called directly as their purpose is to directly support the above functions.
#==============================================================================================================================================================================================
#  TEXTURE CREATION: SHARPENING
#==============================================================================================================================================================================================
#  When texture sizes change with ImageMagick, a sharpening filter is applied so the resulting texture doesn't look like trash.
#  The amount of sharpening is determined by the % of difference between both width and height, which is then averaged out.
#  For example, the new texture is 38% smaller than the texture it is being created from, so a value of 0x0.38 strength is fed to ImageMagick.

function CalculateSharpenStrength([int]$BaseWidth, [int]$BaseHeight, [int]$ModWidth, [int]$ModHeight)
{
  # Calculate the percentage of difference between the smallest and largest dimensions.
  [decimal]$CalcWidth  = [System.Math]::Min($BaseWidth, $ModWidth) / [System.Math]::Max($BaseWidth, $ModWidth)
  [decimal]$CalcHeight = [System.Math]::Min($BaseHeight, $ModHeight) / [System.Math]::Max($BaseHeight, $ModHeight)

  # Subtract 1 from average of the two values previously found (which reverses the %, for example 60% becomes 40%).
  $Strength = FormatDecimal -Value (1 - (($CalcWidth + $CalcHeight) / 2))

  # See if the value is above 60% (this is not actually 60% sharpening, its just convenient the values work so great).
  if ([decimal]$Strength -gt 0.60)
  {
    # Cap the strength at 0.60 or else the image may look "over sharpened".
    $Strength = '0.60'
  }
  # Return the average as the amount of sharpening.
  return '0x' + $Strength
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: MIPMAP FINDER
#==============================================================================================================================================================================================
#  Find which texture to use as the mipmap base image whenever a texture containing mipmaps is created (for all formats: PNG/JPG/DDS).

function GetMipMapBaseImage([hashtable]$MipMapInfo, [int]$Index, [string]$ImageFallback)
{
  # Check to see if new mipmaps were forced.
  if (!$ForceNewMipMaps)
  {
    # See if the mipmap exists in the texture pack.
    if ($MipMapInfo.Exists[$Index])
    {
      # If it exists, use it as the mipmap base.
      return $MipMapInfo.FullPath[$Index]
    }
    # If the user did not force mipmaps from the top level, and a "final" level exists.
    elseif ((!$MipMapTopLevelBase) -and ($MipMapInfo.Final -gt 0))
    {
      # Return the final level that was found and use that as the mipmap base.
      return $MipMapInfo.FullPath[$MipMapInfo.Final]
    }
  }
  # The mipmap does not exist, the user forced new ones, or the user wants to create them from the top level.
  return $ImageFallback
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: PNG/JPG
#==============================================================================================================================================================================================
function CreatePNGTextureSingle([hashtable]$TextureInfo, [string]$ImagePath, [int]$Width, [int]$Height, [string]$Format, [string]$OutputPath, [string]$ForcedName='')
{
  # Get just the name of the input image.
  $ImageName = (Get-Item -LiteralPath $ImagePath).BaseName

  # Get the dimensions of the image that is being fed to the function.
  $ImageSize = GetImageInfo -ImagePath $ImagePath

  # A new name for the image can be forced. Check to see if it has been forced.
  switch ($ForcedName)
  {
     # The output image path to where the new texture will be created.
    ''      { $OutputImage = $OutputPath + '\' + $ImageName + $Format }
    default { $OutputImage = $OutputPath + '\' + $ForcedName + $Format }
  }
  # If its a BC7 texture, only TexConv can convert it.
  if ((TestPath -LiteralPath $TexConvTool) -and ($TextureInfo.ImageFormat -eq 'BC7'))
  {
    # TexConv has issues creating PNG images from BC7 images (when converted again, they become dark). So the image created
    # with TexConv will be again converted with ImageMagick. I know this inefficient, but I know of no other work around.
    $TexConvTemp = CreatePath -LiteralPath ($TempFolder + '\TexConvPNG')

    # The PNG created by TexConv has issues, so it's going to be recreated later by ImageMagick.
    $NewImagePath = $TexConvTemp + '\' + $ImageName + $PNG

    # Create the temporary image as a PNG file from the BC7 file.
    $ToolOutput = RunTexConvTool -Image $ImagePath -Arguments @('-y', '-ft', 'PNG', '-f', 'R8G8B8A8_UNORM') -OutputPath $TexConvTemp

    # Make the image path point to the new image.
    $ImagePath = $NewImagePath

    # Debug: Track if a temp image had to be generated.
    DebugMessage -Message 'Using PNG Tool: TexConv - This is a work-around to convert a BC7 texture!'
    DebugMessage -Message $ToolOutput
  }
  # For the sake of not making this ugly, store ImageMagick arguments in variables.
  $Dimensions = $Width.ToString() + 'x' + $Height.ToString() + '!'
  $ColorType  = 'png:color-type=' + $TextureInfo.PNGColorType
  $Sharpening = CalculateSharpenStrength -BaseWidth $ImageSize.Width -BaseHeight $ImageSize.Height -ModWidth $Width -ModHeight $Height

  # Show the tool that is being used to create the image.
  DebugMessage -Message 'Using PNG Tool: ImageMagick'

  # Create the PNG image with ImageMagick.
  $ToolOutput = Magick-Convert -Image $ImagePath -Arguments @('-resize', $Dimensions, '-define', $ColorType, '-sharpen', $Sharpening) -Output $OutputImage

  # Clean up the feces that this function left behind.
  RemovePath -LiteralPath $TexConvTemp

  # Debug: Show the output of the tool.
  DebugMessage -Message $ToolOutput
}
#==============================================================================================================================================================================================
#  Sub-function of "CreatePNGTexture" to create mipmaps for PNG or JPG textures. This is available as a stand-alone function so other parts
#  of the script (such as applying upscaling filters) can make use of it without having to go through the entire "CreateTexture" process.

function CreatePNGTextureMipMaps([hashtable]$TextureInfo, [string]$ImagePath, [int]$Width, [int]$Height, [string]$Format, [string]$OutputPath)
{
  # Create a mipmap hash table.
  $MipMapInfo = CreateMipMapInfoPlus -TextureInfo $TextureInfo -Width $Width -Height $Height

  # This option allows forcing the number of mipmaps to generate.
  switch ($MaxMipMapEnabled)
  {
    $true   { $MipMapLevels = [int]$MaxMipMapLevels }
    $false  { $MipMapLevels = $MipMapInfo.Levels }
  }
  # Loop through all levels.
  for($i=1; $i -le $MipMapLevels; $i++)
  {
    # Set the image that will be used as the new mipmap.
    $MipMapBase = GetMipMapBaseImage -MipMapInfo $MipMapInfo -Index $i -ImageFallback $ImagePath

    # Generate the new MipMap.
    CreatePNGTextureSingle -TextureInfo $TextureInfo -ImagePath $MipMapBase -Width $MipMapInfo.Width[$i] -Height $MipMapInfo.Height[$i] -Format $Format -OutPutPath $OutputPath -ForcedName $MipMapInfo.Name[$i]
  }
  # Destroy the folder with internal mipmaps if it exists.
  DestroyMipMapInfoPlus
}
#==============================================================================================================================================================================================
#  Sub-function of "CreateStandardTexture" to create a PNG or JPG texture.

function CreatePNGTexture([hashtable]$TextureInfo, [int]$Width, [int]$Height, [string]$Format, [string]$OutputPath)
{
  # Create the PNG image.
  CreatePNGTextureSingle -TextureInfo $TextureInfo -ImagePath $TextureInfo.FullPath -Width $Width -Height $Height -Format $Format -OutPutPath $OutputPath

  # Check if it is a MipMap texture, or a non-Dolphin texture that has mipmaps forced or has at least one custom mipmap supplied.
  if (($TextureInfo.IsMipMap) -or ((!$TextureInfo.DolphinFormat) -and (($ForceCreateMipMaps) -or ($TextureInfo.MipMaps -gt 1))))
  {
    # If it is, then generate MipMaps.
    CreatePNGTextureMipMaps -TextureInfo $TextureInfo -ImagePath $TextureInfo.FullPath -Width $Width -Height $Height -Format $Format -OutputPath $OutputPath
  }
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: DDS DIMENSION CALCULATIONS
#==============================================================================================================================================================================================
#  To use, set "DDSMultFour" as a hashtable variable. This tests if the input dimensions are a multiple of four, and returns a hash table that
#  supplies the corrected Width and Height and the combined dimensions. Data is retrieved with "Var.Width" "Var.Height" or "Var.Dimensions".

function DDSMultFour([int]$Width, [int]$Height)
{
  # Create and store the values using a hash table.
  $DDSData = @{}

  # Calculate the nearest multiple of 4 for width and height.
  $DDSData.Width  = $Width + 4 - 1 - (($Width + 4 - 1) % 4)
  $DDSData.Height = $Height + 4 - 1 - (($Height + 4 - 1) % 4)

  # Store the combined width and height into a string separated by an "x".
  $DDSData.Dimensions = $DDSData.Width.ToString() + 'x' + $DDSData.Height.ToString()

  # Return the hash table data.
  return $DDSData
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: HACK FIX FOR TEXCONV AND COMPRESSONATOR (REQUIRES TEXCONV)
#==============================================================================================================================================================================================
#  While working on CTT-PS v25.0, I realized that the garbage hacks started to pile up, so I rewrote ALL of the texture generation logic. This allowed me to remove all the hacky
#  work-arounds and actually speed up texture creation! But one hack must remain, and that is this pile of code. TexConv is an essential program for BC7 related tasks, and I found
#  that it fails to read some images, mostly DDS DXT1 images. So, create a temporary image from the "bad" image using ImageMagick and feed that to TexConv. If for some odd reason
#  ImageMagick fails to recreate the image, we're basically fucked and the image will not be created. It's hard to say who or what is truly at fault.

function ReadAndFixTexture([hashtable]$TextureInfo, [string]$ImagePath, [string]$TempPath)
{
  # Unfortunately this hack requires TexConv. I could test Compressonator, but it would be slow because it does not have a way to resize images.
  if (!(TestPath -LiteralPath $TexConvTool)) { return $ImagePath }

  # The texture that is returned at the end. We're going to assume the input image is good for now.
  $ReturnImage = $ImagePath

  # Create a folder to generate a test texture. Use the "TexConv" folder created in the "DDSTool_TexConv" function so its automatically cleaned.
  $TestFolder = CreatePath -LiteralPath ($TempPath + '\TestTexConv')

  # Try to create a test image with TexConv and capture the output the program would usually print to the console (that I hide from the users).
  $TexConvOutput = RunTexConvTool -Image $ImagePath -Arguments @('-y', '-ft', 'PNG', '-w', '1', '-h', '1') -OutputPath $TestFolder

  # The image was not created, so TexConv can't read the texture. Try to create a temporary replacement with ImageMagick.
  if ($TexConvOutput -like '*FAILED*')
  {
    # Set up a path for the temporary texture. Use the "TexConv" folder created in the "DDSTool_TexConv" function so its automatically cleaned.
    $NewImageTemp = CreatePath -LiteralPath ($TempPath + '\FixedTexture')

    # Create a reference to the new texture.
    $NewImagePath = $NewImageTemp + '\' + (Get-Item -LiteralPath $ImagePath).BaseName + $TextureInfo.Extension

    # ImageMagick must work. If it doesn't, we're shit out of luck and something is going to fail somewhere.
    Magick-Convert -Image $ImagePath -Output $NewImagePath | Out-Null

    # Blindly return the texture, hoping it worked and nothing breaks.
    $ReturnImage = $NewImagePath

    # Debug: Track whenever this function was used.
    DebugMessage -Message 'ReadAndFixTexture hack was used!'
  }
  # Return whatever texture was set to this value.
  return $ReturnImage
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: FIX FOR STOOPID COMPRESSENATOR HEADERZ
#==============================================================================================================================================================================================
#  Don't like profanity snowflake? Then don't read my fucking shitty ass code.

function FixCompressonatorFuckUp([string]$ImagePath)
{
  # Gonna need one of these.
  $ByteArray = [System.IO.File]::ReadAllBytes($ImagePath)

  # AMD failed to set the all the flags.
  $ByteArray[8]  = 7    # DDSD_CAPS missing - Compressonator sets a 6 here - DDSD_HEIGHT (2) + DDSD_WIDTH (4)
  $ByteArray[9]  = 16   # DDSD_PIXELFORMAT missing, basically saying skip almost half the header...
  $ByteArray[10] = 10   # DDSD_MIPMAPCOUNT + DDSD_LINEARSIZE missing

  # Overwrite the image with this one.
  [System.IO.File]::WriteAllBytes($ImagePath, $ByteArray)

  # I could really go for a piece of pumpkin pie. With ice cream and Cool Whip®.
  DebugMessage -Message 'Compressonator header fix applied!'
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: DDS GENERATION TOOLS
#==============================================================================================================================================================================================
#  Compressonator can create arguably the highest quality images for any DDS format, but it is not without its fair share of issues. It can not work with textures that are already in
#  a DDS format, and it can not resize images. In these cases, a temporary PNG is generated with another tool (so no quality is lost). It also fails to create smaller images at times,
#  and I'm not quite sure why that happens. In this case, the script is smart enough to fall back to another tool to attempt to create any images Compressonator fails to create.

function DDSTool_Compressonator([hashtable]$TextureInfo, [string]$ImagePath, [int]$Width, [int]$Height, [int]$MipMapLevels, [string]$OutputImage)
{
  # Debug: Track the tool being used.
  DebugMessage -Message 'Using DDS Tool - Compressonator'

  # Set up the series of checks in a variable array.
  $RunConditions = New-Object bool[] 1

  # Go through and store the result of each check into the array.
  $RunConditions[0] = (TestPath -LiteralPath $Compressonator)

  # Test the array of conditions.
  if (!(TestBooleanArray -Array $RunConditions)) { return }

  # Create a reference to the temporary texture path. 
  $TempCompressPath = CreatePath -LiteralPath ($TempFolder + '\Compressonator')

  # Compressonator fails reading some images. Make sure this does not happen by using this work around.
  $ImagePath = ReadAndFixTexture -TextureInfo $TextureInfo -ImagePath $ImagePath -TempPath $TempCompressPath

  # Grab the dimensions of the image. Compressonator can not rescale images so it must be done with something else first.
  $Dimensions = GetImageInfo -ImagePath $ImagePath

  # Compare the input dimensions to the texture dimensions. Also check the extension because Compressonator can not work with DDS textures.
  if (($Width -ne $Dimensions.Width) -or ($Height -ne $Dimensions.Height) -or ($Dimensions.Extension -eq $DDS))
  {
    # Get just the name of the input image.
    $ImageName = (Get-Item -LiteralPath $ImagePath).BaseName

    # Create a PNG file because Compressonator can not have DDS as an input.
    switch ($ForcedName)
    {
      # Set the path to the temporary image. If a name was forced, use that name. It will carry over from the previous function.
      ''      { $TempCompressImage = $TempCompressPath + '\' + $ImageName + $PNG }
      default { $TempCompressImage = $TempCompressPath + '\' + $ForcedName + $PNG }
    }
    # Set up the series of checks in a variable array.
    $IMConditions = New-Object bool[] 4

    # Go through and store the result of each check into the array.
    $IMConditions[0] = ($TextureInfo.ImageFormat -ne 'BC7')
    $IMConditions[1] = ($TextureInfo.ImageFormat -ne 'ARGB32')
    $IMConditions[2] = ($TextureInfo.DDSCompression -ne 'BC7')
    $IMConditions[3] = ($TextureInfo.DDSCompression -ne 'ARGB32')

    # Test the array of conditions.
    if (TestBooleanArray -Array $IMConditions) 
    {
      # Store the new dimensions in ImageMagick format.
      $NewDimensions = $Width.ToString() + 'x' + $Height.ToString() + '!'

      # Resize the image and convert to PNG using ImageMagick.
      Magick-Convert -Image $ImagePath -Arguments @('-resize', $NewDimensions) -Output $TempCompressImage
    }
    # If the input texture is a BC7 image, try to use TexConv if it exists.
    elseif (TestPath -LiteralPath $TexConvTool)
    {
      # Get a link to the texture that TexConv will create.
      $TexConvImage = $TempCompressPath + '\' + $ImageName + $PNG

      # Resize the image and convert to PNG using TexConv.
      RunTexConvTool -Image $ImagePath -Arguments @('-y', '-ft', 'PNG', '-w', $Width, '-h', $Height) -OutputPath $TempCompressPath | Out-Null

      # The item must be renamed to the name that is expected.
      Move-Item -LiteralPath $TexConvImage -Destination $TempCompressImage -Force
    }
    # Set the new path to the image.
    $ImagePath = $TempCompressImage
  }
  # Choose the correct block compression.
  switch ($TextureInfo.DDSCompression)
  {
    DXT1    { $DDSType = 'DXT1' }
    DXT5    { $DDSType = 'DXT5' }
    BC7     { $DDSType = 'BC7' }
    ARGB32  { $DDSType = 'ARGB_8888' }
  }
  # If mipmaps were not specified, create the texture without mipmaps.
  switch ($MipMapLevels)
  {
    '0'     { $ToolOutput = CompressonatorCLI -Image $ImagePath -Arguments @('-fd', $DDSType, '-CompressionSpeed', '0', '-nomipmap') -Output $OutputImage }
    default { $ToolOutput = CompressonatorCLI -Image $ImagePath -Arguments @('-fd', $DDSType, '-CompressionSpeed', '0', '-miplevels', $MipMapLevels) -Output $OutputImage }
  }
  # If the image was created and the output was BC7.
  if ((TestPath -LiteralPath $OutputImage) -and ($Texture.DDSCompression -eq 'BC7'))
  {
    # Fix a huge oversight by AMD.
    FixCompressonatorFuckUp -ImagePath $OutputImage
  }
  # We no longer need this so send it to the netherworld.
  RemovePath $TempCompressPath

  # Debug: Show the output of the tool.
  DebugMessage -Message $ToolOutput
}
#==============================================================================================================================================================================================
#  TexConv is a double edged sword in that it is really fast, convert anything to anything, and even resize images on the fly. But it also creates lower quality textures than both
#  DDS Utilities and Compressonator. It is the only program that can convert BC7 textures to other formats, so it is used even in the Compressonator function if the input texture
#  is a BC7 image. It does not have many bugs that I'm aware of, but it can fail to read some images. I created a small hacky work-around for this situation using ImageMagick.

function DDSTool_TexConv([hashtable]$TextureInfo, [string]$ImagePath, [int]$Width, [int]$Height, [int]$MipMapLevels, [string]$OutputImage)
{
  # Debug: Track the tool being used.
  DebugMessage -Message 'Using DDS Tool - TexConv'

  # Set up the series of checks in a variable array.
  $RunConditions = New-Object bool[] 1

  # Go through and store the result of each check into the array.
  $RunConditions[0] = (TestPath -LiteralPath $TexConvTool)

  # Test the array of conditions.
  if (!(TestBooleanArray -Array $RunConditions)) { return }

  # Create a temporary path to create the image. It will be renamed\moved later.
  $TempTexConvPath = CreatePath -LiteralPath ($TempFolder + '\TexConv')

  # TexConv fails reading some images. Make sure this does not happen by using this work around.
  $ImagePath = ReadAndFixTexture -TextureInfo $TextureInfo -ImagePath $ImagePath -TempPath $TempTexConvPath

  # TexConv considers the top level as a mipmap so add 1 to it.
  $MipMapLevels += 1

  # Choose the correct block compression.
  switch ($TextureInfo.DDSCompression)
  {
    DXT1   { $DDSType = 'BC1_UNORM' }
    DXT5   { $DDSType = 'BC3_UNORM' }
    BC7    { $DDSType = 'BC7_UNORM' }
    ARGB32 { $DDSType = 'B8G8R8A8_UNORM' }
  }
  # Create the texture.
  $ToolOutput = RunTexConvTool -Image $ImagePath -Arguments @('-y', '-ft', 'DDS', '-f', $DDSType, '-w', $Width, '-h', $Height, '-m', $MipMapLevels) -OutputPath $TempTexConvPath

  # We need the name of the image without the extension, but all that is sent is the path. So, resolve the name with Get-Item.
  $TempImagePath = $TempTexConvPath + '\' + (Get-Item -LiteralPath $ImagePath).BaseName + $DDS

  # Because texconv does not allow specifying the output path or renaming the image file, force move/rename the file after it was created.
  Move-Item -LiteralPath $TempImagePath -Destination $OutputImage -Force

  # We no longer need this so send it to the netherworld.
  RemovePath $TempTexConvPath

  # Debug: Show the output of the tool.
  DebugMessage -Message $ToolOutput
}
#==============================================================================================================================================================================================
#  DDS Utilities is a nice program which can create some pretty good quality DXT1/DXT5 textures. It does have the problem that all input dimensions must be a multiple of four. The tool
#  nvdxt does have the ability to prescale the image, and allows dimensions of 1x1 and 2x2. 

function DDSTool_DDSUtilities([hashtable]$TextureInfo, [string]$ImagePath, [int]$Width, [int]$Height, [int]$MipMapLevels, [string]$OutputImage)
{
  # Debug: Track the tool being used.
  DebugMessage -Message 'Using DDS Tool - DDS Utilities'

  # Set up the series of checks in a variable array.
  $RunConditions = New-Object bool[] 5

  # Go through and store the result of each check into the array.
  $RunConditions[0] = (TestPath -LiteralPath $DDSUtilities)
  $RunConditions[1] = ($TextureInfo.ImageFormat -ne 'BC7')
  $RunConditions[2] = ($TextureInfo.ImageFormat -ne 'ARGB32')
  $RunConditions[3] = ($TextureInfo.DDSCompression -ne 'BC7')
  $RunConditions[4] = ($TextureInfo.DDSCompression -ne 'ARGB32')

  # Test the array of conditions.
  if (!(TestBooleanArray -Array $RunConditions)) { return }

  # Mipmaps can be created with dimensions of 1 or 2, so do not round to the nearest multiple of four in this case.
  if (($Width -gt 2) -or ($Height -gt 2))
  {
    # Create a hash table with a multiple of 4 version of the input dimensions.
    $MultFour = DDSMultFour -Width $Width -Height $Height
  }
  # While the tool claims to support up to 8192x4096 images, limit it to only 4096x4096 images.
  $PixelCount = $MultFour.Width * $MultFour.Height

  # Pixel limit of 16,777,216 is the product of 4096*4096.
  if ($PixelCount -lt 16777216)
  {
    # Choose the correct block compression.
    switch ($TextureInfo.DDSCompression)
    {
      DXT1 { $DDSQuality = '-quality_normal' }
      DXT5 { $DDSQuality = '-quality_highest' }
    }
    # DDS Utilities considers the top level as a mipmap so add 1 to it.
    $MipMapLevels += 1

    # If mipmaps were not specified, create the texture without mipmaps.
    switch ($MipMapLevels)
    {
      '0'     { $ToolOutput = DDSUtility-NVDXT -Image $ImagePath -Arguments @($TextureInfo.DDSCompression.ToLower(), $DDSQuality, '-prescale', $MultFour.Width, $MultFour.Height, '-nomipmap') -Output $OutputImage }
      default { $ToolOutput = DDSUtility-NVDXT -Image $ImagePath -Arguments @($TextureInfo.DDSCompression.ToLower(), $DDSQuality, '-prescale', $MultFour.Width, $MultFour.Height, '-nmips', $MipMapLevels) -Output $OutputImage }
    }
  }
  # Debug: Show the output of the tool.
  DebugMessage -Message $ToolOutput
}
#==============================================================================================================================================================================================
#  ImageMagick is very powerful, but it does not support BC7 images. It also creates very bad quality DXT1/DXT5 DDS textures and should not be used unless everything else fails.

function DDSTool_ImageMagick([hashtable]$TextureInfo, [string]$ImagePath, [int]$Width, [int]$Height, [int]$MipMapLevels, [string]$OutputImage)
{
  # Debug: Track the tool being used.
  DebugMessage -Message 'Using DDS Tool - ImageMagick'

  # Set up the series of checks in a variable array.
  $RunConditions = New-Object bool[] 2

  # Go through and store the result of each check into the array.
  $RunConditions[0] = ($TextureInfo.ImageFormat -ne 'BC7')
  $RunConditions[1] = ($TextureInfo.DDSCompression -ne 'BC7')

  # Test the array of conditions.
  if (!(TestBooleanArray -Array $RunConditions)) { return }

  # Choose the correct block compression.
  switch ($TextureInfo.DDSCompression)
  {
    ARGB32  { $DDSCompression = 'dds:compression=none' }
    default { $DDSCompression = 'dds:compression=' + $TextureInfo.DDSCompression.ToLower() }
  }
  # To make this more readable, set up ImageMagick arguments in variables.
  $MipMapDefine   = 'dds:mipmaps=' + $MipMapLevels.ToString()
  $NewDimensions  = $Width.ToString() + 'x' + $Height.ToString() + '!'

  # Luckily entering 'dds:mipmaps=0' disables mipmap levels altogether, so just feed it the $mipmaplevels parameter.
  $ToolOutput = Magick-Convert -Image $ImagePath -Arguments @('-define', $DDSCompression, '-define', $MipMapDefine, '-resize', $NewDimensions) -Output $OutputImage | Out-Null

  # Debug: Show the output of the tool.
  DebugMessage -Message $ToolOutput
}
#==============================================================================================================================================================================================
#  Runs each tool from a list until the texture is created, prioritizing the tool selected by the user.

function CreateDDSOptimalTool([hashtable]$TextureInfo, [string]$ImagePath, [int]$Width, [int]$Height, [int]$MipMapLevels, [string]$OutputPath, [string]$ForcedName='')
{
  # Create a list containing all tools, and another list that only contains the selected tool.
  $ToolList = @('Compressonator', 'DDS Utilities', 'TexConv', 'ImageMagick')
  $Priority = @($DDSCreatorTool)

  # This loop arranges the tools in a list that puts the selected tool at the top.
  foreach($Tool in $ToolList)
  {
    # We already have the selected tool at the top of the list.
    if ($Tool -ne $DDSCreatorTool)
    {
      # Add all the other tools in the order of the list.
      $Priority += $Tool
    }
  }
  # If a new name for the output texture was forced.
  switch ($ForcedName)
  {
    # I used a switch here because I'm a boss.
    ''      { $OutputImage = $OutputPath + '\' + $TextureInfo.Name + $DDS }
    default { $OutputImage = $OutputPath + '\' + $ForcedName + $DDS }
  }
  # Loop through the new list to try to create the image with the selected tool first.
  foreach($Tool in $Priority)
  {
    # Run the function by name. Get whether or not the texture was created.
    Invoke-Expression ('DDSTool_' + $Tool.Replace(' ','') + ' -TextureInfo $TextureInfo -ImagePath $ImagePath -Width $Width -Height $Height -MipMapLevels $MipMapLevels -OutputImage $OutputImage')

    # Check to see if the texture was created.
    if (TestPath -LiteralPath $OutputImage)
    {
      # If it was created, end the loop.
      break
    }
    # The tool failed to create the image.
    DebugMessage -Message 'Tool failed to create the image! Trying the next tool...'
  }
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: DDS HEADER CREATION
#==============================================================================================================================================================================================
#  Takes a supplied dimension as a hexadecimal value and converts it into up to two byte values. The DDS header is little endian so when a dimension takes up more than FF (255) it must 
#  be split up and the order reversed. For example, BE-08 (3048) must be stored as 08-BE. I only read the first 16 bits rather than all 32 because I doubt a dimension will exceed 65535.

function GetDimensionBytes([string]$HexDimension)
{
  # Hash tables are great for returning multiple values.
  $Dim = @{}

  # Swap the hex values depending on the length of the value and convert them to bytes.
  switch ($HexDimension.Length)
  {
    # If it's 3 digits long, the last two values become first, and the first value is last.
    '3'     { $Dim.A = [System.Convert]::ToInt32($HexDimension.SubString(1,2),16)
              $Dim.B = [System.Convert]::ToInt32($HexDimension.SubString(0,1),16) }
    # If it's 4 digits long, the last two values and the first two values are swapped.
    '4'     { $Dim.A = [System.Convert]::ToInt32($HexDimension.SubString(2,2),16)
              $Dim.B = [System.Convert]::ToInt32($HexDimension.SubString(0,2),16) }
    # If it's only 1 or 2 digits long, we can just use it directly and zero out the second value.
    default { $Dim.A = [System.Convert]::ToInt32($HexDimension,16)
              $Dim.B = 0 }
  }
  # Return the converted values.
  return $Dim
}
#==============================================================================================================================================================================================
#  Generates a header for a DDS texture using information from the input image and stores it in a byte array. Also stores the input image pixel bytes in a separate byte array. I rely on an
#  input image for some information for the reason that this function will only be used for two tasks: combining custom mipmaps, and extracting custom mipmaps. Some parts of the header of
#  the host texture will not change in the destination texture(s), so there is no reason to manually assemble these properties. 
#  
#  HeaderArray  - A byte array that makes up the newly generated header (no pixel data).
#  HeaderLength - The size of the header. DX9 header this will be 128 bytes. DX10 header this will be 148 bytes.
#  PixelArray   - A byte array that makes up the pixel data from the input image (no header data).
#  PixelLength  - The size of the pixel data. This will not include the header bytes.
#  DDSFourCC    - The value of the FourCC flag. For a DX9 header, this will be DXT1, DXT3, DXT5. For a DX10 header, this will be DX10. BC7 is always DX10.

function GenerateDDSHeaderAndPixelData([string]$ImagePath, [int]$Width, [int]$Height, [int]$MipMapLevels)
{
  # Hash tables are great for returning multiple values.
  $ImageData = @{}

  # Read the image as a byte array.
  $Z = [System.IO.File]::ReadAllBytes($ImagePath)

  # The DDS header from bytes 84-87 hold the FourCC value to identify the compression format or if it has a DX10 header.
  $ImageData.DDSFourCC = [System.BitConverter]::ToString($Z[84..87])
  $ImageData.DDSFourCC = $ImageData.DDSFourCC.Split('-') | foreach { [char][byte]([System.Convert]::ToInt16($_, 16)) }
  $ImageData.DDSFourCC = [string]::Join('', $ImageData.DDSFourCC)

  # Uncompressed textures will not have the FourCC value.
  if ($ImageData.DDSFourCC -eq '')
  {
    $ImageData.DDSFourCC = 'None'
  }
  # If it's a DX10 texture, the header is 148 bytes. If it's a DXT1/DXT3/DXT5 textures, its 128 bytes.
  switch ($ImageData.DDSFourCC)
  {
    DX10    { $ImageData.HeaderLength = 148 }
    default { $ImageData.HeaderLength = 128 }
  }
  # Get the dimensions in bytes.
  $W = GetDimensionBytes ("{0:X0}" -f $Width)
  $H = GetDimensionBytes ("{0:X0}" -f $Height)

  # Create a shorter link to the mipmap levels.
  $MML = $MipMapLevels

  # The header for uncompressed textures (ARGB32).
  if ($ImageData.DDSFourCC -eq 'None')
  {
    [byte[]]$ImageData.HeaderArray  = @(     68,     68,     83,     32,     124,       0,       0,       0,      15,      16,       2,       0,   $H.A,   $H.B,      0,      0 )  # 0x00
    [byte[]]$ImageData.HeaderArray += @(   $W.A,   $W.B,      0,      0,  $Z[20],  $Z[21],  $Z[22],  $Z[23],       1,       0,       0,       0,   $MML,      0,      0,      0 )  # 0x10
    [byte[]]$ImageData.HeaderArray += @(      0,      0,      0,      0,       0,       0,       0,       0,       0,       0,       0,       0,      0,      0,      0,      0 )  # 0x20
    [byte[]]$ImageData.HeaderArray += @(      0,      0,      0,      0,       0,       0,       0,       0,       0,       0,       0,       0,      0,      0,      0,      0 )  # 0x30
    [byte[]]$ImageData.HeaderArray += @(      0,      0,      0,      0,       0,       0,       0,       0,       0,       0,       0,       0,     32,      0,      0,      0 )  # 0x40
    [byte[]]$ImageData.HeaderArray += @(     65,      0,      0,      0,  $Z[84],  $Z[85],  $Z[86],  $Z[87],  $Z[88],  $Z[89],  $Z[90],  $Z[91], $Z[92], $Z[93], $Z[94],  $Z[95])  # 0x50
    [byte[]]$ImageData.HeaderArray += @( $Z[96], $Z[97], $Z[98], $Z[99], $Z[100], $Z[101], $Z[102], $Z[103], $Z[104], $Z[105], $Z[106], $Z[107],      0,     16,      0,      0 )  # 0x60
    [byte[]]$ImageData.HeaderArray += @(      0,      0,      0,      0,       0,       0,       0,       0,       0,       0,       0,       0,      0,      0,      0,      0 )  # 0x70
  }
  # The header for compressed textures (DXT, BC7).
  else
  {
    [byte[]]$ImageData.HeaderArray  = @(   68,     68,     83,     32,     124,      0,      0,      0,       7,     16,     10,      0,    $H.A,   $H.B,      0,      0 )  # 0x00
    [byte[]]$ImageData.HeaderArray += @( $W.A,   $W.B,      0,      0,  $Z[20], $Z[21], $Z[22], $Z[23],       1,      0,      0,      0,    $MML,      0,      0,      0 )  # 0x10
    [byte[]]$ImageData.HeaderArray += @(    0,      0,      0,      0,       0,      0,      0,      0,       0,      0,      0,      0,       0,      0,      0,      0 )  # 0x20
    [byte[]]$ImageData.HeaderArray += @(    0,      0,      0,      0,       0,      0,      0,      0,       0,      0,      0,      0,       0,      0,      0,      0 )  # 0x30
    [byte[]]$ImageData.HeaderArray += @(    0,      0,      0,      0,       0,      0,      0,      0,       0,      0,      0,      0,      32,      0,      0,      0 )  # 0x40
    [byte[]]$ImageData.HeaderArray += @(    4,      0,      0,      0,  $Z[84], $Z[85], $Z[86], $Z[87],       0,      0,      0,      0,       0,      0,      0,      0 )  # 0x50
    [byte[]]$ImageData.HeaderArray += @(    0,      0,      0,      0,       0,      0,      0,      0,       0,      0,      0,      0,       8,     16,     64,      0 )  # 0x60
    [byte[]]$ImageData.HeaderArray += @(    0,      0,      0,      0,       0,      0,      0,      0,       0,      0,      0,      0,       0,      0,      0,      0 )  # 0x70
  }
  # If its a DX10 texture (BC7), add 20 more bytes to the header.
  if ($ImageData.DDSFourCC -eq 'DX10')
  {
    # Byte 128 holds the compression type in a DX10 header, so copy that value.
    [byte[]]$ImageData.HeaderArray += @( $Z[128],      0,      0,      0,       3,      0,      0,      0,       0,      0,      0,      0,       1,      0,      0,      0 )  # 0x80
    [byte[]]$ImageData.HeaderArray += @(       0,      0,      0,      0 )                                                                                                     # 0x90
  }
  # The header bytes are done. So now, find the number of pixel byte values we are actually copying.
  $ImageData.PixelLength = ($Z.Length - $ImageData.HeaderLength)

  # Store all bytes in a new array.
  $ImageData.PixelArray = New-Object Byte[] $ImageData.PixelLength

  # Copy all pixel bytes from the input image byte array ($Z) into the new pixel array. 
  # Start with the byte just past the header, and copy the rest of the entire image which is all pixel data.
  [System.Array]::Copy($Z, $ImageData.HeaderLength, $ImageData.PixelArray, 0, $ImageData.PixelLength)

  # Return the newly created header bytes.
  return $ImageData
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: EXTRACT INTERNAL DDS MIPMAPS
#==============================================================================================================================================================================================
#  Extracts all internal mipmaps from a DDS texture into the output path. 

function ExtractInternalDDSMipMaps([string]$ImagePath, [string]$OutputPath)
{
  # Set up data for the texture. Lie to the get image info function and say it has a material map to skip the ImageMagick identify check.
  $ImageInfo      = GetImageInfo -ImagePath $ImagePath -HasMaterial $true
  $ImageObject    = Get-Item -LiteralPath $ImagePath
  $ImageName      = $ImageObject.BaseName
  $ExtractFolder  = CreatePath -LiteralPath ($TempFolder + '\DetachedTextures')
  $ExtractedImage = $ExtractFolder + '\' + $ImageName + $DDS

  # There is no point in doing anything if it doesn't even have mipmaps.
  if ($ImageInfo.MipMaps -gt 1)
  {
    # Read the image as a byte array.
    $ImageByteArray = [System.IO.File]::ReadAllBytes($ImagePath)

    # Generate a new header for the DDS file.
    $ImageData = GenerateDDSHeaderAndPixelData -ImagePath $ImagePath -Width $ImageInfo.Width -Height $ImageInfo.Height -MipMapLevels '1'

    # To calculate the total size of each image in bytes (the base texture and each mipmap), the number of pixels can be used as a reference. For DXT3, DXT5, and BC7, we can generally 
    # assume that each pixel is equal to 1 byte. The catch is that DDS is made up of compressed blocks of 4x4=16 pixels. This means each block must be at least 16 bytes, even if a block
    # has less than 16 pixels of data. So, rounding up each dimension to the nearest multiple of four before multiplying the dimensions will give us the correct number of bytes.
    $MultFourBytes = DDSMultFour -Width $ImageInfo.Width -Height $ImageInfo.Height

    # So now its time to actually calculate the number of bytes using all we know from above. For DXT3/DXT5/BC7, it's known that the dimensions rounded up to the nearest multiple of four
    # and multiplied together will give the exact number of bytes relating to pixel data. DXT1 textures require exactly half to represent a 4x4 block, so 16 pixels will be represented in
    # 8 bytes. The formula is the same, except the product of the rounded up dimensions needs to be divided in half. After the pixels have been calculated, all thats left is to add in the
    # size of the header. The header is 128 bytes for DDS textures with a D3D9 header, the FourCC flag will read DXT1/DXT3/DXT5. The header is 148 bytes for DDS textures with a DX10 header,
    # the FourCC flag will read DX10. DXT1/DXT3/DXT5 textures can have a DX10 header, and while rare, is a possibility. All BC7 textures will have a DX10 148 byte header.
    switch ($ImageData.DDSFourCC)
    {
      # Note I'm setting two variables here. The MipMapOffset is where the pixel data of the first mipmap starts, which is where the first image pixel data plus the header data ends. The
      # mipmap offset will be updated each time a mipmap is extracted from the texture. I could technically reuse the ByteCount variable for offsets, but this way makes it easier to read.
      'None'  { $ByteCount = $MipMapOffset = ($ImageInfo.Width * $ImageInfo.Height * 4) + $ImageData.HeaderLength }
      'DXT1'  { $ByteCount = $MipMapOffset = ($MultFourBytes.Width * $MultFourBytes.Height) / 2 + $ImageData.HeaderLength }
      default { $ByteCount = $MipMapOffset = ($MultFourBytes.Width * $MultFourBytes.Height) + $ImageData.HeaderLength }
    }
    # The collection of bytes (header + pixel) to represent the new base texture (top mipmap level).
    $NewImageByteArray = New-Object Byte[] $ByteCount

    # Copy the generated header and pixel data of the top level (base texture) from the image into the new array. 
    [System.Array]::Copy($ImageData.HeaderArray, 0, $NewImageByteArray, 0, $ImageData.HeaderLength)
    [System.Array]::Copy($ImageByteArray, $ImageData.HeaderLength, $NewImageByteArray, $ImageData.HeaderLength, ($ByteCount - $ImageData.HeaderLength))

    # Write the texture file. The new byte array should contain the new header, and the pixel data of the first image.
    [System.IO.File]::WriteAllBytes($ExtractedImage, $NewImageByteArray)

    # Now the same shit must be done for every mipmap.
    for($i=1; $i -lt $ImageInfo.MipMaps; $i++)
    {
      # Calculate the dimensions of the mipmap.
      $MipWidth  = CalculateMipMapDimension -Level $i -Dimension $ImageInfo.Width
      $MipHeight = CalculateMipMapDimension -Level $i -Dimension $ImageInfo.Height

      # Again the pixels need to be calculated in 4x4 blocks as opposed to using the actual resolution.
      $MultFourBytes = DDSMultFour -Width $MipWidth -Height $MipHeight

      # As mentioned before, DXT1 textures require special attention and require dividing the product of the dimensions in half to get the actual number of bytes.
      switch ($ImageData.DDSFourCC)
      {
        'None'  { $MipByteCount = ($MipWidth * $MipHeight * 4) + $ImageData.HeaderLength }
        'DXT1'  { $MipByteCount = ($MultFourBytes.Width * $MultFourBytes.Height) / 2 + $ImageData.HeaderLength }
        default { $MipByteCount = ($MultFourBytes.Width * $MultFourBytes.Height) + $ImageData.HeaderLength }
      }
      # Generate a new header for the DDS file.
      $MipMapData = GenerateDDSHeaderAndPixelData -ImagePath $ImagePath -Width $MipWidth -Height $MipHeight -MipMapLevels '1'

      # A temporary byte array.
      $NewMipMapByteArray = New-Object Byte[] $MipByteCount

      # Copy the generated header and the pixel data of the mipmap from the input image into the new array. The mipmap offset finally comes in handy.
      [System.Array]::Copy($MipMapData.HeaderArray, 0, $NewMipMapByteArray, 0, $ImageData.HeaderLength)
      [System.Array]::Copy($ImageByteArray, $MipMapOffset, $NewMipMapByteArray, $ImageData.HeaderLength, ($MipByteCount - $ImageData.HeaderLength))

      # The full name to the extracted mipmap.
      $ExtractedMipMap = $ExtractFolder + '\' + $ImageName + '_mip' + $i + $DDS

      # Write the mipmap file.
      [System.IO.File]::WriteAllBytes($ExtractedMipMap, $NewMipMapByteArray)

      # Update the mipmap offset. Subtract the header size to make up for the header bytes that were added in.
      $MipMapOffset += ($MipByteCount - $ImageData.HeaderLength)
    }
  }
  # If reaching this point, it's a texture without mipmaps.
  else
  {
    # Simply copy the texture because nothing needs to be done with it, and I'm sure the function that called this one will be looking for it.
    Copy-Item -LiteralPath $ImagePath -Destination $ExtractedImage -Force
  }
  # The final phase: loop through all mipmaps in the temporary path.
  foreach($LoopImage in Get-ChildItem -LiteralPath $ExtractFolder)
  {
    # Move all mipmaps to the output path.
    $MovePath = [string]$LoopImage.Directory + '\' + $LoopImage.Name
    Move-Item -LiteralPath $MovePath -Destination $OutputPath -Force
  }
  # Cleanup the temp folder.
  RemovePath -LiteralPath $ExtractFolder
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: DDS SINGLE TEXTURE
#==============================================================================================================================================================================================
#  Just create a DDS texture with corrected dimensions and no mipmap levels.

function CreateDDSImageSingle([hashtable]$TextureInfo, [string]$ImagePath, [int]$Width, [int]$Height, [string]$OutputPath)
{
  # Dolphin crashes when using D3D11 if the dimensions are not a multiple of four.
  $MultFour = DDSMultFour -Width $Width -Height $Height

  # Create the texture with the repaired dimensions.
  CreateDDSOptimalTool -TextureInfo $TextureInfo -ImagePath $ImagePath -Width $MultFour.Width -Height $MultFour.Height -MipMapLevels 0 -OutputPath $OutputPath
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: DDS FAST MIPMAP GENERATION
#==============================================================================================================================================================================================
#  Tells the DDS creation program to generate internal mipmaps from the top level when the texture is created.

function CreateDDSMipMapsFast([hashtable]$TextureInfo, [string]$ImagePath, [int]$Width, [int]$Height, [string]$OutputPath)
{
  # The full path to where the new texture will be created.
  $OutputImage = $OutputPath + '\' + $TextureInfo.Name + $DDS

  # Dolphin crashes when using D3D11 if the dimensions are not a multiple of four.
  $MultFour = DDSMultFour -Width $Width -Height $Height

  # This option allows forcing the number of mipmaps to generate.
  switch ($MaxMipMapEnabled)
  {
    $true   { $MipMapLevels = [int]$MaxMipMapLevels }
    $false  { $MipMapLevels = CalculateMipMapLevels ([System.Math]::Max($MultFour.Width, $MultFour.Height)) }
  }
  # Create the texture with internal mipmaps.
  CreateDDSOptimalTool -TextureInfo $TextureInfo -ImagePath $ImagePath -Width $MultFour.Width -Height $MultFour.Height -MipMapLevels $MipMapLevels -OutputPath $OutputPath

  # If the user wants external mipmaps extract them from the texture.
  if ($ExternalDDSMipMaps)
  {
    # Extract mipmaps to the temporary path.
    ExtractInternalDDSMipMaps -ImagePath $OutputImage -OutputPath $OutputPath
  }
  # Destroy the folder with internal mipmaps if it exists.
  DestroyMipMapInfoPlus
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: DDS CUSTOM MIPMAP GENERATION
#==============================================================================================================================================================================================
#  Creates a DDS texture with custom internal mipmaps.

function CreateDDSMipMapsCustom([hashtable]$TextureInfo, [string]$ImagePath, [int]$Width, [int]$Height, [string]$OutputPath)
{
  # The full path to where the new texture will be created.
  $OutputImage = $OutputPath + '\' + $TextureInfo.Name + $DDS

  # Create a temporary path to create the mipmaps.
  $TempMipMapPath = CreatePath -LiteralPath ($TempFolder + '\NewMipMaps')

  # The path to the temporary top layer.
  $BaseImage = $TempMipMapPath + '\'+ $TextureInfo.Name + $DDS

  # Dolphin crashes when using D3D11 if the dimensions are not a multiple of four.
  $MultFour = DDSMultFour -Width $Width -Height $Height

  # First create the top layer.
  CreateDDSOptimalTool -TextureInfo $TextureInfo -ImagePath $ImagePath -Width $MultFour.Width -Height $MultFour.Height -MipMapLevels 0 -OutputPath $TempMipMapPath

  # This option allows forcing the number of mipmaps to generate.
  switch ($MaxMipMapEnabled)
  {
    $true   { $MipMapLevels = [int]$MaxMipMapLevels }
    $false  { $MipMapLevels = CalculateMipMapLevels ([System.Math]::Max($MultFour.Width, $MultFour.Height)) }
  }
  # Generate a new header for the DDS file and get the pixel data. Send +1 to mipmap levels since the header counts the top level (base texture).
  $ImageData = GenerateDDSHeaderAndPixelData -ImagePath $BaseImage -Width $MultFour.Width -Height $MultFour.Height -MipMapLevels ($MipMapLevels + 1)

  # The total size of the new image in bytes. This number is initially calculated from the header size, and the pixel size of the top level (base texture). This number
  # is incremented by the pixel size of each mipmap in the loop below. The initial size of this value is also used to find the offset of the first lower mipmap level.
  $NewImageByteCount = $MipMapOffset = $ImageData.HeaderLength + $ImageData.PixelLength

  # Create a new mipmap hash table based on the input width and height.
  $MipMapInfo = CreateMipMapInfoPlus -TextureInfo $TextureInfo -Width $MultFour.Width -Height $MultFour.Height

  # All pixel bytes of individual mipmaps need to be stored in individual arrays so they can be accessed later.
  $MipMapData = New-Object hashtable[] ($MipMapLevels + 1)

  # Loop through all mipmap levels.
  for($i=1; $i -le $MipMapLevels; $i++)
  {
    # Find the image which will be used as a base for the new mipmap.
    $MipMapBase = GetMipMapBaseImage -MipMapInfo $MipMapInfo -Index $i -ImageFallback $ImagePath

    # Set up the output path to where the mipmap will be created.
    $MipMapImage = $TempMipMapPath + '\' + $MipMapInfo.Name[$i] + $DDS

    # Create the mipmap from wherever MipMapBase was set to.
    CreateDDSOptimalTool -TextureInfo $TextureInfo -ImagePath $MipMapBase -Width $MipMapInfo.Width[$i] -Height $MipMapInfo.Height[$i] -MipMapLevels 0 -OutputPath $TempMipMapPath -ForcedName $MipMapInfo.Name[$i]

    # Get the pixel data for the mipmap and store it in a hashtable array.
    $MipMapData[$i] = GenerateDDSHeaderAndPixelData -ImagePath $MipMapImage -Width '0' -Height '0' -MipMapLevels '1'

    # Add the number of bytes that make up the mipmap to the total size of the image.
    $NewImageByteCount += $MipMapData[$i].PixelLength
  }
  # Create a new byte array to store all the collective data in.
  $ImageByteArray = New-Object byte[] $NewImageByteCount

  # Copy the generated header and the pixel data of the top level (base texture) into the new byte array.
  [System.Array]::Copy($ImageData.HeaderArray, 0, $ImageByteArray, 0, $ImageData.HeaderLength)
  [System.Array]::Copy($ImageData.PixelArray, 0, $ImageByteArray, $ImageData.HeaderLength, $ImageData.PixelLength)

  # One more loop through all mipmap levels.
  for($i=1; $i -le $MipMapLevels; $i++)
  {
    # Copy the pixel data from the top level into the new byte array.
    [System.Array]::Copy($MipMapData[$i].PixelArray, 0, $ImageByteArray, $MipMapOffset, $MipMapData[$i].PixelLength)

    # Set the offset to start of the group of bytes that make up the next mipmap.
    $MipMapOffset += $MipMapData[$i].PixelLength
  }
  # Write all data to create the image.
  [System.IO.File]::WriteAllBytes($OutputImage, $ImageByteArray)

  # If the user wants external mipmaps extract them from the texture.
  if ($ExternalDDSMipMaps)
  {
    # Extract mipmaps to the temporary path.
    ExtractInternalDDSMipMaps -ImagePath $OutputImage -OutputPath $OutputPath
  }
  # Take out the trash before proceeding.
  RemovePath $TempMipMapPath

  # Destroy the folder with internal mipmaps if it exists.
  DestroyMipMapInfoPlus
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: MAIN DDS CREATE FUNCTION
#==============================================================================================================================================================================================
#  Sub-function of "CreateStandardTexture" to create DDS Textures.

function CreateDDSTexture([hashtable]$TextureInfo, [int]$Width, [int]$Height, [string]$OutputPath)
{
  # The texture is not in the Dolphin format.
  if (!$TextureInfo.DolphinFormat)
  {
    # If the user forced mipmaps for non-Dolphin textures.
    if ($ForceCreateMipMaps)
    {
      # We can take the fast path here because they are being forced.
      CreateDDSMipMapsFast -TextureInfo $TextureInfo -ImagePath $TextureInfo.FullPath -Width $Width -Height $Height -OutputPath $OutputPath
    }
    # If mipmaps were not forced, and mipmaps are supplied.
    elseif ($TextureInfo.MipMaps -gt 1)
    {
      # Well there's some of them there mipmaps so lets combine that shit.
      CreateDDSMipMapsCustom -TextureInfo $TextureInfo -ImagePath $TextureInfo.FullPath -Width $Width -Height $Height -OutputPath $OutputPath
    }
    # There is no mipmaps or they weren't forced.
    else
    {
      # Just create the texture without mipmaps.
      CreateDDSImageSingle -TextureInfo $TextureInfo -ImagePath $TextureInfo.FullPath -Width $Width -Height $Height -OutputPath $OutputPath
    }
  }
  # The texture is a Dolphin texture, but not a mipmap texture.
  elseif (!$TextureInfo.IsMipMap)
  {
    # Just create the texture without mipmaps.
    CreateDDSImageSingle -TextureInfo $TextureInfo -ImagePath $TextureInfo.FullPath -Width $Width -Height $Height -OutputPath $OutputPath
  }
  # The texure is a Dolphin mipmap texture. The mipmap functions will also generate the top layer (base texture).
  else
  {
    # If the user did force new mipmaps, or the image does not have mipmaps provided, fast mipmaps can be used.
    switch (($ForceNewMipMaps) -or (!(TextureHasCustomMipMaps -Image $TextureInfo.FullPath -SearchType 'Both')))
    {
      $true   { CreateDDSMipMapsFast -TextureInfo $TextureInfo -ImagePath $TextureInfo.FullPath -Width $Width -Height $Height -OutputPath $OutputPath }
      $false  { CreateDDSMipMapsCustom -TextureInfo $TextureInfo -ImagePath $TextureInfo.FullPath -Width $Width -Height $Height -OutputPath $OutputPath }
    }
  }
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: PNG/JPG/DDS OUTPUT LAUNCHER
#==============================================================================================================================================================================================
#  Creates a texture and all MipMap levels at a location using the "TextureInfo" of a texture fed into the hash table parameter.
#  Parameters serve as modifiers to the texture, allowing to alter the format, width, height, and output path to create the texture.

function CreateStandardTexture([hashtable]$TextureInfo, [int]$Width, [int]$Height, [string]$Format, [string]$OutputPath)
{
  # The full path to where the new texture will be created.
  $NewTexturePath = $OutputPath + '\' + $TextureInfo.Name + $Format

  # Creating PNG or JPG uses the PNG function. DDS gets its very own special set of funcions.
  switch ($Format)
  {
    $DDS    { CreateDDSTexture -TextureInfo $TextureInfo -Width $Width -Height $Height -OutputPath $OutputPath }
    default { CreatePNGTexture -TextureInfo $TextureInfo -Width $Width -Height $Height -Format $Format -OutputPath $OutputPath }
  }
  # Return whether or not the texture was created.
  return (TestPath -LiteralPath $NewTexturePath)
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: MATERIAL MAPS - FUNCTIONS FOR CREATING MATERIAL MAPS WITH ISHIIRUKA TOOL
#==============================================================================================================================================================================================
#  Creates an Ishiiruka material map from an already existing material map. Unlike the other material map function found below, this one 
#  will return whether or not the function ran. This is so both functions do not run and waste precious time...

function CreateMaterialMap_FromMaterial([hashtable]$TextureInfo, [int]$Width, [int]$Height, [string]$Format, [string]$OutputPath)
{
  # Check for a valid path to Ishiiruka Tool.
  if (!(TestPath -LiteralPath $IshiirukaTool))
  {
    # Report that Ishiiruka Tool was not found so nothing can be done.
    Write_Host ' Notice     : ' -ForegroundColor Magenta -NoNewLine
    Write-Host 'Material map exists, but path to Ishiiruka Tool not found!'

    # If the path failed, then exit this function.
    return $false
  }
  # Get the current dimensions of the material map.
  $Material = GetImageInfo -ImagePath $TextureInfo.MaterialMapPath -HasMaterial $true

  # Check if the texture is a mipmap texture or not.
  if (!$TextureInfo.IsMipMap)
  {
    # Check if the format and dimensions line up so the texture can just be copied instead of recreated.
    if (($TextureInfo.Extension -eq $Format) -and ($Material.Width -eq $Width) -and ($Material.Height -eq $Height))
    {
      # If so, simply copy it. We only copy non-mipmaps because of the whole internal vs. external shit that gets old.
      Copy-Item -LiteralPath $TextureInfo.FullPath -Destination $OutputPath -Force
      Copy-Item -LiteralPath $TextureInfo.MaterialMapPath -Destination $OutputPath -Force

      # Report to the console that the textures were copied.
      Write_Host ' Notice     : ' -ForegroundColor Green -NoNewLine
      Write-Host 'Material map copied from existing material map.'

      # Exit the function now that the work is already done.
      return $true
    }
    # If the above check failed, tell Ishiiruka Tool this is not a mipmap texture.
    $nomipmaps = '-nomipmaps'
  }
  # Check if the user wanted to convert textures to DDS.
  if ($Format -eq $DDS)
  {
    # Send the "compress" command to Ishiiruka Tool to create DDS material maps.
    $compress = '-compress'
  }
  # Send the new dimensions to Ishiiruka Tool.
  $IshiirukaWidth  = '-w' + $Width
  $IshiirukaHeight = '-h' + $Height

  # WORKAROUND: Ishiiruka Tool will not take (_lum) textures directly so work-around this by creating a copy without the (_lum).
  # Affects 0.9.6, 0.9.7 (most recent)
  if ($TextureInfo.ColorIsLum)
  {
    # Derive a lumless name from the texture.
    $LumlessName = $TextureInfo.Name.TrimEnd('_lum')

    # Paths to check and see if the textures were created.
    $FinalTexture  = $OutputPath + '\' + $TextureInfo.Name + $Format
    $FinalMaterial = $OutputPath + '\' + $LumlessName + '.mat' + $Format

    # Set up the path for the temporary texture.
    $TempPathCop = CreatePath -LiteralPath ($TempFolder + '\TempCopied\')
    $TempTexture = $TempPathCop + $LumlessName + $TextureInfo.Extension
    $TempPathGen = CreatePath -LiteralPath ($TempFolder + '\TempGenerated\')

    # Create a copy of the texture without the (_lum).
    Copy-Item -LiteralPath $TextureInfo.FullPath -Destination $TempTexture -Force

    # Run this copy through Ishiiruka Tool.
    Ishiiruka-Tool -Image $TempTexture -Arguments @($nomipmaps, $compress, $IshiirukaWidth, $IshiirukaHeight, '-savecolor', '-frommaterial') -OutputPath $TempPathGen

    # Find the number of badly named mipmaps of both the color texture and the material map.
    foreach($CurrentTexture in Get-ChildItem -LiteralPath $TempPathGen)
    {
      # Get the name of the texture in string format.
      $TextureLoopName = $CurrentTexture.ToString()

      # Find any textures that are similar to the texture's name.
      if ($TextureLoopName -like ($TextureName + '*'))
      {
        # Set up variables and rename the textures. 
        $BadName = $TempPathGen + '\' + $TextureLoopName
        $NewName = $TempPathGen + '\' + $TextureLoopName.TrimEnd($Format) + '_lum' + $Format
        Move-Item -LiteralPath $BadName -Destination $NewName -Force
      }
    }
    # Loop through all textures in the temporary path.
    foreach($MipMapFile in Get-ChildItem -LiteralPath $TempPathGen)
    {
      # Move all textures to the current texture output path.
      $MovePath = [string]$MipMapFile.Directory + '\' + $MipMapFile.Name
      Move-Item -LiteralPath $MovePath -Destination $OutputPath -Force
    }
    # Clean up any leftovers in the temp folders.
    RemovePath -LiteralPath $TempPathCop
    RemovePath -LiteralPath $TempPathGen
  }
  # If it's not a (_lum) texture then simply send the color texture.
  else
  {
    # Paths to check and see if the textures were created.
    $FinalTexture  = $OutputPath + '\' + $TextureInfo.Name + $Format
    $FinalMaterial = $OutputPath + '\' + $TextureInfo.Name + '.mat' + $Format

    # Generate the color textures.
    Ishiiruka-Tool -Image $TextureInfo.FullPath -Arguments @($nomipmaps, $compress, $IshiirukaWidth, $IshiirukaHeight, '-savecolor', '-frommaterial') -OutputPath $OutputPath
  }
  # Generate the material map textures.
  Ishiiruka-Tool -Image $TextureInfo.MaterialMapPath -Arguments @($nomipmaps, $compress, $IshiirukaWidth, $IshiirukaHeight, '-frommaterial') -OutputPath $OutputPath

  # Test if the textures were created.
  if ((TestPath -LiteralPath $FinalTexture) -and (TestPath -LiteralPath $FinalMaterial))
  {
    # Report to the console that the texture was created.
    Write_Host ' Notice     : ' -ForegroundColor Green -NoNewLine
    Write-Host 'Material map created from existing material map.'
    return $true
  }
  # The texture was not created.
  return $false
}
#==============================================================================================================================================================================================
#  Creates an Ishiiruka material map from bump/spec/lum/nrm textures.

function CreateMaterialMap_FromTextures([hashtable]$TextureInfo, [int]$Width, [int]$Height, [string]$Format, [string]$OutputPath)
{
  # Check for a valid path to Ishiiruka Tool.
  if (!(TestPath -LiteralPath $IshiirukaTool))
  {
    # Report that Ishiiruka Tool was not found so nothing can be done.
    Write_Host ' Notice     : ' -ForegroundColor Magenta -NoNewLine
    Write-Host 'Material textures exist, but path to Ishiiruka Tool not found!'

    # If path failed, then exit this function.
    return $false
  }
  # Set the possible material types into an array so they can easily be looped through.
  $MaterialSuffix = 'nrm','bump','spec','lum'

  # If new dimensions are specified (with rescale textures option), new materials must be created with these dimensions.
  if (($Width -ne $TextureInfo.Width) -or ($Height -ne $TextureInfo.Height))
  {
    # Set the path for all of the temporary rescaled textures.
    $TempScaledMaterials = CreatePath -LiteralPath ($TempFolder + '\TempScaledMaterials')

    # Set the path to the temporary color map. 
    $TinoTexturePath = $TempScaledMaterials + "\" + $TextureInfo.Name + $PNG

    # Store the new dimensions in a format needed by ImageMagick.
    $NewDimensions = $Width.ToString() + 'x' + $Height.ToString() + '!'

    # Get the amount of sharpening if it's needed.
    $SharpenStrength = CalculateSharpenStrength -BaseWidth $TextureInfo.Width -BaseHeight $TextureInfo.Height -ModWidth $Width -ModHeight $Height

    # Create the temporary rescaled color map.
    Magick-Convert -Image ($TextureInfo.PathName + $PNG) -Arguments @('-resize', $NewDimensions, '-sharpen', $SharpenStrength) -Output $TinoTexturePath

    # Loop through each material.
    foreach($Suffix in $MaterialSuffix)
    {
      # Create the paths to the original and created materials.
      $OldMaterial = $TextureInfo.PathName + '.' + $Suffix + $PNG
      $NewMaterial = $TempScaledMaterials + '\' + $TextureInfo.Name + '.' + $Suffix + $PNG

      # Check to see if the original material exists.
      if (TestPath -LiteralPath $OldMaterial)
      {
        # If it does, then create a rescaled version of the material.
        Magick-Convert -Image $OldMaterial -Arguments @('-resize', $NewDimensions, '-sharpen', $SharpenStrength) -Output $NewMaterial

        # Console: Add to the string of types used to create the material (so it appears as "nrm/bump/spec/lum/").
        $MaterialsUsed += $Suffix + '/'
      }
    }
  }
  # In any other case, the base textures can be used directly.
  else
  {
    # Set the path to the current texture in the main loop.
    $TinoTexturePath = $TextureInfo.FullPath

    # Console: Loop through each material to find which materials are actually being used to report to the console.
    foreach($Suffix in $MaterialSuffix)
    {
      # Console: Check if the material type exists.
      if (TestPath -LiteralPath ($TextureInfo.PathName + '.' + $Suffix + $PNG))
      {
        # Console: Add to the string of types used to create the material.
        $MaterialsUsed += $Suffix + '/'
      }
    }
  }
  # Console: Trim the last forward slash from the string.
  $MaterialsUsed = $MaterialsUsed.TrimEnd('/')

  # Check if the texture is a mipmap texture or not.
  if (!$TextureInfo.IsMipMap)
  {
    $nomipmaps = '-nomipmaps'
  }
  # Check if the user wanted to convert textures to DDS.
  if ($Format -eq $DDS)
  {
    # If they did, then add the compress argument to Ishiiruka Tool. Otherwise this value will be empty.
    $compress = '-compress'
  }
  # Create the material map and all mipmaps in the temporary folder.
  Ishiiruka-Tool -Image $TinoTexturePath -Arguments @($nomipmaps, $compress, '-savecolor') -OutputPath $OutputPath

  # Cleanup temporary materials if they exist now that they are no longer needed.
  RemovePath -LiteralPath $TempScaledMaterials

  # Test if a material (.lum) exists. If it does, the color texture will come out with the suffix (_lum).
  if (TestPath -LiteralPath ($TextureInfo.PathName + '.lum' + $PNG))
  {
    # Add the (_lum) suffix to the texture path that will be tested.
    $FinalTexture = $OutputPath + '\' + $TextureInfo.Name + '_lum' + $Format
  }
  # The texture did not have a (.lum) material file included.
  else
  {
    # In this case do not append any suffix to the texture path that is to be tested.
    $FinalTexture = $OutputPath + '\' + $TextureInfo.Name + $Format
  }
  # The generated material map will never have (_lum) so just use the texture name +(.mat) for the material test path.
  $FinalMaterial = $OutputPath + '\' + $TextureInfo.Name + '.mat' + $Format

  # Test if the textures were created using the previously two defined paths.
  if ((TestPath -LiteralPath $FinalTexture) -and (TestPath -LiteralPath $FinalMaterial))
  {
    # Console: Report to the console that the texture was created.
    Write_Host ' Notice     : ' -ForegroundColor Green -NoNewLine
    Write-Host ('Material map created from material (' + $MaterialsUsed + ') textures.')
    return $true
  }
  return $false
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: MASTER FUNCTION
#==============================================================================================================================================================================================
#  The master function that links together all the different "CreateTexture" functions and automatically chooses the appropriate function.
#  It is not uncommon for many places in the script to call "CreateStandardTexture" directly, in the case material maps are to be ignored.

function CreateTexture([hashtable]$TextureInfo, [int]$Width, [int]$Height, [string]$Format, [string]$OutputPath)
{
  # Input texture is in BC7 format without TexConv.
  if (($TextureInfo.ImageFormat -eq 'BC7') -and (!(TestPath -LiteralPath $TexConvTool)))
  {
    # Report to the user that TexConv is required to convert BC7 to other formats.
    Write_Host ' Notice     :' -ForegroundColor Magenta -NoNewLine
    Write-Host (' Converting BC7 textures to other formats requires a valid path set to TexConv!')

    # The texture was not created.
    return $false
  }
  # Converting to BC7 requires TexConv.
  if (($TextureInfo.DDSCompression -eq 'BC7') -and (!(TestPath -LiteralPath $TexConvTool)))
  {
    # Report to the user that a program is required to convert BC7 to other formats.
    Write_Host ' Notice     :' -ForegroundColor Magenta -NoNewLine
    Write-Host (' Creating BC7 textures requires a valid path to TexConv!')

    # The texture was not created.
    return $false
  }
  # Check if the texture has an already combined material map.
  if ($TextureInfo.HasMaterialMap)
  {
    # If the script is set to Ishiiruka format, then generate a material map from the material.
    $TextureCreated = CreateMaterialMap_FromMaterial -TextureInfo $TextureInfo -Width $Width -Height $Height -Format $Format -OutputPath $OutputPath
  }
  # If the texture has a bump/spec/lum/nrm textures, then create a material map from them.
  elseif ($TextureInfo.HasMaterials)
  {
    $TextureCreated = CreateMaterialMap_FromTextures -TextureInfo $TextureInfo -Width $Width -Height $Height -Format $Format -OutputPath $OutputPath
  }
  # Otherwise create the texture normally.
  else
  {
    $TextureCreated = CreateStandardTexture -TextureInfo $TextureInfo -Width $Width -Height $Height -Format $Format -OutputPath $OutputPath
  }
  # Return if the texture was created or not.
  return $TextureCreated
}
#==============================================================================================================================================================================================
#  TEXTURE CREATION: MISCELLANEOUS TEXTURE FUNCTIONS
#==============================================================================================================================================================================================
#  Used to copy the current texture, its MipMaps, and Material Map from the current texture path in the hash table to a destination path.

function CopyTexture([string]$copypath)
{
  # Copy the texture if no conversion is necessary.
  Copy-Item -LiteralPath $Texture.FullPath -Destination $copypath -Force

  # If the texture has a material map, copy it as well.
  if ($Texture.HasMaterialMap)
  {
    Copy-Item -LiteralPath $Texture.MaterialMapPath -Destination $copypath -Force
  }
  # If the texture is a MipMap, look for lower MipMap levels and copy them too.
  if (($Texture.IsMipMap) -or ($Texture.MipMaps -gt 1))
  {
    # Attempt to create a MipMap hash table.
    $MipMap = CreateMipMapInfo -TextureInfo $Texture -Width $Texture.Width -Height $Texture.Height

    # Loop through all lower levels.
    for($i=1; $i -le $MipMap.Levels; $i++) 
    {
      # If the MipMap level exists, copy it.
      if ($MipMap.Exists[$i])
      {
        Copy-Item -LiteralPath $MipMap.FullPath[$i] -Destination $copypath -Force
      }
    }
  }
}
#==============================================================================================================================================================================================
#  Checks the decimal value of the input against ScaleThreshold, and increments the integer if the decimal is greater than ScaleThreshold.

function ScaleThresholdCorrection([string]$Value)
{
  # Split the integer from the decimal value.
  $ScaleSplit = (FormatDecimal -Value $Value).Split('.', 2)

  # Store the integer value as an actual integer.
  $IntValue = [int]$ScaleSplit[0]

  # Store the decimal value separately without the integer.
  $DecValue = [decimal]('0.' + $ScaleSplit[1])

  # See if the decimal value is greater than or equal to Scale-Fix Threshold.
  if ($DecValue -ge [decimal]$ScaleThreshold)
  {
    # If it is, increment the scaling integer.
    $IntValue++
  }
  # Return the new integer scale.
  return $IntValue
}
#==============================================================================================================================================================================================
#  Function exists to reduce duplicate code. When rescaling or converting textures, JPG textures require special attention. 

function CheckCopyJPG([string]$CheckExtension, [string]$OutputPath)
{
  # We only want to run this on JPG textures.
  if ($CheckExtension -eq $JPG)
  {
    # Do not even try to convert textures with Material Maps to JPG.
    if (($Texture.HasMaterialMap) -or ($Texture.HasMaterials))
    {
      # Log/Console: Add the logging events.
      SetConsoleMessage -MsgType 3 -Message 'Textures with a Material Map are not converted to JPG!'
      $global:LogMessage = 'Not Converted (Has Material)'

      # Copy the texture since no conversion is necessary.
      CopyTexture $OutputPath
      return $true
    }
    # Check if the original texture has any transparent pixels.
    elseif ($Texture.HasAlphaPixels)
    {
      # Log/Console: Add the logging events.
      SetConsoleMessage -MsgType 3 -Message 'Textures with transparency are not converted to JPG!'
      $global:LogMessage = 'Not Converted (Transparency)'

      # Copy the texture since no conversion is necessary.
      CopyTexture $OutputPath
      return $true
    }
  }
  return $false
}
#==============================================================================================================================================================================================
#  STANDARD OPTION 1: SCAN TEXTURES - ISSUE DETECTION
#==============================================================================================================================================================================================
#  Issue Detection 0: Check to see if it's actually an HD texture.

function CheckTextureForIssue_00()
{
  # See if the user wants to detect NotHD textures, and test both the width and height..
  if ((!$AllowNotHD) -and (($Texture.ScaleWidth -le 1) -or ($Texture.ScaleHeight -le 1)))
  {
    # Copy NotHD textures to their own folder.
    $OutputPath = CreatePath -LiteralPath ($MasterOutputPath + '\NotHDTextures' + $Texture.Relative)
    CopyTexture $OutputPath

    # Log/Console: Output that it copied the file.
    SetConsoleMessage -MsgType 2 -Message 'Texture copied to ' -EndMessage ('NotHDTextures' + $Texture.Relative)
    $global:LogMessage = 'NotHD, '
  }
}
#==============================================================================================================================================================================================
#  Issue Detection 1: Check for Dolphin identified duplicates (ones that end with .1, .2, .3, etc.)

function CheckTextureForIssue_01()
{
  # Splits the texture name into 2 parts based on any periods found
  $SplitPeriod = $Texture.Name.Split('.',2)

  # Check to see something exists after the period, and that it is an integer (so it doesn't catch "material map" textures).
  if (($SplitPeriod[1]) -and ($SplitPeriod[1] -as [int] -is [int]))
  {
    # Copy DolphinDupes to their own folder.
    $OutputPath = CreatePath -LiteralPath ($MasterOutputPath + '\DolphinDuplicates' + $Texture.Relative)
    CopyTexture $OutputPath

    # Log/Console: Output that it copied the file.
    SetConsoleMessage -MsgType 2 -Message 'Texture copied to ' -EndMessage ('DolphinDuplicates' + $Texture.Relative)
    $global:LogMessage += 'Dolphin Duplicate, '
  }
}
#==============================================================================================================================================================================================
#  Issue Detection 2: Test for Duplicate Texture.

function CheckTextureForIssue_02()
{
  # Only run if the user does not want to hide duplicates.
  if (!$IgnoreDuplicates)
  {
    # Find the texture in the "Duplicates" hash table if it exists.
    if ($Duplicates.ContainsKey($Texture.Name))
    {
      # Copy Duplicates to their own folder.
      $OutputPath = CreatePath -LiteralPath ($MasterOutputPath + '\DuplicateTextures' + $Texture.Relative)
      CopyTexture $OutputPath

      # Console: Output that it copied the file.
      SetConsoleMessage -MsgType 2 -Message 'Texture copied to ' -EndMessage ('DuplicateTextures' + $Texture.Relative)

      # Get the value of that texture from the hash table (the size of the texture when added).
      $CheckSize = $Duplicates.Get_Item($Texture.Name)

      # If the sizes match, then it's an exact duplicate.
      if ($CheckSize -eq $Texture.Size)
      {
        # Log: Add the issue to the global issues variable.
        $global:LogMessage += 'Duplicate Texture, '
      }
      # If they don't match report that it is different.
      else
      {
        # Log: Add the issue to the global issues variable.
        $global:LogMessage += 'Duplicate Texture (Different), '
      }
    }
    # If the texture was not in the Duplicates hash table.
    else
    {
      # Add it to the Duplicates hash table by texture name and store the size as its value.
      $Duplicates.Add($Texture.Name, $Texture.Size)
    }
  }
}
#==============================================================================================================================================================================================
#  Issue Detection 3: Check to see if there are any missing external MipMaps.

function CheckTextureForIssue_03()
{
  # Skip this check if the texture is not a MipMap.
  if ($Texture.IsMipMap)
  {
    # If the texture is a MipMap, create a hashtable.
    $MipMap = CreateMipMapInfo -TextureInfo $Texture -Width $Texture.Width -Height $Texture.Height

    # For PNG and JPG. Check if there are any MipMaps missing (which is stored in the MipMap hash table).
    if (($Texture.Extension -ne $DDS) -and ($MipMap.LevelsMissing -gt 0))
    {
      # Log/Console: Add the issue to the global issues variable.
      $global:LogMessage += 'MipMaps Missing (x' + $MipMap.LevelsMissing + '), '
    }
    # The DDS version of MipMap checking. External MipMap type must be enabled. Do not attempt to create external mipmaps for material maps.
    elseif (($Texture.Extension -eq $DDS) -and ($MipMap.LevelsMissing -gt 0) -and ($ExternalDDSMipMaps) -and (!$Texture.HasMaterialMap))
    {
      # Log/Console: Add the issue to the global issues variable.
      $global:LogMessage += 'External MipMaps Missing (x' + $MipMap.LevelsMissing + '), '
    }
  }
}
#==============================================================================================================================================================================================
#  Issue Detection 4: Check to see if the texture has material textures.

function CheckTextureForIssue_04()
{
  # Reference the "HasMaterials" variable.
  if ($Texture.HasMaterials)
  {
    # Log/Console: Add the issue to the global issues variable.
    $global:LogMessage += 'Material Textures, '
  }
}
#==============================================================================================================================================================================================
#  Issue Detection 5: PNG/JPG only. Check to see if there are any MipMaps with bad scaling values.

function CheckTextureForIssue_05()
{
  # Texture must be a PNG/JPG MipMap texture.
  if (($Texture.IsMipMap) -and ($Texture.Extension -ne $DDS))
  {
    # If the texture is a MipMap, create a hashtable.
    $MipMap = CreateMipMapInfo -TextureInfo $Texture -Width $Texture.Width -Height $Texture.Height

    # See if the MipMaps have bad dimensions.
    if ($MipMap.BadDimensions)
    {
      # Log/Console: Add the issue to the global issues variable.
      $global:LogMessage += 'MipMaps Bad Scale (x' + $MipMap.BadDimensions + '), '
    }
  }
}
#==============================================================================================================================================================================================
#  Issue Detection 6: PNG/JPG only. Check to see if the integer variables match between scales.

function CheckTextureForIssue_06()
{
  # Texture must be PNG/JPG and scaling values must not be identical for both width and height.
  if (($Texture.Extension -ne $DDS) -and ($Texture.ScaleWidth -ne $Texture.ScaleHeight))
  {
    # Log/Console: Add the issue to the global issues variable.
    $global:LogMessage += 'Uneven Scale, '
  }
}
#==============================================================================================================================================================================================
#  Issue Detection 7: PNG/JPG only. Check to see if the scale is an integer scale.

function CheckTextureForIssue_07()
{
  # Texture must be in PNG/JPG format.
  if ($Texture.Extension -ne $DDS)
  {
    # Split the value for both width and height to grab a decimal value if it exists.
    $WidthCheck  = $Texture.ScaleWidth.ToString().Split('.',2)
    $HeightCheck = $Texture.ScaleHeight.ToString().Split('.',2)

    # The value should store double zeros if there is no decimal value.
    if (($WidthCheck[1] -ne '00') -or ($HeightCheck[1] -ne '00'))
    {
      # Log/Console: Add the issue to the global issues variable.
      $global:LogMessage += 'Non-Integer Scale, '
    }
  }
}
#==============================================================================================================================================================================================
#  Issue Detection 8: PNG/JPG only. Check to see if the aspects match between original and custom.

function CheckTextureForIssue_08()
{
  # Texture must be PNG/JPG and aspect ratios must not be identical between the original and custom texture.
  if (($Texture.Extension -ne $DDS) -and ($Texture.OldAspect -ne $Texture.Aspect))
  {
    # Log/Console: Add the issue to the global issues variable.
    $global:LogMessage += 'Bad Aspect Ratio, '
  }
}
#==============================================================================================================================================================================================
#  Issue Detection 9: DDS only. Check DDS dimensions against calculated dimensions to see if they are at the nearest multiple of 4.

function CheckTextureForIssue_09()
{
  # Make sure the textures is in DDS format.
  if ($Texture.Extension -eq $DDS)
  {
    # Set an annoying amount of variables to get the "DDS version" of the dimensions.
    $SplitScaleWidth = $Texture.ScaleWidth.ToString().Split('.',2)

    # Calculate the dimensions using the original texture and the current width scale.
    $CheckWidth = [int]$Texture.OldWidth * [int]$SplitScaleWidth[0]

    # Height scale is not used because if the scales are uneven it would throw off the calculation.
    $CheckHeight = [int]$Texture.OldHeight * [int]$SplitScaleWidth[0]

    # Run the new dimensions through the DDS dimension algorithm to get a hashtable with the "nearest multiple of 4" dimensions.
    $MultFour = DDSMultFour -Width $CheckWidth -Height $CheckHeight

    # If the dimensions end up different than the custom texture, then the custom texture is wrong.
    if ($Texture.Dimensions -ne $MultFour.Dimensions)
    {
      # Log/Console: Add the issue to the global issues variable.
      $global:LogMessage += 'Bad DDS Dimensions, '
    }
  }
}
#==============================================================================================================================================================================================
#  Issue Detection 10: DDS only. Check DDS for missing internal mipmaps.

function CheckTextureForIssue_10()
{
  # Texture must be a DDS mipmap texture, and the user must not force external mipmaps.
  if (($Texture.IsMipMap) -and ($Texture.Extension -eq $DDS) -and (!$ExternalDDSMipMaps) -and (!$Texture.HasMaterialMap))
  {
    # If the texture is a MipMap, create a hashtable.
    $MipMap = CreateMipMapInfo -TextureInfo $Texture -Width $Texture.Width -Height $Texture.Height

    # Create a folder to extract MipMaps to.
    $ExtractedPath = CreatePath -LiteralPath ($TempFolder + '\Extracted')

    # Extract MipMaps from the texture to see if it has internal MipMaps.
    ExtractInternalDDSMipMaps -ImagePath $Texture.FullPath -OutputPath $ExtractedPath

    # Count the number of files that remain in the folder, and subtract 1 to compensate for the top level.
    $MipMapsFound = ([System.IO.Directory]::GetFiles($ExtractedPath).Count) - 1

    # Find how many mipmap levels are missing.
    $CountMissing = $MipMap.Levels - $MipMapsFound

    # Remove the temporary directory and all extracted mipmaps.
    RemovePath -LiteralPath $ExtractedPath

    # The log stuff to report missing mipmaps.
    if ($CountMissing -gt 4)
    {
      # Log/Console: Add the issue to the global issues variable.
      $global:LogMessage += 'Internal MipMaps Missing (x' + ($CountMissing - 4) + '), '
    }
  }
}
#==============================================================================================================================================================================================
#  STANDARD OPTION 1: SCAN TEXTURES - TEXTURE REPAIR AND COPY
#==============================================================================================================================================================================================
#  Try to fix the texture and/or copy the broken texture to a new directory.

function AttemptRepairAndCopy()
{
  # Find the difference in aspect between the original and custom textures.
  $AspectDifference = [System.Math]::Abs($Texture.Aspect - $Texture.OldAspect)

  # Attempt to repair the bad texture if the user wanted to, and the aspect difference is within the aspect fix threshold.
  if (($RepairTextures) -and ($AspectDifference -le [decimal]$AspectThreshold))
  {
    # Find the smallest scale between width and height and see if the integer should be incremented.
    $NewScale = ScaleThresholdCorrection -Value ([System.Math]::Min($Texture.ScaleWidth, $Texture.ScaleHeight))

    # Use the new scaling value to determine the new dimensions.
    $NewWidth  = ([int]$Texture.OldWidth * $NewScale)
    $NewHeight = ([int]$Texture.OldHeight * $NewScale)

    # Create the repaired folder location if it does not exist.
    $OutputPath = CreatePath -LiteralPath ($MasterOutputPath + '\RepairedTextures' + $Texture.Relative)

    # Create the texture in the repaired folder.
    $TextureRepaired = CreateTexture -TextureInfo $Texture -Width $NewWidth -Height $NewHeight -Format $Texture.Extension -OutputPath $OutputPath

    # If the texture was repaired, report it.
    if ($TextureRepaired)
    {
      # Add to the total number of repaired textures.
      $global:CountRepaired += 1

      # Console: Show that the texture was repaired.
      SetConsoleMessage -MsgType 2 -Message 'Texture successfully repaired to ' -EndMessage ('RepairedTextures' + $Texture.Relative)

      # Log: Update the log message to say that the texture was repaired.
      $global:LogMessage = 'REPAIRED: ' + $LogMessage
    }
    # This should never happen, but if it does the texture failed to be repaired.
    else
    {
      # Console: Report that it failed being created.
      SetConsoleMessage -MsgType 0 -Message 'Texture failed creation and was not repaired!'
    }
  }
  # Check if the user wants to copy bad textures, but only copy them if they weren't fixed.
  if (($CopyBadTextures) -and (!$TextureRepaired))
  {
    # Count the number of textures that were copied.
    $global:CountCopied += 1

    # Create the broken textures folder if it does not exist and copy the broken texture.
    $OutputPath = CreatePath -LiteralPath ($MasterOutputPath + '\BrokenTextures' + $Texture.Relative)
    CopyTexture $OutputPath

    # Console: Add the logging events.
    SetConsoleMessage -MsgType 2 -Message 'Texture copied to ' -EndMessage ('BrokenTextures' + $Texture.Relative)

    # Log: Update the log message to say that the texture was copied.
    $global:LogMessage = 'COPIED: ' + $LogMessage
  }
}
#==============================================================================================================================================================================================
#  STANDARD OPTION 1: SCAN TEXTURES - MASTER FUNCTION
#==============================================================================================================================================================================================
#  Checks a texture for all issues and reports to logs.

function ScanTextureForIssues()
{
  # A string to store all issues. Used for both display and reference.
  $global:LogMessage = ''

  # Check the texture for issues, which updates the "LogMessage" variable with found issues.
  for($i = 0 ; $i -le 10 ; $i++)
  {
    # Force calling the function by name. Because there are two digits in the name (ex: CheckTextureForIssue_03) the index must be converted to a double digit.
    Invoke-Expression ('CheckTextureForIssue_' + (IntToStringDoubleDigit -Value $i))
  }
  # If the texture has issues this string will not be empty.
  if ($LogMessage -ne '')
  {
    # Each issue adds a comma and space, so trim this from the final issue.
    $global:LogMessage = $LogMessage.TrimEnd(', ')

    # Count the total number of textures with issues.
    $global:CountIssues += 1
  }
  # The string was empty so there were no issues.
  else
  {
    # Log that the texture is OK.
    $global:LogMessage = 'OK'
  }
  # Force output of the issues to the console.
  Write_Host ' Status     : ' -ForegroundColor Yellow -NoNewLine
  Write-Host $LogMessage

  # If the texture has any issues except the following: NotHD, Duplicate, or DolphinDupe.
  if (($LogMessage -ne 'OK') -and ($LogMessage -notlike '*NotHD*') -and ($LogMessage -notlike '*Duplicate*'))
  {
    # Attempt to repair or copy the broken texture.
    AttemptRepairAndCopy
  }
}
#==============================================================================================================================================================================================
#  CONVERT AND RESCALE SUPPORT FUNCTION - REMOVE FLAGS FROM TEXTURE NAMES
#==============================================================================================================================================================================================
# If the user chose "User Defined" as the compression type, search for flags on texture names and remove them.

function RemoveFlagsFromName([hashtable]$Texture, [string]$CreatedPath, [string]$Format)
{
  # Build a list of all the possible flags that could be present in the texture name.
  $FormatList = @('_DXTN', '_DXTC', '_DXT5', '_BC3', '_BC7', '_ARGB32')

  # Try to find a matching flag in the texture name.
  foreach($Match in $FormatList)
  {
    # Compare the texture name to the current flag in the list.
    if ($Texture.Name -like ('*' + $Match + '*'))
    {
      # Only remove flags from the base textures if the flag option allows it.
      if ($DDSFlagRemoval -eq 'New & Base')
      {
        # Rename the base texture found in the pack.
        $Ren_BaseImagePath = $Texture.Path + '\' + $Texture.Name.Replace($Match, '') + $Texture.Extension
        Move-Item -LiteralPath $Texture.FullPath -Destination $Ren_BaseImagePath -Force
      }
      # The only time to not remove the flag from the newly generated texture is if the flag removal is set to "None".
      if ($DDSFlagRemoval -ne 'None')
      {
        # Rename the new image that was either converted or rescaled.
        $CreatedImagePath = $CreatedPath + '\' + $Texture.Name + $Format
        $Ren_CreatedImagePath = $CreatedPath + '\' + $Texture.Name.Replace($Match, '') + $Format
        Move-Item -LiteralPath $CreatedImagePath -Destination $Ren_CreatedImagePath -Force
      }
      # Report that the flag has been removed from the texture.
      Write_Host ' Notice     : ' -ForegroundColor Magenta -NoNewLine
      Write-Host ('User defined flag "' + $Match.Replace('_','') + '" removed from ' + $Texture.Name.Replace($Match, '') + $Format + '.')
    }
  }
}
#==============================================================================================================================================================================================
#  Removes flags from folders only if the folder contains a name that is more than just the flag. For example "FolderName_ARGB32" will be renamed "FolderName", but "_ARGB32"
#  will not be detected by this function. This is part one of removing flags. Flags used as complete folder names is handled in the below function.

function RemoveFlagsFromFolderNames([string]$LoopPath)
{
  # Build a list of all the possible flags that could be present in the texture name.
  $FlagList = @('_DXTN', '_DXTC', '_DXT5', '_BC3', '_BC7', '_ARGB32')

  # Loop through all folders and sub-folders to attempt to find texture files.
  foreach($Folder in Get-ChildItem -LiteralPath $LoopPath -Recurse -Force -ErrorAction 'SilentlyContinue')
  {
    # Check to make sure it's a folder.
    if ($Folder.PSIsContainer)
    {
      # A tilde (~) represents a generated directory. Check a condition for both base pack and generated pack.
      $BasePackCondition = (($Folder.FullName -notlike '*~*') -and ($DDSFlagRemoval -eq 'New & Base'))
      $ConvPackCondition = (($Folder.FullName -like '*~*') -and ($DDSFlagRemoval -ne 'None'))

      # Check if either condition passes for the "base" folders or the "converted" folders.
      if (($BasePackCondition) -or ($ConvPackCondition))
      {    
        # Try to find a matching flag in the folder name.
        foreach($Flag in $FlagList)
        {
          # See if the folder name contains the flag, but is not named with just a flag and no other characters.
          if (($Folder.Name -like ('*' + $Flag + '*')) -and ($Folder.Name -ne $Flag))
          {
            # Get the new path to the folder, minus the flag.
            $NewFolderName = $Folder.FullName.Replace($Folder.Name,'') + $Folder.Name.Replace($Flag,'')

            # Rename the folder.
            Move-Item -LiteralPath $Folder.FullName -Destination $NewFolderName -Force
          }
        }
      }
    }
  }
}
#==============================================================================================================================================================================================
#  Removes folders that are used as flags and shifts the contents of the directory back. For example, "Folder\_ARGB32\SubFolder" becomes "Folder\Subfolder". Paths may contain
#  multiple flags, so this function must handle that. When a flag is removed, the path has changed in the loop, so the first flag must be removed before trying to access the
#  folder. How this is done is hard to explain, and I suck ass at writing complex code like this, or explaining what I'm actually trying to do.

function RemoveFolderFlagsShiftDirs([string]$LoopPath)
{
  # Build a list of all the possible flags that could be present in the texture name.
  $FlagList = @('_DXTN', '_DXTC', '_DXT5', '_BC3', '_BC7', '_ARGB32')

  # Loop through all folders and sub-folders to attempt to find texture files.
  foreach($Folder in Get-ChildItem -LiteralPath $LoopPath -Recurse -Force -ErrorAction 'SilentlyContinue')
  {
    # Check to make sure it's a folder.
    if ($Folder.PSIsContainer)
    {
      # A tilde (~) represents a generated directory. Check a condition for both base pack and generated pack.
      $BasePackCondition = (($Folder.FullName -notlike '*~*') -and ($DDSFlagRemoval -eq 'New & Base'))
      $ConvPackCondition = (($Folder.FullName -like '*~*') -and ($DDSFlagRemoval -ne 'None'))

      # Check if either condition passes for the "base" folders or the "converted" folders.
      if (($BasePackCondition) -or ($ConvPackCondition))
      {
        # Try to find a matching flag in the folder name.
        foreach($Flag in $FlagList)
        {
          # The folder name is entirely made up of a flag and contains no other text. (Example: _ARGB32)
          if ($Folder.Name -eq $Flag)
          {
            # This is where shit gets confusing and took me forever to figure out. Sometimes the path will contain more than one flag. But, one of the flags has
            # already been removed, so the path has changed compared to when the loop started. The loop itself contains an outdated path that needs to be fixed,
            # so we must modify that path to remove the flag. So to start out, track the flags in the path in the order they are found using an array.
            $FlagsFound = @()

            # Loop through all folder names to find a flag.
            foreach($CheckName in $Folder.FullName.Split('\'))
            {
              # Loop through all possible flags.
              foreach($Flag in $FlagList)
              {
                # Compare the current folder flag name to the current one in the looped list.
                if ($CheckName -eq $Flag)
                {
                  # If there is a match, add the flag to the array.
                  $FlagsFound += $Flag
                }
              }
            }
            # Store the name of the folder in a separate variable that will be modified to include the final path without previous flags.
            $FinalFolderPath = $Folder.FullName

            # So we have the number of flags in the path, but we need to remove them in the correct order from first to last.
            if ($FlagsFound.Length -gt 1)
            {
              # Loop through all flags that came before the current flag.
              for($i = 0; $i -lt ($FlagsFound.Length - 1); $i++)
              {
                # Remove the previously used flag from the path. Use regex as it allows defining the number of times to remove the flag. We only want to remove the 
                # flag once, even if the user mistakenly used the same flag twice in the same path. Example: "Folder\_ARGB32\SubFolder\_BC7\SubSubFolder\_ARGB32"
                [regex]$ReplaceFlag = ('\\' + $FlagsFound[$i])
                $FinalFolderPath = $ReplaceFlag.Replace($FinalFolderPath, '', 1)
              }
            }
            # Loop through the folder that only has a flag for a name to try to find sub-folders.
            foreach($FlagFile in Get-ChildItem -LiteralPath $FinalFolderPath)
            {
              # Move the file or folder and all of its contents back one folder.
              $BackFlagPath = $FinalFolderPath.Replace('\' + $Folder.Name,'') + '\' + $FlagFile.Name
              Move-Item -LiteralPath $FlagFile.FullName -Destination $BackFlagPath -Force
            }
            # Count the number of files in the folder to make sure none remain.
            $FilesRemaining = Get-ChildItem -LiteralPath $FinalFolderPath -Recurse | Measure-Object | %{$_.Count}

            # If the folder has been completely emptied out.
            if ($FilesRemaining -eq 0)
            {
              # Remove the flag folder completely.
              RemovePath -LiteralPath $FinalFolderPath
            }
          }
        }
      }
    }
  }
}
#==============================================================================================================================================================================================
#  Master function to run the above loop. Depending on the location of the output folder, it may need to be ran twice.

function RemoveFlagsFromFolders()
{
  # First scan for and remove flags in "Texture Path". If the output path has not changed, this first loop will do.
  RemoveFlagsFromFolderNames -LoopPath $MasterInputPath
  RemoveFolderFlagsShiftDirs -LoopPath $MasterInputPath

  # See if the "Output Path" is within the Texture Path.
  if ($MasterOutputPath -ne ($MasterInputPath + '\~CTT_Generated'))
  {
    # If the output path has changed, run the loop on it as well.
    RemoveFlagsFromFolderNames -LoopPath $MasterOutputPath
    RemoveFolderFlagsShiftDirs -LoopPath $MasterOutputPath
  }
}
#==============================================================================================================================================================================================
#  STANDARD OPTION 2: CONVERT TEXTURES TO ANOTHER FORMAT
#==============================================================================================================================================================================================
#  This is called if the user forces the script to convert textures to a specific format.

function ConvertTextureFormat()
{
  # Change the conversion type into the 3 letter equivalent.
  $FileType = ExtensionToText -FileExt $ConvertFormat

  # Store converted textures in their own unique directory.
  $ConvertedPath  = CreatePath -LiteralPath ($MasterOutputPath + '\ConvertedTextures(' + $ConvertSuffix + ')' + $Texture.Relative)

  # Check to see if the user wants to convert to JPG.
  if (CheckCopyJPG -CheckExtension $ConvertFormat -OutputPath $ConvertedPath) { return }

  # If the user wishes to auto-repair Dolphin textures, find new dimensions based on the nearest low integer scale.
  if (($ConvertRepair) -and ($Texture.DolphinFormat))
  {
    # Find the smallest scale between width and height and see if the integer should be incremented.
    $NewScale = ScaleThresholdCorrection -Value ([System.Math]::Min($Texture.ScaleWidth, $Texture.ScaleHeight))

    # Use the new scaling value to determine the new dimensions by multiplying it by the texture's "original" dimensions.
    $NewWidth  = $Texture.OldWidth * $NewScale
    $NewHeight = $Texture.OldHeight * $NewScale

    # Alert the user that repairs are being done if the calculated dimensions are different than the texture's current dimensions.
    if ((!$Texture.HasMaterialMap) -and (($NewWidth -ne $Texture.Width) -or ($NewHeight -ne $Texture.Height)))
    {
      $AutoRepairText = (', Repaired to (' + $NewWidth + 'x' + $NewHeight + ') Using (' + $NewScale + 'x) Scale')
      Write_Host ' Notice     : ' -ForegroundColor Green -NoNewLine
      Write-Host ('Dimensions repaired to (' + $NewWidth + 'x' + $NewHeight + ') using (' + $NewScale.ToString() + 'x) scale.')
    }
  }
  # The user did not want to auto-repair textures, and/or it was not a Dolphin texture.
  else
  {
    # In both cases, use the texture's current dimensions. "Original" dimensions can not be referenced for non-Dolphin textures. 
    $NewWidth  = $Texture.Width
    $NewHeight = $Texture.Height
  }
  # Create the converted texture.
  if (CreateTexture -TextureInfo $Texture -Width $NewWidth -Height $NewHeight -Format $ConvertFormat -OutputPath $ConvertedPath)
  {
    # Log/Console: Each format will have a different output to the console and log file.
    switch ($ConvertFormat)
    {
      # If the texture was converted to PNG, log the format and color space.
      $PNG  { SetConsoleMessage -MsgType 1 -Message ('Successfully converted to ' + $FileType + ' format! (' + $Texture.PNGBitDepth + '-Bit ' + $Texture.PNGColorSpace + ')')
              $global:LogMessage = ('Converted to ' + $FileType + ' Format (' + $Texture.PNGBitDepth + '-Bit ' + $Texture.PNGColorSpace + ')' + $AutoRepairText)
            }
      # If the texture was converted to DDS, log the compression type.
      $DDS  { SetConsoleMessage -MsgType 1 -Message ('Successfully converted to ' + $FileType + ' format! (' + $Texture.DDSCompression + ')')
              $global:LogMessage = ('Converted to ' + $FileType + ' Format (' + $Texture.DDSCompression + ')' + $AutoRepairText)
            }
      # If the texture was converted to JPG, just log the format.
      $JPG  { SetConsoleMessage -MsgType 1 -Message ('Successfully converted to ' + $FileType + ' format!')
              $global:LogMessage = ('Converted to ' + $FileType + ' Format' + $AutoRepairText)
            }
    }
    # Only attempt to rename images if the user selected this compression mode.
    if ($DDSBlkCompress -eq 'User Defined')
    {
      # Remove flags from the textures.
      RemoveFlagsFromName -Texture $Texture -CreatedPath $ConvertedPath -Format $ConvertFormat
    }
  }
  # If the texture was not created, report an error.
  else
  {
    SetConsoleMessage -MsgType 0 -Message 'Texture failed creation and was not converted!'
    $global:LogMessage = 'Failed Creation'
  }
}
#==============================================================================================================================================================================================
#  STANDARD OPTION 3: RESCALE TEXTURES WITH NEW SCALING FACTOR
#==============================================================================================================================================================================================
#  A menu that is displayed when Rescaling textures and "ManualRescale" is enabled.

function ManualRescaleMenu()
{
  # Write information about the texture to the console window.
  Write_Host ' Texture    : ' -ForegroundColor Yellow -NoNewLine
  Write-Host $Texture.FullName -ForegroundColor Cyan
  Write_Host ' Path       : ' -ForegroundColor Yellow -NoNewLine
  Write-Host ((Get-Item -LiteralPath $MasterInputPath).Name + $Texture.Relative)
  Write_Host ' Original   : ' -ForegroundColor Yellow -NoNewLine
  Write-Host ($Texture.OldDimensions + ' : ' + $Texture.OldAspect.ToString())
  Write_Host ' Custom     : ' -ForegroundColor Yellow -NoNewLine
  Write-Host ($Texture.Dimensions + ' : ' + $Texture.Aspect.ToString() + ' : (' + $Texture.FullScale + ' Scale)')
  Write-Host ''
  Write-Host ' Enter a new scaling value for the texture.'
  Write-Host (' Range: ') -ForegroundColor Yellow -NoNewLine
  Write-Host ('1-100 , ') -NoNewLine
  Write-Host ('Skip Texture: ') -ForegroundColor Yellow -NoNewLine
  Write-Host ('0 , ') -NoNewLine
  Write-Host ('Default: ') -ForegroundColor Yellow -NoNewLine
  Write-Host $RescaleFactor
  Write-Host ''
  $MenuInput = Read-Host '> '
  Write-Host ''

  # Check that the entered scale is 0-100.
  if ($MenuInput -match '^(?:100|[1-9]?[0-9])$')
  {
    return $MenuInput
  }
  # If there is invalid input or the user wishes to use the default value, then return the stored scale.
  return $RescaleFactor
}
#==============================================================================================================================================================================================
#  Determines the scaling value used based on the value of "Rescale Condition".

function GetRescaleScalingValue()
{
  # Set up the condition for when a texture should be rescaled based on the user selected value for "Rescale Condition".
  switch ($RescaleScaling)
  {
    # The RescaleFactor is the global variable set by the GUI.
    Always    { $RescaleCondition = $true }
    Upscale   { $RescaleCondition = (($Texture.ScaleWidth -le [decimal]$RescaleFactor) -and ($Texture.ScaleHeight -le [decimal]$RescaleFactor)) }
    Downscale { $RescaleCondition = (($Texture.ScaleWidth -ge [decimal]$RescaleFactor) -and ($Texture.ScaleHeight -ge [decimal]$RescaleFactor)) }
  }
  # If the condition passes, rescale the texture using the chosen rescaling factor.
  if ($RescaleCondition)
  {
    return $RescaleFactor
  }
  # If the condition fails, choose the greater of the two scales (between width and height) for the new scaling value.
  # Example: 3.82/4.16, 4 will be used as the new scaling factor. For most cases, this will not actually rescale the texture much unless width and height are uneven.
  return ([System.Math]::Max($Texture.ScaleWidth, $Texture.ScaleHeight)).ToString().SubString(0,1)
}
#==============================================================================================================================================================================================
#  This is called if the user forces the script to convert textures to an integer scale.

function RescaleTextureInteger()
{
  # Change the conversion type into the 3 letter equivalent.
  $FileType = ExtensionToText -FileExt $RescaleFormat

  # Include the format that was forced in the path to the rescaled textures.
  $RescaledPath = CreatePath -LiteralPath ($MasterOutputPath + '\RescaledTextures(' + $RescaleSuffix + ')' + $Texture.Relative)

  # Check to see if the user wants to convert to JPG.
  if (CheckCopyJPG -CheckExtension $RescaleFormat -OutputPath $RescaledPath) { return }

  # If Manual Rescale is enabled, get the new scale from the menu. If it's disabled, get the new scale based on the value of "Rescale Condition".
  switch ($ManualRescale)
  {
    $true   { $NewScale = ManualRescaleMenu }
    $false  { $NewScale = GetRescaleScalingValue }
  }
  # Manual Rescale allows entering a value of "0" to skip the texture, so do that if it's found.
  if ($NewScale -eq '0')
  {
    Write_Host ' Notice     : ' -ForegroundColor Yellow -NoNewLine
    Write-Host 'Skipping this texture.'
    return
  }
  # Calculate the new dimensions based on the new scaling value.
  $NewWidth  = [int]($Texture.OldWidth * $NewScale)
  $NewHeight = [int]($Texture.OldHeight * $NewScale)

  # Create the rescaled texture.
  if (CreateTexture -TextureInfo $Texture -Width $NewWidth -Height $NewHeight -Format $RescaleFormat -OutputPath $RescaledPath)
  {
    # Log/Console: Each format will have a different output to the console and log file.
    switch ($RescaleFormat)
    {
      # If the texture was converted to PNG, log the format and color space.
      $PNG  { SetConsoleMessage -MsgType 1 -Message ('Successfully rescaled to ' + $NewWidth + 'x' + $NewHeight + ' (' + $NewScale + 'x) ' + $FileType + ' format! (' + $Texture.PNGBitDepth + '-Bit ' + $Texture.PNGColorSpace + ')')
              $global:LogMessage = ('Rescaled to ' + $NewWidth + 'x' + $NewHeight + ' (' + $NewScale + 'x) ' + $FileType + ' Format' + ' (' + $Texture.PNGBitDepth + '-Bit ' + $Texture.PNGColorSpace + ')')
            }
      # If the texture was converted to DDS, log the compression type.
      $DDS  { SetConsoleMessage -MsgType 1 -Message ('Successfully rescaled to ' + $NewWidth + 'x' + $NewHeight + ' (' + $NewScale + 'x) ' + $FileType + ' format! (' + $Texture.DDSCompression + ')')
              $global:LogMessage = ('Rescaled to ' + $NewWidth + 'x' + $NewHeight + ' (' + $NewScale + 'x) ' + $FileType + ' Format' + ' (' + $Texture.DDSCompression + ')')
            }
      # If the texture was converted to JPG, just log the format.
      $JPG  { SetConsoleMessage -MsgType 1 -Message ('Successfully rescaled to ' + $NewWidth + 'x' + $NewHeight + ' (' + $NewScale + 'x) ' + $FileType + ' format!')
              $global:LogMessage = ('Rescaled to ' + $NewWidth + 'x' + $NewHeight + ' (' + $NewScale + 'x) ' + $FileType + ' Format')
            }
    }
    # Only attempt to rename images if the user selected this compression mode.
    if ($DDSBlkCompress -eq 'User Defined')
    {
      # Remove flags from the textures.
      RemoveFlagsFromName -Texture $Texture -CreatedPath $RescaledPath -Format $RescaleFormat
    }
  }
  # Log/Console: If the texture was not created, report an error.
  else
  {
    # Log/Console: Add the logging events.
    SetConsoleMessage -MsgType 0 -Message 'Texture failed creation and was not rescaled!'
    $global:LogMessage = 'Failed Creation'
  }
}
#==============================================================================================================================================================================================
#  STANDARD OPTION 4: ADD IDENTIFYING WATERMARK TO ALL TEXTURES
#==============================================================================================================================================================================================
#  Calculates the new dimensions that will be used for the watermark and caption.

function GetWatermarkDimensions([int]$Width, [int]$Height)
{
  # Create a hash table to store the calculated dimensions.
  $Calculated = @{}

  # We don't want textures to be less than 256 pixels in width or text may be unreadable, so store the width and height before checks so they can be used if the checks immediately pass.
  $Calculated.Width  = $Width
  $Calculated.Height = $Height

  # Check to see if the texture width is less than 256 pixels.
  if ($Calculated.Width -lt 256)
  {
    # Start with a new scaling factor of 2 which will be incremented by 1 each loop iteration.
    $ScaleFactor = 2

    # If the width failed to be at least 256 pixels, calculate a new width and height that equals/exceeds 256 pixels using the lowest possible integer scale.
    while($Calculated.Width -lt 256)
    {
      # Each iteration increments the scale by 1x. Loop exits when greater than or equal to 256 is reached.
      $Calculated.Width  = $Width * $ScaleFactor
      $Calculated.Height = $Height * $ScaleFactor
      $ScaleFactor ++
    }
  }
  # Return the calculated dimensions.
  return $Calculated
}
#==============================================================================================================================================================================================
#  Creates the base texture that will have the watermark applied to it.

function CreateWatermarkTexture([int]$Width, [int]$Height, [string]$Path)
{
  # Set the path for the temporary texture that will serve as the base texture that will have a caption applied to it.
  $TexturePath = $Path + '\tex.png'

  # Store the dimensions in a format needed by ImageMagick when creating images.
  $Dimensions = $Width.ToString() + 'x' + $Height.ToString()

  # Check if the texture is a DDS texture generated with Ishiiruka Tool.
  if (($Texture.HasMaterialMap) -and ($Texture.Extension -eq $DDS))
  {
    # I don't even want to fuck with trying to convert a (_lum) texture.
    if ($Texture.ColorIsLum)
    {
      # Instead just create a black texture.
      Magick-Convert -Arguments @('-size', $Dimensions, 'xc:#000000') -Output $TexturePath

      # And let the user know why it's a black image.
      Write_Host ' Notice     : ' -ForegroundColor Magenta -NoNewLine
      Write-Host 'Ishiiruka (_lum) color texures can not be converted. Generated texture will be a black image!'
    }
    # If it's not a (_lum) texture attempt to convert it if Ishiiruka Tool is found.
    elseif (TestPath -LiteralPath $IshiirukaTool)
    {
      # Create a link to the temporary generated texture.
      $IshiirukaFile = $Path + '\' + $Texture.Name + $PNG

      # Resize parameters for Ishiiruka Tool.
      $IshiiWidth  = '-w' + $Width
      $IshiiHeight = '-h' + $Height

      # Create a temporary color texture that is in PNG format.
      Ishiiruka-Tool -Image $Texture.MaterialMapPath -Arguments @('-nomipmaps', '-savecolor', $IshiiWidth, $IshiiHeight, '-frommaterial') -OutputPath $Path

      # Rename the file to 'tex.png' for the combination step.
      Move-Item -LiteralPath $IshiirukaFile -Destination $TexturePath -Force
    }
    # Ishiiruka Tool was not found.
    else
    {
      # Instead just create a black texture.
      Magick-Convert -Arguments @('-size', $Dimensions, 'xc:#000000') -Output $TexturePath

      # And let the user know why it's a black image.
      Write_Host ' Notice     : ' -ForegroundColor Magenta -NoNewLine
      Write-Host 'Ishiiruka Tool not found. Generated texture will be a black image!'
    }
  }
  # Check if the texture is in BC7 format.
  elseif ($Texture.ImageFormat -eq 'BC7')
  {
    # BC7 textures can only be converted with TexConv.
    if (TestPath -LiteralPath $TexConvTool)
    {
      # Create a link to the temporary generated texture.
      $ConvertedBC7 = $Path + '\' + $Texture.Name + $PNG

      # Create the temporary image using TexConv.
      RunTexConvTool -Image $Texture.FullPath -Arguments @('-y', '-ft', 'PNG', '-f', 'R8G8B8A8_UNORM', '-w', $Width, '-h', $Height) -OutputPath $Path | Out-Null

      # Rename the file to 'tex.png' for the combination step.
      Move-Item -LiteralPath $ConvertedBC7 -Destination $TexturePath -Force
    }
    # TexConv was not found.
    else
    {
      # Instead just create a black texture.
      Magick-Convert -Arguments @('-size', $Dimensions, 'xc:#000000') -Output $TexturePath

      # And let the user know why it's a black image.
      Write_Host ' Notice     : ' -ForegroundColor Magenta -NoNewLine
      Write-Host 'Converting BC7 textures requires TexConv. Generated texture will be a black image!'
    }
  }
  # In every other case, generate the temporary texture from the custom texture.
  else
  {
    # Dimensions in the format that ImageMagick expects.
    $IMDimensions = $Dimensions + '!'

    # Create the temporary texture.
    Magick-Convert -Image $Texture.FullPath -Arguments @('-resize', $IMDimensions) -Output $TexturePath
  }
  # Return the path to the texture so it can be set to a variable on creation and referenced.
  return $TexturePath
}
#==============================================================================================================================================================================================
#  Creates the caption that will serve as the texture watermark.

function CreateWatermarkCaption([int]$Width, [string]$Path)
{
  # Check if the user wanted a specific number of characters in the watermark.
  if ([int]$WM_Length -gt 0)
  {
    # Less than 6 characters is pretty useless, so force 6 if its less than 6.
    if ([int]$WM_Length -lt 6)
    {
      # Extract characters from the end of the texture name to use as the caption.
      $CaptionText = 'caption:' + $Texture.Name.Substring($Texture.Name.Length - 6, 6)
    }
    # Otherwise, use the value the user input.
    else
    {
      # Extract characters from the end of the texture name to use as the caption.
      $CaptionText = 'caption:' + $Texture.Name.Substring($Texture.Name.Length - $WM_Length, $WM_Length)
    }
  }
  # The user specified "0" as the number of characters.
  else
  {
    # If the value was 0, the user wanted to use the full name.
    $CaptionText = 'caption:' + $Texture.Name
  }
  # Set the caption's font size, width (using 80% of the calculated width), and destination path.
  $CaptionSize  = ([int]$WM_FontSize * ($Width / 128)).ToString()
  $CaptionWidth = ($Width * 0.80).ToString() + 'x'
  $CaptionPath  = $Path + '\cap.png'

  # Create the caption that will overlay the texture.
  Magick-Convert -Arguments @('-background', 'transparent', '-fill', $WM_FontColor, '-undercolor', $WM_BGColor, '-font', $WM_FontFace, '-pointsize', $CaptionSize, '-size', $CaptionWidth, '-gravity', 'center', $CaptionText) -Output $CaptionPath

  # Return the path to the caption so it can be set to a variable on creation and referenced.
  return $CaptionPath
}
#==============================================================================================================================================================================================
#  Master function that creates a texture with a watermark using part or all of the texture's name.

function AddTextureWatermark()
{
  # Create a temporary folder for the base texture and the caption.
  $TempWatermarkPath = CreatePath -LiteralPath ($TempFolder + '\TempWatermark')

  # Calculate the dimensions that will be used for the watermark.
  $Calculated = GetWatermarkDimensions -Width $Texture.Width -Height $Texture.Height

  # Create the base texture and the caption that will be applied to it.
  $TexturePath = CreateWatermarkTexture -Width $Calculated.Width -Height $Calculated.Height -Path $TempWatermarkPath
  $CaptionPath = CreateWatermarkCaption -Width $Calculated.Width -Path $TempWatermarkPath

  # Set the full path to output texture.
  $OutputPath    = CreatePath -LiteralPath ($MasterOutputPath + '\WatermarkTextures' + $Texture.Relative)
  $TexOutputPath = $OutputPath + '\' + $Texture.Name + $PNG

  # Test if the texture and caption were created.
  if ((TestPath -LiteralPath $TexturePath) -and (TestPath -LiteralPath $CaptionPath))
  {
    # Apply the caption to the texture using the composite command.
    Magick-Convert -Image $TexturePath -Arguments @($CaptionPath, '-gravity', 'center', '-composite') -Output $TexOutputPath
  }
  # Clean up the temporary files and folders.
  RemovePath -LiteralPath $TempWatermarkPath

  # Console/Log: Report to the user that the texture was created.
  if (TestPath -LiteralPath $TexOutputPath)
  {
    SetConsoleMessage -MsgType 1 -Message 'Texture with watermark created successfully.'
    $global:LogMessage = 'Watermark Created'
  }
  # Console/Log: Report to the user that the texture was not created.
  else
  {
    SetConsoleMessage -MsgType 0 -Message 'Texture with watermark failed creation.'
    $global:LogMessage = 'Watermark Failed'
  }
}
#==============================================================================================================================================================================================
#  STANDARD OPTION 5: CREATE MATERIAL MAPS WITH ISHIIRUKA TOOL
#==============================================================================================================================================================================================
#  Creates material maps from bump/spec/lum/nrm textures. Parameter "$IshiiMethod" defines where to create the texture. 1 - Output Folder, 2 - Overwrite the Textures/Destroy Materials

function CreateMaterialMaps($IshiiMethod)
{
  # Check to see if the texture actually has supplied material maps.
  if (!$Texture.HasMaterials)
  {
    # Log/Console: Add the logging events.
    SetConsoleMessage -MsgType 1 -Message 'No material textures (bump/spec/lum/nrm) exist for this texture.'
    $global:LogMessage = 'No Materials'
    return
  }
  # Get the extension as text for the output folder.
  $FileType = ExtensionToText -FileExt $IshiirukaFormat

  # This method creates the material map in the output path.
  if ($IshiiMethod -eq 1)
  {
    # Set up the path to create material map to a new folder.
    $MaterialOutputPath = CreatePath -LiteralPath ($MasterOutputPath + '\MaterialMaps ' + '(' + $FileType + ')' + $Texture.Relative)

    # Attempt to create the material map.
    if (!(CreateMaterialMap_FromTextures -TextureInfo $Texture -Width $Texture.Width -Height $Texture.Height -Format $IshiirukaFormat -OutputPath $MaterialOutputPath))
    {
      # Report if the material map failed creation
      Write-Host ' Warning    : Material map failed creation!' -ForegroundColor Red
    }
  }
  # This method creates the material map in-place.
  else
  {
    # Set up the path to create material maps to a new folder.
    $TempMaterialPath = CreatePath -LiteralPath ($TempFolder + '\TempMaterials')

    # Attempt to create the material map.
    if (CreateMaterialMap_FromTextures -TextureInfo $Texture -Width $Texture.Width -Height $Texture.Height -Format $IshiirukaFormat -OutputPath $TempMaterialPath)
    {
      # Remove the old material textures.
      RemovePath -LiteralPath $Texture.FullPath
      RemovePath -LiteralPath ($Texture.PathName + '.nrm' + $PNG)
      RemovePath -LiteralPath ($Texture.PathName + '.bump' + $PNG)
      RemovePath -LiteralPath ($Texture.PathName + '.spec' + $PNG)
      RemovePath -LiteralPath ($Texture.PathName + '.lum' + $PNG)

      # Log/Console: Add the logging events.
      $global:LogMessage = 'Material Map Created'

      # Loop through all Material Maps in the temp materials directory.
      foreach($MaterialMap in Get-ChildItem -LiteralPath $TempMaterialPath)
      {
        # Move all Material Maps to the current texture path.
        $MovePath = [string]$MaterialMap.Directory + '\' + $MaterialMap.Name
        Move-Item -LiteralPath $MovePath -Destination $Texture.Path -Force
      }
    }
    # It was not created.
    else
    {
      # Report if the material map failed creation
      Write-Host ' Warning    : Material map failed creation!' -ForegroundColor Red
    }
    # Clean up on aisle four.
    RemovePath -LiteralPath $TempMaterialPath
  }
}
#==============================================================================================================================================================================================
#  STANDARD OPTION 6: OPTIMIZE PNG TEXTURES WITH OPTIPNG
#==============================================================================================================================================================================================
#  Calculate/store stuff for OptiPNG using a hash table. Also used in function "FixBadOptiPNGTexture".

function CreateOptiPNGData([string]$InputPath) 
{
  # Initialize a hash table.
  $OptiData = @{}

  # Get the texture as an object so it can be analyzed.
  $OptiObject = Get-ChildItem -LiteralPath $InputPath

  # Store the name of the texture.
  $OptiData.Name     = $OptiObject.BaseName
  $OptiData.FullName = $OptiObject.Name

  # Store the size of the texture in Bytes.
  $OptiData.Size = ($OptiObject | Measure-Object -property length -sum).sum

  # This function will generate ass-loads of errors if a channel is not in the string, so silence them all.
  $ErrorActionPreference = 'silentlycontinue'

  # Run the "-verbose" command on the texture to find the channel information. Verbose is stored as an array of strings.
  $Verbose = (Magick-Identify -Image $InputPath -Arguments @('-quiet','-verbose'))

  # Search the array of strings for color data. Find the numeric value of the bit depth stored in the string.
  $R_String = (($Verbose | Select-String -Pattern 'Red.*bit') -Split 'Red: ') -Split '-bit'
  $G_String = (($Verbose | Select-String -Pattern 'Green.*bit') -Split 'Green: ') -Split '-bit'
  $B_String = (($Verbose | Select-String -Pattern 'Blue.*bit') -Split 'Blue: ') -Split '-bit'
  $A_String = (($Verbose | Select-String -Pattern 'Alpha.*bit') -Split 'Alpha: ') -Split '-bit'

  # Initialize an array to store the depth in each channel.
  $Channel = New-Object int[] 4

  # Search for the channel depth and convert it to an integer. If the channel is not found, set depth to zero.
  if ($R_String[1]) { $Channel[0] = [int]$R_String[1] } else { $Channel[0] = 0 }
  if ($G_String[1]) { $Channel[1] = [int]$G_String[1] } else { $Channel[1] = 0 } # Heh. G-String.
  if ($B_String[1]) { $Channel[2] = [int]$B_String[1] } else { $Channel[2] = 0 }
  if ($A_String[1]) { $Channel[3] = [int]$A_String[1] } else { $Channel[3] = 0 }

  # Default the depth fail to false.
  $OptiData.DepthFail = $false

  # Loop through all the channels.
  for($i=0; $i -lt $Channel.Length; $i++)
  {
    # See if the bit depth falls between 0 and 8, meaning it must be 1-7 to fail.
    if (($Channel[$i] -gt 0) -and ($Channel[$i] -lt 8))
    {
      # If any of the channels failed to be greater than 8 bit set the depth fail.
      $OptiData.DepthFail = $true

      # Track which channel failed.
      switch ($i)
      {
        '0' { $OptiData.ChannelFailed = 'Red' }
        '1' { $OptiData.ChannelFailed = 'Green' }
        '2' { $OptiData.ChannelFailed = 'Blue' }
        '3' { $OptiData.ChannelFailed = 'Alpha' }
      }
      # Exit the loop so it isn't overwritten if another channel passes.
      break
    }
  }
  # Store if the image has indexed color space.
  $OptiData.Indexed = ([string]$Verbose -match 'Indexed')

  # Return the hash table.
  return $OptiData
}
#==============================================================================================================================================================================================
#  Displays a warning message if a texture was skipped optimizing due to errors.

function OptiPNG-ShowFailMessage([hashtable]$OldImage, [hashtable]$NewImage)
{
  # Check if the image failed in both indexed color and the depth check.
  if (($OldImage.Indexed) -and ($OldImage.DepthFail))
  {
    Write_Host ' Message    : ' -ForegroundColor Magenta -NoNewLine
    Write-Host ('Skipped ' + $OldImage.Name + ' (' + $OldImage.ChannelFailed + ' Channel Less Than 8bpp + Indexed)')
    $global:LogMessage = 'Skipped (' + $OldImage.ChannelFailed + ' Channel Less Than 8bpp + Indexed)'
  }
  # Check if the image only failed as indexed color space.
  elseif ($OldImage.Indexed)
  {
    Write_Host ' Message    : ' -ForegroundColor Magenta -NoNewLine
    Write-Host ('Skipped ' + $OldImage.Name + ' (Indexed Color Space)')
    $global:LogMessage = 'Skipped (Indexed Color Space)'
  }
  # Check if the image only failed the depth check.
  elseif ($OldImage.DepthFail)
  {
    Write_Host ' Message    : ' -ForegroundColor Magenta -NoNewLine
    Write-Host ('Skipped ' + $OldImage.Name + ' (' + $OldImage.ChannelFailed + ' Channel Less Than 8bpp)')
    $global:LogMessage = 'Skipped (' + $OldImage.ChannelFailed + ' Channel Less Than 8bpp)'
  }
  # Check if the new image failed in both indexed color and the depth check.
  elseif (($NewImage.Indexed) -and ($NewImage.DepthFail))
  {
    Write_Host ' Message    : ' -ForegroundColor Magenta -NoNewLine
    Write-Host ('Skipped ' + $OldImage.Name + ' (Result ' + $NewImage.ChannelFailed + ' Channel Less Than 8bpp + Indexed)')
    $global:LogMessage = 'Skipped (Result ' + $NewImage.ChannelFailed + ' Channel Less Than 8bpp + Indexed)'
  }
  # Check if the new image only failed as indexed color space.
  elseif ($NewImage.Indexed)
  {
    Write_Host ' Message    : ' -ForegroundColor Magenta -NoNewLine
    Write-Host ('Skipped ' + $OldImage.Name + ' (Result Indexed Color Space)')
    $global:LogMessage = 'Skipped (Result Indexed Color Space)'
  }
  # Check if the new image only failed the depth check.
  elseif ($NewImage.DepthFail)
  {
    Write_Host ' Message    : ' -ForegroundColor Magenta -NoNewLine
    Write-Host ('Skipped ' + $OldImage.Name + ' (Result ' + $NewImage.ChannelFailed + ' Channel Less Than 8bpp)')
    $global:LogMessage = 'Skipped (Result ' + $NewImage.ChannelFailed + ' Channel Less Than 8bpp)'
  }
}
#==============================================================================================================================================================================================
#  Optimizes a texture with OptiPNG and returns the reduction in Bytes. Input parameter takes a full path to the texture + file extension.

function OptimizeTexture([string]$InputPath, [int]$OptiMethod)
{
  # Initialize a hash table so multiple values can be returned.
  $OptiResults = @{}

  # Create information of the old image before optimization.
  $OldImage = CreateOptiPNGData -InputPath $InputPath

  # Set up temporary paths to the optimized texture.
  $OptiTempPath    = CreatePath -LiteralPath ($TempFolder + '\OptiTemp\')
  $OptiTempTexture = $OptiTempPath + $OldImage.FullName

  # Run OptiPNG and create a new texture in the temp path.
  OptiPNG-Optimize -Image $InputPath -Tests $OptiPNGTests -Output $OptiTempPath | Out-Null

  # Create information of the new image after optimization.
  $NewImage = CreateOptiPNGData -InputPath $OptiTempTexture

  # -------------------------------------------------------
  # If any of the tests failed then fail the texture.
  if (($OldImage.Indexed) -or ($OldImage.DepthFail) -or ($NewImage.Indexed) -or ($NewImage.DepthFail))
  {
    # Track whether or not any tests failed on either texture.
    $OptiResults.FailTests = $true

    # Console/Log: Show the user which test failed.
    OptiPNG-ShowFailMessage $OldImage $NewImage

    # Remove the temp path and send data back to the host function.
    RemovePath -LiteralPath $OptiTempPath
    $OptiResults.Reduction = 0
    return $OptiResults
  }
  # -------------------------------------------------------
  # Method 1: Output the optimized texture to a new folder.
  if ($OptiMethod -eq 1)
  {
    # Create the path to the output texture.
    $OutputPath    = CreatePath -LiteralPath ($MasterOutputPath + '\OptimizedTextures' + $Texture.Relative)
    $OutputTexture = $OutputPath + '\' + $NewImage.FullName
  }
  # Method 2: Optimize the files in-place if the user wished it.
  elseif ($OptiMethod -eq 2)
  {
    # Create the path to the output texture.
    $OutputTexture = $InputPath
  }
  # -------------------------------------------------------
  # Check if there was actually any reduction in file size.
  if ($NewImage.Size -lt $OldImage.Size)
  {
    # Calculate the size difference in Bytes.
    $OptiResults.Reduction = $OldImage.Size - $NewImage.Size

    # Move the optimized texture to the new path.
    Move-Item -LiteralPath $OptiTempTexture -Destination $OutputTexture -Force
  }
  # If there was no reduction....
  else
  {
    # Store that the amount of reduction is zero so it can be returned as 0.
    $OptiResults.Reduction = 0
  }
  # -------------------------------------------------------
  # Cleanup the temp texture path.
  RemovePath -LiteralPath $OptiTempPath

  # Check if files are being created in folders.
  if ($OptiMethod -eq 1)
  {
    # Check to see if the folder that the texture was to be copied to is empty.
    if ([System.IO.Directory]::GetFiles($OutputPath).Count -eq 0)
    {
      # If no files are found in the folder then remove it.
      RemovePath -LiteralPath $OutputPath
    }
  }
  # Return the reduction.
  return $OptiResults
}
#==============================================================================================================================================================================================
#  The master function to start optimizing textures. Parameter "$OptiMethod" defines where to create the texture. 1 - Output Folder, 2 - Overwrite the Texture

function OptimizeWithOptiPNG([int]$OptiMethod)
{
  # -------------------------------------------------------
  # Make sure to only run this on PNG files.
  if ($Texture.Extension -ne $PNG)
  {
    # Log/Console: Alert the user that the texture is not a PNG.
    SetConsoleMessage -MsgType 1 -Message 'Texture not in PNG format'
    $global:LogMessage = 'Skipped (Not PNG)'
    return
  }
  # Do not run this on textures with material maps.
  if ($Texture.HasMaterialMap)
  {
    # Log/Console:  Alert the user that Tino's textures should not be optimized.
    SetConsoleMessage -MsgType 1 -Message 'Textures with Material Maps are skipped.'
    $global:LogMessage = 'Skipped (Material Map)'
    return
  }
  # -------------------------------------------------------
  Write_Host ' Notice     : ' -ForegroundColor Yellow -NoNewLine
  Write-Host 'Running texture through OptiPNG. This may take some time....'

  # Optimize the base texture and get the results in a hash table.
  $BaseOptiData = OptimizeTexture -InputPath $Texture.FullPath -OptiMethod $OptiMethod

  # Store the amount of reduction so far.
  $TotalReduction = $BaseOptiData.Reduction

  # Keep track of the number of mipmaps that may fail the tests.
  $MipMapsFailedTests = 0

  # If the texture is a MipMap, look for MipMap levels and optimize them too.
  if (($Texture.IsMipMap) -or ($Texture.MipMaps -gt 1))
  {
    # Create a MipMap hash table.
    $MipMap = CreateMipMapInfo -TextureInfo $Texture -Width $Texture.Width -Height $Texture.Height

    # Loop through all lower levels.
    for($i=1; $i -le $MipMap.Levels; $i++)
    {
      # If the MipMap level exists, optimize it and store any reduction to the total texture reduction.
      if ($MipMap.Exists[$i])
      {
        # Optimize the mipmap and get the results.
        $MipMapOptiData = OptimizeTexture -InputPath $MipMap.FullPath[$i] -OptiMethod $OptiMethod

        # Add to the amount of reduction.
        $TotalReduction += $MipMapOptiData.Reduction

        # Store the total number of mipmaps that failed tests.
        if ($MipMapOptiData.FailTests)
        {
          $MipMapsFailedTests += 1
        }
      }
    }
  }
  # -------------------------------------------------------
  # Check to see if the base texture failed the tests.
  if ($BaseOptiData.FailTests)
  {
    # Check if the texture was a mipmap.
    if ($Texture.IsMipMap)
    {
      # See if all mipmaps failed the tests.
      if ($MipMapsFailedTests -eq $MipMap.Levels)
      {
        # If they did, leave now so nothing is logged.
        return
      }
    }
    # It's not a mipmap.
    else
    {
      # If the base texture failed tests then log nothing.
      return
    }
  }
  # -------------------------------------------------------
  # Check to see if there was actually any reduction between the original and custom textures. 
  if ($TotalReduction -gt 0)
  {
    # Log/Console: Increment the total number of optimized textures.
    $global:CountOptimized += 1

    # Log/Console: Display the reduced size in Bytes if it's less than 1 KB.
    if ($TotalReduction -lt 1024)
    {
      SetConsoleMessage -MsgType 2 -Message 'Texture successfully optimized (reduced by ' -EndMessage ($TotalReduction.ToString() + ' Bytes)')
      $global:LogMessage = ('Optimized (' + $TotalReduction.ToString() + ' Bytes)')
    }
    # Log/Console: Display the size in KB if its over or equal to 1 KB.
    else
    {
      $TotalReductionKB = FormatDecimal -Value ($TotalReduction/1024)
      SetConsoleMessage -MsgType 2 -Message 'Texture successfully optimized (reduced by ' -EndMessage ($TotalReductionKB.ToString() + ' KB)')
      $global:LogMessage = ('Optimized (' + $TotalReductionKB.ToString() + ' KB)')
    }
  }
  # Log/Console: If there was no reduction then the texture was already optimized.
  else
  {
    SetConsoleMessage -MsgType 1 -Message 'Texture already optimized.'
    $global:LogMessage = 'Already Optimized'
  }
  # Store the total reduction so far in Bytes.
  $global:TotalReductionB += $TotalReduction
}
#==============================================================================================================================================================================================
#  STANDARD OPTION 7: APPLY UPSCALING FILTER TO ALL TEXTURES
#==============================================================================================================================================================================================
#  Applies an upscaling filter to a texture.

function StandardUpscalingFilter([string]$BaseTexture, [string]$UpscaleFactor, [string]$OutputFile)
{
  # PNG and JPG use a different method than DDS.
  if ($UpscaleFormat -eq $PNG)
  {
    # Upscale the texture using the selected filter and filter method.
    switch -wildcard ($UpscaleFilter)
    {
      '*xBRZ'  { xBRZ-ScalerTest -Image $BaseTexture -UpscaleFactor $UpscaleFactor -Output $OutputFile }
      'waifu*' { Waifu2x-Upscale -Image $BaseTexture -UpscaleFactor $UpscaleFactor -Output $OutputFile }
      default  { Magick-UpscaleFilter -Image $BaseTexture -Filter $UpscaleFilter -UpscaleFactor $UpscaleFactor -ColorType $Texture.PNGColorType -Output $OutputFile }
    }
    # Find if the texture was actually created.
    $TextureCreated = (TestPath -LiteralPath $OutputFile)

    # No point in doing any of the below if its not a mipmap texture.
    if (($TextureCreated) -and (($Texture.IsMipMap) -or ($Texture.MipMaps -gt 1)))
    {
      # Create a temporary path to copy the result to.
      $TempFilteredPath = CreatePath -LiteralPath ($TempFolder + '\TempFiltered')
      $TemporaryTexture = $TempFilteredPath + '\' + $Texture.Name + $UpscaleFormat

      # Copy the texture a temporary folder to create mipmaps from.
      Copy-Item -LiteralPath $OutputFile -Destination $TemporaryTexture -Force

      # Create a texture hash table from the result so mipmaps can be easily generated.
      $PNGTexture = CreateTextureInfo -File (Get-Item -LiteralPath $TemporaryTexture)

      # Create the mipmaps.
      CreatePNGTextureMipMaps -TextureInfo $PNGTexture -ImagePath $PNGTexture.FullPath -Width $PNGTexture.Width -Height $PNGTexture.Height -Format $PNG -OutputPath $UpscaledPath
    }
  }
  # The method for upscaling DDS textures.
  elseif ($UpscaleFormat -eq $DDS)
  {
    # Create a temporary path for temporary textures temporarily.
    $TempFilteredPath = CreatePath -LiteralPath ($TempFolder + '\TempFiltered')
    $CreatedTexture = $TempFilteredPath + '\' + $Texture.Name + $PNG

    # Upscale the texture using the selected filter and filter method.
    switch -wildcard ($UpscaleFilter)
    {
      '*xBRZ'  { xBRZ-ScalerTest -Image $BaseTexture -UpscaleFactor $UpscaleFactor -Output $CreatedTexture }
      'waifu*' { Waifu2x-Upscale -Image $BaseTexture -UpscaleFactor $UpscaleFactor -Output $CreatedTexture }
      default  { Magick-UpscaleFilter -Image $BaseTexture -Filter $UpscaleFilter -UpscaleFactor $UpscaleFactor -ColorType $Texture.PNGColorType -Output $CreatedTexture }
    }
    # Create a texture hash table from the result so it can easily be converted to DDS.
    $DDSTexture = CreateTextureInfo -File (Get-Item -LiteralPath $CreatedTexture)

    # Create the DDS texture.
    $TextureCreated = CreateStandardTexture -TextureInfo $DDSTexture -Width $DDSTexture.Width -Height $DDSTexture.Height -Format $DDS -OutputPath $UpscaledPath
  }
  # Clean up the temporary files and folders (if they exist).
  RemovePath -LiteralPath $TempFilteredPath

  # Return that the texture was actually created.
  return $TextureCreated
}
#==============================================================================================================================================================================================
#  Applies an upscaling filter to a texture using a special method to preserve the edges of seamless textures.

function SeamlessUpscalingFilter([string]$BaseTexture, [string]$UpscaleFactor, [string]$Width, [string]$Height, [string]$OutputFile)
{
  # Tracks whether or not the final texture was created.
  $TextureCreated = $false

  # Create a temporary path for temporary textures temporarily.
  $TempFilteredPath = CreatePath -LiteralPath ($TempFolder + '\TempFiltered')

  # Set the paths to temporary files and the final result.
  $MontagePath  = $TempFilteredPath + '\montage.png'
  $CroppedPath  = $TempFilteredPath + '\cropped.png'
  $FilteredPath = $TempFilteredPath + '\filtered.png'
  $ResultPath   = $TempFilteredPath + '\result.png'

  # Create an array that holds the base texture nine times.
  $MontageTextures = @($BaseTexture, $BaseTexture, $BaseTexture, $BaseTexture, $BaseTexture, $BaseTexture, $BaseTexture, $BaseTexture, $BaseTexture)

  # Create an image using the same image 9 times with ImageMagick, which will automatically create it in a 3x3 grid.
  Magick-Montage -Collection $MontageTextures -Arguments @('-geometry', '+0+0', '-background', 'none') -Output $MontagePath

  # Get the offset of where to start cropping (from the top left of the image) by multiplying dimensions by the SeamlessCrop (global var set by the user), and flooring it to the nearest integer.
  $WidthCropOffset  = [int][System.Math]::Floor($Texture.Width * 0.75)
  $HeightCropOffset = [int][System.Math]::Floor($Texture.Height * 0.75)

  # Set the dimensions of the image to keep after the montage but before filtering. Offsets are multiplied by 2 to account for all four sides (top, bottom, left, right).
  $WidthKeepTotal  = [string](($Texture.Width * 3) - ($WidthCropOffset * 2))
  $HeightKeepTotal = [string](($Texture.Height * 3) - ($HeightCropOffset * 2))

  # Set the geometry parameter for ImageMagick to crop the image with offsets.
  $CropGeometry = $WidthKeepTotal + 'x' + $HeightKeepTotal + '+' + $WidthCropOffset + '+' + $HeightCropOffset

  # Crop the center image from the tiled image. This will leave some pixels left over for the upscaler to work with that also need to be cropped further down the line.
  Magick-Convert -Image $MontagePath -Arguments @('-crop', $CropGeometry, '+repage') -Output $CroppedPath

  # Upscale the cropped texture using the selected filter and filter method.
  switch -wildcard ($UpscaleFilter)
  {
    '*xBRZ'  { xBRZ-ScalerTest -Image $CroppedPath -UpscaleFactor $UpscaleFactor -Output $FilteredPath }
    'waifu*' { Waifu2x-Upscale -Image $CroppedPath -UpscaleFactor $UpscaleFactor -Output $FilteredPath }
    default  { Magick-UpscaleFilter -Image $CroppedPath -Filter $UpscaleFilter -UpscaleFactor $UpscaleFactor -ColorType $Texture.PNGColorType -Output $FilteredPath }
  }
  # More pixels still need to be cropped, but check for only "Noise" mode in the waifu2x mode (which doesn't upscale the image).
  if (($UpscaleFilter -like 'waifu*') -and ($Waifu2xCMode -eq 'Noise'))
  {
    # Get the offsets for the amount that still needs to be cropped.
    $WidthCropOffsetExtra  = $Texture.Width - $WidthCropOffset
    $HeightCropOffsetExtra = $Texture.Height - $HeightCropOffset

    # Since we're in "Noise" mode, use the original texture dimensions.
    $CropGeometry = $Texture.Width + 'x' + $Texture.Height + '+' + $WidthCropOffsetExtra + '+' + $HeightCropOffsetExtra
  }
  # This path is hit when using any filter other than waifu2x in noise mode.
  else
  {
    # Get the offset for the amount that still needs to be cropped.
    $WidthCropOffsetExtra  = ($Texture.Width - $WidthCropOffset) * [int]$UpscaleFactor
    $HeightCropOffsetExtra = ($Texture.Height - $HeightCropOffset) * [int]$UpscaleFactor

    # Use the new dimensions to set how much of the image to crop/keep using the above offsets.
    $CropGeometry = $Width + 'x' + $Height + '+' + $WidthCropOffsetExtra + '+' + $HeightCropOffsetExtra
  }
  # Crop the center image from what remains of the tiled image.
  Magick-Convert -Image $FilteredPath -Arguments @('-crop', $CropGeometry, '+repage', '-define', ('png:color-type=' + $Texture.PNGColorType)) -Output $ResultPath

  # If filtering PNG or JPG, mipmaps need to be generated if its a MipMap texture.
  if ($UpscaleFormat -eq $PNG)
  {
    # Path to the renamed texture so resulting texture can be renamed and texture info can be created.
    $RenamedPath = $TempFilteredPath + '\' + $Texture.Name + $PNG

    # Rename the texture using Move-Item so it can be compatible with PowerShell v2.
    Move-Item -LiteralPath $ResultPath -Destination $RenamedPath -Force

    # Copy the generated texture to the output path. This is the final step for the top level.
    Copy-Item -LiteralPath $RenamedPath -Destination $OutputFile -Force

    # Make sure the texture now exists in the path it was supposed to be moved to.
    $TextureCreated = (TestPath -LiteralPath $OutputFile)

    # No point in doing any of the below if its not a mipmap texture.
    if (($TextureCreated) -and (($Texture.IsMipMap) -or ($Texture.MipMaps -gt 1)))
    {
      # Create a texture hash table from the result so mipmaps can be generated.
      $PNGTexture = CreateTextureInfo -File (Get-Item -LiteralPath $RenamedPath)

      # Create the mipmaps.
      CreatePNGTextureMipMaps -TextureInfo $PNGTexture -ImagePath $PNGTexture.FullPath -Width $PNGTexture.Width -Height $PNGTexture.Height -Format $PNG -OutputPath $UpscaledPath
    }
  }
  # If the original texture was DDS then convert it back to DDS.
  elseif ($UpscaleFormat -eq $DDS)
  {
    # Path to the renamed texture so texture info can be created.
    $RenamedPath = $TempFilteredPath + '\' + $Texture.Name + $PNG

    # Rename the texture using Move-Item so it can be compatible with PowerShell v2.
    Move-Item -LiteralPath $ResultPath -Destination $RenamedPath -Force

    # Create a texture hash table from the result so it can easily be converted to DDS.
    $DDSTexture = CreateTextureInfo -File (Get-Item -LiteralPath $RenamedPath)

    # Create the DDS texture.
    $TextureCreated = CreateStandardTexture -TextureInfo $DDSTexture -Width $Width -Height $Height -Format $DDS -OutputPath $UpscaledPath
  }
  # Clean up the temporary files and folders.
  RemovePath -LiteralPath $TempFilteredPath

  # Return that the texture was actually created.
  return $TextureCreated
}
#==============================================================================================================================================================================================
#  The master function that is ran from the main loop which sets up data for the above functions. 

function ApplyUpscalingFilter()
{
  # Set the upscale limit for MaxWidth/MaxHeight.
  $MaxUpscale = 32768
  $MaxWidth   = ($MaxUpscale / 2)
  $MaxHeight  = ($MaxUpscale / 2)

  # Do not run this on enormous textures.
  if (($Texture.Width -gt $MaxWidth) -or ($Texture.Height -gt $MaxHeight))
  {
    Write_Host ' Notice     : ' -ForegroundColor Magenta -NoNewLine
    Write-Host ('Input texture exceeds the limit of ' + $MaxWidth + 'x' + $MaxHeight + ' so it will not be upscaled!')
    $global:LogMessage = 'Skipped: Dimensions Exceed ' + $MaxWidth + 'x' + $MaxHeight
    return
  }
  #------------------------------------------------------------------------------------------------------------------------------------
  # Make sure the directory to create rescaled textures exists.
  $UpscaledPath = CreatePath -LiteralPath ($MasterOutputPath + '\FilteredTextures(' + $UpscaleFilter + ')' + $Texture.Relative)

  # If it's a PNG or JPG image then use the base texture.
  if ($Texture.Extension -ne $DDS)
  {
    # Use the existing texture in the pack as a base.
    $UpscaleBase = $Texture.FullPath

    # Make the final texture in PNG format.
    $UpscaledTexture = $UpscaledPath + '\' + $Texture.Name + $PNG
  }
  # If it's a DDS texture, create a temporary PNG image.
  else
  {
    # Do not attempt to filter Ishiiruka DDS textures.
    if ($Texture.HasMaterialMap)
    {
      Write_Host ' Notice     : ' -ForegroundColor Magenta -NoNewLine
      Write-Host 'Ishiiruka DDS textures can not have upscaling filters applied!'
      $global:LogMessage = 'Skipped: Ishiiruka DDS Texture'
      return
    }
    # Create a temporary folder to create a PNG file from the image.
    $TempUpscalePath = CreatePath -LiteralPath ($TempFolder + '\TempConvert')
    $UpscaleBase = $TempUpscalePath + '\' + $Texture.Name + $PNG

    # BC7 textures require TexConv.
    if ($Texture.ImageFormat -eq 'BC7')
    {
      # Create the temporary image using TexConv.
      $Pizza = RunTexConvTool -Image $Texture.FullPath -Arguments @('-y', '-ft', 'PNG', '-f', 'R8G8B8A8_UNORM') -OutputPath $TempUpscalePath
    }
    # All other formats can use ImageMagick.
    else
    {
      # Create the temporary texture.
      $Pizza = Magick-Convert -Image $Texture.FullPath -Output $UpscaleBase
    }
    # Make the final texture in DDS format.
    $UpscaledTexture = $UpscaledPath + '\' + $Texture.Name + $UpscaleFormat
  }
  #------------------------------------------------------------------------------------------------------------------------------------
  # Store the amount of scaling which will be used instead of the actual amount in functions because it can change below.
  $NewScale = $FilterNewScale

  # Calculate the new width/height which is determined by the scaling factor.
  $NewWidth  = $Texture.Width * [int]$NewScale
  $NewHeight = $Texture.Height * [int]$NewScale

  # Check to if the user is trying to create textures larger than the max values (usually 8192x8192).
  if (($NewWidth -gt [int]$MaxUpscale) -or ($NewHeight -gt [int]$MaxUpscale))
  {
    # Choose the greater of the two dimensions to find the new scaling value.
    $DimensionCheck   = [System.Math]::Max($Texture.Width, $Texture.Height)
    $DimensionResult  = [System.Math]::Max($NewWidth, $NewHeight)

    # Find a lower scaling value. Loop until the result is less than the maximum if possible.
    while($DimensionResult -gt $MaxUpscale)
    {
      # Each iteration decrements the scale by 1x. We want this in string format for functions...
      $NewScale = ([int]$NewScale - 1).ToString()

      # Calculate the new dimension to see if it passes the condition to end the loop.
      $DimensionResult = $DimensionCheck * [int]$NewScale
    }
    # Make sure the upscaling factor is actually worth our time.
    if ([int]$NewScale -gt 1)
    {
      # Report to the user the texture will have a reduced upscaling value.
      Write_Host ' Notice     : ' -ForegroundColor Magenta -NoNewLine
      Write-Host ('Texture result exceeds ' + $MaxUpscale + 'x' + $MaxUpscale + '! Using a smaller scaling value (' + $NewScale + 'x).')
    }
    # If the upscale factor failed to be greater than 1x.
    else
    {
      # Report to the user that an upscaling filter will not be applied.
      Write_Host ' Notice     : ' -ForegroundColor Magenta -NoNewLine
      Write-Host 'Texture is too large to apply an upscaling value!'
      return
    }
    # Calculate the new width/height which is determined by the scaling factor.
    $NewWidth  = $Texture.Width * [int]$NewScale
    $NewHeight = $Texture.Height * [int]$NewScale
  }
  #------------------------------------------------------------------------------------------------------------------------------------
  # Apply the seamless technique if: the texture has alpha and seamless is set to "all", or if the texture has no alpha and seamless is not set to "disable".
  if ((($Texture.HasAlphaPixels) -and ($SeamlessMethod -eq 'All')) -or ((!$Texture.HasAlphaPixels) -and ($SeamlessMethod -ne 'Disable')))
  {
    $TextureCreated = SeamlessUpscalingFilter -BaseTexture $UpscaleBase -UpscaleFactor $NewScale -Width $NewWidth -Height $NewHeight -OutputFile $UpscaledTexture
  }
  # Otherwise just upscale the texture using the standard method.
  else
  {
    $TextureCreated = StandardUpscalingFilter -BaseTexture $UpscaleBase -UpscaleFactor $NewScale -OutputFile $UpscaledTexture
  }
  #------------------------------------------------------------------------------------------------------------------------------------
  # Log/Console: Report that the texture has been created.
  if ($TextureCreated)
  {
    # Log/Console: Add the logging events.
    $FilterResult = $NewScale + 'x, ' + $NewWidth.ToString() + 'x' + $NewHeight.ToString() + ', ' + $UpscaleFilter
    SetConsoleMessage -MsgType 1 -Message ('Successfully upscaled the texture (' + $FilterResult + ')!')
    $global:LogMessage = ('Filtered (' + $FilterResult + ')')
  }
  # Log/Console: If the texture was not created, report an error.
  else
  {
    # Log/Console: Add the logging events.
    SetConsoleMessage -MsgType 0 -Message 'Texture failed creation and was not upscaled!'
    $global:LogMessage = 'Failed Creation'
  }
  # If the texture was DDS this will need to be cleaned.
  RemovePath -LiteralPath $TempUpscalePath
}
#==============================================================================================================================================================================================
#  ADVANCED OPTION 1: GENERATE NEW MIPMAPS
#==============================================================================================================================================================================================
#  Generates new mipmaps within the texture pack itself.

function GenerateNewMipMaps()
{
  # Do not even run any code here if the texture is not a MipMap.
  if (!$Texture.IsMipMap)
  {
    # Log/Console: Add the logging events.
    SetConsoleMessage -MsgType 1 -Message 'Texture is not a MipMap [m] texture.'
    $global:LogMessage = 'Not a MipMap Texture'
    return
  }
  # Create a temporary folder to generate the MipMaps to.
  $TempForceMipMapsPath = CreatePath -LiteralPath ($TempFolder + '\TempForceMipMaps')

  # Create the converted texture. The below function will automatically handle creating mipmaps.
  $MipMappedTexture = CreateTexture -TextureInfo $Texture -Width $Texture.Width -Height $Texture.Height -Format $Texture.Extension -OutputPath $TempForceMipMapsPath

  # Loop through all textures in the current directory.
  foreach($MipMap in Get-ChildItem -LiteralPath $Texture.Path)
  {
    # Check to see if the current texture name is similar to the target texture name.
    if ($MipMap.BaseName -like ($Texture.Name + '*'))
    {
      # Remove the texture/MipMap.
      $RemoveFile = [string]$MipMap.Directory + '\' + $MipMap.Name
      RemovePath -LiteralPath $RemoveFile
    }
  }
  # Loop through all textures found in the temp MipMap directory.
  foreach($MipMap in Get-ChildItem -LiteralPath $TempForceMipMapsPath)
  {
    # Check to see if the current texture name is similar to the target texture name.
    if ($MipMap.BaseName -like ($Texture.Name + '*'))
    {
      # Move the texture/MipMap to the current texture path.
      $MoveFile = [string]$MipMap.Directory + '\' + $MipMap.Name
      Move-Item -LiteralPath $MoveFile -Destination $Texture.Path -Force
    }
  }
  # Log/Console: Report that the texture has been created.
  if ($MipMappedTexture)
  {
    # Increment the counting variable.
    $global:CountMipMapped += 1

    # Log/Console: Add the logging events.
    Write_Host ' Message    : ' -ForegroundColor Green -NoNewLine
    Write-Host 'Generated new mipmaps for this texture!'
    $global:LogMessage = 'MipMaps Generated'
  }
  # Log/Console: If the texture was not created, report an error.
  else
  {
    # Log/Console: Add the logging events.
    Write_Host ' Message    : ' -ForegroundColor Red -NoNewLine
    Write-Host 'Failed creating mipmaps for this texture!'
    $global:LogMessage = 'MipMaps Failed'
  }
  # Cleanup the temporary textures.
  RemovePath -LiteralPath $TempForceMipMapsPath
}
#==============================================================================================================================================================================================
#  STANDARD OPTION 8: CALCULATE TEXTURES VRAM REQUIREMENT
#==============================================================================================================================================================================================
#  Sub-function of "CalculateVRAMForTextures". Also used when converting or rescaling texture packs.
#  I definitely could have used other parts of my code, and/or optimized this function further. Oh well, I just wanted something that works.

function GetTextureVRAMUsage([string]$ImagePath)
{
  # Get the extension of the image to know which course of action to take.
  $Extension = (Get-Item -LiteralPath $ImagePath).Extension

  # Get the image as a byte array.
  $ByteArray = [System.IO.File]::ReadAllBytes($ImagePath)

  # For PNG images, the dimensions can be pulled from the header.
  if ($Extension -eq $PNG)
  {
    # Read value 17-20 for width and 21-24 for height. Remove all dashes from the byte array.
    $HexWidth  = ([System.BitConverter]::ToString($ByteArray[16..19])).Replace('-','')
    $HexHeight = ([System.BitConverter]::ToString($ByteArray[20..23])).Replace('-','')

    # Convert the hex value to decimal.
    $Width   = [System.Convert]::ToInt32($HexWidth,16)
    $Height  = [System.Convert]::ToInt32($HexHeight,16)

    # Add to the number of PNG textures.
    $global:VRAMCountPNG += 1

    # Calculate the amount of VRAM usage in MB.
    return ($Width * $Height * 4)
  }
  # For JPG images, a bitmap object must be created to get dimension.
  elseif ($Extension -eq $JPG)
  {
    # Get the image as a bitmap object.
    $ImageObject = New-Object System.Drawing.Bitmap $ImagePath

    # Get the dimensions.
    $Width  = $ImageObject.Width
    $Height = $ImageObject.Height

    # Add to the number of JPG textures.
    $global:VRAMCountJPG += 1

    # Calculate the amount of VRAM usage.
    return ($Width * $Height * 4)
  }
  # As always, DDS textures are a mess to work with.
  elseif ($Extension -eq $DDS)
  {
    # Get the width and height. DDS headers are little endian so they must be read backwards.
    $HexWidth   = ([System.BitConverter]::ToString($ByteArray[19..16])).Replace('-','')
    $HexHeight  = ([System.BitConverter]::ToString($ByteArray[15..12])).Replace('-','')
    $HexMipMaps = ([System.BitConverter]::ToString($ByteArray[28]))

    # Convert the hex value to decimal.
    $Width   = [System.Convert]::ToInt32($HexWidth,16)
    $Height  = [System.Convert]::ToInt32($HexHeight,16)
    $MipMaps = [System.Convert]::ToInt32($HexMipMaps,16)

    # The dimensions must be calculated as a multiple of four.
    $MultFourBytes = DDSMultFour -Width $Width -Height $Height

    # The DDS header from bytes 85-88 should hold the FOURCC value to identify the compression format or if it has a DX10 header.
    # DXT1: 44-58-54-31, DXT3: 44-58-54-31, DXT5: 44-58-54-35, DX10: 44-58-31-30
    $DDSFourCC = [System.BitConverter]::ToString($ByteArray[84..87])
    $DDSFourCC = [string]::Join('',($DDSFourCC.Split('-') | foreach { [char][byte]([System.Convert]::ToInt16($_, 16)) }))

    # The DX10 FourCC flag is not very useful on its own. We must get the actual compression type from a different flag.
    if ($DDSFourCC -eq 'DX10')
    {
      # Get the block compression type found at Byte[128] and convert it to base 10.
      $DX10BCFlag = [System.Convert]::ToInt32([System.BitConverter]::ToString($ByteArray[128]), 16)

      # Get the type that it represents.
      $DDSFourCC = GetDX10BlockCompression -DXGI_FORMAT $DX10BCFlag
    }
    # Get the total size of the image so far. Default uncompressed texture formats.
    switch ($DDSFourCC)
    {
      'DXT1'  { $TotalSize = ($MultFourBytes.Width * $MultFourBytes.Height) / 2 }
      'DXT3'  { $TotalSize = ($MultFourBytes.Width * $MultFourBytes.Height) }
      'DXT5'  { $TotalSize = ($MultFourBytes.Width * $MultFourBytes.Height) }
      'BC7'   { $TotalSize = ($MultFourBytes.Width * $MultFourBytes.Height) }
      default { $TotalSize = ($Width * $Height * 4) }
    }
    # Check to see if the image has internal mipmaps.
    if ($MipMaps -gt 1)
    {
      # The same shit must be done for every mipmap.
      for($i=1; $i -lt $MipMaps; $i++)
      {
        # Calculate the dimensions of the mipmap.
        $MipWidth  = CalculateMipMapDimension -Level $i -Dimension $Width
        $MipHeight = CalculateMipMapDimension -Level $i -Dimension $Height

        # Again the pixels need to be calculated in 4x4 blocks as opposed to using the actual resolution.
        $MultFourBytes = DDSMultFour -Width $MipWidth -Height $MipHeight

        # Add the size of the mipmap to the total size.
        switch ($DDSFourCC)
        {
          'DXT1'  { $TotalSize += ($MultFourBytes.Width * $MultFourBytes.Height) / 2 }
          'DXT3'  { $TotalSize += ($MultFourBytes.Width * $MultFourBytes.Height) }
          'DXT5'  { $TotalSize += ($MultFourBytes.Width * $MultFourBytes.Height) }
          'BC7'   { $TotalSize += ($MultFourBytes.Width * $MultFourBytes.Height) }
          default { $TotalSize += ($Width * $Height * 4) }
        }
      }
    }
    # Add to the number of DDS textures.
    $global:VRAMCountDDS += 1

    # The total size of the image has been calculated so return it.
    return $TotalSize
  }
}
#==============================================================================================================================================================================================
#  Runs a loop separate from the master loop and calculates VRAM for all textures in the "VRAMPackPath" variable which is set from the GUI.

function CalculateVRAMForTextures()
{
  Clear-Host
  Write_Host '-----------------------------------------------------------------------------------------------------------------------' -ForegroundColor Gray
  Write_Host (' ' + $TitleBarMessage.Replace('-','').Trim() + ' usage for textures ...') -ForegroundColor Yellow
  Write_Host '-----------------------------------------------------------------------------------------------------------------------' -ForegroundColor Gray

  # Zero out the VRAM calculation. It is stored in bytes, which can get huge, so a 64-bit integer is used.
  [int64]$global:VRAMTotal = 0

  # Count the number of file types just for shits and giggles.
  $global:VRAMCountPNG = 0
  $global:VRAMCountDDS = 0
  $global:VRAMCountJPG = 0

  # Loop through all folders and sub-folders to attempt to find texture files.
  foreach($File in Get-ChildItem -LiteralPath $VRAMPackPath -Recurse -Force -ErrorAction 'SilentlyContinue')
  {
    # Build a list of accepted file extensions.
    $ExtList = @($PNG, $JPG, $DDS)

    # When checking Dolphin textures, other images will throw off the calculation, so only allow them with "Allow All Images".
    $Validation = (($AllowAllImages) -or ($File.Name -like 'tex1_*'))

    # See if the file's extension is on that list.
    if (($Validation) -and ($ExtList -contains $File.Extension))
    {
      # Get the amount of VRAM consumption.
      $VRAMSize = GetTextureVRAMUsage -ImagePath $File.FullName

      # Add the calculated VRAM usage to the total usage.
      [int64]$global:VRAMTotal += $VRAMSize

      # Calculate the VRAM usage in MB to display to the user.
      $VRAMSizeMB = (FormatDecimal -Value ($VRAMSize / 1024 / 1024))

      # Display the VRAM usage to the user.
      Write_Host (' ' + (ExtendString -InputString $File.Name -Length 52)) -ForegroundColor Green -NoNewLine
      Write-Host (' : ' + $VRAMSizeMB + ' MB')
    }
  }
  # Get the total VRAM consumption in megabytes. Make sure it only has two decimal places.
  $VRAMTotalMB = (FormatDecimal -Value ($VRAMTotal / 1024 / 1024))

  # Report the total consumption and number of file types to the user.
  Write_Host '-----------------------------------------------------------------------------------------------------------------------' -ForegroundColor Gray
  Write-Host ''
  if ($VRAMCountPNG -gt 0)
  {
    Write_Host (' Total PNG Textures     : ') -ForegroundColor Cyan -NoNewLine
    Write-Host $VRAMCountPNG
  }
  if ($VRAMCountJPG -gt 0)
  {
    Write_Host (' Total JPG Textures     : ') -ForegroundColor Cyan -NoNewLine
    Write-Host $VRAMCountJPG
  }
  if ($VRAMCountDDS -gt 0)
  {
    Write_Host (' Total DDS Textures     : ') -ForegroundColor Cyan -NoNewLine
    Write-Host $VRAMCountDDS
  }
  Write_Host (' Total VRAM Requirement : ') -ForegroundColor Cyan -NoNewLine
  Write-Host ($VRAMTotalMB.ToString() + ' MB')
  Write-Host ''
  Write_Host '-----------------------------------------------------------------------------------------------------------------------' -ForegroundColor Gray
}
#==============================================================================================================================================================================================
#  ADVANCED OPTION 2: REMOVE INVALID MIPMAPS
#==============================================================================================================================================================================================
#  Removes mipmaps from textures that aren't actually mipmap textures.

function RemoveInvalidMipMaps()
{
  # We only want to work with textures that are not mipmap textures.
  if (($Texture.IsMipMap) -or ($Texture.HasMaterialMap))
  {
    # Log/Console: Add the logging events.
    SetConsoleMessage -MsgType 1 -Message 'OK'
    $global:LogMessage = 'OK'
    return
  }
  # Count for the number of bad MipMaps.
  $InvalidMipMaps = 0
  $InvalidInternal = 0

  # Loop through all textures in the current directory.
  foreach($MipMap in Get-ChildItem -LiteralPath $Texture.Path)
  {
    # Check to see if the texture name is similar to the current loop texture.
    if ($MipMap.Name -like ($Texture.Name + '*' + $Texture.Extension))
    {
      # Split the texture name into 6 slots.
      $NameSplit = $MipMap.BaseName.Split('_.',6)

      # Loop through slot 5 (detects non-mipmaps) and slot 6 (detects paletted non-mipmaps).
      for($x=4; $x -lt 6; $x++)
      {
        # Are we deep enough yet? If it exists, then check the first letter for "m" (which is extracted from "mip").
        if (($NameSplit[$x]) -and ($NameSplit[$x].Substring(0,1) -eq 'm'))
        {
          # Balls deep. If it passes, remove the file.
          RemovePath -LiteralPath ($Texture.Path + '\' + $MipMap)

          # Console: Update the console with the texture that was removed.
          Write_Host ' Removed    : ' -ForegroundColor Red -NoNewLine
          Write-Host $MipMap

          # Track that MipMaps were deleted and count how many.
          $DeletedMipMaps = $true
          $InvalidMipMaps ++
        }
      }
    }
  }
  # If dealing with a DDS texture, remove any internal mipmaps if present.
  if (($Texture.Extension -eq $DDS))
  {
    # Create a folder to extract MipMaps to.
    $ExtractedPath = CreatePath -LiteralPath ($TempFolder + '\Extracted')

    # Extract MipMaps from the texture to see if it has internal MipMaps.
    ExtractInternalDDSMipMaps -ImagePath $Texture.FullPath -OutputPath $ExtractedPath

    # Count the number of files that remain in the folder, and subtract 1 to compensate for the top level.
    $InvalidInternal = ([System.IO.Directory]::GetFiles($ExtractedPath).Count) - 1

    # Check if there are internal mipmaps.
    if ($InvalidInternal -gt 0)
    {
      # If there was, create a path to the extracted top level that does not contain internal mipmaps.
      $ExtractedTexture = $ExtractedPath + '\' + $Texture.FullName

      # Overwrite the texture in the pack that has internal mipmaps with the texture that does not have internal mipmaps.
      Move-Item -LiteralPath $ExtractedTexture -Destination $Texture.Path -Force

      # Track that MipMaps were deleted.  
      $DeletedInternal = $true

      # Console: Update the console saying mipmaps were removed.
      Write-Host (' Removed    : ' + $InvalidInternal + ' invalid internal mipmaps.') -ForegroundColor Green
    }
    # Remove the temporary directory and all extracted mipmaps.
    RemovePath -LiteralPath $ExtractedPath
  }
  # Check to see if MipMaps were deleted.
  if ($DeletedMipMaps -or $DeletedInternal)
  {
    # Count the number of textures with invalid mipmaps.
    $global:CountInvalidMips += 1

    # If both types of mipmaps were deleted, then display the number of both.
    if (($DeletedMipMaps) -and ($DeletedInternal))
    {
      $global:LogMessage = ('Removed ' + $InvalidMipMaps + ' Invalid MipMaps, Removed ' + $InvalidInternal + ' Invalid Internal MipMaps')
    }
    # If only external mipmaps were deleted then show those.
    elseif ($DeletedMipMaps)
    {
      $global:LogMessage = ('Removed ' + $InvalidMipMaps + ' Invalid MipMaps')
    }
    # Last possible situation is internal mipmaps were deleted.
    else
    {
      $global:LogMessage = ('Removed ' + $InvalidInternal + ' Invalid Internal MipMaps')
    }
  }
  # No MipMaps were deleted.
  else
  {
    # Log/Console: Because no MipMaps were removed, update both the console and log saying that the texture is ok.
    SetConsoleMessage -MsgType 1 -Message 'OK'
    $global:LogMessage = 'OK'
  }
}
#==============================================================================================================================================================================================
#  ADVANCED OPTION 3: EXTRACT INTERNAL DDS MIPMAPS
#==============================================================================================================================================================================================
#  Extracts internal mipmaps from all DDS Textures found.

function ExtractAllDDSMipMaps()
{
  # We only want to work with DDS textures.
  if ($Texture.Extension -ne $DDS)
  {
    # Log/Console: Add the logging events.
    SetConsoleMessage -MsgType 1 -Message 'Image is not a DDS texture.'
    $global:LogMessage = 'Not a DDS Texture'
    return
  }
  # Create a folder to extract MipMaps to.
  $ExtractedPath = CreatePath -LiteralPath ($TempFolder + '\DDSExtracted')

  # Extract all internal DDS MipMaps.
  ExtractInternalDDSMipMaps -ImagePath $Texture.FullPath -OutputPath $ExtractedPath

  # Count the number of mipmaps in the temporary folder. Subtract 1 to account for the top layer.
  $DDSLevelsCounted = ([System.IO.Directory]::GetFiles($ExtractedPath).Count) - 1

  # Check to see if there are actually any internal mipmaps to be found.
  if ($DDSLevelsCounted -gt 0)
  {
    # Loop through all DDS mipmaps.
    foreach($DDSMipMap in Get-ChildItem -LiteralPath $ExtractedPath)
    {
      # Move the mipmap to the texture path.
      $DDSDestination = $Texture.Path + '\' + $DDSMipMap
      Move-Item -LiteralPath $DDSMipMap.FullName -Destination $DDSDestination -Force

      # Keep track if at least 1 mipmap was moved.
      $MipMapsMoved = $true
    }
  }
  # If any mipmaps were moved at all then log the number of them moved.
  if ($MipMapsMoved)
  {
    # Log/Console: Report that the texture is okay.
    Write_Host ' Message    : ' -ForegroundColor Green -NoNewLine
    Write-Host ('Extracted ' + $DDSLevelsCounted + ' MipMaps')
    $global:LogMessage = 'Extracted ' + $DDSLevelsCounted + ' MipMaps'
  }
  # Also log if no mipmaps were found.
  else
  {
    # Log/Console: Report that the texture is okay.
    SetConsoleMessage -MsgType 1 -Message ('No DDS internal MipMaps were found.')
    $global:LogMessage = 'No Internal MipMaps Found'
  }
  # Remove the temporary folder.
  RemovePath -LiteralPath $ExtractedPath
}
#==============================================================================================================================================================================================
#  ADVANCED OPTION 4: REMOVE ALPHA CHANNEL FROM OPAQUE TEXTURES
#==============================================================================================================================================================================================
#  Recreates a texture that has an alpha channel but doesn't actually contain transparent pixels, into a texture that does not have an alpha channel.

function RemoveAlphaChannel()
{
  # Fuck JPG don't do anything with it.
  if ($Texture.Extension -eq $JPG)
  {
    # Log/Console: Report stuff.
    Write_Host ' Message    : ' -ForegroundColor Yellow -NoNewLine
    Write-Host 'JPG textures can not have transparency so they are skipped.'
    $global:LogMessage = 'Skipped (JPG Format)'
    return
  }
  # Check if there are no transparent pixels.
  if (!$Texture.HasAlphaPixels)
  {
    # Set up the temporary paths.
    $TempPath    = CreatePath -LiteralPath ($TempFolder + '\Repaired\')
    $TempTexture = $TempPath + $Texture.FullName

    # PNG is easy, simply generate it without alpha.
    if ($Texture.Extension -eq $PNG)
    {
      # Create the texture without an alpha channel.
      Magick-Convert -Image $Texture.FullPath -Arguments @('-alpha', 'off') -Output $TempTexture
    }
    # The function "CreateStandardTexture" automatically handles alpha in DDS files. 
    elseif ($Texture.Extension -eq $DDS)
    {
      # Because it was meant to return something, and this is an unusual but effective use, store it in a random variable to avoid the result spilling over.
      $Pumpkin = CreateStandardTexture -TextureInfo $Texture -Width $Texture.Width -Height $Texture.Height -Format $DDS -OutputPath $TempPath
    }
    # Make sure the texture was created.
    if (TestPath -LiteralPath $TempTexture)
    {
      # Count the number of textures that had their alpha channel removed.
      $global:CountSlicedAlpha += 1

      # Move the result to the output path.
      Move-Item -LiteralPath $TempTexture -Destination $Texture.FullPath -Force

      # Log/Console: Report stuff.
      Write_Host ' Notice     : ' -ForegroundColor Green -NoNewLine
      Write-Host 'Alpha channel successfully removed from opaque texture!'
      $global:LogMessage = 'Alpha Removed'
    }
    # Destroy the temporary path.
    RemovePath -LiteralPath $TempPath
  }
  # Texture has both transparency + alpha, or no transparency + no alpha.
  else
  {
    # Log/Console: Report stuff.
    SetConsoleMessage -MsgType 1 -Message 'OK'
    $global:LogMessage = 'OK'
  }
}
#==============================================================================================================================================================================================
#  ADVANCED OPTION 5: COMBINE MULTIPLE TEXTURES
#==============================================================================================================================================================================================
#  This option does not run from the "Master Loop". It is initiated through the GUI when the "Start" button is pressed and bypasses the "Master Loop".

function CombineMultipleTextures()
{
  # Output that the loop is about to start to the PS window.
  Clear-Host
  Write_Host '-----------------------------------------------------------------------------------------------------------------------' -ForegroundColor Gray
  Write_Host ' Combining textures ...' -ForegroundColor Yellow
  Write_Host '-----------------------------------------------------------------------------------------------------------------------' -ForegroundColor Gray
  Write-Host ''

  # Create the output path if it doesn't exist.
  $OutputPath = CreatePath -LiteralPath ($MasterOutputPath + '\CombinedTexture\')

  # Set the full texture output path to include the "CombinedName" which is inherited from the GUI text box "Texture Output Name" (aka $CombineNameTextBox).
  $TexOutputPath = $OutputPath + $CombinedName + $PNG

  # Create an empty array because we need each texture in a normal array instead of a 2D one.
  $MontageTextures = @()

  # Loop through all entries in "$TextureArray" which is a 2-Dimensional global array created by the GUI.
  foreach($TexEntry in $TextureArray)
  {
    # The TextureArray will hold null values because it does not use [0] as a placeholder. We don't want them, so ignore them.
    if ($TexEntry -ne $null)
    {
      # Write the name of the texture to the console.
      Write-Host (' ' + $TexEntry)

      # Add the current texture to the collection.
      $MontageTextures += $TexEntry
    }
  }
  # Create the image by montaging all images in the texture array.
  Magick-Montage -Collection $MontageTextures -Arguments @('-tile', ($TextureRows + 'x' + $TextureColumns), '-geometry', '+0+0', '-background', 'none') -Output $TexOutputPath

  # Check to see if the texture was created.
  if (TestPath -LiteralPath $TexOutputPath)
  {
    # Set the path to generate a CTT file.
    $CTTFile = $OutputPath + $CombinedName + '.ctt'

    # If a CTT file already exists, remove it before starting to add data to it.
    RemovePath -LiteralPath $CTTFile

    # Add data to the CTT file.
    Add-Content -LiteralPath $CTTFile -value $TexOutputPath
    Add-Content -LiteralPath $CTTFile -value $TextureRows
    Add-Content -LiteralPath $CTTFile -value $TextureColumns

    # Add the list of texture names to the CTT file.
    foreach($TexEntry in $MontageTextures)
    {
      Add-Content -LiteralPath $CTTFile -value ([string](Get-ChildItem -LiteralPath $TexEntry).Name)
    }
  }
  # Display to the user that we're done here.
  Write-Host ''
  Write_Host '-----------------------------------------------------------------------------------------------------------------------' -ForegroundColor Gray
  Write-Host ''
}
#==============================================================================================================================================================================================
#  ADVANCED OPTION 6: SPLIT COMBINED MULTI-TEXTURE
#==============================================================================================================================================================================================
#  This option does not run from the "Master Loop". It is initiated through the GUI when the "Start" button is pressed and bypasses the "Master Loop".

function GUI_SplitMultiTexture()
{
  # Output that the loop is about to start to the PS window.
  Clear-Host
  Write_Host '-----------------------------------------------------------------------------------------------------------------------' -ForegroundColor Gray
  Write_Host ' Splitting texture ...' -ForegroundColor Yellow
  Write_Host '-----------------------------------------------------------------------------------------------------------------------' -ForegroundColor Gray
  Write-Host ''

  # If a CTT file was selected display that it was loaded.
  if ($CTTDataFile -ne '')
  {
    Write-Host ' Retrieved data from previously generated CTT file...'
    Write-Host ''
  }
  # Otherwise just display that it's being split.
  else
  {
    Write-Host ' Splitting the texture into multiple pieces...'
    Write-Host ''
  }
  # Create the output path if it doesn't exist. Get the name of the texture to use as the output string.
  $OutputPath = CreatePath -LiteralPath ($MasterOutputPath + '\SplitTextures\')
  $OutputName = [string](Get-ChildItem -LiteralPath $CombinedTexture).BaseName

  # Calculate the width and height of each individual image.
  $Dimensions = GetImageInfo -ImagePath $CombinedTexture
  $TileWidth  = $Dimensions.Width / [int]$CTextureColumns
  $TileHeight = $Dimensions.Height / [int]$CTextureRows

  # For anything else, crop using the new dimensions.
  $CropGeometry = $TileWidth.ToString() + 'x' + $TileHeight.ToString()

  # Set the full texture output path to include the texture name plus the IM "_%d" parameter to give each image a digit (0, 1, 2, etc).
  $OutputFile = $OutputPath + $OutputName + '_%d.png'

  # Divide the image up based on the calculated dimensions. This command actually creates multiple images. 
  # The "_%d" parameter in the name results in image0, image1, image2, etc...
  Magick-Convert -Image $CombinedTexture -Arguments @('-crop', $CropGeometry, '+repage') -Output $OutputFile

  # Start with index 0 since that is where ImageMagick starts when renaming the split images.
  $Index = 0

  # Loop through all rows.
  for($row = 1; $row -le [int]$CTextureRows; $row++)
  {
    # And loop through all columns.
    for($col = 1; $col -le [int]$CTextureColumns; $col++)
    {
      # Create the current name of the texture (the result from ImageMagick).
      $CurrentName = $OutputPath + $OutputName + '_' + $Index + '.png'

      # If a CTT file was selected rename all textures back to their original names.
      if ($CTTDataFile -ne '')
      {
        # Create a new name for the texture.
        $UpdateName = $OutputPath + $CTextureArray[$row,$col]

        # Display stuff to the console.
        Write-Host (' Texture ' + $row + ',' + $col + ' created as ' + $CTextureArray[$row,$col])

        # Rename the texture based on what was found in the CTT file.
        Move-Item -LiteralPath $CurrentName -Destination $UpdateName -Force
      }
      else
      {
        # Update the variable to store only the name of the texture.
        $CurrentName = [string](Get-ChildItem -LiteralPath $CurrentName).Name

        # Display stuff to the console.
        Write-Host (' Texture ' + $row + ',' + $col + ' created as ' + $CurrentName)
      }
      # Increment the index number.
      $Index++
    }
  }
  # Display to the user that we're done here.
  Write-Host ''
  Write_Host '-----------------------------------------------------------------------------------------------------------------------' -ForegroundColor Gray
  Write-Host ''
}
#==============================================================================================================================================================================================
#  MASTER LOOP: COPY NON-TEXTURES
#==============================================================================================================================================================================================
#  Set of conditions to check whether or not to copy a "non-texture file" when using Options 5 or 6.

function CheckNonTextureFile($file)
{
  # Only copy non-texture files if the user is converting or rescaling a pack.
  if (($MasterOperation -eq 'ForceIntScaling') -or ($MasterOperation -eq 'ConvertTextures'))
  {
    # Check to see if a folder snuck its way in or some (bug?) that has no file name or path.
    if ((!$file.PSIsContainer) -and ($file.Name.Length -gt 0))
    {
      # Set up the series of checks in a variable array.
      $CopyCheck = New-Object bool[] 13

      # Go through and store the result of each check into the array.
      $CopyCheck[0]  = ($file.DirectoryName -notlike '*~*')               # - Verify that the file is not in the generated directory.
      $CopyCheck[1]  = ($file.Name -notlike 'tex1*.png')                  # - Verify that it's not a Dolphin PNG texture.
      $CopyCheck[2]  = ($file.Name -notlike 'tex1*.dds')                  # - Verify that it's not a Dolphin DDS texture.
      $CopyCheck[3]  = ($file.Name -notlike 'tex1*.jpg')                  # - Verify that it's not a Dolphin JPG texture.
      $CopyCheck[4]  = ($file.Name -notlike '*_mip*')                     # - Verify that it's not a mipmap texture.
      $CopyCheck[5]  = ($file.Name -notlike '*.log')                      # - Verify that it's not this script's log file (.txt files can still pass).
      $CopyCheck[6]  = ($file.Name -notlike '*.ps1')                      # - Verify that it's not a PowerShell script.
      $CopyCheck[7]  = ($file.Name -notlike '*thumbs.db')                 # - Verify that it's not a Windows thumbnail database file.
      $CopyCheck[8]  = ($file.Name -notlike '*nvdxt_scratch.tmp')         # - Verify that it's not a leftover DDS Utilities file.
      $CopyCheck[9]  = ($file.Name -notlike '*desktop.ini')               # - Verify that it's not a Windows desktop ini file.
      $CopyCheck[10] = ($file.Name -notlike '*Custom Texture Tool PS*')   # - Verify that it's not anything relating to CTT-PS.
      $CopyCheck[11] = ($file.Name -notlike '*CTT-PS Changelog*')         # - Verify that it's not the CTT-PS changelog.
      $CopyCheck[12] = ($file.Name -notlike '*PS Execution Policy*')      # - Verify enough of the name of that included batch script to skip it.

      # If all conditions pass return true to copy the texture.
      return (TestBooleanArray -Array $CopyCheck)
    }
  }
  # If it didn't pass the initial checks then do not copy the file.
  return $false
}
#==============================================================================================================================================================================================
#  Copies a "non-texture file" if it passes all the checks in the above function.

function AttemptCopyNonTextureFile($file)
{
  # Perform rigorous testing to see if the file should be copied.
  if (($CopyNonTextures) -and (CheckNonTextureFile $file))
  {
    # Check to see if Rescale Textures was enabled (which references the current output folder).
    if ($MasterOperation -eq 'ForceIntScaling')
    {
      # If a format was forced, include the format in the folder name.
      $TempPath = '\RescaledTextures(' + $RescaleSuffix + ')'
    }
    # Check to see if Convert Texture Format was enabled (which references the current output folder).
    elseif ($MasterOperation -eq 'ConvertTextures')
    {
      # Include the format in the output folder.
      $TempPath = '\ConvertedTextures(' + $ConvertSuffix + ')'
    }
    # Create the folder structure of where the file should go.
    $Relative = $file.DirectoryName.Replace($MasterInputPath,'')
    $NTFolder = (Get-Location | Get-Item).Name
    $FullPath = [string]$file.Directory + '\' + $file
    $CopyPath = CreatePath -LiteralPath ($MasterOutputPath + $TempPath + $Relative)

    # Copy the file into the new location.
    Copy-Item -LiteralPath $FullPath -Destination $CopyPath -Force

    # Log/Console: Display that the file has been copied.
    Write_Host ' File       : ' -ForegroundColor Yellow -NoNewLine
    Write-Host $file -ForegroundColor Red
    Write_Host ' Path       : ' -ForegroundColor Yellow -NoNewLine
    Write-Host ($NTFolder + $Relative)
    Write_Host ' Message    : ' -ForegroundColor Yellow -NoNewLine
    Write-Host 'Non-texture file copied to ' -NoNewline
    Write-Host ($TempPath + $Relative) -ForegroundColor Green
    Write_Host '-----------------------------------------------------------------------------------------------------------------------' -ForegroundColor Gray
  }
}
#==============================================================================================================================================================================================
#  MASTER LOOP: TITLE BAR PROGRESS
#==============================================================================================================================================================================================
#  Counts the number of textures in a pack, which does not include the number of mipmaps or material maps.

function CountTexturesToProcess()
{
  # Keep track of the number of textures counted. Default to 0 for aesthetic value if zero textures are found (so title bar properly displays 0/0).
  $TotalTextures = 0

  # Force the title bar to display that the length of time is being calculated.
  $host.UI.RawUI.WindowTitle = ($ScriptName + ' - Calculating...')

  # Without Allow All Images, we only want to find Dolphin type textures.
  if (!$AllowAllImages)
  {
    # Add the filter 'tex1' to distinguish Dolphin textures from other images.
    $TexFilter = '*tex1'
  }
  # Get the Input Path and all directories/sub-directories found within the Input Path.
  $Directories = @($MasterInputPath)
  $Directories += [System.IO.Directory]::GetDirectories($MasterInputPath, '*', 'AllDirectories')

  # Loop through all folders found in the collection.
  foreach($FolderPath in $Directories)
  {
    # Omit any folders that contain the tilde (~) symbol.
    if ($FolderPath -notlike '*~*')
    {
      # Build the collection of files within that folder.
      $FileCollection = @()
      $FileCollection += [System.IO.Directory]::GetFiles($FolderPath, ($TexFilter + '*.png'))
      $FileCollection += [System.IO.Directory]::GetFiles($FolderPath, ($TexFilter + '*.dds'))
      $FileCollection += [System.IO.Directory]::GetFiles($FolderPath, ($TexFilter + '*.jpg'))

      # Loop through all files within the collection. We don't want Dolphin textures that are mipmaps, material maps, or material textures.
      foreach($TexFile in $FileCollection)
      {
        # Stacking conditions like this is ugly, but piling all the conditions into a single condition is by far the fastest method (I benchmarked it). 
        if (($TexFile -notlike '*tex1*_mip*') -and ($TexFile -notlike '*tex1*.mat*') -and ($TexFile -notlike '*tex1*.nrm*') -and ($TexFile -notlike '*.bump*') -and ($TexFile -notlike '*.spec*') -and ($TexFile -notlike '*.lum*'))
        {
          # If the texture passed all checks, increment the texture count.
          $TotalTextures ++
        }
      }
    }
  }
  # The title bar won't be updated again until the first file is processed, so force the title bar to display file 0 and 0% before executing the loop.
  $host.UI.RawUI.WindowTitle = ($ScriptName + $TitleBarMessage + 'Texture: '  + '0/' + $TotalTextures + ' (0%)')

  # Return the total number of textures that will be processed by the main loop.
  return $TotalTextures
}
#==============================================================================================================================================================================================
#  Before updating the title bar percentage, make sure a texture is: not in a folder containing the tilde (~), a valid texture, not a mipmap level, and not any kind of material.

function CheckUpdateTitleBar($file)
{
  # Resolve this now and store in a variable so it doesn't have to be resolved multiple times.
  $FileName = $file.Name
  $FullName = $file.FullName

  # Set up the series of checks in a variable array.
  $UpdateCheck = New-Object bool[] 9

  # If AllowAllImages is enabled, always update for all image types. If it's not enabled, only update for images with "tex1" prefix.
  $UpdateCheck[0] = (($AllowAllImages) -or ($FileName -like 'tex1*'))

  # We only want images in a path that doesn't contain a "~", and we don't want Dolphin textures that are mipmaps, material maps, or material textures.
  $UpdateCheck[1] = ($FullName -notlike '*~*')
  $UpdateCheck[2] = (($FileName -like '*.png') -or ($FileName -like '*.dds') -or ($FileName -like '*.jpg'))
  $UpdateCheck[3] = ($FileName -notlike '*tex1*_mip*')
  $UpdateCheck[4] = ($FileName -notlike '*tex1*.mat*')
  $UpdateCheck[5] = ($FileName -notlike '*tex1*.nrm*')
  $UpdateCheck[6] = ($FileName -notlike '*.bump*')
  $UpdateCheck[7] = ($FileName -notlike '*.spec*')
  $UpdateCheck[8] = ($FileName -notlike '*.lum*')

  # If all conditions pass return true to update the title bar.
  return (TestBooleanArray -Array $UpdateCheck)
}
#==============================================================================================================================================================================================
#  Updates the title bar with progress.

function AttemptUpdateTitleBar($file, [int]$TotalFiles)
{
  # Check to see if the title bar should be updated.
  if (CheckUpdateTitleBar $file)
  {
    # Increment the number of textures processed in the loop.
    $global:CountProcessed += 1

    # Find the absolute value and convert it to a string.
    $Percent = (($CountProcessed / $TotalFiles) * 100).ToString().Split('.',2)

    # Update the title bar with the current percent of progress.
    $host.UI.RawUI.WindowTitle = ($ScriptName + $TitleBarMessage + 'Texture: ' + $CountProcessed + '/' + $TotalFiles + ' (' + $Percent[0] + '%)')
  }
}
#==============================================================================================================================================================================================
#  MASTER LOOP: ESCAPE KEY PRESSED DURING LOOP
#==============================================================================================================================================================================================
#  Verify that the loop is to be cancelled and clean up some of the junk folders it created.

function VerifyCancelMasterLoop()
{
  # Show the Yes/No dialog and capture the result.
  $YesNoCancel = ShowYesNoDialog -OffsetX 10 -OffsetY 16 -DisplayText '  Are you sure you wish to cancel the current operation?'

  # If the user pressed Yes, ask the user to also remove directories.
  if ($YesNoCancel)
  {
    # Show the Yes/No dialog that asks to remove directories.
    if (ShowYesNoDialog -OffsetX 34 -OffsetY 16 -DisplayText '  Also remove partially generated directories?' -PlayBeep $false)
    {
      # I decided on just removing whatever folder was being generated, instead of removing the entire generated directory.
      switch ($MasterOperation)
      {
        'ScanAllTextures' {  RemovePath -LiteralPath ($MasterOutputPath + '\BrokenTextures')
                             RemovePath -LiteralPath ($MasterOutputPath + '\RepairedTextures') }
        'ForceIntScaling' {  RemovePath -LiteralPath ($MasterOutputPath + '\RescaledTextures(' + $RescaleSuffix + ')') }
        'ConvertTextures' {  RemovePath -LiteralPath ($MasterOutputPath + '\ConvertedTextures(' + $ConvertSuffix + ')') }
        'CreateMaterials' {  RemovePath -LiteralPath ($MasterOutputPath + '\MaterialMaps') }
        'CreateWatermark' {  RemovePath -LiteralPath ($MasterOutputPath + '\WatermarkTextures') }
        'OptiPNGTextures' {  RemovePath -LiteralPath ($MasterOutputPath + '\OptimizedTextures') }
        'UpscaleTextures' {  RemovePath -LiteralPath ($MasterOutputPath + '\FilteredTextures(' + $UpscaleFilter + ')') }
      }
    }
  }
  # Return the result of the pressed button.
  return $YesNoCancel
}
#==============================================================================================================================================================================================
#  Allows pausing the loop, cancelling the loop, or forcibly closing the PowerShell console.

function CheckKeyPresses()
{
  # Check for a key press during the loop.
  if ([System.Console]::KeyAvailable)
  {
    # Check to see if the key pressed was Escape.
    $PressedKey = [System.Console]::ReadKey()

    # Flush the input buffer in case the user mashed several keys.
    $Host.UI.RawUI.FlushInputBuffer()

    # SPACE: If the Space key was pressed then pause the loop.
    if (($PressedKey.Key.ToString() -eq 'Space') -or  ($PressedKey.Key.ToString() -eq 'Spacebar'))
    {
      # This will not end the loop, the user must press "OK" to continue.
      ShowOKDialog -OffsetX 14 -OffsetY 18 -DisplayText 'The operation has been paused. Press "OK" to resume.'
    }
    # ESCAPE: If the Escape key was pressed then prompt the user.
    elseif ($PressedKey.Key.ToString() -eq 'Escape')
    {
      # Return the result of the button press.
      return VerifyCancelMasterLoop
    }
    # CONTROL+C: If the user presses the conventional close combination (Control + C), catch it and cleanly exit.
    elseif (($PressedKey.Key.ToString() -eq 'C') -and ($PressedKey.Modifiers -band [System.ConsoleModifiers]'Control'))
    {
      # Enable this variable which will tell the Dialog to close which exits the script.
      $global:FastClose = $true
    }
    # ALT+F4: If the user presses the conventional close combination (Control + C), catch it and cleanly exit.
    elseif (($PressedKey.Key.ToString() -eq 'F4') -and ($PressedKey.Modifiers -band [System.ConsoleModifiers]'Alt'))
    {
      # Enable this variable which will tell the Dialog to close which exits the script.
      $global:FastClose = $true
    }
  }
  # This variable tells the script to close after the loop has exited. This avoids a crash error with .NET
  # which is caused by closing an active dialog while a loop is in progress or objects are still in the pipeline.
  if ($FastClose)
  {
    # Immediately end the loop and exit the script.
    return $true
  }  
  # Continue the loop if it was not cancelled in any way.
  return $false
}
#==============================================================================================================================================================================================
#  MASTER LOOP: AUTO-RENAME OUTPUT PATH
#==============================================================================================================================================================================================
#  If the user entered a custom name from the GUI when rescaling or converting textures.

function AutoRenameOutputPath()
{
  # Check to see if convert textures was enabled and if the user entered a custom folder name.
  if (($MasterOperation -eq 'ConvertTextures') -and ($AutoTextConvert -ne ''))
  {
    # Include the format in the output folder.
    $RenamePath = $MasterOutputPath + '\ConvertedTextures(' + $ConvertSuffix + ')'
    $NewNamePath = $MasterOutputPath + '\' + $AutoTextConvert

    # Use Move-Item to rename the folder because PS 2.0 does not like -LiteralPath in Rename-Item.
    Move-Item -LiteralPath $RenamePath -Destination $NewNamePath -Force
  }
  # Check to see if rescale textures was enabled and if the user entered a custom folder name.
  elseif (($MasterOperation -eq 'ForceIntScaling') -and ($AutoTextRescale -ne ''))
  {
    # If a format was forced, include the format in the folder name.
    $RenamePath = $MasterOutputPath + '\RescaledTextures(' + $RescaleSuffix + ')'
    $NewNamePath = $MasterOutputPath + '\' + $AutoTextRescale

    # Use Move-Item to rename the folder because PS 2.0 does not like -LiteralPath in Rename-Item.
    Move-Item -LiteralPath $RenamePath -Destination $NewNamePath -Force
  }
}
#==============================================================================================================================================================================================
#  DOCUMENTATION: THE MASTER LOOP
#==============================================================================================================================================================================================
#  The "Master Loop" is where texture processing begins the moment the GUI "Start" button is pressed.
#
#  My old code used a bunch of variables to determine which option was actually ran. The corresponding variable would be set to "$true" while all others were set to "$false", then a huge
#  collection of "if" statements would pick out the correct one. After the loop was completely finished, all variables would return to false. This was the way I did it since the beginning
#  when this was a batch script. The initial idea was that multiple options could be ran simultaneously. But this idea never happened, and there is no reason for it to happen.
#
#  So now there is a single variable named "$MasterOperation" that stores the current operation that will take place in the master loop. This variable is set depending on which option is
#  highlighted in the GUI when pressing "Start". The value it stores to determine which option was selected uses the old names of the variables that no longer exist. Below is the full list
#  of valid values for "$MasterOperation". Obviously, this is a string variable.
#
#  ScanAllTextures  -  Scan Dolphin Textures For Issues
#  ConvertTextures  -  Convert Textures to Another Format
#  ForceIntScaling  -  Rescale Textures With New Scaling Factor
#  CreateWatermark  -  Add Identifying Watermark to All Textures
#  CreateMaterials  -  Create Material Maps With Ishiiruka Tool
#  MaterialInPlace  -  Create Material Maps With Ishiiruka Tool (In-Place)
#  OptiPNGTextures  -  Optimize PNG Textures With OptiPNG
#  OptimizeInPlace  -  Optimize PNG Textures With OptiPNG (In-Place)
#  UpscaleTextures  -  Apply Upscaling Filter to All Textures
#  GenerateMipMaps  -  Generate New MipMaps
#  RemoveBadMipMap  -  Remove Invalid MipMaps
#  DetachDDSMipMap  -  Extract DDS Internal MipMaps
#  AlphaChannelFix  -  Remove Alpha Channel From Opaque Textures
#
#  It was a pain trying to think of names that all have the same length (OCD in full throttle). The (In-Place) variations of the same option use an alternate name to distinguish where the
#  user wanted to output textures. While the loop is in progress, $MasterOperation will always contain which operation is taking place, so it can be referenced to know which option is in 
#  progress. When the loop ends, it will default back to an empty string and can no longer be referenced.
#==============================================================================================================================================================================================
#  MASTER LOOP: THE MASTER LOOP
#==============================================================================================================================================================================================
#  All operations (standard/advanced options) are ran through this loop in some form.

function MasterLoop()
{
  # To avoid a subsequent run from exiting immediately, flush the keyboard input buffer in case the user mashed the "Escape" key in a previous iteration.
  $Host.UI.RawUI.FlushInputBuffer()

  # Console: Output that the loop is about to start to the PS window.
  Clear-Host
  Write_Host '-----------------------------------------------------------------------------------------------------------------------' -ForegroundColor Gray
  Write_Host ' Keyboard Functions' -ForegroundColor Yellow
  Write_Host '-----------------------------------------------------------------------------------------------------------------------' -ForegroundColor Gray
  Write_Host ' Escape     :' -ForegroundColor Green -NoNewLine
  Write-Host ' Cancel processing and remove partially generated directories.'
  Write_Host ' Spacebar   :' -ForegroundColor Green -NoNewLine
  Write-Host ' Pause processing after the current action is complete.'
  Write_Host '-----------------------------------------------------------------------------------------------------------------------' -ForegroundColor Gray
  Write_Host (' ' + $TitleBarMessage.Replace('-','').Trim() + ' textures ...') -ForegroundColor Yellow
  Write_Host '-----------------------------------------------------------------------------------------------------------------------' -ForegroundColor Gray

  # Give the users time to glance at the options before them.
  Start-Sleep -m 1000

  # Count the textures that will be processed.
  $TotalFiles = CountTexturesToProcess

  # Create the log file if it's not disabled.
  AttemptCreateLogFile

  # Loop through all folders and sub-folders to attempt to find texture files.
  foreach($file in Get-ChildItem -LiteralPath $MasterInputPath -Recurse -Force -ErrorAction 'SilentlyContinue')
  {
    # Check to see if the user paused the loop, cancelled the loop, or forcibly closed PowerShell.
    if (CheckKeyPresses)
    {
      # Update the title bar with cancelled status.
      $host.UI.RawUI.WindowTitle = ($ScriptName + $TitleBarMessage + 'Cancelled')

      # Console: Report that the process was cancelled.
      Write-Host ''
      Write-Host ' The current operation was cancelled!' -ForeGroundColor Yellow
      Write-Host ''

      # The loop was cancelled so nothing more here needs to be done.
      return
    }
    # Creates texture data in the form of a global hash table. Returns "null" if it is not a valid texture file.
    $global:Texture = CreateTextureInfo -File $file

    # Proceed only if there is valid texture data.
    if ($Texture -ne $null)
    {
      # Console: Show information about the texture before doing work.
      ConsoleUpdateLoopStart

      # Run the Standard or Advanced option that was selected.
      switch ($MasterOperation)
      {
        'ScanAllTextures' { ScanTextureForIssues }   # - Scan Dolphin Textures For Issues
        'ConvertTextures' { ConvertTextureFormat }   # - Convert Textures to Another Format
        'ForceIntScaling' { RescaleTextureInteger }  # - Rescale Textures With New Scaling Factor
        'CreateWatermark' { AddTextureWatermark }    # - Add Identifying Watermark to All Textures
        'CreateMaterials' { CreateMaterialMaps 1 }   # - Create Material Maps With Ishiiruka Tool
        'MaterialInPlace' { CreateMaterialMaps 2 }   # - Create Material Maps With Ishiiruka Tool (In-Place)
        'OptiPNGTextures' { OptimizeWithOptiPNG 1 }  # - Optimize PNG Textures With OptiPNG
        'OptimizeInPlace' { OptimizeWithOptiPNG 2 }  # - Optimize PNG Textures With OptiPNG (In-Place)
        'UpscaleTextures' { ApplyUpscalingFilter }   # - Apply Upscaling Filter to All Textures
        'GenerateMipMaps' { GenerateNewMipMaps }     # - Generate New MipMaps
        'RemoveBadMipMap' { RemoveInvalidMipMaps }   # - Remove Invalid MipMaps
        'DetachDDSMipMap' { ExtractAllDDSMipMaps }   # - Extract DDS Internal MipMaps
        'AlphaChannelFix' { RemoveAlphaChannel }     # - Remove Alpha Channel From Opaque Textures
      }
      # Console: Show more information about the texture after doing work.
      ConsoleUpdateLoopEnd

      # Log: Attempt to update the log file with texture information.
      AttemptUpdateLogFile
    }
    # If there is no texture data to be had, it is not a texture.
    else
    {
      # Attempt to copy the current file in the loop if "Copy Non-Textures" is enabled.
      AttemptCopyNonTextureFile $file
    }
    # Attempt to update the title bar with the number of textures processed.
    AttemptUpdateTitleBar $file $TotalFiles
  }
  # Update the title bar with the complete text percent of progress.
  $host.UI.RawUI.WindowTitle = ($ScriptName + $TitleBarMessage.Replace(' from','') + 'Complete: ' + $CountProcessed + '/' + $TotalFiles + ' (100%)')

  # Check if the user defined the output, and are either converting or rescaling textures.
  if (($DDSBlkCompress -eq 'User Defined') -and (($MasterOperation -eq 'ConvertTextures') -or ($MasterOperation -eq 'ForceIntScaling')))
  {
    # If all that stuff up there is true, remove any flags found on folders.
    RemoveFlagsFromFolders
  }
  # Console + Log: Perform the final update to the console and log file.
  ConsoleAndLogFinalUpdate

  # Completely remove the Temp folder and any remnants that my have been left astray.
  RemovePath -LiteralPath $TempFolder

  # Check to see if the user wanted rescaled or converted paths renamed.
  AutoRenameOutputPath
}
#==============================================================================================================================================================================================
#  MASTER LOOP: SETTING THE MASTER OPERATION
#==============================================================================================================================================================================================
#  In this section we'll get to ride on the back of a dolphin while taking in the fresh ocean air... Oh wait. This is where the master operation gets assigned!
#==============================================================================================================================================================================================
function Initiate_ScanTextures()
{
  $global:TitleBarMessage = ' - Scanning '
  $global:MasterOperation = 'ScanAllTextures'
  return $true
}
#==============================================================================================================================================================================================
function Initiate_ConvertTextures()
{
  $FileType = ExtensionToText -FileExt $ConvertFormat

  # If converting to DDS and the format is specified (meaning "User Defined" is not set as the compression type).
  if (($ConvertFormat -eq $DDS) -and ($DDSBlkCompress -ne 'User Defined'))
  {
    # Include the compression type in the generated path (for example: "ConvertedTextures(DDS-BC7)" will be the output path).
    $global:ConvertSuffix = ($FileType + '-' + $DDSBlkCompress.Replace('/','-'))
  }
  # We're not converting to DDS, or the user selected "User Defined" as the compression type.
  else
  {
    # Do not include the compression type, as it may be PNG. If User Defined, we don't want DDS textures going to different sub-folders.
    $global:ConvertSuffix = $FileType
  }
  $global:TitleBarMessage = ' - Converting '
  $global:MasterOperation = 'ConvertTextures'
  return $true
}
#==============================================================================================================================================================================================
function Initiate_RescaleTextures()
{
  $FileType = ExtensionToText -FileExt $RescaleFormat
  
  # If converting to DDS and the format is specified (meaning "User Defined" is not set as the compression type).
  if (($RescaleFormat -eq $DDS) -and ($DDSBlkCompress -ne 'User Defined'))
  {
    # Include the compression type in the generated path (for example: "ConvertedTextures(DDS-BC7)" will be the output path).
    $global:RescaleSuffix = ($FileType + '-' + $DDSBlkCompress.Replace('/','-'))
  }
  # We're not converting to DDS, or the user selected "User Defined" as the compression type.
  else
  {
    # Do not include the compression type, as it may be PNG. If User Defined, we don't want DDS textures going to different sub-folders.
    $global:RescaleSuffix = $FileType
  }
  $global:TitleBarMessage = ' - Rescaling '
  $global:MasterOperation = 'ForceIntScaling'
  return $true
}
#==============================================================================================================================================================================================
function Initiate_MaterialMapTextures()
{
  # Make sure Ishiiruka Tool location is known.
  if (!(TestPath -LiteralPath $IshiirukaTool))
  {
    # If it's not then show an error message and prevent the Master Loop from running.
    Write-Host ''
    Write-Host ' ERROR:' -ForegroundColor Red -NoNewLine
    Write-Host ' Ishiiruka Tool was not found. Click the "Options" button and locate the path to Ishiiruka Tool.'
    Start-Sleep -m 3500
    Clear-Host
    return $false
  }
  # Update the title bar.
  $global:TitleBarMessage = ' - Material Mapping '

  # Update which option to run based on whether or not the user wants to create materials in-place or not.
  switch ($InPlaceMaterial)
  {
    $true  { $global:MasterOperation = 'MaterialInPlace' } 
    $false { $global:MasterOperation = 'CreateMaterials' }
  }
  return $true
}
#==============================================================================================================================================================================================
function Initiate_WatermarkTextures()
{
  $global:TitleBarMessage = ' - Watermarking '
  $global:MasterOperation = 'CreateWatermark'
  return $true
}
#==============================================================================================================================================================================================
function Initiate_OptiPNGTextures()
{
  # Make sure OptiPNG location is known.
  if (!(TestPath -LiteralPath $OptiPNGPath))
  {
    # If it's not then show an error message and prevent the Master Loop from running.
    Write-Host ''
    Write-Host ' ERROR:' -ForegroundColor Red -NoNewLine
    Write-Host ' OptiPNG was not found. Click the "Options" button and locate the path to OptiPNG.'
    Start-Sleep -m 3500
    Clear-Host
    return $false
  }
  # Update the title bar.
  $global:TitleBarMessage = ' - Optimizing '

  # Update which option to run based on whether or not the user wants to optimize textures in-place or not.
  switch ($InPlaceOptiPNG) 
  {
    $true  { $global:MasterOperation = 'OptimizeInPlace' }
    $false { $global:MasterOperation = 'OptiPNGTextures' }
  }
  return $true
}
#==============================================================================================================================================================================================
# What a mess. Most functions here are like 6 lines. Yet all this crap for upscaling filters. Whatever, I can't see a way around it without even more functions so.. screw you guys, I'm going home.

function Initiate_UpscaleFilterTextures()
{
  # Check if xBRZ was selected as the filter.
  if ($FilterSelected -eq 'xBRZ')
  {
    # Store the strength in the chosen filter.
    $global:UpscaleFilter = $FilterNewScale + 'xBRZ'
  }
  # Check if waifu2x was selected as the filter.
  elseif ($FilterSelected -eq 'Waifu2x')
  {
    # Store the strength in the chosen filter.
    $global:UpscaleFilter = 'waifu' + $FilterNewScale + 'x'

    # String variables that are fed to waifu2x as paramters in the command line. 
    # Default them to an empty value so they aren't passed unless they are actually needed.
    $global:wf2xOpenCL = ''
    $global:wf2xNoGpuA = ''
    $global:wf2xNoGpuB = ''
    $global:wf2xModelA = ''
    $global:wf2xModelB = ''

    # Set up options based on Waifu2x-CPP.
    if ($Waifu2xApp -eq 'waifu2x-converter_x64.exe')
    {
      # Set up the NoGPU toggle.
      if ($Waifu2xNoGPU)
      {
        $global:wf2xNoGpuA = '--disable-gpu'
        $global:wf2xNoGpuB = ''
      }
      # Set up the OpenCL toggle, this only works with waifu2x-CPP.
      if ($Waifu2xOpenCL)
      {
        $global:wf2xOpenCL = '--force-OpenCL'
      }
    }
    # Set up options based on Waifu2x-Caffe.
    elseif ($Waifu2xApp -eq 'waifu2x-caffe-cui.exe')
    {
      # Set up the NoGPU toggle.
      if ($Waifu2xNoGPU)
      {
        $global:wf2xNoGpuA = '--process'
        $global:wf2xNoGpuB = 'cpu'
      }
      # If using Waifu2x-Caffe, impose the selected model.    
      $global:wf2xModelA = '--model_dir'
      $global:wf2xModelB = "models\" + $Waifu2xModel
    }
  }
  # Any other filter can simply use the selected filter name.
  else
  {
    # Force it to lowercase so it can be passed to ImageMagick.
    $global:UpscaleFilter = $FilterSelected.ToLower()
  }
  # Update the title bar and which option to run.
  $global:TitleBarMessage = ' - Filtering '
  $global:MasterOperation = 'UpscaleTextures'
  return $true
}
#==============================================================================================================================================================================================
function Initiate_BC7Viewer()
{
  # TexConv is required to use the Image Viewer.
  if (!(TestPath -LiteralPath $TexConvTool))
  {
    # Show the dialog because its invisible.
    $MainDialog.Visible = $true
  
    # Show a message that TexConv was not installed to the user.
    ShowOKDialog -OffsetX 12 -OffsetY 10 -DisplayText 'DirectXTex TexConv is required but not found! The path to this tool can be configured on the "Options" menu.'
  }
  else
  {
    # Hide the console and show the Image Viewer.
    ShowPowerShellConsole -ShowConsole $false

    # Allows the viewer to be reset by trapping it in a loop.
    $global:RefreshViewer = $true

    # Trap this in a loop until the function sets it to false.
    while($RefreshViewer -eq $true)
    {
      # Show the Image Viewer. If it's closed, and RefreshViewer is still true, it will reopen.
      CreateBC7ViewerDialog | Out-Null
    }
    # Show the console afterwards (if it is enabled).
    ShowPowerShellConsole -ShowConsole $AlwaysShowConsole
  }
  return $false
}
#==============================================================================================================================================================================================
function Initiate_GenerateMipMaps()
{
  $global:TitleBarMessage = ' - MipMapping '
  $global:MasterOperation = 'GenerateMipMaps'
  return $true
}
#==============================================================================================================================================================================================
function Initiate_RemoveBadMipMaps()
{
  $global:TitleBarMessage = ' - Checking '
  $global:MasterOperation = 'RemoveBadMipMap'
  return $true
}
#==============================================================================================================================================================================================
function Initiate_DetachDDSMipMap()
{
  $global:TitleBarMessage = ' - Extracting MipMaps from '
  $global:MasterOperation = 'DetachDDSMipMap'
  return $true
}
#==============================================================================================================================================================================================
function Initiate_AlphaChannelFix()
{
  $global:TitleBarMessage = ' - De-Alpha-ing '
  $global:MasterOperation = 'AlphaChannelFix'
  return $true
}
#==============================================================================================================================================================================================
function Initiate_CombineTextures()
{
  # Keeps track if any textures have not been selected.
  $CheckPassed = $true

  # Loop through all rows.
  for($row = 1; $row -le [int]$TextureRows; $row++)
  {
    # And loop through all columns.
    for($col = 1; $col -le [int]$TextureColumns; $col++)
    {
      # Test the current texture in the array to see if it has been selected.
      if ($TextureArray[$row,$col] -eq '')
      {
        # If this is the first failure, create an initial message.
        if ($CheckPassed)
        {
          Clear-Host
          Write-Host ''
          Write-Host ' ERROR: ' -ForegroundColor Red -NoNewLine
          Write-Host 'Not all textures have been selected!'
          Write-Host ''
        }
        # If a texture has not been selected, report which texture failed and set $CheckPassed to false so the operation does not continue.
        Write-Host ('- No texture selected for Row ' + $row + ' Column ' + $col + '.')
        $CheckPassed = $false
      }
    }
  }
  # Only start the process if all textures have been selected.
  if ($CheckPassed)
  {
    # Update the title bar and execute the main function.
    $global:TitleBarMessage = ' - Combining Textures '
    CombineMultipleTextures
  }
  # If not all texture have been selected then alert the user.
  else
  {
    Write-Host ''
    Write-Host ' These textures must be selected before processing can begin.'
    Start-Sleep -m 3500
  }
  return $false
}
#==============================================================================================================================================================================================
function Initiate_SplitMultiTexture()
{
  # Make sure a texture has been selected.
  if ($CombinedTexture -ne 'Select a texture to split into multiple textures...')
  {
    # Update the title bar and which option to run.
    $global:TitleBarMessage = ' - Splitting Multi-Texture '
    GUI_SplitMultiTexture
  }
  # A texture has not been selected.
  else
  {
    # Display an error message to the user.
    ShowOKDialog -OffsetX 28 -OffsetY 18 -DisplayText 'ERROR: A texture has not been selected to split!'
  }
  return $false
}
#==============================================================================================================================================================================================
function Initiate_CalculateVRAMUsage()
{
  # Make sure a texture has been selected.
  if (TestPath -LiteralPath $VRAMPackPath)
  {
    # Update the title bar and which option to run.
    $global:TitleBarMessage = ' - Calculating VRAM '
    CalculateVRAMForTextures
  }
  # The path is empty.
  else
  {
    # Display an error message to the user.
    ShowOKDialog -OffsetX 12 -OffsetY 10 -DisplayText 'ERROR: The "Texture Path" for the Calculate VRAM option is empty. A path must be entered or selected!'
  }
  return $false
}
#==============================================================================================================================================================================================
#  MASTER LOOP: STARTING THE MASTER LOOP
#==============================================================================================================================================================================================
# This is where it all begins... or at least where it would begin if you didn't actually have to click the 'Start' button to get here.

function StartMasterLoop()
{
  # If ImageMagick was not found, prompt the user to find it.
  if ($ImageMagickVersion -eq 0)
  {
    # Show a message that ImageMagick was not installed to the user.
    ShowOKDialog -OffsetX 22 -OffsetY 10 -DisplayText 'ImageMagick not found! Reinstall ImageMagick, or configure the install path from the "Options" menu.'

    # Exit the function early. Do not run the Master Loop.
    return
  }
  # If the control button was held when pressing start.
  if ([System.Windows.Forms.Control]::ModifierKeys -eq [System.Windows.Forms.Keys]::Control)
  {
    # Allow processing selected textures rather than the input folder.
    if (!(ProcessSelectedTextures))
    {
      # If the image was not set when the dialog was closed, do not start the loop.
      return
    }
  }
  # Hide the main GUI.
  $MainDialog.Visible = $false

  # I absolutely hate workarounds like this. Check to see if the user is not running the BC7 Viewer.
  if (($CurrentOptions -eq 'Advanced') -and ($AdvancedOptions.SelectedIndex.ToString() -ne 0))
  {
    # If the console was hidden then show it.
    ShowPowerShellConsole -ShowConsole $true
  }
  # Hide the help dialog if it is visible to the user and store it's current state so it can be reshown later.
  if ($HelpDialog.Visible)
  {
    $HelpWasVisible = $true
    $HelpDialog.Visible = $false
  }
  # If the standard options menu is visible then run a standard option.
  if ($CurrentOptions -eq 'Standard')
  {
    # Set up the corresponding option. Get the return state to know whether or not to run the master loop.
    switch ($StandardOptions.SelectedIndex.ToString())
    {
      '0' { $RunMasterLoop = Initiate_ScanTextures }
      '1' { $RunMasterLoop = Initiate_ConvertTextures }
      '2' { $RunMasterLoop = Initiate_RescaleTextures }
      '3' { $RunMasterLoop = Initiate_WatermarkTextures }
      '4' { $RunMasterLoop = Initiate_MaterialMapTextures }
      '5' { $RunMasterLoop = Initiate_OptiPNGTextures }
      '6' { $RunMasterLoop = Initiate_UpscaleFilterTextures }
      '7' { $RunMasterLoop = Initiate_CalculateVRAMUsage }
    }
  }
  # If the advanced options menu is visible then run an advanced option.
  else
  {
    # Set up the corresponding option. Get the return state to know whether or not to run the master loop.
    switch ($AdvancedOptions.SelectedIndex.ToString())
    {
      '0' { $RunMasterLoop = Initiate_BC7Viewer }
      '1' { $RunMasterLoop = Initiate_GenerateMipMaps }
      '2' { $RunMasterLoop = Initiate_RemoveBadMipMaps }
      '3' { $RunMasterLoop = Initiate_DetachDDSMipMap }
      '4' { $RunMasterLoop = Initiate_AlphaChannelFix }
      '5' { $RunMasterLoop = Initiate_CombineTextures }
      '6' { $RunMasterLoop = Initiate_SplitMultiTexture }
    }
  }
  # Only run the master loop if no errors were found, or it wasn't forcefully skipped (I'm looking at you "combine and split" texture options...).
  if ($RunMasterLoop)
  {
    # Run the selected option and measure the length of time it takes to finish.
    $Results = (Measure-Command { MasterLoop }).ToString().Split('.',2)

    # Report the results.
    Write_Host ' Total Time : ' -ForegroundColor Red -NoNewLine
    Write-Host ($Results[0] + '.' + $Results[1].SubString(0,2))

    # Reset all global variables.
    ResetGlobalVars
  }
  # Restore the MasterInputPath if it was altered when using "Process Selected" menu.
  if ($ProcessSelected)
  {
    $global:ProcessSelected  = $false
    $global:MasterInputPath  = $MasterInputSave
    $global:MasterOutputPath = $MasterOutputSave
  }
  # If the user pressed (Control+C) or (Alt+F4) during the loop (which sets $FastClose to true), exit the script now.
  if ($FastClose)
  {
    # Closing the dialog basically (literally?) forces the script to end.
    $MainDialog.Close()
  }
  # I'm going to branch everything else off here to see if it fixes a few issues like the GUI popping up for a split second. Edit: Obviously, it does.
  else
  {
    # Enable the GUI.
    $MainDialog.Visible = $true
    $MainDialog.Activate()

    # Automatically hide the console window if the user wanted.
    if (!$AlwaysShowConsole)
    {
      ShowPowerShellConsole -ShowConsole $false
    }
    # If the help dialog was visible then reshow it.
    $HelpDialog.Visible = $HelpWasVisible
  }
}
#==============================================================================================================================================================================================
#  MASTER LOOP: PROCESS SELECTED TEXTURES
#==============================================================================================================================================================================================
#  This is a somewhat hidden GUI option to allow selecting a handful of textures and processing those instead of using the "Texture Path". My original intention was to make it so a single
#  texture could be processed, but a "bug" allowed me to keep adding textures and it processed them all. So I rolled with it. First I found what I did wrong, which was technically right for
#  processing multiple textures, and built around that instead. The functionality is basic, there is no way to remove textures from the stack other than closing the GUI window.
#==============================================================================================================================================================================================
#  Shared function between "button click" and "drag and drop" functions. Adds an image to the stack and generates a preview on the button. 

function ProcessTextures_AddTexture($InputFile)
{
  # Get the texture's dimensions as a hash table.
  $ImageInfo = GetImageInfo -ImagePath $InputFile.FullName

  # Calculate the dimensions for the preview so that scaling is correct.
  if ($ImageInfo.Width -gt $ImageInfo.Height)
  {
    # If width is greater than height, then we need to calculate the height.
    $Width  = 116
    $Height = [int]($ImageInfo.Height / ($ImageInfo.Width / $Width))
  }
  else
  {
    # If height is greater than width, then we need to calculate the width.
    $Height = 116
    $Width  = [int]($ImageInfo.Width / ($ImageInfo.Height / $Height))
  }
  # For PNG and JPG we can just use the image directly for the preview.
  if ($InputFile.Extension -ne $DDS)
  {
    # Set the path to the image using the input image.
    $ImagePath = $InputFile.FullName
  }
  # DDS is a bit more complex and requires a temporary image to be generated.
  else
  {
    # I see no way around creating a texture hashtable now that BC7 support has been added.
    $TextureInfo = CreateTextureInfo -File $InputFile -BypassTildeCheck $true

    # Create a temporary image for the preview.
    $TempPath   = CreatePath -LiteralPath ($TempFolder + '\DDS_Preview\')
    $ImagePath  = $TempPath + $InputFile.BaseName + $PNG

    # Use my handy create texture function to create the image.
    CreateTexture -TextureInfo $TextureInfo -Width $Width -Height $Height -Format $PNG -OutputPath $TempPath
  }
  # Resize it to fit the button. Convert the image type into a bitmap type so it can be resized.
  $TempImage = [System.Drawing.Image]::FromFile($ImagePath)
  $global:ImgBitMap = New-Object System.Drawing.Bitmap($TempImage, $Width, $Height)
  $TempImage.Dispose()

  # Add the bitmap to the bitmap list and add the image name to the image file list.
  $global:BitMapStack.Add($ImgBitMap)
  $global:ImagesStack.Add($InputFile.Name)

  # Show the preview on the button. Remove the background color and text.
  $this.BackgroundImage = $ImgBitMap
  $this.BackColor = [System.Drawing.Color]::Transparent
  $this.Text = ''

  # Set up a temporary path and copy the texture to that path.
  $TempPath    = CreatePath -LiteralPath ($TempFolder + '\SelectedTextures\-SelectedTextures-\')
  $TempTexture = $TempPath + $InputFile.Name
  Copy-Item -LiteralPath $InputFile.FullName -Destination $TempTexture -Force

  # Update the default path to where the last texture was dropped from.
  $global:SelectionPath = [string]$InputFile.Directory

  # Count the number of times an image was dropped onto the window.
  $global:CountStacked += 1

  # Force the current page to the most recently added texture.
  $global:ImageViewPage = $CountStacked

  # Allow pressing the "Start" button.
  $ProcessButton.Enabled = $true

  # If multiple textures are added to the stack, show the count on the button.
  if ($CountStacked -gt 1)
  {
    $this.Font = New-Object System.Drawing.Font('Arial', 20, [System.Drawing.FontStyle]::Bold)
    $this.Forecolor = [System.Drawing.Color]::White
    $this.Text = $CountStacked.ToString()
    $this.FlatAppearance.BorderSize = 0
    $LeftButton.Enabled = $True
    $RightButton.Enabled = $true
  }
}
#==============================================================================================================================================================================================
#  Allows adding an image to the stack by dropping an image onto the preview window.

function ProcessTextures_AddTexture_DragAndDrop()
{
  # Make sure there is data present before actually doing anything.
  if ($_.Data.GetDataPresent([Windows.Forms.DataFormats]::FileDrop))
  {
    # Create a list of the data to select the first item from the list.
    $DroppedFile = $_.Data.GetData([Windows.Forms.DataFormats]::FileDrop)

    # Loop through all dropped files.
    foreach($File in $DroppedFile)
    {
      # Get the dropped file.
      $ExtCheck  = @($PNG,$DDS,$JPG)
      $ImageFile = Get-Item -LiteralPath $File

      # Make sure the texture has a valid extension and it's not already been added to the list.
      if (($ExtCheck -contains $ImageFile.Extension) -and ($ImagesStack -notcontains $ImageFile.Name))
      {
        # Update the image on the button and add the image to the array.
        ProcessTextures_AddTexture -InputFile $ImageFile
      }
    }
  }
}
#==============================================================================================================================================================================================
#  Allows adding an image to the stack by clicking the preview window and selecting an image.

function ProcessTextures_AddTexture_ButtonClick()
{
  # Create an open file dialog to grab a PNG image.
  $SelectedFile = Get-FileName -Path $SelectionPath -Description @('PNG Images', 'DDS Images', 'JPG Images') -FileName @('*.png','*.dds','*.jpg')

  # Check if the image exists.
  if (TestPath -LiteralPath $SelectedFile)
  {
    # Get the selected file.
    $ExtCheck  = @($PNG,$DDS,$JPG)
    $ImageFile = Get-Item -LiteralPath $SelectedFile

    # Make sure the texture has a valid extension and it's not already been added to the list.
    if (($ExtCheck -contains $ImageFile.Extension) -and ($ImagesStack -notcontains $ImageFile.Name))
    {
      # Update the image on the button and add the image to the array.
      ProcessTextures_AddTexture -InputFile $ImageFile
    }
  }
}
#==============================================================================================================================================================================================
#  Allows changing the Process Selected preview image to the previous or next texture in the image stack.

function ProcessTextures_SwitchPage([string]$Direction)
{
  # If going left, subtract 1. If going right, add 1.
  if ($Direction -eq 'Left') {$Shift = -1} else {$Shift = 1}

  # Alter the page variable.
  $global:ImageViewPage += $Shift

  # If the page has reached 0 (going left), reset it to the top.
  if ($ImageViewPage -le 0)
  {
    $global:ImageViewPage = $CountStacked
  }
  # If the page exceeded the number of images (going right), reset it to the bottom.
  elseif ($ImageViewPage -gt $CountStacked)
  {
    $global:ImageViewPage = 1
  }
  # Set the image as the preview on the button. Remove the background color and text.
  $ImageButton.BackgroundImage = $BitMapStack[($ImageViewPage-1)]
  $ImageButton.Text = $ImageViewPage
}
#==============================================================================================================================================================================================
#  Temporarily overrides the "Output Path" with a custom path. The original path is restored after the "Master Loop" is finished.

function ProcessTextures_UpdateTempOutputPath()
{
  # Display an "Open Folder" menu to get the path.
  $SelectedFolderPath = Get-Folder -Message 'Select the path to output textures. This change is only temporary, meaning it only affects this run and will not permanently change the global "Output Path".'

  # Check to see if a folder was selected from the Open menu and test if that path exists.
  if (($SelectedFolderPath -ne '') -and (TestPath -LiteralPath $SelectedFolderPath))
  {
    # Add a work-around for when a directory is chosen that does not contain a sub-folder.
    if ((($SelectedFolderPath | Measure-Object -Character).Characters) -eq 3)
    {
      $TempOutputPath = $SelectedFolderPath.Replace('\','')
    }
    else
    {
      $TempOutputPath = $SelectedFolderPath
    }
    # Set the output path to the selected path.
    $global:MasterOutputPath = $TempOutputPath + '\~CTT_Generated'
  }
}
#==============================================================================================================================================================================================
#  Creates the "Process Textures" dialog and displays it.

function ProcessTextures_CreateGUI()
{
  # Count the number of textures added to the stack, and keep track of which page the preview window is on.
  $global:CountStacked  = 0
  $global:ImageViewPage = 0

  # Create a list to store the bitmap images (for previews), and a list to store the image names (to check if it was already added to the array).
  $global:BitMapStack = New-Object System.Collections.Generic.List[System.Object]
  $global:ImagesStack = New-Object System.Collections.Generic.List[String]

  # Create the dialog that is displayed.
  $SingleDialog = New-Object System.Windows.Forms.Form
  $SingleDialog.Topmost = $True
  $SingleDialog.Text = "Process Selected"
  $SingleDialog.Size = New-Object System.Drawing.Size(176, (238 + $HeightOffset))
  $SingleDialog.MinimumSize = New-Object System.Drawing.Size(176, (238 + $HeightOffset))
  $SingleDialog.MaximumSize = New-Object System.Drawing.Size(176, (238 + $HeightOffset))
  $SingleDialog.MaximizeBox = $false
  $SingleDialog.MinimizeBox = $false
  if ($WindowsVersion -ne '7')
  {
    $SingleDialog.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
  }
  $SingleDialog.StartPosition = "CenterScreen"
  $SingleDialog.KeyPreview = $True
  $SingleDialog.Add_KeyDown({ EscapeCloseDialog })
  $SingleDialog.Add_Shown({$SingleDialog.Activate()})
  $SingleDialog.Font = $DialogFont
  DialogSetIcon $SingleDialog

  # Create the Start button and add it to the dialog.
  $global:ProcessButton = New-Object System.Windows.Forms.Button
  $ProcessButton.Size = New-Object System.Drawing.Size(80, 28)
  $ProcessButton.Location = New-Object System.Drawing.Size(40, 132)
  $ProcessButton.Text = 'Start'
  $ProcessButton.Enabled = $false
  $ProcessButton.Add_Click({$global:ProcessSelected = $true ; $SingleDialog.Close()})
  $SingleDialog.Controls.Add($ProcessButton)

  # Create the image button and add it to the dialog.
  $global:ImageButton = New-Object System.Windows.Forms.Button
  $ImageButton.Size = New-Object System.Drawing.Size(116, 116)
  $ImageButton.Location = New-Object System.Drawing.Size(22, 10)
  $ImageButton.Text = 'Drag and drop images or click here.'
  $ImageButton.BackColor = [System.Drawing.ColorTranslator]::FromHtml('#E0E0E0')
  $ImageButton.BackgroundImageLayout = 'Center'
  $ImageButton.AllowDrop = $true
  $ImageButton.FlatStyle = [Windows.Forms.FlatStyle]::Flat
  $ImageButton.FlatAppearance.BorderSize = 1
  $ImageButton.Add_DragEnter({$_.Effect = [Windows.Forms.DragDropEffects]::Copy})
  $ImageButton.Add_DragDrop({ ProcessTextures_AddTexture_DragAndDrop })
  $ImageButton.Add_Click({ ProcessTextures_AddTexture_ButtonClick })
  $SingleDialog.Controls.Add($ImageButton)

  # Create the Left button and add it to the dialog.
  $global:LeftButton = New-Object System.Windows.Forms.Button
  $LeftButton.Size = New-Object System.Drawing.Size(20, 28)
  $LeftButton.Location = New-Object System.Drawing.Size(14, 132)
  $LeftButton.Text = '<'
  $LeftButton.Enabled = $false
  $LeftButton.Add_Click({ProcessTextures_SwitchPage -Direction 'Left'})
  $SingleDialog.Controls.Add($LeftButton)

  # Create the Right button and add it to the dialog.
  $global:RightButton = New-Object System.Windows.Forms.Button
  $RightButton.Size = New-Object System.Drawing.Size(20, 28)
  $RightButton.Location = New-Object System.Drawing.Size(126, 132)
  $RightButton.Text = '>'
  $RightButton.Enabled = $false
  $RightButton.Add_Click({ProcessTextures_SwitchPage -Direction 'Right'})
  $SingleDialog.Controls.Add($RightButton)

  # Create the Output path button and add it to the dialog.
  $global:OutPathButton = New-Object System.Windows.Forms.Button
  $OutPathButton.Size = New-Object System.Drawing.Size(132, 28)
  $OutPathButton.Location = New-Object System.Drawing.Size(14, 164)
  $OutPathButton.Text = 'Change Output Path'
  $OutPathButton.Enabled = $true
  $OutPathButton.Add_Click({ ProcessTextures_UpdateTempOutputPath })
  $SingleDialog.Controls.Add($OutPathButton)

  # After the dialog is fully created, show it to the user.
  $SingleDialog.ShowDialog() | Out-Null

  # If preview images were actually generated then destroy the bitmap.
  if ($ImgBitMap -ne $null)
  {
    $ImgBitMap.Dispose()
  }
  # Check that the "Start" button was pressed and that there are images in the stack.
  if (($ProcessSelected) -and ($CountStacked -ge 1))
  {
    # Then process only the images in the stack.
    return $true
  }
  # Clear the lists so memory isn't being wasted on stupid shit.
  $BitMapStack.Clear()
  $ImagesStack.Clear()
}
#==============================================================================================================================================================================================
#  A menu to select specific textures, view them, and process them through the Master Loop. Bypasses the "Texture Path".

function ProcessSelectedTextures()
{
  # Lets this function know whether or not to start the main loop. Only becomes true by pressing "Start".
  $global:ProcessSelected = $false

  # Back up the master paths so they can be restored after being set to something else.
  $global:MasterInputSave  = $MasterInputPath
  $global:MasterOutputSave = $MasterOutputPath

  # Temporarily override the MasterInputPath. This will be set back to normal in "StartMasterLoop".
  $global:MasterInputPath = ($TempFolder + '\SelectedTextures')

  # Create and display the GUI to the user.
  ProcessTextures_CreateGUI
  
  # We don't want junk laying around so properly dispose of the temp images.
  RemovePath -LiteralPath $TempFolder
  
  # If the X button was clicked, set the paths back to what they were.
  $global:MasterInputPath  = $MasterInputSave
  $global:MasterOutputPath = $MasterOutputSave

  # Return to the main menu.
  return $false
}
#==============================================================================================================================================================================================
#  GUI: BC7 VIEWER DIALOG - A viewer for BC7 (and other) textures that I put as little effort as possible into creating.
#==============================================================================================================================================================================================
#  Gets the dimensions that are needed for the preview window (max of 460 for both width and height) and returns them as a hash table.

function BC7Viewer_GetPreviewDimensions([int]$Width, [int]$Height)
{
  # Multiple values need to be returned.
  $Dimensions = @{}

  # If the image is smaller than the window, do not resize it.
  if (($Width -le 460) -and ($Height -le 460))
  {
    $Dimensions.Width  = $Width
    $Dimensions.Height = $Height
  }
  # If it's bigger than the window it has to be resized to fit.
  else
  {
    # Calculate the dimensions for the preview so that scaling is correct.
    if ($Width -gt $Height)
    {
      # If width is greater than height, then we need to calculate the height.
      $Dimensions.Width  = 460
      $Dimensions.Height = [int]($Height / ($Width / $Dimensions.Width))
    }
    else
    {
      # If height is greater than width, then we need to calculate the width.
      $Dimensions.Height = 460
      $Dimensions.Width  = [int]($Width / ($Height / $Dimensions.Height))
    }
  }
  # Return the dimensions.
  return $Dimensions
}
#==============================================================================================================================================================================================
function BC7Viewer_CreatePreviewImage([string]$ImagePath, [string]$Width, [string]$Height, [string]$GlobalBitmap)
{
  # Get the image as an object so some properties can be taken from it.
  $ImageFile = Get-Item -LiteralPath $ImagePath

  # Get the new dimensions for the preview window.
  $Dimensions = BC7Viewer_GetPreviewDimensions -Width $Width -Height $Height

  # For PNG and JPG we can just use the image directly for the preview.
  if ($ImageFile.Extension -eq $DDS)
  {
    # Create an image for the preview. Set the image path to the image.
    $PreviewPath  = CreatePath -LiteralPath ($TempFolder + '\BC7_Preview')
    $PreviewImage = $PreviewPath + '\' + $ImageFile.BaseName + $PNG

    # Create the image into the preview path.
    RunTexConvTool -Image $ImagePath -Arguments @('-y', '-ft', 'PNG', '-w', $Dimensions.Width, '-h', $Dimensions.Height) -OutputPath $PreviewPath | Out-Null

    # This will now be the image that a bitmap is created from.
    $ImagePath = $PreviewImage
  }
  # Resize it to fit the button. Convert the image type into a bitmap type so it can be resized.
  $ImgObject = [System.Drawing.Image]::FromFile($ImagePath)
  $TempBitMap = New-Object System.Drawing.Bitmap($ImgObject, $Dimensions.Width, $Dimensions.Height)
  $ImgObject.Dispose()

  # Set the bitmap to a global variable so it can be disposed of later.
  Set-Variable -Name $GlobalBitmap -Value $TempBitMap -Scope 'Global'
}
#==============================================================================================================================================================================================
function BC7Viewer_CreateImages([hashtable]$TextureInfo)
{
  # Create the top level preview image.
  BC7Viewer_CreatePreviewImage -ImagePath $TextureInfo.FullPath -Width $TextureInfo.Width -Height $TextureInfo.Height -GlobalBitmap 'BC7ImgBitMap' | Out-Null

  # Add the bitmap to the bitmap list.
  $global:BC7BitMapStack.Add($BC7ImgBitMap)

  # A temporary list of all mipmaps is needed, which is then stored in a collection after its fully compiled. The top level counts as mipmap
  # level zero (so it can be viewed with the mipmap arrow selection buttons), and all mipmaps are added as they are found in the loop below.
  $MipMapList = @($BC7ImgBitMap)

  # Just to make this less ugly, initally set the number of mipmaps to zero.
  $MipMapLevels = '0'

  # Check to see if it is a mipmap texture.
  if (($TextureInfo.IsMipMap) -or ($TextureInfo.MipMaps -gt 1))
  {
    # MipMap info is needed.
    $MipMapInfo = CreateMipMapInfoPlus -TextureInfo $TextureInfo -Width $TextureInfo.Width -Height $TextureInfo.Height

    # Loop through all mipmap levels.
    for($i=1 ; $i -le $MipMapInfo.Levels ; $i++)
    {
      # Do stuff it the mipmap exists.
      if ($MipMapInfo.Exists[$i])
      {
        # Create the mipmap preview image.
        BC7Viewer_CreatePreviewImage -ImagePath $MipMapInfo.FullPath[$i] -Width $MipMapInfo.Width[$i] -Height $MipMapInfo.Height[$i] -GlobalBitmap 'BC7MipMapBitMap' | Out-Null

        # Add the bitmap to the bitmap list.
        $MipMapList += $BC7MipMapBitMap
      }
    }
    # Set the number of mipmaps to the amount that was counted.
    $MipMapLevels = $MipMapInfo.LevelsCounted.ToString()

    # After the bitmaps are loaded the temp images can be destroyed.
    DestroyMipMapInfoPlus
  }
  # Add the all images to the bitmap list.
  $global:BC7MipMapStack.Add($MipMapList)

  # Add the number of mipmaps to the image properties.
  return $MipMapLevels
}
#==============================================================================================================================================================================================
function BC7Viewer_AddTexture($InputFile)
{
  # I see no way around creating a texture hashtable now that BC7 support has been added.
  $Texture = CreateTextureInfo -File $InputFile -BypassTildeCheck $true

  # Don't do anything if there isn't any texture info to be had or it's a material map texture.
  if (($Texture -eq $null) -or ($Texture.HasMaterialMap)) { return }

  # Hide any previews and show a message that the image is being generated.
  $BC7ViewImage.BackgroundImage = $null
  $BC7ViewImage.Text = 'Generating preview... please be patient!'
  $BC7ViewImage.FlatAppearance.BorderSize = 1

  # Create the preview images. This includes the top level and all mipmaps.
  $MipMapLevels = BC7Viewer_CreateImages -TextureInfo $Texture

  # Force the current page to the most recently added texture. Reset the mipmap current page to 0.
  $global:BC7ImagePage  = $BC7BitMapStack.Count
  $global:BC7MipMapPage = 0

  # Set the properties for the image.
  $global:BC7PropName.Add($Texture.FullName)
  $global:BC7PropSize.Add($Texture.Dimensions)
  $global:BC7PropMipMaps.Add($MipMapLevels)
  $global:BC7PropPath.Add($Texture.Path)

  # Update all the text on the GUI.
  $BC7CurTexIntBox.Text    = $BC7BitMapStack.Count
  $BC7CurMipMapIntBox.Text = '0'
  $BC7TexNameLabel.Text    = 'Name: ' + $Texture.FullName
  $BC7TexSizeLabel.Text    = 'Dimensions: ' + $Texture.Dimensions
  $BC7TexMipMapLabel.Text  = 'MipMaps: ' + $BC7PropMipMaps[($BC7BitMapStack.Count-1)]
  $BC7TexPathLabel.Text    = 'Path: ' + $Texture.Path

  # Add the texture to the list box.
  $BC7TextureListBox.Items.Add($Texture.FullName) | Out-Null

  # If everything is disabled, enable it. Also change the background color of the image so it is transparent.
  if (!$BC7CurTexButtonL.Enabled)
  {
    $BC7CurTexButtonL.Enabled = $true
    $BC7CurTexIntBox.Enabled = $true
    $BC7CurTexButtonR.Enabled = $true
    $BC7CurMipMapButtonL.Enabled = $true
    $BC7CurMipMapIntBox.Enabled = $true
    $BC7CurMipMapButtonR.Enabled = $true
    $BC7TexNameLabel.Visible = $true
    $BC7TexSizeLabel.Visible = $true
    $BC7TexMipMapLabel.Visible = $true
    $BC7TexPathLabel.Visible = $true
    $BC7ViewImage.BackColor = [System.Drawing.Color]::Transparent
    $BC7ViewImage.FlatAppearance.MouseOverBackColor = [System.Drawing.Color]::Transparent
  }
  # Update the background image to the last created bitmap and remove the text.
  $BC7ViewImage.BackgroundImage = $BC7BitMapStack[($BC7BitMapStack.Count-1)]
  $BC7ViewImage.Text = ''
  $BC7ViewImage.FlatAppearance.BorderSize = 0

  # Update the default path to where the last texture was dropped from.
  $global:SelectionPath = $Texture.Path
}
#==============================================================================================================================================================================================
function BC7Viewer_AddTexture_DragAndDrop()
{
  # Make sure there is data present before actually doing anything.
  if ($_.Data.GetDataPresent([Windows.Forms.DataFormats]::FileDrop))
  {
    # Disable the dialog while it is decoding.
    $BC7ViewDialog.Enabled = $false

    # Create a list of the data to select the first item from the list.
    $DroppedFile = $_.Data.GetData([Windows.Forms.DataFormats]::FileDrop)

    # Loop through all dropped files.
    foreach($File in Get-ChildItem -LiteralPath $DroppedFile -Recurse)
    {
      # Get the dropped file.
      $ExtCheck  = @($DDS,$PNG,$JPG)
      $ImageFile = Get-Item -LiteralPath $File.FullName

      # Make sure the texture has a valid extension and it's not already been added to the list.
      if (($ExtCheck -contains $ImageFile.Extension) -and ($BC7PropName -notcontains $ImageFile.Name) -and ($ImageFile.Name -notlike '*_mip*'))
      {
        # Update the image on the button and add the image to the array.
        BC7Viewer_AddTexture -InputFile $ImageFile
      }
    }
    # Enable the dialog after all images are added.
    $BC7ViewDialog.Enabled = $true
  }
}
#==============================================================================================================================================================================================
function BC7Viewer_AddTexture_ButtonClick()
{
  # Create an open file dialog to grab a PNG image.
  $SelectedFile = Get-FileName -Path $SelectionPath -Description @('DDS Images', 'PNG Images', 'JPG Images') -FileName @('*.dds','*.png','*.jpg')

  # Check if the image exists.
  if (TestPath -LiteralPath $SelectedFile)
  {
    # Disable the dialog while it is decoding.
    $BC7ViewDialog.Enabled = $false

    # Get the selected file.
    $ExtCheck  = @($PNG,$DDS,$JPG)
    $ImageFile = Get-Item -LiteralPath $SelectedFile

    # Make sure the texture has a valid extension and it's not already been added to the list.
    if (($ExtCheck -contains $ImageFile.Extension) -and ($BC7PropName -notcontains $ImageFile.Name) -and ($ImageFile.Name -notlike '*_mip*'))
    {
      # Update the image on the button and add the image to the array.
      BC7Viewer_AddTexture -InputFile $ImageFile
    }
    # Enable the dialog after all images are added.
    $BC7ViewDialog.Enabled = $true
  }
}
#==============================================================================================================================================================================================
function BC7Viewer_SwitchPage([string]$Direction)
{
  # If going left, subtract 1. If going right, add 1.
  if ($Direction -eq 'Left') {$Shift = -1} else {$Shift = 1}

  # Alter the page variable.
  $global:BC7ImagePage += $Shift

  # If the page has reached 0 (going left), reset it to the top.
  if ($BC7ImagePage -le 0)
  {
    $global:BC7ImagePage = $BC7BitMapStack.Count
  }
  # If the page exceeded the number of images (going right), reset it to the bottom.
  elseif ($BC7ImagePage -gt $BC7BitMapStack.Count)
  {
    $global:BC7ImagePage = 1
  }
  # Set the image as the preview on the button.
  $BC7ViewImage.BackgroundImage = $BC7BitMapStack[($BC7ImagePage-1)]

  # Update all the text boxes with the selected image information.
  $BC7CurTexIntBox.Text   = $BC7ImagePage
  $BC7TexNameLabel.Text   = 'Name: ' + $BC7PropName[($BC7ImagePage-1)]
  $BC7TexSizeLabel.Text   = 'Dimensions: ' + $BC7PropSize[($BC7ImagePage-1)]
  $BC7TexMipMapLabel.Text = 'MipMaps: ' + $BC7PropMipMaps[($BC7ImagePage-1)]
  $BC7TexPathLabel.Text   = 'Path: ' + $BC7PropPath[($BC7ImagePage-1)]

  # Reset the mipmap text box.
  $global:BC7MipMapPage = 0

  # Update the mipmap text box.
  $BC7CurMipMapIntBox.Text = $BC7MipMapPage
}
#==============================================================================================================================================================================================
function BC7Viewer_MipMapSwitchPage([string]$Direction)
{
  # If going left, subtract 1. If going right, add 1.
  if ($Direction -eq 'Left') {$Shift = -1} else {$Shift = 1}

  # Alter the page variable.
  $global:BC7MipMapPage += $Shift

  # If the page has reached 0 (going left), reset it to the top.
  if ($BC7MipMapPage -lt 0)
  {
    $global:BC7MipMapPage = [int]$BC7PropMipMaps[$BC7ImagePage-1]
  }
  # If the page exceeded the number of images (going right), reset it to the bottom.
  elseif ($BC7MipMapPage -gt [int]$BC7PropMipMaps[$BC7ImagePage-1])
  {
    $global:BC7MipMapPage = 0
  }
  # Set the image as the preview on the button. Remove the background color and text.
  $BC7ViewImage.BackgroundImage = $BC7MipMapStack[$BC7ImagePage-1][$BC7MipMapPage]

  # Update the mipmap text box.
  $BC7CurMipMapIntBox.Text = $BC7MipMapPage
}
#==============================================================================================================================================================================================
function BC7Viewer_ListBoxSelection()
{
  # Alter the page variable. The image page starts at 1, but the selected index starts at 0 so add 1.
  $global:BC7ImagePage = $this.SelectedIndex + 1

  # Set the image as the preview on the button.
  $BC7ViewImage.BackgroundImage = $BC7BitMapStack[($BC7ImagePage-1)]

  # Update all the text boxes with the selected image information.
  $BC7CurTexIntBox.Text   = $BC7ImagePage
  $BC7TexNameLabel.Text   = 'Name: ' + $BC7PropName[($BC7ImagePage-1)]
  $BC7TexSizeLabel.Text   = 'Dimensions: ' + $BC7PropSize[($BC7ImagePage-1)]
  $BC7TexMipMapLabel.Text = 'MipMaps: ' + $BC7PropMipMaps[($BC7ImagePage-1)]
  $BC7TexPathLabel.Text   = 'Path: ' + $BC7PropPath[($BC7ImagePage-1)]

  # Reset the mipmap text box.
  $global:BC7MipMapPage = 0

  # Update the mipmap text box.
  $BC7CurMipMapIntBox.Text = $BC7MipMapPage
}
#==============================================================================================================================================================================================
function BC7Viewer_ToggleListBox()
{
  # Check the current width of the dialog to see if its in the smaller state.
  if ($BC7ViewDialog.Width -le 496)
  {
    # If its in the smaller state, make it bigger.
    $BC7ViewDialog.Size = New-Object System.Drawing.Size(740, (670 + $HeightOffset))
    $BC7ViewDialog.MinimumSize = New-Object System.Drawing.Size(740, (670 + $HeightOffset))
    $BC7ViewDialog.MaximumSize = New-Object System.Drawing.Size(740, (670 + $HeightOffset))
    $BC7ExpandButton.Text = 'List <'
  }
  # I shit my pants as I wrote this comment.
  else
  {
    # If its in the bigger state, make it smaller.
    $BC7ViewDialog.Size = New-Object System.Drawing.Size(496, (670 + $HeightOffset))
    $BC7ViewDialog.MinimumSize = New-Object System.Drawing.Size(496, (670 + $HeightOffset))
    $BC7ViewDialog.MaximumSize = New-Object System.Drawing.Size(496, (670 + $HeightOffset))
    $BC7ExpandButton.Text = 'List >'
  }
}
#==============================================================================================================================================================================================
function BC7Viewer_KeyPressEvent()
{
  # Do not attempt to switch pages unless the bitmap stack actually contains images.
  if ($BC7BitMapStack.Count -gt 1)
  {
    # Grab the key that was pressed.
    switch ($_.KeyCode)
    {
      # Force clicking a button depending on the key that was pressed.
      'Left'  { $BC7CurTexButtonL.PerformClick() }
      'Right' { $BC7CurTexButtonR.PerformClick() }
      'Down'  { $BC7CurMipMapButtonL.PerformClick() }
      'Up'    { $BC7CurMipMapButtonR.PerformClick() }
    }
  }
}
#==============================================================================================================================================================================================
function ClearBC7Viewer()
{
  $BC7ViewDialog.Close()
  $global:RefreshViewer = $true
}
#==============================================================================================================================================================================================
function CreateBC7ViewerDialog()
{
  # Get rid of any text on the screen. I want errors that pop up to be known.
  Clear-Host

  # Because I'm far to lazy to do this properly. This variable allows clearing the viewer by forcing it closed reopening it.
  $global:RefreshViewer = $false

  # To make this work with all images, "AllowAllImages" needs to be temporarily forced to "true".
  $AllowAllImagesWasSet = $AllowAllImages
  $global:AllowAllImages = $true

  # Create lists to store the bitmap images (for previews). For mipmaps, each entry will contain an array. This will simulate a 2-dimensional array.
  $global:BC7BitMapStack = New-Object System.Collections.Generic.List[System.Object]
  $global:BC7MipMapStack = New-Object System.Collections.Generic.List[System.Object[]]

  # Create lists to store image properties.
  $global:BC7PropName    = New-Object System.Collections.Generic.List[String]
  $global:BC7PropSize    = New-Object System.Collections.Generic.List[String]
  $global:BC7PropMipMaps = New-Object System.Collections.Generic.List[String]
  $global:BC7PropPath    = New-Object System.Collections.Generic.List[String]

  # Keep track of the number of pages. 
  $global:BC7ImagePage  = 0
  $global:BC7MipMapPage = 0
  #-------------------------------------------------------------------------------------------------------------------------
  # Create the dialog.
  $BC7ViewDialog = New-Object System.Windows.Forms.Form
  $BC7ViewDialog.Text = ('Basic Image Viewer')
  $BC7ViewDialog.Size = New-Object System.Drawing.Size(496, (670 + $HeightOffset))
  $BC7ViewDialog.MinimumSize = New-Object System.Drawing.Size(496, (670 + $HeightOffset))
  $BC7ViewDialog.MaximumSize = New-Object System.Drawing.Size(496, (670 + $HeightOffset))
  $BC7ViewDialog.MaximizeBox = $true
  $BC7ViewDialog.MinimizeBox = $true
  $BC7ViewDialog.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::None
  $BC7ViewDialog.Font = $DialogFont
  if ($WindowsVersion -ne '7')
  {
    $BC7ViewDialog.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
  }
  $BC7ViewDialog.StartPosition = "CenterScreen"
  $BC7ViewDialog.KeyPreview = $true
  $BC7ViewDialog.Add_KeyDown({ EscapeCloseDialog })
  $BC7ViewDialog.Add_Shown({ $BC7ViewDialog.Activate() })
  HelpDialogSetIcon $BC7ViewDialog

  # Allow switching pages with the arrow keys.
  $BC7ViewDialog.Add_PreviewKeyDown({ $_.IsInputKey = $true })
  $BC7ViewDialog.Add_KeyDown({ BC7Viewer_KeyPressEvent })
  
  # Create the image button and add it to the dialog.
  $BC7ViewImage = New-Object System.Windows.Forms.Button
  $BC7ViewImage.Size = New-Object System.Drawing.Size(460, 460)
  $BC7ViewImage.Location = New-Object System.Drawing.Size(10, 10)
  $BC7ViewImage.Text = 'Drag and drop an image or click here.'
  $BC7ViewImage.TabStop = $false
  $BC7ViewImage.BackColor = [System.Drawing.ColorTranslator]::FromHtml('#E0E0E0')
  $BC7ViewImage.BackgroundImageLayout = 'Center'
  $BC7ViewImage.FlatStyle = [Windows.Forms.FlatStyle]::Flat
  $BC7ViewImage.FlatAppearance.BorderSize = 1
  $BC7ViewImage.FlatAppearance.MouseOverBackColor = [System.Drawing.ColorTranslator]::FromHtml('#E0E0E0')
  $BC7ViewImage.AllowDrop = $true
  $BC7ViewImage.Add_DragEnter({$_.Effect = [Windows.Forms.DragDropEffects]::Copy})
  $BC7ViewImage.Add_DragDrop({ BC7Viewer_AddTexture_DragAndDrop })
  $BC7ViewImage.Add_Click({ BC7Viewer_AddTexture_ButtonClick })
  $BC7ViewDialog.Controls.Add($BC7ViewImage)
  #-------------------------------------------------------------------------------------------------------------------------
  # Create the Current Texture label and add it to the dialog.
  $BC7CurTexLabel = New-Object System.Windows.Forms.Label
  $BC7CurTexLabel.Size = New-Object System.Drawing.Size(50, 16)
  $BC7CurTexLabel.Location = New-Object System.Drawing.Size(80, 479)
  $BC7CurTexLabel.Text = 'Texture:'
  $BC7ViewDialog.Controls.Add($BC7CurTexLabel)

  # Create left button.
  $BC7CurTexButtonL = New-Object System.Windows.Forms.Button
  $BC7CurTexButtonL.Size = New-Object System.Drawing.Size(20, 23)
  $BC7CurTexButtonL.Location = New-Object System.Drawing.Size(134, 474)
  $BC7CurTexButtonL.Text = '<'
  $BC7CurTexButtonL.TabStop = $false
  $BC7CurTexButtonL.Add_Click({ BC7Viewer_SwitchPage -Direction 'Left' })
  $BC7CurTexButtonL.Enabled = $false
  $BC7CurTexButtonL.Font = $DialogFont
  $BC7ViewDialog.Controls.Add($BC7CurTexButtonL)

  # Create the textbox.
  $BC7CurTexIntBox = New-Object System.Windows.Forms.TextBox
  $BC7CurTexIntBox.Size = New-Object System.Drawing.Size(28, 20)
  $BC7CurTexIntBox.Location = New-Object System.Drawing.Size(156, 474)
  $BC7CurTexIntBox.BackColor = [System.Drawing.SystemColors]::Window
  $BC7CurTexIntBox.TabStop = $false
  $BC7CurTexIntBox.Font = $DialogFont
  $BC7CurTexIntBox.Text = '0'
  $BC7CurTexIntBox.Enabled = $false
  $BC7CurTexIntBox.ReadOnly = $true
  $BC7ViewDialog.Controls.Add($BC7CurTexIntBox)

  # Create the right button.
  $BC7CurTexButtonR = New-Object System.Windows.Forms.Button
  $BC7CurTexButtonR.Size = New-Object System.Drawing.Size(20, 23)
  $BC7CurTexButtonR.Location = New-Object System.Drawing.Size(186, 474)
  $BC7CurTexButtonR.Text = '>'
  $BC7CurTexButtonR.TabStop = $false
  $BC7CurTexButtonR.Add_Click({ BC7Viewer_SwitchPage -Direction 'Right' })
  $BC7CurTexButtonR.Enabled = $false
  $BC7CurTexButtonR.Font = $DialogFont
  $BC7ViewDialog.Controls.Add($BC7CurTexButtonR)
  #-------------------------------------------------------------------------------------------------------------------------
  # Create the Current MipMap label and add it to the dialog.
  $BC7CurMipMapLabel = New-Object System.Windows.Forms.Label
  $BC7CurMipMapLabel.Size = New-Object System.Drawing.Size(50, 16)
  $BC7CurMipMapLabel.Location = New-Object System.Drawing.Size(240, 479)
  $BC7CurMipMapLabel.Text = 'MipMap:'
  $BC7ViewDialog.Controls.Add($BC7CurMipMapLabel)

  # Create left button.
  $BC7CurMipMapButtonL = New-Object System.Windows.Forms.Button
  $BC7CurMipMapButtonL.Size = New-Object System.Drawing.Size(20, 23)
  $BC7CurMipMapButtonL.Location = New-Object System.Drawing.Size(294, 474)
  $BC7CurMipMapButtonL.Text = '<'
  $BC7CurMipMapButtonL.TabStop = $false
  $BC7CurMipMapButtonL.Add_Click({ BC7Viewer_MipMapSwitchPage -Direction 'Left' })
  $BC7CurMipMapButtonL.Enabled = $false
  $BC7CurMipMapButtonL.Font = $DialogFont
  $BC7ViewDialog.Controls.Add($BC7CurMipMapButtonL)

  # Create the textbox.
  $BC7CurMipMapIntBox = New-Object System.Windows.Forms.TextBox
  $BC7CurMipMapIntBox.Size = New-Object System.Drawing.Size(28, 20)
  $BC7CurMipMapIntBox.Location = New-Object System.Drawing.Size(316, 474)
  $BC7CurMipMapIntBox.BackColor = [System.Drawing.SystemColors]::Window
  $BC7CurMipMapIntBox.TabStop = $false
  $BC7CurMipMapIntBox.Font = $DialogFont
  $BC7CurMipMapIntBox.Text = '0'
  $BC7CurMipMapIntBox.Enabled = $false
  $BC7CurMipMapIntBox.ReadOnly = $true
  $BC7ViewDialog.Controls.Add($BC7CurMipMapIntBox)

  # Create the right button.
  $BC7CurMipMapButtonR = New-Object System.Windows.Forms.Button
  $BC7CurMipMapButtonR.Size = New-Object System.Drawing.Size(20, 23)
  $BC7CurMipMapButtonR.Location = New-Object System.Drawing.Size(346, 474)
  $BC7CurMipMapButtonR.Text = '>'
  $BC7CurMipMapButtonR.TabStop = $false
  $BC7CurMipMapButtonR.Add_Click({ BC7Viewer_MipMapSwitchPage -Direction 'Right' })
  $BC7CurMipMapButtonR.Enabled = $false
  $BC7CurMipMapButtonR.Font = $DialogFont
  $BC7ViewDialog.Controls.Add($BC7CurMipMapButtonR)
  #-------------------------------------------------------------------------------------------------------------------------
  $BC7ExpandButton = New-Object System.Windows.Forms.Button
  $BC7ExpandButton.Size = New-Object System.Drawing.Size(42, 23)
  $BC7ExpandButton.Location = New-Object System.Drawing.Size(428, 474)
  $BC7ExpandButton.Text = 'List >'
  $BC7ExpandButton.TabStop = $false
  $BC7ExpandButton.Add_Click({ BC7Viewer_ToggleListBox })
  $BC7ViewDialog.Controls.Add($BC7ExpandButton)
  #----------------------------------------------------------------------------------------------------------------------------------------------
  $BC7TextureListBox = New-Object System.Windows.Forms.ListBox
  $BC7TextureListBox.Size = New-Object System.Drawing.Size(234, 588)
  $BC7TextureListBox.Location = New-Object System.Drawing.Size(482, 10)
  $BC7TextureListBox.Add_SelectedIndexChanged({ BC7Viewer_ListBoxSelection })
  $BC7TextureListBox.TabStop = $false
  $BC7TextureListBox.AllowDrop = $true
  $BC7TextureListBox.Add_DragEnter({$_.Effect = [Windows.Forms.DragDropEffects]::Copy})
  $BC7TextureListBox.Add_DragDrop({ BC7Viewer_AddTexture_DragAndDrop })
  $BC7ViewDialog.Controls.Add($BC7TextureListBox)
  #-------------------------------------------------------------------------------------------------------------------------
  # Create a group to hold the properties.
  $BC7ViewerPropGroup = New-Object System.Windows.Forms.GroupBox
  $BC7ViewerPropGroup.Size = New-Object System.Drawing.Size(460, 90)
  $BC7ViewerPropGroup.Location = New-Object System.Drawing.Size(10, 496)
  $BC7ViewDialog.Controls.Add($BC7ViewerPropGroup)

  # Create the Name label.
  $BC7TexNameLabel = New-Object System.Windows.Forms.Label
  $BC7TexNameLabel.Size = New-Object System.Drawing.Size(440, 16)
  $BC7TexNameLabel.Location = New-Object System.Drawing.Size(10, 10)
  $BC7TexNameLabel.Text = 'Name: Example.dds'
  $BC7TexNameLabel.Visible = $false
  $BC7ViewerPropGroup.Controls.Add($BC7TexNameLabel)

  # Create the Dimensions label.
  $BC7TexSizeLabel = New-Object System.Windows.Forms.Label
  $BC7TexSizeLabel.Size = New-Object System.Drawing.Size(440, 16)
  $BC7TexSizeLabel.Location = New-Object System.Drawing.Size(10, 26)
  $BC7TexSizeLabel.Text = 'Dimensions: 64x64'
  $BC7TexSizeLabel.Visible = $false
  $BC7ViewerPropGroup.Controls.Add($BC7TexSizeLabel)

  # Create the MipMaps label.
  $BC7TexMipMapLabel = New-Object System.Windows.Forms.Label
  $BC7TexMipMapLabel.Size = New-Object System.Drawing.Size(440, 16)
  $BC7TexMipMapLabel.Location = New-Object System.Drawing.Size(10, 42)
  $BC7TexMipMapLabel.Text = 'MipMaps: 7'
  $BC7TexMipMapLabel.Visible = $false
  $BC7ViewerPropGroup.Controls.Add($BC7TexMipMapLabel)

  # Create the Paths label.
  $BC7TexPathLabel = New-Object System.Windows.Forms.Label
  $BC7TexPathLabel.Size = New-Object System.Drawing.Size(440, 30)
  $BC7TexPathLabel.Location = New-Object System.Drawing.Size(10, 58)
  $BC7TexPathLabel.Text = 'Path: C:\Users\UserName\Pictures\ExamplePath'
  $BC7TexPathLabel.Visible = $false
  $BC7ViewerPropGroup.Controls.Add($BC7TexPathLabel)
  #-------------------------------------------------------------------------------------------------------------------------
  $BC7CloseButton = New-Object System.Windows.Forms.Button
  $BC7CloseButton.Size = New-Object System.Drawing.Size(80, 28)
  $BC7CloseButton.Location = New-Object System.Drawing.Size(10, 596)
  $BC7CloseButton.Text = 'Clear'
  $BC7CloseButton.TabStop = $false
  $BC7CloseButton.Add_Click({ ClearBC7Viewer })
  $BC7CloseButton.Anchor = ([System.Windows.Forms.AnchorStyles]::Bottom, [System.Windows.Forms.AnchorStyles]::Left)
  $BC7ViewDialog.Controls.Add($BC7CloseButton)
  $BC7CloseTip = New-Object System.Windows.Forms.ToolTip
  $BC7CloseTip.InitialDelay = $ToolTipDelay
  $BC7CloseTip.AutoPopDelay = $ToolTipDuration
  $BC7CloseTipString = 'Clears all textures from the viewer.'
  $BC7CloseTip.SetToolTip($BC7CloseButton, $BC7CloseTipString)
  #-------------------------------------------------------------------------------------------------------------------------
  $BC7CloseButton = New-Object System.Windows.Forms.Button
  $BC7CloseButton.Size = New-Object System.Drawing.Size(80, 28)
  $BC7CloseButton.Location = New-Object System.Drawing.Size(388, 596)
  $BC7CloseButton.Text = 'Close'
  $BC7CloseButton.TabStop = $false
  $BC7CloseButton.Add_Click({ $BC7ViewDialog.Close() })
  $BC7CloseButton.Anchor = ([System.Windows.Forms.AnchorStyles]::Bottom, [System.Windows.Forms.AnchorStyles]::Right)
  $BC7ViewDialog.Controls.Add($BC7CloseButton)
  #-------------------------------------------------------------------------------------------------------------------------
  # After the dialog is fully created, show it to the user.
  $BC7ViewDialog.ShowDialog()
  #-------------------------------------------------------------------------------------------------------------------------
  # If preview images were actually generated then destroy the bitmap.
  if ($BC7ImgBitMap -ne $null)    { $BC7ImgBitMap.Dispose() }
  if ($BC7MipMapBitMap -ne $null) { $BC7MipMapBitMap.Dispose() }

  # Clear the lists so memory isn't being wasted on stupid shit.
  $BC7BitMapStack.Clear()
  $BC7MipMapStack.Clear()
  $BC7PropName.Clear()
  $BC7PropSize.Clear()
  $BC7PropMipMaps.Clear()
  $BC7PropPath.Clear()

  # Restore whatever the user had set for "AllowAllImages".
  $global:AllowAllImages = $AllowAllImagesWasSet

  # We don't want junk laying around so properly dispose of the temp images.
  RemovePath -LiteralPath $TempFolder
}
#==============================================================================================================================================================================================
#  INITIALIZATION: TEMPORARY FOLDER TEST
#==============================================================================================================================================================================================
#  Tests the temporary folder to see if it can be written to. If not it defaults to "C:\CTT-PS_Temp".

function TestTempFolder()
{
  # Set up a path to attempt to create a test document.
  $TestWritePath = $TempFolder + '\test.txt'

  # Create a folder to store the temporary document in.
  CreatePath -LiteralPath $TempFolder | Out-Null

  # Attempt to create a text document.
  Add-Content -LiteralPath $TestWritePath -value "test"

  # Test the path to see if it exists.
  if (!(Test-Path -LiteralPath $TestWritePath))
  {
    # Output an error message to alert the user the Temp Folder is not a valid location.
    Write_Host '-----------------------------------------------------------------------------------------------------------------------' -ForegroundColor Gray
    Write-Host (' ' + $ScriptName) -ForegroundColor Yellow
    Write_Host '-----------------------------------------------------------------------------------------------------------------------' -ForegroundColor Gray
    Write-Host ''
    Write-Host ' NOTICE:'  -ForegroundColor Red -NoNewLine
    Write-Host ' FAILED TO WRITE TO TEMP FOLDER'
    Write-Host ''
    Write-Host ' Temp Folder will be automatically relocated to "C:\CTT-PS_Temp"'
    Write-Host ' This path may be changed by pressing the "Options" button on the GUI.'
    Write-Host ''
    Write-Host ' Press any key to start the script.'

    # Update the temp folder when the script is closed.
    $global:UpdateTempFolder = $true

    # Update the global variable with the new path.
    $global:TempFolder = "C:\CTT-PS_Temp"

    # Pause the script and wait for user input.
    [void][System.Console]::ReadKey($true)
  }
  # The file was successfully created.
  else
  {
    # Destroy the Temp Folder.
    RemovePath -LiteralPath $TempFolder
  }
}
#==============================================================================================================================================================================================
#  INITIALIZATION: SET MASTER INPUT/OUTPUT PATHS
#==============================================================================================================================================================================================
#  Sets the Master Input and Output paths to the base path or a stored path from a previous run.

function SetMasterPath([bool]$StoreFolder, [string]$StoredPath, [string]$BackupPath)
{
  # Test if the user stored a texture folder using the checkbox.
  if (($StoreFolder) -and (TestPath -LiteralPath $StoredPath))
  {
    # If the folder exists, set the master path to the stored path.
    return $StoredPath
  }
  # Otherwise just use the current folder the script is in.
  else
  {
    return $BackupPath
  }
}
#==============================================================================================================================================================================================
#  INITIALIZATION A: STUFF TO DO BEFORE CREATING THE GUI - Yep there's an INITIALIZATION B section as well at the end of this script.
#==============================================================================================================================================================================================
# Prevent Control + C from terminating the PowerShell window unexpectedly.
[System.Console]::TreatControlCAsInput = $true

# Function that tests if the temporary folder can be written to. Defaults the folder to "C:\CTT-PS_Temp" if it can't.
TestTempFolder

# Get the folder the script is in.
$global:BaseFolder = Split-Path $script:MyInvocation.MyCommand.Path

# These variables control whether or not the values they represent are updated when the script is closed. They should always start as false and become true later.
# I used to include these variables in the script's header just to put them somewhere. But they are not safe to change, so I decided to hide them here.
$global:UpdateTempFolder = $false
$global:UpdateImageMagick = $false

# Test if the user stored a texture folder using the checkbox.
$global:MasterInputPath  = SetMasterPath -StoreFolder $StoreInputFolder -StoredPath $SavedInputFolder -BackupPath $BaseFolder
$global:MasterOutputPath = SetMasterPath -StoreFolder $StoreOutputFolder -StoredPath ($SavedOutputFolder + '\~CTT_Generated') -BackupPath ($BaseFolder + '\~CTT_Generated')

#  If Waifu2x exists get which one is currently selected.
if (TestPath -LiteralPath $Waifu2xPath)
{
  $global:Waifu2xApp = [string](Get-Item -LiteralPath $Waifu2xPath).Name
}
# Get the name of the script and the path to the script.
$global:ScriptPath = $MyInvocation.MyCommand.Path

# Store the current version of PowerShell as a single number (ex: "5.0.10240.16384" simply becomes "5")
$PSSplit = $PSVersionTable.PSVersion.ToString().Split('.',2)
$global:PSVersion = [int]$PSSplit[0]

# Get the current version of windows.
$GetWinVersion = ([System.Environment]::OSVersion.Version).ToString().Split('.')
$GetWinVersion = $GetWinVersion[0] + '.' + $GetWinVersion[1]

# Set the version of windows. Share versions for Vista/7 and for 8/8.1.
switch ($GetWinVersion)
{
  '6.0'  { $WindowsVersion = '7'  } # Windows Vista
  '6.1'  { $WindowsVersion = '7'  } # Windows 7
  '6.2'  { $WindowsVersion = '8'  } # Windows 8
  '6.3'  { $WindowsVersion = '8'  } # Windows 8.1
  '10.0' { $WindowsVersion = '10' } # Windows 10
}
# Get an instance of the graphics class to get the monitor's current Dpi.
$Graphics   = [System.Drawing.Graphics]::FromHwnd([IntPtr]::Zero)
$MonitorDPI = $Graphics.DpiX

# Increase the maximum number of lines to 20k. After 20k they start to be overwritten with new lines.
$host.UI.RawUI.BufferSize = New-Object System.Management.Automation.Host.Size(120,20000)

# Force the PowerShell console window size (fixes size for PowerShell v2). Adjust according to monitor DPI.
switch ($MonitorDPI.ToString())
{
  '120'   { $host.UI.RawUI.WindowSize = New-Object System.Management.Automation.Host.Size(120,38) }
  default { $host.UI.RawUI.WindowSize = New-Object System.Management.Automation.Host.Size(120,50) }
}
# Find the number of running instances of powershell.
$PSInstances = @(Get-Process powershell -ErrorAction SilentlyContinue).Count

# Don't attempt to center the console if PowerShell v2 is found, if the user disabled it, or if there is already a running instance.
if (($PSVersion -gt 2) -and ($AutoCenterConsole) -and ($PSInstances -lt 2))
{
  # Get the resolution of the primary monitor.
  [int]$Screen_X = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Width
  [int]$Screen_Y = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Height

  # Calculate the new position of the screen.
  $ScreenPosition_X = (($Screen_X / 2) - 436) # The PS console is (873) pixels wide, so divide the resolution in half and subtract half the PS window (436).
  $ScreenPosition_Y = (($Screen_Y / 2) - 319) # The PS console is (639) pixels tall, so divide the resolution in half and subtract half the PS window (319).

  # Set the position of the PowerShell window.
  Get-Process powershell | Set-ConsoleWindow -X $ScreenPosition_X -Y $ScreenPosition_Y
}
# Clean any junk off the screen.
Clear-Host
#==============================================================================================================================================================================================
#  CTT GUI: SCREEN DPI FIXES
#==============================================================================================================================================================================================
#  Fixes the GUI when the DPI is set to 125%. Above that, the entire GUI is upscaled automatically and the settings for 96 DPI are fine.

# Windows Vista/7
if ($WindowsVersion -eq '7')
{
  # Adjust the height depending on the DPI.
  switch ($MonitorDPI.ToString())
  {
    '120'   { $HeightOffset = 6 ; $global:DialogFont = New-Object System.Drawing.Font('Microsoft Sans Serif', 6.50) }
    default { $HeightOffset = 0 ; $global:DialogFont = New-Object System.Drawing.Font('Microsoft Sans Serif', 8.25) }
  }
}
# Windows 8-10
else
{
  # Adjust the height depending on the DPI.
  switch ($MonitorDPI.ToString())
  {
    '120'   { $HeightOffset = 6 ; $global:DialogFont = New-Object System.Drawing.Font('Microsoft Sans Serif', 6.50) }
    default { $HeightOffset = 0 ; $global:DialogFont = New-Object System.Drawing.Font('Microsoft Sans Serif', 8.25) }
  }
}
#==============================================================================================================================================================================================
#  CTT GUI: CLOSE MENU WITH ESCAPE
#==============================================================================================================================================================================================
#  Closes the current dialog with escape button. Used for add-button events. Works with any dialog.

function EscapeCloseDialog()
{
  # Check for escape pressed.
  if ($_.KeyCode -eq "Escape")
  {
    # Close whatever dialog was fed to the parameter.
    $this.Close()
  }
}
#==============================================================================================================================================================================================
#  CTT GUI - MAIN DIALOG CREATION
#==============================================================================================================================================================================================
#  Create an icon for the GUI using a Base64 string. 
#  Source: https://blog.netnerds.net/2015/10/use-base64-for-notifyicon-in-powershell/

function DialogSetIcon($InputDialog)
{
  $B64 =  'iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH4AsUEzAXMM7u5gAACspJREFUWMOVl2uMVdd1x
          3977/O47zsPZpjBA8MMGIhNsIEQjNyoEQ/xclNSp477QI7qurbSfmiiyFXtRlHSWq7qtEkTqWmbtnEiQlrJrVsTnjXExdgxxhAS7BjCy8O8GWbu3Dv33vPce/fDMHatOLG6v6yjo33W+q//Olp
          r/QW/5IyPjzN//nyGhoak53kdUsrlwD1CiA1CiGVA+82rU8AFY8zLxph9wIXLly/f2LBhg7XWMjAwwOLFi98zhnivl2NjY3R1dc093+E4zmellBuFED1CCKSU7+nMWosxBmPMsDHmWJqmX+/u7
          j71y5IU78PANxzHeUQphRCzV+cs2Pd0Za1926ZpqtM0/XpXV9dnKpUKtVqN3t7eXwxgZGSEBQsWMDo6ukJKucd13bVKKaukEGGUcL3SoNqICBNNmgLCYuysEyXAdwTlYoaOljyFnE+qDcYYkiQ
          5myTJb/X09JwfGBh4F4ifY2B4ePhux3G+77pui5QSJQWvXxrjpwM3WHRLJx1tRXzPQTkO8iYb2liMTonjhOuTNa6NTNDbWeSuVX1oY9FaE8fxRJIkmxYuXHju6tWr9PX1vQPg2rVrLFq0iMHBw
          RWu6/7Q87wWpRRBGHPk5M+YCix3r16K57sYK7BCYsVcFezbVmIRFqIo5JWzl0iDJvduWkVLKY/WmiiKkiiKevr6+q7P/WfvYmBoaOg13/fXOo7DxNQMew7/hGypzIbVS1GuQ4pAG9AWtAFzs95
          zJVDS4gpQWIxOOPPGW4wMjrB7+xoW93QQxwlhGP4sDMP1S5cunQYQV65cob+/n4GBgW/4vv+I67pEccJTe16k6Ra551dXYqRDagWRtkSppZkYYm0x1iIBJSyOEPgOZBzwlcCTkEYxx187z9hbA
          3zhD7bSNa+FKI6Jougvoyh6bNmyZVYAXLp06Q7f989mMhnru0o8tedljl2s8Jvb1lFuyRMbSTPVTIcGRwg+0leiv83nwo2AH1yaphZqXMEsACXIOFD0JVkFo+PTHD95jvme5ck/3IbvuQRBECV
          J0tff3z8qz549K6WUn3UcB9eR4sBL53n6+DDZzvmEymW0bhisxVyZiunMK3579TzuXlyip8VjZZtka1+GZpQyPhMzWAmpNGO23tbBgrxkqBrh5TJUnQInLs9w8KU3kULgOI5vrX0SwMnlch03m
          wyNZsiTe89SzXcQ+0UmmobYxNRCw0Mfbqev1aet4FMNE7514iqHrwZIwFECLGQd+POdK7g0Ps3+NybxXUXBkwSqyA2nyJ998zi7ProSIQRKqQdOnTr1aQksl1L2AJx+Y4QLIwk1Wea6zjBWT7k
          8FbO4LFhQdGkt5qhFKfvPjfHvFwJiIwi1YCYyVIOUDy0soJTg268McbUSMlwNyHuSG9qlZrOMjSb8677XcF2FlJJCofCAtNbeI4TAWsPJM4OEMx6YLBN1xVA14ddva+ETq7tpK+WYDlPeHJpi1
          50LWNOTpxpo6lFKI0yZiVJSbRDAH228FWsNXSWfe9d0c6MGaBf8Ev/wLz/EdeQcCzuktXbDXOt89UfjoDKQukxWLI9vvoXfv2sBfe05ZiLNc2cGWLGwDaUkf7trCesWF6hpQ1UblnRm+NSGHlI
          LC9vz/P3vrOapT6zie6fGiOsGYgkiw7XBBmMT1bmWvtwBlgHoVHNlfAYKbYCCRPL0C2Os6y2TGMmViRqPvTDBq2NNvrrrduqp5Mv3LOGLL1xjpBry19v7KfkuRkgO/mSQgckmpwbr/NerNWxsw
          SjI+qRZj+GRCrf2d2Kt7XKste0AxhqqUQqtEhwLQrL3RwrpXOCJjy/mjw9dg0KW565b0v1v8hebV5BxJE9s7EVJmEmgkUqOnh/gd/cNzwZsaJi52etcAa6D8RQzzXhuYOWl1hpjDFprlCdAWVA
          apAHPsve84sP/eJmfGh9KLqI1w6HE429eHyIxlloKUxHUEst3zw/x0MnreK05cHxIFGQUuBIcwBPgSQQWY2ZHt2OMmbLWdmChtewwLpJZAJ4FD0zeZTyXR5TAK8Y4BQebcbmYUSRWEOrZUaCEo
          OL50FUiaXhgYkgtCAOhBiHABeVCseDNJd1wtNYXtNYdQgiWLipyfiAEqcEzkBVQktAqsHlNvSVL0uKzvuTylc4sEghSixIgpODzyzsIHMVXLs+AzAAGrAaRggFI8XxBV0eRm8yPyTRNX07TFGs
          ta5fPAx2AiMDTkBdQFJBL6JyneHxZiccW5vhWd5aCFDS14Nlqle/emEQZwURi+NKSVv7qtjKiZKHVg5ILOQWuBRtye1+JciE7N6LPO1rrfUmSPOo4Dncu6aAjc42KDUgdDX4KvqS94HBmzXwwB
          lcpLJAgOD49wd+1tiAcBzk+zu91dFJJLI/0lLHa8OjpScgrCAWqmqCbDT61dTVxokmShCRJDso0TS/EcTxsjGH54nnc3uGRi6rkbIOMDBEi5tGePC9NVNk5cJ1jkzW0FpypN/hSawtF1yUHfHt
          eO/85PY0xghuR5dO9bXztjjZKXkpWJGTTBh/sdvnouiXESUoYhkxNTe1V69evD9rb2+/0PO8O3/Pp6/B57uUr5FuL5PIKJ+cgdJN/0i6TbW0cdRyWBw0avs+Lrovl5n5gJT9A0nF9gt5CmanY0
          F/MYRt1Lg6M402M8fiulSzqaiOOY+r1+tObN2/+N/nwww/bMAy/1mg00lRrblvazUMf6UZMTZAN6pSTiFciF5tY5EzIBwyszBZ5oR4QRNCILI3I0owMJobPpy7/PThCauDHwxMcOHcVpzbNr/T
          mWPuBWzBa02w2dZIknwNQly9fZu3atSO7d+9uU0rd5bget/a0MjA4zltTMRlf4TsKISXdOmY3CfsqMxwUDjo12FBDECMaEaIe4jUSfny9RjI5yT+/epHKyDR9psaf3ruG1kKOKAhoNBpPNRqN7
          z/44IOIo0ePsmnTJgBOnDhxptzSslp5HtONOl/43mleT7MUFsxDzitjygV01iPNeRjHwarZhUwYEFqjogQVxKjaDExWaY5N0xvXeOL+NXSWiqRRRLVSGZ2cnFyya9eu4F1b8cmTJ6nWaisKudz
          /FMvlTum6hEnEN59/kyMDTeJSiWx7EVHMQ9bHeg5WqdmPjUEmKYQxtt4kqtRhqsr6dodHtixnfrmIiWNmqtWparX6oR07dlx9/vnn2bx58zsADh06xLZt2zhy5MgHs9ns6WK57DqeR5imXByd4
          j9eG+T4tQayXMIt5nAyHlIJEAKrDTpKiRoBcaXGmg6X+9YtZNWiDvKeSxpF1Gu1qSAINm3ZsuXsXPCf0wWHDx9m69at7N+/v7NQKLyYLxaX+ZkMRggSnTJameHYuRFOv1VlIrQYJW+WQFN2YdU
          tRbasWsCS7jaUVChriYKAmVpttF6r3f1rH/vY1feVZgcOHGDHjh08++yzLaVS6U/8TOYzmWzW9zwPKyVCzE7OZhTTCDQGQ953yGd9lJRYM1uSJI4JgkDHYfjlyYmJL953//3BXILvqw2PHTvGx
          o0beeaZZ0ShUOhSSj3p+f4D2WwWx3WRcnajsQje0SdvyzCiMCQKw6e11p8Lg+bUro//hj148CDbt2///4nT/3v2fOc7uXmdnQ+4rrfDcdRyJVWXEOQtAmttwxo9lqT6fJrEB6vV6t77PvnJKsD
          +/fvZuXPnL/T7v2ctaRyINKcJAAAAAElFTkSuQmCC'

  # PowerShell doesn't care about the spaces in the string but remove them anyway. Makes it easier to export the icon if I want to.
  $B64 = [regex]::Replace($B64,'\s','')

  # Create a streaming image by streaming the base64 string.
  $Stream = [System.IO.MemoryStream][System.Convert]::FromBase64String($B64)
  $Bitmap = New-Object System.Drawing.Bitmap($Stream)

  # Convert the bitmap into an icon and display it on the dialog.
  $Icon = [System.Drawing.Icon]::FromHandle($Bitmap.GetHicon())
  $InputDialog.Icon = $Icon
  $Bitmap.Dispose()
}
#==============================================================================================================================================================================================
#  Set the icon for the PowerShell window. Rather than reuse the previous icon, give it a unique one.

function ConsoleSetIcon()
{
  $B64 =  'iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH4QYNFS0gbU9URgAACrRJREFUWMOVl3uQ1uV1x
          z/P8/wu7/vuu7vAssuC3HZBYIqKCKkFbRq5BF2JoVWJbTEopNVJ0nZ00nRa2zROqqS1dabVqcl0pjpKnTohhSg3GSCBUALlIuINHGBd9sIusJf3tu/v8lz6x+6SOtE4Pf88v3nmOed8z3me3zn
          nK/g10tfXx6RJk+jq6pJBEDRKKecCq4UQS4QQc4CG0aMDwFlr7WFr7RvA2fPnz19dsmSJc87R0dHBzJkzP9GH+KTN3t5empubx74XeJ73uJRymRBiqhACKeUnGnPOYa3FWtttrd2vtX5u8uTJx
          35dkOIzMvCC53mPKqUQYuTo2Ppp4py7tmqtjdb6uebm5scGBwcpFovMmDHj0wH09PQwZcoULl26NE9Kudn3/UVKKaekEHGSMtRXoVKISWOD02Cdw1mQEoQELxTUjMswrrGGbC5EG4u1ljRNT6V
          p+vtTp04909HR8TEQvxJOd3f3bZ7nbfd9f5yUEiUF7e/1cvH9qzRPb2JcYy1BxkNKD6VG1K1xGKtJ4pTBy0V6O6/QNKOW+b/ZgrEOYwxJklxJ03T5tGnT3mlvb6elpeWXAC5evMj06dPp7Oyc5
          /v+L4IgGKeUIokSju35kOF+x023z8bzfXACZyVuVNk6N2JEOBAOJaEaRbx35BypHubz991Evr4GYwxxHKdxHE9taWm5PPbOPpaBrq6u42EYLvI8j6ErJfZtPk0uW8+NS2cjpYc1AqPBWa5dwVg
          U0gOUw/NAKod2KWdPfkRfTw8r193ClJlNJElCFEUfRlF06+zZs4cAxIULF2htbaWjo+OFMAwf9X2fJE750TM/x1ZrWbL6BrAeJhXo2KFjRzxsManDGDdy/8rh+wIZgJcBPxSoAKxOOHnwDH29F
          3nou19kYtM4oiQhjuPvx3H8V3PmzHEC4Ny5cwvCMDyVyWRc6Cux5dnDvLNvkDvu/xy5+hpMIomqhmjIIpVg/ufraGwJ6T5b5b2fDTFcMKgAvAD8rMDPQCYv8XMw0DPEsQPvML4ZNm5aRRD6VKv
          VOE3TltbW1kvy1KlTUkr5uOd5+J4SR3af4eCL3eQyTaSxT6HXMtCVcPVCQk2j4vY/mMjcpXU0XBdw3Q2S+V/MEA1rhnoTrnZFlAYSFq5qpH6KpL8zRgUZoqEc5w4VObrrA6SUeJ4XOuc2AXi5X
          K5xtMhQGa7y+qa3SYcm4pI8xcsWkyRUi5Zlf9RAU0tIfUNIuZCy58V23t0zjBAC5Y88JT8D6743j85zQ5zY0Y8fKjJ5iavkKF7Os/mvD/LbX75hREep9ceOHfu6BOZKKacCXDjZQ//ZFF2qpdg
          bUOjV9F1IaGgRTLjOp35CjuGi5tjOXk78uIpJJDoWVIuWSiFl1uI8Qgl++nIXlz+K6O+ukslLClcFupxB92oOvHYc31dIKcnn8+ulc261EALnHO1HO6mJAvJkiK9CX3uZxfeM47Z7J1M3IUd5S
          PPR+wMsXTOF1kU1DA9ZqiVDVDFUixatLVLCl75xPdZaxk8OWXrvZMyAJcQnSx0Hf/gLfE+NZaFNOueWjJXO7qN9eIR4CMxgytonW1n5tSk0t+aolgyHftLBtHkTEFKy4Z9nMfNzNZSKllLBMHF
          WyLKHpmI0NE6r4U9+uJCN/3ATh17tReqUEIdPhsrFYS73DY2V9LkSmANgjKH3QhlLFh+BxHDkpV6GS4akIui+UOQHf3qQf33sFM45opJg4z/NYuGXGmhdXMejz8+jtj7EGcXRXZ0c2dnFsw8f5
          fVnTiOcxgMgINEBA92DCOFwzjV7zrkGAGstpUIKCCwJFsVb/3EZK+Hev5vJk2t2YZzj4JaT9F8u8sSLXyDISDY8NQPpQbUIelhyeF8HT//hG3hk8fGpR+GQaCQCj8RKonIy1rBqpDFmtIVqnBK
          kWBJSDAklKuzf/AF/PHcrxUGNwWJxnDr4Ps//7fvo1DFchMoAVEuObZu7+N5X/wshFQKBD6SAxqGBGIFGghgpYtZapLV2wDkHFoLx/qjrhCopGk3qII08HAptwTiBdYrDP/4pNhXEw1Atj7Tpo
          cEQ6zys8wBFOhp5grsGwilBkA+w1mKMqUhjzFljDE4IJszOExOTYtBoYswoIE3qHMZKUiMIsooXT3wTIcHEDkbb8jf+ppGV69vQCFIUBkEKOCQJkGIggPGTaxnNfK+ntT6stb7d8zxmLp7Iu9t
          7gRyWAIcjwZJiUb7lzsfuI1Ob4b51HtlQEJcE27YOkSSahx5uZPCq5YnnW2mZ38C//fl2hFMIJAkCgUMTMX1+PXW1OUrlKkmSnPGMMW+kafptz/NoWdBI2NhJdcBhjEYDBofwHT/66KuAxfcV1
          oJJBXsPXGHzd7eBkBi5mg0bmigNOh54pB5r2/j3b+9BMtK6lbRgyyx7aCFJoknTlDRNd0mt9dkkSbqttUyd28jk+T5eLgE/AaUxwrLhqbs4/t8F7p/zCof2FxFG8PZbFV745hso5SGVx9ZNu/n
          JtiEwglK/Y93XJ/Bnz61EBqB8i5dNmHyjz8I7ZpGkmiiKGBgYeFXdeuut1YaGhpuDIFiQCQIaWkKOvd6O9GtAGhzQfvpD9mw+R6p9Dm87y9SFMxiuhBzZeQaED04iUJx48zy10yfSMr2e0qBlW
          msO6wW0v9eDlyvylSfm0zS9gSSJKZfLL61YseI1+cgjj7goiv6lUqno1Bha5k/md77WjJdN8TIQhI7iwMhvpYSgJi+5eX4tr3xnK86GOCNx1sfYAPD5weOH+NneHpyGD96+wt5Xj+NnNHNvzzB
          70XVYqxkeHjZpmn4LQJ0/f55Fixb1PPjggxOUUr/lqYAp14+n61wvhUvgrEVKgUMQZh0PP3UHrzx7mo4zZQQCgYdAIgAlBL4SnD7QgQk9/vPvD2G0Y9L1EV/5y1uon5AjiqpUKpVnKpXK9o0bN
          yL27dvH8uXLATh06NDJcfXjF0rlUyhU2Pyd43Sc8rHG4azAWA/rJNqMDGLWSRACOTqXSQlKglIGqTRSCppnRTz49C00TaolTWMKhcFL/f39s9asWVP92FR89OhRCoXSvHw+d6Cutr5JSI84TXn
          t6bc4+z8pcckDa3BupLQ6FM4CYzxBOKR0CKFBSsJA03Kz4suP/waNk2qxNqFUKgwUCoXFbW1t7Xv37mXFihW/BLB7927uvPNO9uzZc2M2mz1RW1vve15AFGk6zw2w7+V2zp9IECbEOoHEcW0kF
          SNARnhCzIwbPb6wbgZzFjSSywWkOqJcLg5Uq9XlK1euPDXm/Fd4wZtvvsmqVavYsWNHUz6f/3lNTe2cTCaDMYJUG65cKnJseydd75YpXXUYM0rRlCVbB80zMyy9fwbTZjUgpUQpRxxXKZeLl8r
          F4m2r77mn/TOp2c6dO2lra2Pr1q3j6urq/iKTyTwWhtkwCAJAIoTAOEe1EhOXNdpasnmPmnwWqSRYC86RpDHVatUkSfSP/VeuPLn2gQeqYwF+Jjfcv38/y5YtY8uWLSKfzzcrpTaFYbg+m82il
          I+UI0BwAjmWeq7RMJIkIoqil4wx34qqwwNrfvf33K5du7jrrrv+f+T0/8rml1/OTWxqWh/6QZv01FylVLMQoma0r1estb0m1WfSNNk1VCy+unbt2gLAjh07uPvuuz/V7v8Cv3t9mxmDZx8AAAA
          ASUVORK5CYII='

  # PowerShell doesn't care about the spaces in the string but remove them anyway. Makes it easier to export the icon if I want to.
  $B64 = [regex]::Replace($B64,'\s','')

  # Create a streaming image by streaming the base64 string.
  $Stream = [System.IO.MemoryStream][System.Convert]::FromBase64String($B64)
  $Bitmap = New-Object System.Drawing.Bitmap($Stream)

  # Convert the bitmap into an icon and display it on the PowerShell window.
  $Icon = [System.Drawing.Icon]::FromHandle($Bitmap.GetHicon())
  Set-ConsoleIcon $Icon
  $Bitmap.Dispose()
}
#==============================================================================================================================================================================================
#  CTT GUI - MAIN DIALOG
#==============================================================================================================================================================================================
$ToolTipDelay = 1000
$ToolTipDuration = 30000
#==============================================================================================================================================================================================
#  CTT GUI - Create the main Dialog.
#==============================================================================================================================================================================================
$MainDialog = New-Object System.Windows.Forms.Form
$MainDialog.Text = $ScriptName
$MainDialog.Size = New-Object System.Drawing.Size(414, (464 + $HeightOffset))
$MainDialog.MinimumSize = New-Object System.Drawing.Size(414, (464 + $HeightOffset))
$MainDialog.MaximumSize = New-Object System.Drawing.Size(414, (464 + $HeightOffset))
$MainDialog.MaximizeBox = $false
$MainDialog.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::None
if ($WindowsVersion -ne '7')
{
  $MainDialog.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
}
$MainDialog.StartPosition = "CenterScreen"
$MainDialog.KeyPreview = $true
$MainDialog.Topmost = !$DisableTopMost
$MainDialog.Add_KeyDown({ EscapeCloseDialog })
$MainDialog.Font = $DialogFont
$MainDialog.Add_Shown({ $MainDialog.Activate() })
DialogSetIcon $MainDialog
ConsoleSetIcon
#==============================================================================================================================================================================================
#  CTT GUI: UPDATE INPUT/OUTPUT PATHS
#==============================================================================================================================================================================================
#  Shared below the next 2 function to reduce duplicate code.

function GUI_UpdateFolderPath_MasterPaths([string]$InputPath)
{
  # Users might think it's cool to put a final slash at the end. It's not cool.
  if ($InputPath.Substring(($InputPath.Length - 1), 1) -eq '\')
  {
    # If a slash was found, keep everything but the slash.
    $InputPath = $InputPath.Substring(0, ($InputPath.Length - 1))
  }
  # Append the CTT_Generated folder to the InputPath to create the output path.
  $OutputPath = $InputPath + '\~CTT_Generated'

  # Update the corresponding path and the text box.
  if ($this.Name -eq 'MasterInputPath')
  {
    # If the input path was selected also update the output path.
    $InputTextBox.Text = $InputPath
    $global:MasterInputPath = $InputPath
    $OutputTextBox.Text = $OutputPath
    $global:MasterOutputPath = $OutputPath
  }
  elseif ($this.Name -eq 'MasterOutputPath')
  {
    # If the output path was selected only update that.
    $OutputTextBox.Text = $OutputPath
    $global:MasterOutputPath = $OutputPath
  }
}
#==============================================================================================================================================================================================
#  Updates the "Texture Path" and "Output Path" with a drag and drop.

function GUI_UpdateFolderPath_DragDrop()
{
  # Make sure there is data present before actually doing anything.
  if ($_.Data.GetDataPresent([Windows.Forms.DataFormats]::FileDrop))
  {
    # Create a list of the data to select the first item from the list.
    $DroppedPath = [string]($_.Data.GetData([Windows.Forms.DataFormats]::FileDrop))

    # Make sure the path is a folder and prevent the path if it contains a tilde (~) in it.
    if (($DroppedPath -notlike '*~*') -and ($DroppedPath.Length -gt 3) -and (Test-Path -LiteralPath $DroppedPath -PathType Container))
    {
      # Update the path using a function that is shared with the below function.
      GUI_UpdateFolderPath_MasterPaths -InputPath $DroppedPath
    }
  }
}
#==============================================================================================================================================================================================
#  Updates the "Texture Path" and "Output Path" from the button.

function GUI_UpdateFolderPath_Button([string]$Message)
{
  # Display an "Open Folder" menu to get the path.
  $SelectedPath = Get-Folder -Message $Message

  # Check to see if a folder was selected from the Open menu and test if that path exists.
  if (($SelectedPath -ne '') -and ($SelectedPath -notlike '*~*') -and ($SelectedPath.Length -gt 3) -and (TestPath -LiteralPath $SelectedPath))
  {
    # Update the path using a function that is shared with the above function.
    GUI_UpdateFolderPath_MasterPaths -InputPath $SelectedPath
  }
}
#==============================================================================================================================================================================================
#  Updates the "Texture Path" and "Output Path" when manually entering the text.

function GUI_UpdateFolderPath_TextBox()
{
  # Get the current value of the MasterPath.
  $CurrentPath = Get-Variable -Name $this.Name -ValueOnly
  $EnteredText = $this.Text

  # To avoid updating constantly, check to see if the text actually changed.
  if ($EnteredText -ne $CurrentPath)
  {
    # Check to see if a folder was selected from the Open menu and test if that path exists.
    if (($EnteredText -ne '') -and ($EnteredText -notlike '*~*') -and ($EnteredText.Length -gt 3) -and (TestPath -LiteralPath $EnteredText))
    {
      # Update the path using a function that is shared with the above function.
      GUI_UpdateFolderPath_MasterPaths -InputPath $EnteredText
    }
    # The text was empty or invalid.
    else
    {
      # Set the textbox text back to the MasterPath.
      $this.Text = $CurrentPath
    }
  }
}
#==============================================================================================================================================================================================
#  CTT GUI - Create Input Path Selection
#==============================================================================================================================================================================================
$InputGroup = New-Object System.Windows.Forms.GroupBox
$InputGroup.Size = New-Object System.Drawing.Size(380, 50)
$InputGroup.Location = New-Object System.Drawing.Size(10, 5)
$InputGroup.Text = ' Texture Path '
$InputGroup.Add_Click({ Invoke-Item -LiteralPath $MasterInputPath})
$MainDialog.Controls.Add($InputGroup)
$InputGroupTip = New-Object System.Windows.Forms.ToolTip
$InputGroupTip.InitialDelay = $ToolTipDelay
$InputGroupTip.AutoPopDelay = $ToolTipDuration
$InputGroupTipString = 'Path to the folder that contains textures.'
$InputGroupTip.SetToolTip($InputGroup, $InputGroupTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$InputTextBox = New-Object System.Windows.Forms.TextBox
$InputTextBox.Name = 'MasterInputPath'
$InputTextBox.Size = New-Object System.Drawing.Size(320, 22)
$InputTextBox.Location = New-Object System.Drawing.Size(18, 20)
$InputTextBox.Text = $MasterInputPath
$InputTextBox.AllowDrop = $true
$InputTextBox.Add_DragEnter({ $_.Effect = [Windows.Forms.DragDropEffects]::Copy })
$InputTextBox.Add_DragDrop({ GUI_UpdateFolderPath_DragDrop })
$InputTextBox.Add_Leave({ GUI_UpdateFolderPath_TextBox })
$InputGroup.Controls.Add($InputTextBox)
#----------------------------------------------------------------------------------------------------------------------------------------------
$InputButton = New-Object System.Windows.Forms.Button
$InputButton.Name = 'MasterInputPath'
$InputButton.Size = New-Object System.Drawing.Size(24, 22)
$InputButton.Location = New-Object System.Drawing.Size(346, 18)
$InputButton.Text = '...'
$InputButtonMessage = 'Select a folder that contains textures. This should be a Dolphin texture pack folder that contains the 3-digit or 6-digit GameID. Example: SX4 or SX4E01'
$InputButton.Add_Click({ GUI_UpdateFolderPath_Button -Message $InputButtonMessage })
$InputGroup.Controls.Add($InputButton)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Store the Texture Folder
$StoreInputCheck = New-Object System.Windows.Forms.CheckBox
$StoreInputCheck.Name = 'StoreInputFolder'
$StoreInputCheck.Size = New-Object System.Drawing.Size(16, 16)
$StoreInputCheck.Location = New-Object System.Drawing.Size(4, 23)
$StoreInputCheck.Checked = $StoreInputFolder
$StoreInputCheck.Text = ''
$StoreInputCheck.Add_CheckStateChanged({ GUI_UpdateCheckBoxState })
$StoreInputCheck.Enabled = $EnableStoring
$InputGroup.Controls.Add($StoreInputCheck)
$StoreInputTip = New-Object System.Windows.Forms.ToolTip
$StoreInputTip.InitialDelay = 300
$StoreInputTip.AutoPopDelay = $ToolTipDuration
$StoreInputTipString = 'Saves the selected Texture Path when the script{0}'
$StoreInputTipString += 'is closed. If the preference to save changes on{0}'
$StoreInputTipString += 'exit is disabled, this box will have no effect.'
$StoreInputTipString = [String]::Format($StoreInputTipString, [Environment]::NewLine)
$StoreInputTip.SetToolTip($StoreInputCheck, $StoreInputTipString)
#==============================================================================================================================================================================================
#  CTT GUI - Create Output Path Selection
#==============================================================================================================================================================================================
$OutputGroup = New-Object System.Windows.Forms.GroupBox
$OutputGroup.Size = New-Object System.Drawing.Size(380, 50)
$OutputGroup.Location = New-Object System.Drawing.Size(10, 60)
$OutputGroup.Text = ' Output Path '
$OutputGroup.Add_Click({ if (TestPath -LiteralPath $MasterOutputPath) { Invoke-Item -LiteralPath $MasterOutputPath } })
$MainDialog.Controls.Add($OutputGroup)
$OutputGroupTip = New-Object System.Windows.Forms.ToolTip
$OutputGroupTip.InitialDelay = $ToolTipDelay
$OutputGroupTip.AutoPopDelay = $ToolTipDuration
$OutputGroupTipString = 'Path to where this script will generate textures.'
$OutputGroupTip.SetToolTip($OutputGroup, $OutputGroupTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$OutputTextBox = New-Object System.Windows.Forms.TextBox
$OutputTextBox.Name = 'MasterOutputPath'
$OutputTextBox.Size = New-Object System.Drawing.Size(320, 22)
$OutputTextBox.Location = New-Object System.Drawing.Size(18, 20)
$OutputTextBox.Text = $MasterOutputPath
$OutputTextBox.AllowDrop = $true
$OutputTextBox.Add_DragEnter({$_.Effect = [Windows.Forms.DragDropEffects]::Copy})
$OutputTextBox.Add_DragDrop({ GUI_UpdateFolderPath_DragDrop })
$OutputTextBox.Add_Leave({ GUI_UpdateFolderPath_TextBox })
$OutputGroup.Controls.Add($OutputTextBox)
#----------------------------------------------------------------------------------------------------------------------------------------------
$OutputButton = New-Object System.Windows.Forms.Button
$OutputButton.Name = 'MasterOutputPath'
$OutputButton.Size = New-Object System.Drawing.Size(24, 22)
$OutputButton.Location = New-Object System.Drawing.Size(346, 18)
$OutputButton.Text = '...'
$OutputButtonMessage = 'Select a folder to output generated textures. Textures generated by this script will be created in the output folder in a sub-folder named "~CTT_Generated".'
$OutputButton.Add_Click({GUI_UpdateFolderPath_Button -Message $OutputButtonMessage})
$OutputGroup.Controls.Add($OutputButton)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Store the Output Folder
$StoreOutputCheck = New-Object System.Windows.Forms.CheckBox
$StoreOutputCheck.Name = 'StoreOutputFolder'
$StoreOutputCheck.Size = New-Object System.Drawing.Size(16, 16)
$StoreOutputCheck.Location = New-Object System.Drawing.Size(4, 23)
$StoreOutputCheck.Checked = $StoreOutputFolder
$StoreOutputCheck.Text = ''
$StoreOutputCheck.Add_CheckStateChanged({ GUI_UpdateCheckBoxState })
$StoreOutputCheck.Enabled = $EnableStoring
$OutputGroup.Controls.Add($StoreOutputCheck)
$StoreOutputTip = New-Object System.Windows.Forms.ToolTip
$StoreOutputTip.InitialDelay = 300
$StoreOutputTip.AutoPopDelay = $ToolTipDuration
$StoreOutputTipString = 'Saves the selected Output Path when the script{0}'
$StoreOutputTipString += 'is closed. If the preference to save changes on{0}'
$StoreOutputTipString += 'exit is disabled, this box will have no effect.'
$StoreOutputTipString = [String]::Format($StoreOutputTipString, [Environment]::NewLine)
$StoreOutputTip.SetToolTip($StoreOutputCheck, $StoreOutputTipString)
#==============================================================================================================================================================================================
#  CTT GUI: UPDATE OPTION STATE FUNCTIONS
#==============================================================================================================================================================================================
#  Generic function that takes care of all check boxes that have their value toggled.

function GUI_UpdateCheckBoxState()
{
  # Update the variable with the reversed state.
  Set-Variable -Name $this.Name -Value $this.Checked -Scope 'Global'
}
#==============================================================================================================================================================================================
#  Generic function that takes care of almost all combo boxes that have their value changed.

function GUI_UpdateComboBoxState($NewValue)
{
  # Update the variable with the new value that was fed to the parameter.
  Set-Variable -Name $this.Name -Value $NewValue -Scope 'Global'
}
#==============================================================================================================================================================================================
#  Note: I noticed a flaw with "NumericUpDown" boxes. When a user types more than 2 decimal places, the box will correct itself, but the internal value remains 
#  whatever the user typed in. As a work-around, I round this value and manually update the box with it so that it matches what is stored in the global variable.

function GUI_UpdateNumericUpDown([string]$TypeDefinition)
{
  # Convert the value into a decimal format and split the integer from the decimal.
  $ValueSplit = (FormatDecimal -Value $this.Value).Split('.', 2)

  # If the Numeric Up/Down only accepts integers, keep only the integer. If it wants a decimal, then use the entire number.
  switch ($TypeDefinition)
  {
    'integer' { $NewValue = $ValueSplit[0] }
    'decimal' { $NewValue = $ValueSplit[0] + '.' + $ValueSplit[1] }
  }
  # Update the variable with the new value.
  Set-Variable -Name $this.Name -Value $NewValue -Scope 'Global'
}
#==============================================================================================================================================================================================
#  When an option is selected from the Standard or Advanced options menus, this updates which sub-options are visible to the user.

function GUI_UpdateSelectedOptions([string]$Index)
{
  # Check to see if an option wasn't forced.
  if ($Index -eq '')
  {
    # Get the selected index in the form of a string to apply it to a switch.
    $Index = $this.SelectedIndex
  }
  # Initially hide all option groups.
  $ScanGroup.Hide()
  $RescaleGroup.Hide()
  $ConvertGroup.Hide()
  $MaterialGroup.Hide()
  $WatermarkGroup.Hide()
  $OptiPNGGroup.Hide()
  $UpscaleFilterGroup.Hide()
  $VRAMGroup.Hide()

  # And the advanced options groups.
  $GenNewMipMapsGroup.Hide()
  $InvalidMipMapsGroup.Hide()
  $ExtractMipMapGroup.Hide()
  $RemoveAlphaGroup.Hide()
  $CombineTextureGroup.Hide()
  $SplitTextureGroup.Hide()
  $ImageViewerGroup.Hide()

  # Standard Options
  if ($StandardOptions.Visible)
  {
    # Show the group of options that corresponds to the selected index.
    switch ($Index)
    {
      '0' { $ScanGroup.Show() }
      '1' { $ConvertGroup.Show() }
      '2' { $RescaleGroup.Show() }    
      '3' { $WatermarkGroup.Show() }
      '4' { $MaterialGroup.Show() }
      '5' { $OptiPNGGroup.Show() }
      '6' { $UpscaleFilterGroup.Show() }
      '7' { $VRAMGroup.Show() }
    }
    # Store the selected option group and the current index.
    $global:CurrentOptions = 'Standard'
    $global:StoredStandard = $Index
  }
  # Advanced Options
  else
  {
    # Show the group of options that corresponds to the selected index.
    switch ($Index)
    {
      '0'   { $ImageViewerGroup.Show() }
      '1'   { $GenNewMipMapsGroup.Show() }
      '2'   { $InvalidMipMapsGroup.Show() }
      '3'   { $ExtractMipMapGroup.Show() }
      '4'   { $RemoveAlphaGroup.Show() }    
      '5'   { $CombineTextureGroup.Show() }
      '6'   { $SplitTextureGroup.Show() }
    }
    # Store the selected option group and the current index.
    $global:CurrentOptions = 'Advanced'
    $global:StoredAdvanced = $Index
  }
}
#==============================================================================================================================================================================================
#  When a button on the side of the standard/advanced menu is pressed, this toggles which menu is visible and updates which options are shown.

function GUI_OptionsButtonPress()
{
  if ($this.Name -eq 'Standard')
  {
    $StandardGroup.Visible = $true
    $AdvancedGroup.Visible = $false
    GUI_UpdateSelectedOptions -Index $StandardOptions.SelectedIndex
  }
  elseif ($this.Name -eq 'Advanced')
  {
    $StandardGroup.Visible = $false
    $AdvancedGroup.Visible = $true
    GUI_UpdateSelectedOptions -Index $AdvancedOptions.SelectedIndex
  }
}
#==============================================================================================================================================================================================
#  Quickly load a specific help topic depending on the currently selected "Standard" or "Advanced" Option.

function GUI_QuickHelp()
{
  # Check to see if the dialog is currently hidden.
  if (!$HelpDialog.Visible)
  {
    # Show the help dialog.
    $HelpDialog.Show()

    # Perform some 'Get-Variable' trickery to get the currently selected Standard or Advanced sub-node.
    $SelectedOption = Get-Variable -Name ($CurrentOptions + 'Options') -ValueOnly

    # This gets messy and deep real fast. Loop through all nodes in the help dialog.
    foreach($Node in $HelpTopics.Nodes)
    {
      # Find the node that matches the "Main Window" item.
      if ($Node.ToString() -eq 'TreeNode: Main Window' )
      {
        # Loop through all "Main Window" subnodes.
        foreach($SubNode in $Node.Nodes)
        {
          # Select the correct node, either Standard or Advanced Options.
          if ($SubNode.ToString() -eq ('TreeNode: ' + $CurrentOptions + ' Options'))
          {
            # Loop through all subnodes in the current node.
            foreach($SubSubNode in $SubNode.Nodes)
            {
              # Select the correct subnode based on the selected option.
              if ($SubSubNode.ToString() -eq ('TreeNode: ' + $SelectedOption.SelectedItem))
              {
                # Display the help topic.
                $HelpTopics.SelectedNode = $SubSubNode
                return
              }
            }
          }
        }
      }
    }
  }
  # The help dialog is already open.
  else
  {
    # So close it.
    $HelpDialog.Hide()
  }
}
#==============================================================================================================================================================================================
# CTT GUI - Create the Main Options list.
#==============================================================================================================================================================================================
$StandardGroup = New-Object System.Windows.Forms.GroupBox
$StandardGroup.Size = New-Object System.Drawing.Size(380, 140)
$StandardGroup.Location = New-Object System.Drawing.Size(10, 115)
$StandardGroup.Text = ' Standard Options '
$MainDialog.Controls.Add($StandardGroup)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Window that holds all of the Main Menu options.
$StandardOptions = New-Object System.Windows.Forms.ListBox
$StandardOptions.Size = New-Object System.Drawing.Size(288, 116)
$StandardOptions.Location = New-Object System.Drawing.Size(10, 20)
$StandardOptions.Items.Add('Scan Dolphin Textures For Issues') | Out-Null
$StandardOptions.Items.Add('Convert Textures to Another Format') | Out-Null
$StandardOptions.Items.Add('Rescale Textures With New Scaling Factor') | Out-Null
$StandardOptions.Items.Add('Add Identifying Watermark to All Textures') | Out-Null
$StandardOptions.Items.Add('Create Material Maps With Ishiiruka Tool') | Out-Null
$StandardOptions.Items.Add('Optimize PNG Textures With OptiPNG') | Out-Null
$StandardOptions.Items.Add('Apply Upscaling Filter to All Textures') | Out-Null
$StandardOptions.Items.Add('Calculate Textures VRAM Requirement') | Out-Null
$StandardOptions.SelectedIndex = $StoredStandard
$StandardOptions.Add_SelectedIndexChanged({ GUI_UpdateSelectedOptions -Index '' })
$StandardGroup.Controls.Add($StandardOptions)
#----------------------------------------------------------------------------------------------------------------------------------------------
$StandardButtonA = New-Object System.Windows.Forms.Button
$StandardButtonA.Name = 'Standard'
$StandardButtonA.Size = New-Object System.Drawing.Size(72, 30)
$StandardButtonA.Location = New-Object System.Drawing.Size(302, 20)
$StandardButtonA.Text = 'Standard'
$StandardButtonA.Add_Click({ GUI_OptionsButtonPress })
$StandardGroup.Controls.Add($StandardButtonA)
$StandardButtonATip = New-Object System.Windows.Forms.ToolTip
$StandardButtonATip.InitialDelay = $ToolTipDelay
$StandardButtonATip.AutoPopDelay = $ToolTipDuration
$StandardButtonATipString = 'Standard options do not modify the texture pack directly.{0}'
$StandardButtonATipString += 'Textures created with these options are sent to the Output{0}'
$StandardButtonATipString += 'Path folder within the "~CTT_Generated" sub-folder.'
$StandardButtonATipString = [String]::Format($StandardButtonATipString, [Environment]::NewLine)
$StandardButtonATip.SetToolTip($StandardButtonA, $StandardButtonATipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$StandardButtonB = New-Object System.Windows.Forms.Button
$StandardButtonB.Name = 'Advanced'
$StandardButtonB.Size = New-Object System.Drawing.Size(72, 30)
$StandardButtonB.Location = New-Object System.Drawing.Size(302, 58)
$StandardButtonB.Text = 'Advanced'
$StandardButtonB.Add_Click({ GUI_OptionsButtonPress })
$StandardGroup.Controls.Add($StandardButtonB)
$StandardButtonBTip = New-Object System.Windows.Forms.ToolTip
$StandardButtonBTip.InitialDelay = $ToolTipDelay
$StandardButtonBTip.AutoPopDelay = $ToolTipDuration
$StandardButtonBTipString = 'Advanced options modify the texture pack directly, so they{0}'
$StandardButtonBTipString += 'must be used with caution. It is suggested to back up the{0}'
$StandardButtonBTipString += 'texture pack before using these options. The changes that{0}'
$StandardButtonBTipString += 'they make are irreversible, and may end up being undesired.'
$StandardButtonBTipString = [String]::Format($StandardButtonBTipString, [Environment]::NewLine)
$StandardButtonBTip.SetToolTip($StandardButtonB, $StandardButtonBTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$StandardButtonC = New-Object System.Windows.Forms.Button
$StandardButtonC.Name = 'Quick Help'
$StandardButtonC.Size = New-Object System.Drawing.Size(72, 30)
$StandardButtonC.Location = New-Object System.Drawing.Size(302, 96)
$StandardButtonC.Text = 'Quick Help'
$StandardButtonC.Add_Click({ GUI_QuickHelp })
$StandardGroup.Controls.Add($StandardButtonC)
$StandardButtonCTip = New-Object System.Windows.Forms.ToolTip
$StandardButtonCTip.InitialDelay = $ToolTipDelay
$StandardButtonCTip.AutoPopDelay = $ToolTipDuration
$StandardButtonCTipString = "Opens the Help dialog and quickly links to this option's explantion."
$StandardButtonCTip.SetToolTip($StandardButtonC, $StandardButtonCTipString)
#==============================================================================================================================================================================================
# CTT GUI - Create the Advanced Options list.
#==============================================================================================================================================================================================
$AdvancedGroup = New-Object System.Windows.Forms.GroupBox
$AdvancedGroup.Size = New-Object System.Drawing.Size(380, 140)
$AdvancedGroup.Location = New-Object System.Drawing.Size(10, 115)
$AdvancedGroup.Text = ' Advanced Options '
$MainDialog.Controls.Add($AdvancedGroup)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Window that holds all of the Advanced Menu options.
$AdvancedOptions = New-Object System.Windows.Forms.ListBox
$AdvancedOptions.Size = New-Object System.Drawing.Size(288, 116)
$AdvancedOptions.Location = New-Object System.Drawing.Size(10, 20)
$AdvancedOptions.Items.Add('Basic Image Viewer') | Out-Null
$AdvancedOptions.Items.Add('Generate New MipMaps') | Out-Null
$AdvancedOptions.Items.Add('Remove Invalid MipMaps') | Out-Null
$AdvancedOptions.Items.Add('Extract DDS Internal MipMaps') | Out-Null
$AdvancedOptions.Items.Add('Remove Alpha Channel From Opaque Textures') | Out-Null
$AdvancedOptions.Items.Add('Combine Multiple Textures') | Out-Null
$AdvancedOptions.Items.Add('Split Combined Multi-Texture') | Out-Null
$AdvancedOptions.SelectedIndex = $StoredAdvanced
$AdvancedOptions.Add_SelectedIndexChanged({ GUI_UpdateSelectedOptions -Index '' })
$AdvancedGroup.Controls.Add($AdvancedOptions)
#----------------------------------------------------------------------------------------------------------------------------------------------
$AdvancedButtonA = New-Object System.Windows.Forms.Button
$AdvancedButtonA.Name = 'Standard'
$AdvancedButtonA.Size = New-Object System.Drawing.Size(72, 30)
$AdvancedButtonA.Location = New-Object System.Drawing.Size(302, 20)
$AdvancedButtonA.Text = 'Standard'
$AdvancedButtonA.Add_Click({ GUI_OptionsButtonPress })
$AdvancedGroup.Controls.Add($AdvancedButtonA)
$AdvancedButtonATip = New-Object System.Windows.Forms.ToolTip
$AdvancedButtonATip.InitialDelay = $ToolTipDelay
$AdvancedButtonATip.AutoPopDelay = $ToolTipDuration
$AdvancedButtonATipString = 'Standard options do not modify the texture pack directly.{0}'
$AdvancedButtonATipString += 'Textures created with these options are sent to the Output{0}'
$AdvancedButtonATipString += 'Path folder within the "~CTT_Generated" sub-folder.'
$AdvancedButtonATipString = [String]::Format($AdvancedButtonATipString, [Environment]::NewLine)
$AdvancedButtonATip.SetToolTip($AdvancedButtonA, $AdvancedButtonATipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$AdvancedButtonB = New-Object System.Windows.Forms.Button
$AdvancedButtonB.Name = 'Advanced'
$AdvancedButtonB.Size = New-Object System.Drawing.Size(72, 30)
$AdvancedButtonB.Location = New-Object System.Drawing.Size(302, 58)
$AdvancedButtonB.Text = 'Advanced'
$AdvancedButtonB.Add_Click({ GUI_OptionsButtonPress })
$AdvancedGroup.Controls.Add($AdvancedButtonB)
$AdvancedButtonBTip = New-Object System.Windows.Forms.ToolTip
$AdvancedButtonBTip.InitialDelay = $ToolTipDelay
$AdvancedButtonBTip.AutoPopDelay = $ToolTipDuration
$AdvancedButtonBTipString = 'Advanced options modify the texture pack directly, so they{0}'
$AdvancedButtonBTipString += 'must be used with caution. It is suggested to back up the{0}'
$AdvancedButtonBTipString += 'texture pack before using these options. The changes that{0}'
$AdvancedButtonBTipString += 'they make are irreversible, and may end up being undesired.'
$AdvancedButtonBTipString = [String]::Format($AdvancedButtonBTipString, [Environment]::NewLine)
$AdvancedButtonBTip.SetToolTip($AdvancedButtonB, $AdvancedButtonBTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$AdvancedButtonC = New-Object System.Windows.Forms.Button
$AdvancedButtonC.Name = 'Quick Help'
$AdvancedButtonC.Size = New-Object System.Drawing.Size(72, 30)
$AdvancedButtonC.Location = New-Object System.Drawing.Size(302, 96)
$AdvancedButtonC.Text = 'Quick Help'
$AdvancedButtonC.Add_Click({ GUI_QuickHelp })
$AdvancedGroup.Controls.Add($AdvancedButtonC)
$AdvancedButtonCTip = New-Object System.Windows.Forms.ToolTip
$AdvancedButtonCTip.InitialDelay = $ToolTipDelay
$AdvancedButtonCTip.AutoPopDelay = $ToolTipDuration
$AdvancedButtonCTipString = "Opens the Help dialog and quickly links to this option's explantion."
$AdvancedButtonCTip.SetToolTip($AdvancedButtonC, $AdvancedButtonCTipString)
#==============================================================================================================================================================================================
#  CTT GUI - CREATE BOTTOM BUTTONS
#==============================================================================================================================================================================================
# Start Processing
$StartButton = New-Object System.Windows.Forms.Button
$StartButton.Size = New-Object System.Drawing.Size(84, 28)
$StartButton.Location = New-Object System.Drawing.Size(10, 390)
$StartButton.Text = 'Start'
$StartButton.Add_Click({ StartMasterLoop })
$MainDialog.Controls.Add($StartButton)
$StartTip = New-Object System.Windows.Forms.ToolTip
$StartTip.InitialDelay = $ToolTipDelay
$StartTip.AutoPopDelay = $ToolTipDuration
$StartTipString = 'Begins processing textures with the selected option.{0}'
$StartTipString += '{0}'
$StartTipString += 'If the Control key is held while pressing this button,{0}'
$StartTipString += 'a menu appears that allows manually selecting textures{0}'
$StartTipString += 'to process (which temporarily skips the Texture Path).'
$StartTipString = [String]::Format($StartTipString, [Environment]::NewLine)
$StartTip.SetToolTip($StartButton, $StartTipString)
#==============================================================================================================================================================================================
#  Toggles showing the side panel with the "Options" button where tool paths and other "Internal Options" can be configured.

function GUI_ToggleOptionsPanel()
{
  # An icky yet effective solution is to check the current width of the dialog.
  if ($MainDialog.Width -le 414)
  {
    # Resize the main dialog to its maximum width.
    $MainDialog.MinimumSize = New-Object System.Drawing.Size(806, (464 + $HeightOffset))
    $MainDialog.MaximumSize = New-Object System.Drawing.Size(806, (464 + $HeightOffset))
    $MainDialog.Width = 806

    # Make the options visible.
    $OptionsGroup.Visible = $true
    $MipMapGroup.Visible = $true
    $CTTOptionsGroup.Visible = $true

    # Show the correct buttons.
    $ToolPathsButton.Visible = $true
    $DefaultButton.Visible = $true
    $ImportButton.Visible = $true

    # If the paths menu stuff is visible hide it.
    $ToolPathsCloseButton.Visible = $false
    $HideURLCheck.Visible = $false
  }
  # The current dialog width is at its maximum (meaning the options menu is visible).
  else
  {
    # Resize the main dialog to its normal width.
    $MainDialog.MinimumSize = New-Object System.Drawing.Size(414, (464 + $HeightOffset))
    $MainDialog.MaximumSize = New-Object System.Drawing.Size(414, (464 + $HeightOffset))
    $MainDialog.Width = 414

    # Hide all options.
    $OptionsGroup.Visible = $false
    $MipMapGroup.Visible = $false
    $CTTOptionsGroup.Visible = $false

    # Hide the paths while were at it.
    $PathsGroup.Visible = $false
  }
}
#----------------------------------------------------------------------------------------------------------------------------------------------
# Options Button
$OptionsButton = New-Object System.Windows.Forms.Button
$OptionsButton.Size = New-Object System.Drawing.Size(84, 28)
$OptionsButton.Location = New-Object System.Drawing.Size(108, 390)
$OptionsButton.Text = 'Options'
$OptionsButton.Add_Click({ GUI_ToggleOptionsPanel })
$MainDialog.Controls.Add($OptionsButton)
$OptionsTip = New-Object System.Windows.Forms.ToolTip
$OptionsTip.InitialDelay = $ToolTipDelay
$OptionsTip.AutoPopDelay = $ToolTipDuration
$OptionsTipString = 'Opens the Options menu where paths, texture options,{0}'
$OptionsTipString += 'mipmap options, and preferences may be configured.'
$OptionsTipString = [String]::Format($OptionsTipString, [Environment]::NewLine)
$OptionsTip.SetToolTip($OptionsButton, $OptionsTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Help Button
$HelpButton = New-Object System.Windows.Forms.Button
$HelpButton.Name = 'Help'
$HelpButton.Size = New-Object System.Drawing.Size(84, 28)
$HelpButton.Location =  New-Object System.Drawing.Size(206, 390)
$HelpButton.Text = 'Help'
$HelpButton.Add_Click({if (!$HelpDialog.Visible) {$HelpDialog.Show()} else {$HelpDialog.Hide()}})
$MainDialog.Controls.Add($HelpButton)
$HelpButtonTip = New-Object System.Windows.Forms.ToolTip
$HelpButtonTip.InitialDelay = $ToolTipDelay
$HelpButtonTip.AutoPopDelay = $ToolTipDuration
$HelpButtonTipString = 'Opens the Help dialog which covers how to use this script.'
$HelpButtonTip.SetToolTip($HelpButton, $HelpButtonTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Close the Dialog
$CloseButton = New-Object System.Windows.Forms.Button
$CloseButton.Size = New-Object System.Drawing.Size(84, 28)
$CloseButton.Location = New-Object System.Drawing.Size(304, 390)
$CloseButton.Text = 'Exit'
$CloseButton.Add_Click({$MainDialog.Close()})
$MainDialog.Controls.Add($CloseButton)
$CloseTip = New-Object System.Windows.Forms.ToolTip
$CloseTip.InitialDelay = $ToolTipDelay
$CloseTip.AutoPopDelay = $ToolTipDuration
$CloseTipString = 'Closes the GUI and exits Custom Texture Tool PS.'
$CloseTip.SetToolTip($CloseButton, $CloseTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
function GUI_ShowPathsPanel()
{
  # Hide all options.
  $OptionsGroup.Visible = $false
  $MipMapGroup.Visible = $false
  $CTTOptionsGroup.Visible = $false

  # Show the paths.
  $PathsGroup.Visible = $true

  # Swap the button visibility.
  $ToolPathsButton.Visible = $false
  $DefaultButton.Visible = $false
  $ImportButton.Visible = $false
  $ToolPathsCloseButton.Visible = $true

  # Show the checkmark to hide url icons.
  $HideURLCheck.Visible = $true
}
#----------------------------------------------------------------------------------------------------------------------------------------------
# Show Tool Paths 
$ToolPathsButton = New-Object System.Windows.Forms.Button
$ToolPathsButton.Size = New-Object System.Drawing.Size(114, 28)
$ToolPathsButton.Location = New-Object System.Drawing.Size(400, 390)
$ToolPathsButton.Text = 'Configure Paths'
$ToolPathsButton.Add_Click({GUI_ShowPathsPanel})
$MainDialog.Controls.Add($ToolPathsButton)
$ToolPathsTip = New-Object System.Windows.Forms.ToolTip
$ToolPathsTip.InitialDelay = $ToolTipDelay
$ToolPathsTip.AutoPopDelay = $ToolTipDuration
$ToolPathsTipString = 'Opens the menu to configure the paths to all tools.'
$ToolPathsTip.SetToolTip($ToolPathsButton, $ToolPathsTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
function GUI_HidePathsPanel()
{
  # Show all options.
  $OptionsGroup.Visible = $true
  $MipMapGroup.Visible = $true
  $CTTOptionsGroup.Visible = $true

  # Hide the paths.
  $PathsGroup.Visible = $false
  
  # Swap the button visibility.
  $ToolPathsButton.Visible = $true
  $DefaultButton.Visible = $true
  $ImportButton.Visible = $true
  $ToolPathsCloseButton.Visible = $false

  # Hide the checkmark to hide url icons.
  $HideURLCheck.Visible = $false
}
#----------------------------------------------------------------------------------------------------------------------------------------------
# Hide Tool Paths 
$ToolPathsCloseButton = New-Object System.Windows.Forms.Button
$ToolPathsCloseButton.Size = New-Object System.Drawing.Size(130, 28)
$ToolPathsCloseButton.Location = New-Object System.Drawing.Size(400, 390)
$ToolPathsCloseButton.Text = 'Return to Options'
$ToolPathsCloseButton.Add_Click({GUI_HidePathsPanel})
$MainDialog.Controls.Add($ToolPathsCloseButton)
$ToolPathsCloseTip = New-Object System.Windows.Forms.ToolTip
$ToolPathsCloseTip.InitialDelay = $ToolTipDelay
$ToolPathsCloseTip.AutoPopDelay = $ToolTipDuration
$ToolPathsCloseTipString = 'Closes the paths menu and returns to the options menu.'
$ToolPathsCloseTip.SetToolTip($ToolPathsCloseButton, $ToolPathsCloseTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Default Stored Options
$DefaultButton = New-Object System.Windows.Forms.Button
$DefaultButton.Size = New-Object System.Drawing.Size(116, 28)
$DefaultButton.Location = New-Object System.Drawing.Size(526, 390)
$DefaultButton.Text = 'Restore Defaults'
$DefaultButton.Add_Click({RestoreDefaultOptions})
$MainDialog.Controls.Add($DefaultButton)
$DefaultTip = New-Object System.Windows.Forms.ToolTip
$DefaultTip.InitialDelay = $ToolTipDelay
$DefaultTip.AutoPopDelay = $ToolTipDuration
$DefaultTipString = 'Resets all options to their default values.'
$DefaultTip.SetToolTip($DefaultButton, $DefaultTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Import Stored Options
$ImportButton = New-Object System.Windows.Forms.Button
$ImportButton.Size = New-Object System.Drawing.Size(126, 28)
$ImportButton.Location = New-Object System.Drawing.Size(654, 390)
$ImportButton.Text = 'Import Stored Options'
$ImportButton.Add_Click({ImportStoredOptions})
$MainDialog.Controls.Add($ImportButton)
$ImportTip = New-Object System.Windows.Forms.ToolTip
$ImportTip.InitialDelay = $ToolTipDelay
$ImportTip.AutoPopDelay = $ToolTipDuration
$ImportTipString = 'Allows importing all Stored Options from another version of Custom Texture{0}'
$ImportTipString += 'Tool PS by simply selecting the script file. It should work on any version of{0}'
$ImportTipString += 'the PowerShell versions of the script. This feature exists to retain settings{0}'
$ImportTipString += 'in future versions of this script, and not have to set them every single time.'
$ImportTipString = [String]::Format($ImportTipString, [Environment]::NewLine)
$ImportTip.SetToolTip($ImportButton, $ImportTipString)
#==============================================================================================================================================================================================
#  CTT GUI: UPDATE EXTERNAL TOOL PATHS
#==============================================================================================================================================================================================
#  Shared below the next 2 function to reduce duplicate code. 
#  Contains a bunch of hacked in shit depending on which variable is being updated.
function GUI_UpdateFilePath_Finish([object]$TextBox, [string]$VarName, [string]$ToolPath)
{
  # Update the variable.
  Set-Variable -Name $VarName -Value $ToolPath -Scope 'Global'

  # I remember a time when this was a "universal" function...
  switch ($VarName)
  {
    # Before updating the global variable, check if we're changing the path to ImageMagick.
    'ImageMagick'     {
                        # Hack the executable from the path because we only want the base path.
                        $ToolPath = $ToolPath.Replace('\magick.exe','')
                        $ToolPath = $ToolPath.Replace('\convert.exe','')

                        # Flag this true to update the path in "StoreAllOptions" when the script is closed.
                        $global:UpdateImageMagick = $true

                        # Sets the version that is found and updates the title bar.
                        FindImageMagick
                      }
    # Before updating the global variable, check if we're changing the path to TexConvTool.
    'TexConvTool'     {
                        # Remove all items from the GUI menu.
                        $DDSCreatorCombo.Items.Remove('DDS Utilities') | Out-Null
                        $DDSCreatorCombo.Items.Remove('Compressonator') | Out-Null
                        $DDSCreatorCombo.Items.Remove('ImageMagick') | Out-Null
                        $DDSCreatorCombo.Items.Remove('Add Tool...') | Out-Null

                        # Add all items back to the GUI menu.
                        if (TestPath -LiteralPath $DDSUtilities)    { $DDSCreatorCombo.Items.Add('DDS Utilities') | Out-Null }
                        if (TestPath -LiteralPath $Compressonator)  { $DDSCreatorCombo.Items.Add('Compressonator') | Out-Null }
                        $DDSCreatorCombo.Items.Add('TexConv') | Out-Null
                        $DDSCreatorCombo.Items.Add('ImageMagick') | Out-Null

                        # Adds the option "Add Tool..." to the menu if all tools are not already added.
                        CheckAddDDSToolOption

                        # Reselect the currently chosen tool.
                        $DDSCreatorCombo.SelectedItem = $DDSCreatorTool

                        # Back up the selected tools for DDS compression and the backup format.
                        $CompressBackup = $DDSBCCombo.SelectedItem
                        $FallbackBackup = $DDSFBCCombo.SelectedItem

                        # Just to be safe, try to remove these from the list if they are present.
                        $DDSBCCombo.Items.Remove('BC7') | Out-Null
                        $DDSBCCombo.Items.Remove('ARGB32') | Out-Null
                        $DDSBCCombo.Items.Remove('User Defined') | Out-Null
                        $DDSFBCCombo.Items.Remove('BC7') | Out-Null
                        $DDSFBCCombo.Items.Remove('ARGB32') | Out-Null

                        # Add BC7 and ARGB32 to the list of selectable DDS output formats.
                        $DDSBCCombo.Items.Add('BC7') | Out-Null
                        $DDSBCCombo.Items.Add('ARGB32') | Out-Null
                        $DDSBCCombo.Items.Add('User Defined') | Out-Null
                        $DDSFBCCombo.Items.Add('BC7') | Out-Null
                        $DDSFBCCombo.Items.Add('ARGB32') | Out-Null

                        # Reselect the tool that was previously chosen. Removing them from the list will unselect them so this must be done.
                        $DDSBCCombo.SelectedItem = $CompressBackup
                        $DDSFBCCombo.SelectedItem = $FallbackBackup
                      }
    # Before updating the global variable, check if we're changing the path to Compressonator.
    'Compressonator'  {
                        # Remove all items from the GUI menu.
                        $DDSCreatorCombo.Items.Remove('DDS Utilities') | Out-Null
                        $DDSCreatorCombo.Items.Remove('TexConv') | Out-Null
                        $DDSCreatorCombo.Items.Remove('ImageMagick') | Out-Null
                        $DDSCreatorCombo.Items.Remove('Add Tool...') | Out-Null

                        # Add all items back to the GUI menu.
                        if (TestPath -LiteralPath $DDSUtilities) { $DDSCreatorCombo.Items.Add('DDS Utilities') | Out-Null }
                        $DDSCreatorCombo.Items.Add('Compressonator') | Out-Null
                        if (TestPath -LiteralPath $TexConvTool) { $DDSCreatorCombo.Items.Add('TexConv') | Out-Null }
                        $DDSCreatorCombo.Items.Add('ImageMagick') | Out-Null

                        # Adds the option "Add Tool..." to the menu if all tools are not already added.
                        CheckAddDDSToolOption

                        # Reselect the currently chosen tool.
                        $DDSCreatorCombo.SelectedItem = $DDSCreatorTool
                      }
    # Before updating the global variable, check if we're changing the path to DDS Utilities.
    'DDSUtilities'    {
                        # Remove all items from the GUI menu.
                        $DDSCreatorCombo.Items.Remove('Compressonator') | Out-Null
                        $DDSCreatorCombo.Items.Remove('TexConv') | Out-Null
                        $DDSCreatorCombo.Items.Remove('ImageMagick') | Out-Null
                        $DDSCreatorCombo.Items.Remove('Add Tool...') | Out-Null

                        # Add all items back to the GUI menu.
                        $DDSCreatorCombo.Items.Add('DDS Utilities') | Out-Null
                        if (TestPath -LiteralPath $Compressonator) { $DDSCreatorCombo.Items.Add('Compressonator') | Out-Null }
                        if (TestPath -LiteralPath $TexConvTool) { $DDSCreatorCombo.Items.Add('TexConv') | Out-Null }
                        $DDSCreatorCombo.Items.Add('ImageMagick') | Out-Null

                        # Adds the option "Add Tool..." to the menu if all tools are not already added.
                        CheckAddDDSToolOption

                        # Reselect the currently chosen tool.
                        $DDSCreatorCombo.SelectedItem = $DDSCreatorTool
                      }
    # If changing the waifu2x path and the current filter is waifu2x, some GUI elements must be updated.
    'Waifu2xPath'     {
                        # Remove all items from the GUI menu.
                        $U_FilterCombo.Items.Remove('xBRZ') | Out-Null
                        $U_FilterCombo.Items.Remove('Point') | Out-Null
                        $U_FilterCombo.Items.Remove('Cubic') | Out-Null
                        $U_FilterCombo.Items.Remove('Lancoz') | Out-Null
                        $U_FilterCombo.Items.Remove('Add Filter...') | Out-Null

                        # Add all items back to the GUI menu.
                        if (TestPath -LiteralPath $ScalerTestPath) { $U_FilterCombo.Items.Add('xBRZ') | Out-Null }
                        $U_FilterCombo.Items.Add('Waifu2x') | Out-Null
                        $U_FilterCombo.Items.Add('Point') | Out-Null
                        $U_FilterCombo.Items.Add('Cubic') | Out-Null
                        $U_FilterCombo.Items.Add('Lancoz') | Out-Null

                        # Adds the option "Add Filter..." to the menu if all tools are not already added.
                        CheckAddFilterOption

                        # Reselect the currently chosen tool.
                        $U_FilterCombo.SelectedItem = $FilterSelected

                        # Get the name of the selected Waifu2x application.
                        $global:Waifu2xApp = [string](Get-ChildItem -LiteralPath $Waifu2xPath).Name

                        # Update GUI related stuff depending on which version was selected.
                        GUI_UpdateWaifu2xSelection
                      }
    # If the path to xBRZ was selected.
    'ScalerTestPath'  {
                        # Remove all items from the GUI menu.
                        $U_FilterCombo.Items.Remove('Waifu2x') | Out-Null
                        $U_FilterCombo.Items.Remove('Point') | Out-Null
                        $U_FilterCombo.Items.Remove('Cubic') | Out-Null
                        $U_FilterCombo.Items.Remove('Lancoz') | Out-Null
                        $U_FilterCombo.Items.Remove('Add Filter...') | Out-Null

                        # Add all items back to the GUI menu.
                        $U_FilterCombo.Items.Add('xBRZ') | Out-Null
                        if (TestPath -LiteralPath $Waifu2xPath) { $U_FilterCombo.Items.Add('Waifu2x') | Out-Null }
                        $U_FilterCombo.Items.Add('Point') | Out-Null
                        $U_FilterCombo.Items.Add('Cubic') | Out-Null
                        $U_FilterCombo.Items.Add('Lancoz') | Out-Null

                        # Adds the option "Add Filter..." to the menu if all tools are not already added.
                        CheckAddFilterOption

                        # Reselect the currently chosen tool.
                        $U_FilterCombo.SelectedItem = $FilterSelected
                      }            
    # The path to Ishiiruka Tool can be updated from the Paths menu or the option for the tool.
    'IshiirukaTool'   {
                        # So both paths must be updated. Whichever one was updated, force upding the other.
                        switch ($TextBox)
                        {
                          $IshiiPathTextBoxA  { $IshiiPathTextBoxB.Text = $ToolPath }
                          $IshiiPathTextBoxB  { $IshiiPathTextBoxA.Text = $ToolPath }
                        }
                      }
    # The path to OptiPNG can be updated from the Paths menu or the option for the tool.
    'OptiPNGPath'     {
                        # So both paths must be updated. Whichever one was updated, force upding the other.
                        switch ($TextBox)
                        {
                          $OptiPathTextBoxA  { $OptiPathTextBoxB.Text = $ToolPath }
                          $OptiPathTextBoxB  { $OptiPathTextBoxA.Text = $ToolPath }
                        }
                      }
  }
  # Update the text box with the new path.
  $TextBox.Text = $ToolPath
}
#==============================================================================================================================================================================================
#  Updates the tools paths on the options panel with a drag and drop.

function GUI_UpdateFilePath_DragDrop([string[]]$FileName)
{
  # Make sure there is data present before actually doing anything.
  if ($_.Data.GetDataPresent([Windows.Forms.DataFormats]::FileDrop))
  {
    # Create a list of the data to select the first item from the list.
    $DroppedPath = [string]($_.Data.GetData([Windows.Forms.DataFormats]::FileDrop))

    # To support both waifu2x versions and ImageMagick versions, some trickery is needed. The parameter accepts an array, so both executables need to be tested.
    foreach($FileText in $FileName)
    {
      # Make sure the path is a file (defined by type "leaf").
      if (Test-Path -LiteralPath $DroppedPath -PathType Leaf)
      {
        # Get the name of the item.
        $DroppedItem = (Get-Item -LiteralPath $DroppedPath).Name

        # Make sure the correct executable was chosen.
        if ($FileText -eq $DroppedItem)
        {
          # Finish doing everything that needs to be done.
          GUI_UpdateFilePath_Finish -TextBox $this -VarName $this.Name -ToolPath $DroppedPath
          return
        }
      }
      # You know what? Let's set up a condition to check a path to see if the file is inside.
      elseif (Test-Path -LiteralPath $DroppedPath -PathType Container)
      {
        # Set up a path to also include the executable file.
        $PathWithExe = $DroppedPath + '\' + $FileText

        # Make sure the file exists in the chosen path.
        if (TestPath -LiteralPath $PathWithExe)
        {
          # Finish doing everything that needs to be done.
          GUI_UpdateFilePath_Finish -TextBox $this -VarName $this.Name -ToolPath $PathWithExe
          return
        }
      }
    }
  }
}
#==============================================================================================================================================================================================
#  Updates the tools paths on the options panel with the button.

function GUI_UpdateFilePath_Button([object]$TextBox, [string[]]$Description, [string[]]$FileName)
{
  # Display an "Open Folder" menu to get the path. Get-FileName already handles arrays so no need to worry about extra shit.
  $SelectedPath = Get-FileName -Path 'C:\' -Description $Description -FileName $FileName

  # Check to see if a folder was selected from the Open menu and test if that path exists.
  if (($SelectedPath -ne '') -and (TestPath -LiteralPath $SelectedPath))
  {
    # Finish doing everything that needs to be done.
    GUI_UpdateFilePath_Finish -TextBox $TextBox -VarName $this.Name -ToolPath $SelectedPath
  }
}
#==============================================================================================================================================================================================
#  Updates the tool paths on the panel panel by editing the text box. The $FileName parameter is an array to accept multiple applications.

function GUI_UpdateFilePath_TextBox([string[]]$FileName)
{
  # Get the current value of the variable by pulling it from textbox name.
  $CurrentPath = Get-Variable -Name $this.Name -ValueOnly
  $EnteredText = $this.Text

  # To avoid updating constantly, check to see if the text actually changed.
  if (($EnteredText -ne $CurrentPath) -and ($EnteredText -ne ''))
  {
    # To support both waifu2x versions and ImageMagick versions, some trickery is needed. The parameter accepts an array, so both executables need to be tested.
    foreach($FileText in $FileName)
    {
      # Users might think it's cool to put a final slash at the end. It's not cool.
      if ($EnteredText.Substring(($EnteredText.Length - 1), 1) -eq '\')
      {
        # If a slash was found, keep everything but the slash.
        $EnteredText = $EnteredText.Substring(0, ($EnteredText.Length - 1))
      }
      # Make sure the path is a file (defined by type "leaf").
      if (Test-Path -LiteralPath $EnteredText -PathType Leaf)
      {
        # Get the name of the item.
        $EnteredItem = (Get-Item -LiteralPath $EnteredText).Name

        # Make sure the correct executable was chosen.
        if ($FileText -eq $EnteredItem)
        {
          # Finish doing everything that needs to be done.
          GUI_UpdateFilePath_Finish -TextBox $this -VarName $this.Name -ToolPath $EnteredText
          return
        }
      }
      # You know what? Let's set up a condition to check a path to see if the file is inside.
      elseif (Test-Path -LiteralPath $EnteredText -PathType Container)
      {
        # Set up a path to also include the executable file.
        $PathWithExe = $EnteredText + '\' + $FileText

        # Make sure the file exists in the chosen path.
        if (TestPath -LiteralPath $PathWithExe)
        {
          # Finish doing everything that needs to be done.
          GUI_UpdateFilePath_Finish -TextBox $this -VarName $this.Name -ToolPath $PathWithExe
          return
        }
      }
    }
  }
  # If the entered text was empty or invalid, set the textbox text back to what it was.
  $this.Text = $CurrentPath
}
#==============================================================================================================================================================================================
#  CTT GUI - EXTERNAL TOOL PATHS INTERNET ICONS
#==============================================================================================================================================================================================
$Web =  'iVBORw0KGgoAAAANSUhEUgAAAAwAAAAMCAYAAABWdVznAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAB3RJTUUH4QQeBBQpP58DDgAAAfFJREFUKM9dkt1LUwEcQ
        M+9XnW64bzVTKYtXZZlOVqlgYNU6IOKsCKCXoyCrKyXqJ6CgvoPQiqIwLfKwB6krLdQ7Mt0rhqrpaOP+TGd3cmcrm366yGC7Dyf83YUEeFfjp26KLquU2gxc7vjLcbH+8oSQUQQETbtbJaRL8P
        y7XtYRicMCX6NSjSWlkH/qHiOX5O/ngqQ52yUS+fOkGMz80vPwzeWTWR+kow1xZv3Ya62nsDR0CIAGoBtmZ11qxdIJfsoL1KIrz2M2fKTG/fM5CulfOj2YyRWAqDaN+wWt9uNJdLHbA5oSQWXe
        Y7KjIemWgcH99mZzhQyF9c4f+W6aBNGmrHxKIbjLBsDHbx2XebhwBThWZVYUBjpTzMVNJDFGe52CWqWmuRdYJL6A+3EtsbxBqDtTppFf5ChUART1g9yCnVKKqrJR9Ay80lULY5WkKGqYRWpVA8
        LA+XYTluxqiZO7i/j8bMAMp1gSBJoYngV6/pDUlJWQK1nMzU7anEeec6FvXtoPurjSaiNLXUKeszLywddiiIi5BbVSNq8huptHmLTceq2u2htKWV4/DO3Om9SYbfS+0gIv+r+EwCUuZuksqoek
        16M0yboy3MxaVFC2T5etPv51NujACj/r7GiYpdU1zUyE1coTnbytLt/yRq/Aa3d2wA09thgAAAAAElFTkSuQmCC'

# Load the image from stream and convert it from a bitmap to an image class.
$Web = [regex]::Replace($Web,'\s','')

# Create a memory stream from the base64 strings.
$WebStream = [System.IO.MemoryStream][System.Convert]::FromBase64String($Web)

# Create bitmap classes from the memory streams.
$WebBitmap = New-Object System.Drawing.Bitmap($WebStream)
$WebBitmapB = New-Object System.Drawing.Bitmap($WebBitmap, 10, 10)
#==============================================================================================================================================================================================
function OpenToolWebPage([string]$URL)
{
  Start-Process -FilePath $URL 
}
#==============================================================================================================================================================================================
# Toggles URL Icons
function TogglePathURL()
{
  $ImageMagickDL.Visible    = !$HidePathURLs
  $DDSUtilitiesDL.Visible   = !$HidePathURLs
  $IshiiToolDL.Visible      = !$HidePathURLs
  $OptiToolDL.Visible       = !$HidePathURLs
  $xBRZToolDL.Visible       = !$HidePathURLs
  $Waifu2xToolDL.Visible    = !$HidePathURLs
  $CompressonatorDL.Visible = !$HidePathURLs
  $TexConvToolDL.Visible    = !$HidePathURLs
  if ($HidePathURLs)
  {
    $ImageMagickLabel.Location    = New-Object System.Drawing.Size(10, 10)
    $TexConvToolLabel.Location    = New-Object System.Drawing.Size(10, 50)
    $CompressonatorLabel.Location = New-Object System.Drawing.Size(10, 90)
    $DDSUtilitiesLabel.Location   = New-Object System.Drawing.Size(10, 130)
    $IshiiPathLabel.Location      = New-Object System.Drawing.Size(10, 170)
    $OptiPathLabel.Location       = New-Object System.Drawing.Size(10, 210)
    $xBRZPathLabel.Location       = New-Object System.Drawing.Size(10, 250)
    $Waifu2xPathLabel.Location    = New-Object System.Drawing.Size(10, 290)
    return
  }
  $ImageMagickLabel.Location    = New-Object System.Drawing.Size(22, 10)
  $TexConvToolLabel.Location    = New-Object System.Drawing.Size(22, 50)
  $CompressonatorLabel.Location = New-Object System.Drawing.Size(22, 90)
  $DDSUtilitiesLabel.Location   = New-Object System.Drawing.Size(22, 130)
  $IshiiPathLabel.Location      = New-Object System.Drawing.Size(22, 170)
  $OptiPathLabel.Location       = New-Object System.Drawing.Size(22, 210)
  $xBRZPathLabel.Location       = New-Object System.Drawing.Size(22, 250)
  $Waifu2xPathLabel.Location    = New-Object System.Drawing.Size(22, 290)
}
#==============================================================================================================================================================================================
# Set the initial position for the tool labels based on whether or not the icons are visible.
if ($HidePathURLs) { $Tool_X = 10 } else { $Tool_X = 22 }
#==============================================================================================================================================================================================
$HideURLCheck = New-Object System.Windows.Forms.CheckBox
$HideURLCheck.Name = 'HidePathURLs'
$HideURLCheck.Size = New-Object System.Drawing.Size(160, 16)
$HideURLCheck.Location = New-Object System.Drawing.Size(610, 396)
$HideURLCheck.Checked = $HidePathURLs
$HideURLCheck.Text = ' Hide Weblink Icons'
$HideURLCheck.Add_CheckStateChanged({ GUI_UpdateCheckBoxState ; TogglePathURL })
$HideURLCheck.Visible = $false
$MainDialog.Controls.Add($HideURLCheck)
#==============================================================================================================================================================================================
$PathsGroup = New-Object System.Windows.Forms.GroupBox
$PathsGroup.Size = New-Object System.Drawing.Size(380, 379)
$PathsGroup.Location = New-Object System.Drawing.Size(400, 5)
$PathsGroup.Text = ''
$MainDialog.Controls.Add($PathsGroup)
#==============================================================================================================================================================================================
#  CTT GUI - ImageMagick Path
#==============================================================================================================================================================================================
$ImageMagickDL = New-Object System.Windows.Forms.Button
$ImageMagickDL.Size = New-Object System.Drawing.Size(10, 10)
$ImageMagickDL.Location = New-Object System.Drawing.Size(10, 12)
$ImageMagickDL.Visible = !$HidePathURLs
$ImageMagickDL.BackgroundImage = $WebBitmapB
$ImageMagickDL.FlatStyle = [Windows.Forms.FlatStyle]::Flat
$ImageMagickDL.FlatAppearance.BorderSize = 0
$ImageMagickDL.Add_Click({ OpenToolWebPage 'http://www.imagemagick.org/script/download.php#windows' })
$PathsGroup.Controls.Add($ImageMagickDL)
#==============================================================================================================================================================================================
$ImageMagickLabel = New-Object System.Windows.Forms.Label
$ImageMagickLabel.Size = New-Object System.Drawing.Size(140, 14)
$ImageMagickLabel.Location = New-Object System.Drawing.Size($Tool_X, 10)
$ImageMagickLabel.Text = 'ImageMagick:'
$ImageMagickTip = New-Object System.Windows.Forms.ToolTip
$ImageMagickTip.InitialDelay = $ToolTipDelay
$ImageMagickTip.AutoPopDelay = $ToolTipDuration
$ImageMagickTipString = 'The path to ImageMagick. The script by default will pull this path from the{0}'
$ImageMagickTipString += 'Windows registry, but a new path can be forced here. Do note that changing{0}'
$ImageMagickTipString += "this path will remove the script's ability to retrieve the registry value.{0}"
$ImageMagickTipString += "{0}"
$ImageMagickTipString += "Fully required by this script or it will not function."
$ImageMagickTipString = [String]::Format($ImageMagickTipString, [Environment]::NewLine)
$ImageMagickTip.SetToolTip($ImageMagickLabel, $ImageMagickTipString)
$PathsGroup.Controls.Add($ImageMagickLabel)
#----------------------------------------------------------------------------------------------------------------------------------------------
$ImageMagickTextBox = New-Object System.Windows.Forms.TextBox
$ImageMagickTextBox.Name = 'ImageMagick'
$ImageMagickTextBox.Size = New-Object System.Drawing.Size(328, 22)
$ImageMagickTextBox.Location = New-Object System.Drawing.Size(10, 25)
$ImageMagickTextBox.Text = $ImageMagick
$ImageMagickTextBox.AllowDrop = $true
$ImageMagickTextBox.Add_DragEnter({ $_.Effect = [Windows.Forms.DragDropEffects]::Copy })
$ImageMagickTextBox.Add_DragDrop({ GUI_UpdateFilePath_DragDrop -FileName @('magick.exe','convert.exe') })
$ImageMagickTextBox.Add_Leave({ GUI_UpdateFilePath_TextBox -FileName @('magick.exe','convert.exe') })
$PathsGroup.Controls.Add($ImageMagickTextBox)
#----------------------------------------------------------------------------------------------------------------------------------------------
$ImageMagickButton = New-Object System.Windows.Forms.Button
$ImageMagickButton.Name = 'ImageMagick'
$ImageMagickButton.Size = New-Object System.Drawing.Size(24, 22)
$ImageMagickButton.Location = New-Object System.Drawing.Size(346, 23)
$ImageMagickButton.Text = '...'
$ImageMagickButton.Add_Click({ GUI_UpdateFilePath_Button -TextBox $ImageMagickTextBox -Description @('ImageMagick v7','ImageMagick v6') -FileName @('magick.exe','convert.exe') })
$PathsGroup.Controls.Add($ImageMagickButton)
#==============================================================================================================================================================================================
#  CTT GUI - TexConv Path Selection
#==============================================================================================================================================================================================
$TexConvToolDL = New-Object System.Windows.Forms.Button
$TexConvToolDL.Size = New-Object System.Drawing.Size(10, 10)
$TexConvToolDL.Location = New-Object System.Drawing.Size(10, 52)
$TexConvToolDL.Visible = !$HidePathURLs
$TexConvToolDL.BackgroundImage = $WebBitmapB
$TexConvToolDL.FlatStyle = [Windows.Forms.FlatStyle]::Flat
$TexConvToolDL.FlatAppearance.BorderSize = 0
$TexConvToolDL.Add_Click({ OpenToolWebPage 'https://github.com/Microsoft/DirectXTex/releases' })
$PathsGroup.Controls.Add($TexConvToolDL)
#----------------------------------------------------------------------------------------------------------------------------------------------
$TexConvToolLabel = New-Object System.Windows.Forms.Label
$TexConvToolLabel.Size = New-Object System.Drawing.Size(140, 14)
$TexConvToolLabel.Location = New-Object System.Drawing.Size($Tool_X, 50)
$TexConvToolLabel.Text = 'DirectXTex TexConv:'
$TexConvToolTip = New-Object System.Windows.Forms.ToolTip
$TexConvToolTip.InitialDelay = $ToolTipDelay
$TexConvToolTip.AutoPopDelay = $ToolTipDuration
$TexConvToolTipString = 'Required by this script to create BC7 textures, or an alternative to DDS Utilities{0}'
$TexConvToolTipString += 'for DXT1/5. This program is faster than the other DDS creators, but it creates{0}'
$TexConvToolTipString += 'lesser quality DXT1/5 textures than both DDS Utilities and Compressonator.'
$TexConvToolTipString = [String]::Format($TexConvToolTipString, [Environment]::NewLine)
$TexConvToolTip.SetToolTip($TexConvToolLabel, $TexConvToolTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$TexConvToolTextBox = New-Object System.Windows.Forms.TextBox
$TexConvToolTextBox.Name = 'TexConvTool'
$TexConvToolTextBox.Size = New-Object System.Drawing.Size(328, 22)
$TexConvToolTextBox.Location = New-Object System.Drawing.Size(10, 65)
$TexConvToolTextBox.Text = $TexConvTool
$TexConvToolTextBox.AllowDrop = $true
$TexConvToolTextBox.Add_DragEnter({ $_.Effect = [Windows.Forms.DragDropEffects]::Copy })
$TexConvToolTextBox.Add_DragDrop({ GUI_UpdateFilePath_DragDrop -FileName 'texconv.exe' })
$TexConvToolTextBox.Add_Leave({ GUI_UpdateFilePath_TextBox -FileName 'texconv.exe' })
#----------------------------------------------------------------------------------------------------------------------------------------------
$TexConvToolButton = New-Object System.Windows.Forms.Button
$TexConvToolButton.Name = 'TexConvTool'
$TexConvToolButton.Size = New-Object System.Drawing.Size(24, 22)
$TexConvToolButton.Location = New-Object System.Drawing.Size(346, 63)
$TexConvToolButton.Text = '...'
$TexConvToolButton.Add_Click({ GUI_UpdateFilePath_Button -TextBox $TexConvToolTextBox -Description 'TexConv' -FileName 'texconv.exe' })
#----------------------------------------------------------------------------------------------------------------------------------------------
$PathsGroup.Controls.Add($TexConvToolLabel)
$PathsGroup.Controls.Add($TexConvToolTextBox)
$PathsGroup.Controls.Add($TexConvToolButton)
#==============================================================================================================================================================================================
#  CTT GUI - AMD Compressonator
#==============================================================================================================================================================================================
$CompressonatorDL = New-Object System.Windows.Forms.Button
$CompressonatorDL.Size = New-Object System.Drawing.Size(10, 10)
$CompressonatorDL.Location = New-Object System.Drawing.Size(10, 92)
$CompressonatorDL.Visible = !$HidePathURLs
$CompressonatorDL.BackgroundImage = $WebBitmapB
$CompressonatorDL.FlatStyle = [Windows.Forms.FlatStyle]::Flat
$CompressonatorDL.FlatAppearance.BorderSize = 0
$CompressonatorDL.Add_Click({ OpenToolWebPage 'https://github.com/GPUOpen-Tools/Compressonator/releases' })
$PathsGroup.Controls.Add($CompressonatorDL)
#----------------------------------------------------------------------------------------------------------------------------------------------
$CompressonatorLabel = New-Object System.Windows.Forms.Label
$CompressonatorLabel.Size = New-Object System.Drawing.Size(140, 14)
$CompressonatorLabel.Location = New-Object System.Drawing.Size($Tool_X, 90)
$CompressonatorLabel.Text = 'AMD Compressonator:'
$CompressonatorTip = New-Object System.Windows.Forms.ToolTip
$CompressonatorTip.InitialDelay = $ToolTipDelay
$CompressonatorTip.AutoPopDelay = $ToolTipDuration
$CompressonatorTipString = 'The path to Compressonator. The script by default will pull this path from{0}'
$CompressonatorTipString += 'the Windows registry, but the path can be forced here. Note that changing{0}'
$CompressonatorTipString += "this path will remove the script's ability to retrieve the registry value.{0}"
$CompressonatorTipString = [String]::Format($CompressonatorTipString, [Environment]::NewLine)
$CompressonatorTip.SetToolTip($CompressonatorLabel, $CompressonatorTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$CompressonatorTextBox = New-Object System.Windows.Forms.TextBox
$CompressonatorTextBox.Name = 'Compressonator'
$CompressonatorTextBox.Size = New-Object System.Drawing.Size(328, 22)
$CompressonatorTextBox.Location = New-Object System.Drawing.Size(10, 105)
$CompressonatorTextBox.Text = $Compressonator
$CompressonatorTextBox.AllowDrop = $true
$CompressonatorTextBox.Add_DragEnter({ $_.Effect = [Windows.Forms.DragDropEffects]::Copy })
$CompressonatorTextBox.Add_DragDrop({ GUI_UpdateFilePath_DragDrop -FileName 'CompressonatorCLI.exe' })
$CompressonatorTextBox.Add_Leave({ GUI_UpdateFilePath_TextBox -FileName 'CompressonatorCLI.exe' })
#----------------------------------------------------------------------------------------------------------------------------------------------
$CompressonatorButton = New-Object System.Windows.Forms.Button
$CompressonatorButton.Name = 'Compressonator'
$CompressonatorButton.Size = New-Object System.Drawing.Size(24, 22)
$CompressonatorButton.Location = New-Object System.Drawing.Size(346, 103)
$CompressonatorButton.Text = '...'
$CompressonatorButton.Add_Click({ GUI_UpdateFilePath_Button -TextBox $CompressonatorTextBox -Description 'Compressonator' -FileName 'CompressonatorCLI.exe' })
#----------------------------------------------------------------------------------------------------------------------------------------------
$PathsGroup.Controls.Add($CompressonatorLabel)
$PathsGroup.Controls.Add($CompressonatorTextBox)
$PathsGroup.Controls.Add($CompressonatorButton)
#==============================================================================================================================================================================================
#  CTT GUI - DDS Utilities Path
#==============================================================================================================================================================================================
$DDSUtilitiesDL = New-Object System.Windows.Forms.Button
$DDSUtilitiesDL.Size = New-Object System.Drawing.Size(10, 10)
$DDSUtilitiesDL.Location = New-Object System.Drawing.Size(10, 132)
$DDSUtilitiesDL.Visible = !$HidePathURLs
$DDSUtilitiesDL.BackgroundImage = $WebBitmapB
$DDSUtilitiesDL.FlatStyle = [Windows.Forms.FlatStyle]::Flat
$DDSUtilitiesDL.FlatAppearance.BorderSize = 0
$DDSUtilitiesDL.Add_Click({ OpenToolWebPage 'https://developer.nvidia.com/gameworksdownload#?dn=dds-utilities-8-31' })
$PathsGroup.Controls.Add($DDSUtilitiesDL)
#----------------------------------------------------------------------------------------------------------------------------------------------
$DDSUtilitiesLabel = New-Object System.Windows.Forms.Label
$DDSUtilitiesLabel.Size = New-Object System.Drawing.Size(140, 14)
$DDSUtilitiesLabel.Location = New-Object System.Drawing.Size($Tool_X, 130)
$DDSUtilitiesLabel.Text = 'Nvidia DDS Utilities:'
$DDSUtilitiesTip = New-Object System.Windows.Forms.ToolTip
$DDSUtilitiesTip.InitialDelay = $ToolTipDelay
$DDSUtilitiesTip.AutoPopDelay = $ToolTipDuration
$DDSUtilitiesTipString = 'The path to DDS Utilities. The script by default will pull this path from the{0}'
$DDSUtilitiesTipString += 'Windows registry, but the path can be forced here. Note that changing this{0}'
$DDSUtilitiesTipString += "path will remove the script's ability to retrieve the registry value."
$DDSUtilitiesTipString = [String]::Format($DDSUtilitiesTipString, [Environment]::NewLine)
$DDSUtilitiesTip.SetToolTip($DDSUtilitiesLabel, $DDSUtilitiesTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$DDSUtilitiesTextBox = New-Object System.Windows.Forms.TextBox
$DDSUtilitiesTextBox.Name = 'DDSUtilities'
$DDSUtilitiesTextBox.Size = New-Object System.Drawing.Size(328, 22)
$DDSUtilitiesTextBox.Location = New-Object System.Drawing.Size(10, 145)
$DDSUtilitiesTextBox.Text = $DDSUtilities
$DDSUtilitiesTextBox.AllowDrop = $true
$DDSUtilitiesTextBox.Add_DragEnter({$_.Effect = [Windows.Forms.DragDropEffects]::Copy})
$DDSUtilitiesTextBox.Add_DragDrop({ GUI_UpdateFilePath_DragDrop -FileName 'nvdxt.exe' })
$DDSUtilitiesTextBox.Add_Leave({ GUI_UpdateFilePath_TextBox -FileName 'nvdxt.exe' })
#----------------------------------------------------------------------------------------------------------------------------------------------
$DDSUtilitiesButton = New-Object System.Windows.Forms.Button
$DDSUtilitiesButton.Name = 'DDSUtilities'
$DDSUtilitiesButton.Size = New-Object System.Drawing.Size(24, 22)
$DDSUtilitiesButton.Location = New-Object System.Drawing.Size(346, 143)
$DDSUtilitiesButton.Text = '...'
$DDSUtilitiesButton.Add_Click({ GUI_UpdateFilePath_Button -TextBox $DDSUtilitiesTextBox -Description 'DDS Utilities' -FileName 'nvdxt.exe' })
#----------------------------------------------------------------------------------------------------------------------------------------------
$PathsGroup.Controls.Add($DDSUtilitiesLabel)
$PathsGroup.Controls.Add($DDSUtilitiesTextBox)
$PathsGroup.Controls.Add($DDSUtilitiesButton)
#==============================================================================================================================================================================================
#  CTT GUI - Ishiiruka Tool Path Selection
#==============================================================================================================================================================================================
$IshiiToolDL = New-Object System.Windows.Forms.Button
$IshiiToolDL.Size = New-Object System.Drawing.Size(10, 10)
$IshiiToolDL.Location = New-Object System.Drawing.Size(10, 172)
$IshiiToolDL.Visible = !$HidePathURLs
$IshiiToolDL.BackgroundImage = $WebBitmapB
$IshiiToolDL.FlatStyle = [Windows.Forms.FlatStyle]::Flat
$IshiiToolDL.FlatAppearance.BorderSize = 0
$IshiiToolDL.Add_Click({ OpenToolWebPage 'https://forums.dolphin-emu.org/Thread-unofficial-ishiiruka-dolphin-custom-version?pid=297815#pid297815' })
$PathsGroup.Controls.Add($IshiiToolDL)
#----------------------------------------------------------------------------------------------------------------------------------------------
$IshiiPathLabel = New-Object System.Windows.Forms.Label
$IshiiPathLabel.Size = New-Object System.Drawing.Size(140, 14)
$IshiiPathLabel.Location = New-Object System.Drawing.Size($Tool_X, 170)
$IshiiPathLabel.Text = 'Ishiiruka Tool:'
$IshiiPathTip = New-Object System.Windows.Forms.ToolTip
$IshiiPathTip.InitialDelay = $ToolTipDelay
$IshiiPathTip.AutoPopDelay = $ToolTipDuration
$IshiiPathTipString = 'The path to the texture encoder by Tino that combines bump/spec/lum/nrm{0}'
$IshiiPathTipString += 'textures into a material map. This tool is also required to work with already{0}'
$IshiiPathTipString += 'combined material maps (meaning the "mat" file created from the previously{0}'
$IshiiPathTipString += 'mentioned textures). If this tool is not found when material maps are found{0}'
$IshiiPathTipString += 'then these textures will not be converted.{0}'
$IshiiPathTipString += '{0}'
$IshiiPathTipString += 'Required whenever a pack contains material maps or material textures.'
$IshiiPathTipString = [String]::Format($IshiiPathTipString, [Environment]::NewLine)
$IshiiPathTip.SetToolTip($IshiiPathLabel, $IshiiPathTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$IshiiPathTextBoxA = New-Object System.Windows.Forms.TextBox
$IshiiPathTextBoxA.Name = 'IshiirukaTool'
$IshiiPathTextBoxA.Size = New-Object System.Drawing.Size(328, 22)
$IshiiPathTextBoxA.Location = New-Object System.Drawing.Size(10, 185)
$IshiiPathTextBoxA.Text = $IshiirukaTool
$IshiiPathTextBoxA.AllowDrop = $true
$IshiiPathTextBoxA.Add_DragEnter({ $_.Effect = [Windows.Forms.DragDropEffects]::Copy })
$IshiiPathTextBoxA.Add_DragDrop({ GUI_UpdateFilePath_DragDrop -FileName 'TextureEncoder.exe'})
$IshiiPathTextBoxA.Add_Leave({ GUI_UpdateFilePath_TextBox -FileName 'TextureEncoder.exe' })
#----------------------------------------------------------------------------------------------------------------------------------------------
$IshiiPathButton = New-Object System.Windows.Forms.Button
$IshiiPathButton.Name = 'IshiirukaTool'
$IshiiPathButton.Size = New-Object System.Drawing.Size(24, 22)
$IshiiPathButton.Location = New-Object System.Drawing.Size(346, 183)
$IshiiPathButton.Text = '...'
$IshiiPathButton.Add_Click({ GUI_UpdateFilePath_Button -TextBox $IshiiPathTextBoxA -Description 'Ishiiruka Tool' -FileName 'TextureEncoder.exe' })
#----------------------------------------------------------------------------------------------------------------------------------------------
$PathsGroup.Controls.Add($IshiiPathLabel)
$PathsGroup.Controls.Add($IshiiPathTextBoxA)
$PathsGroup.Controls.Add($IshiiPathButton)
#==============================================================================================================================================================================================
#  CTT GUI - OptiPNG Path Selection
#==============================================================================================================================================================================================
$OptiToolDL = New-Object System.Windows.Forms.Button
$OptiToolDL.Size = New-Object System.Drawing.Size(10, 10)
$OptiToolDL.Location = New-Object System.Drawing.Size(10, 212)
$OptiToolDL.Visible = !$HidePathURLs
$OptiToolDL.BackgroundImage = $WebBitmapB
$OptiToolDL.FlatStyle = [Windows.Forms.FlatStyle]::Flat
$OptiToolDL.FlatAppearance.BorderSize = 0
$OptiToolDL.Add_Click({ OpenToolWebPage 'http://optipng.sourceforge.net/' })
$PathsGroup.Controls.Add($OptiToolDL)
#----------------------------------------------------------------------------------------------------------------------------------------------
$OptiPathLabel = New-Object System.Windows.Forms.Label
$OptiPathLabel.Size = New-Object System.Drawing.Size(140, 14)
$OptiPathLabel.Location = New-Object System.Drawing.Size($Tool_X, 210)
$OptiPathLabel.Text = 'OptiPNG:'
$OptiPathTip = New-Object System.Windows.Forms.ToolTip
$OptiPathTip.InitialDelay = $ToolTipDelay
$OptiPathTip.AutoPopDelay = $ToolTipDuration
$OptiPathTipString = 'This is the path to OptiPNG which is completely optional. OptiPNG {0}'
$OptiPathTipString += 'attempts to recompress PNG files in order to reduce their file size by{0}'
$OptiPathTipString += 'running a number of different "tests" and going with the best results.{0}'
$OptiPathTipString += '{0}'
$OptiPathTipString += 'Required for "Optimize PNG Textures With OptiPNG".'
$OptiPathTipString = [String]::Format($OptiPathTipString, [Environment]::NewLine)
$OptiPathTip.SetToolTip($OptiPathLabel, $OptiPathTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$OptiPathTextBoxA = New-Object System.Windows.Forms.TextBox
$OptiPathTextBoxA.Name = 'OptiPNGPath'
$OptiPathTextBoxA.Size = New-Object System.Drawing.Size(328, 22)
$OptiPathTextBoxA.Location = New-Object System.Drawing.Size(10, 225)
$OptiPathTextBoxA.Text = $OptiPNGPath
$OptiPathTextBoxA.AllowDrop = $true
$OptiPathTextBoxA.Add_DragEnter({ $_.Effect = [Windows.Forms.DragDropEffects]::Copy })
$OptiPathTextBoxA.Add_DragDrop({ GUI_UpdateFilePath_DragDrop -FileName 'optipng.exe' })
$OptiPathTextBoxA.Add_Leave({ GUI_UpdateFilePath_TextBox -FileName 'optipng.exe' })
#----------------------------------------------------------------------------------------------------------------------------------------------
$OptiPathButton = New-Object System.Windows.Forms.Button
$OptiPathButton.Name = 'OptiPNGPath'
$OptiPathButton.Size = New-Object System.Drawing.Size(24, 22)
$OptiPathButton.Location = New-Object System.Drawing.Size(346, 223)
$OptiPathButton.Text = '...'
$OptiPathButton.Add_Click({ GUI_UpdateFilePath_Button -TextBox $OptiPathTextBoxA -Description 'OptiPNG' -FileName 'optipng.exe' })
#----------------------------------------------------------------------------------------------------------------------------------------------
$PathsGroup.Controls.Add($OptiPathLabel)
$PathsGroup.Controls.Add($OptiPathTextBoxA)
$PathsGroup.Controls.Add($OptiPathButton)
#==============================================================================================================================================================================================
#  CTT GUI - xBRZ Path Selection
#==============================================================================================================================================================================================
$xBRZToolDL = New-Object System.Windows.Forms.Button
$xBRZToolDL.Size = New-Object System.Drawing.Size(10, 10)
$xBRZToolDL.Location = New-Object System.Drawing.Size(10, 252)
$xBRZToolDL.Visible = !$HidePathURLs
$xBRZToolDL.BackgroundImage = $WebBitmapB
$xBRZToolDL.FlatStyle = [Windows.Forms.FlatStyle]::Flat
$xBRZToolDL.FlatAppearance.BorderSize = 0
$xBRZToolDL.Add_Click({ OpenToolWebPage 'https://sourceforge.net/projects/xbrz/' })
$PathsGroup.Controls.Add($xBRZToolDL)
#----------------------------------------------------------------------------------------------------------------------------------------------
$xBRZPathLabel = New-Object System.Windows.Forms.Label
$xBRZPathLabel.Size = New-Object System.Drawing.Size(140, 14)
$xBRZPathLabel.Location = New-Object System.Drawing.Size($Tool_X, 250)
$xBRZPathLabel.Text = 'xBRZ ScalerTest:'
$xBRZPathTip = New-Object System.Windows.Forms.ToolTip
$xBRZPathTip.InitialDelay = $ToolTipDelay
$xBRZPathTip.AutoPopDelay = $ToolTipDuration
$xBRZPathTipString = 'This tool makes it possible to apply the xBRZ upscaling filter to a folder{0}'
$xBRZPathTipString += 'full of textures. This tool is only used when applying the xBRZ filter, all{0}'
$xBRZPathTipString += 'other filters are applied to textures using ImageMagick.{0}'
$xBRZPathTipString += '{0}'
$xBRZPathTipString += 'Required to use xBRZ in "Apply Upscaling Filter to All Textures".'
$xBRZPathTipString = [String]::Format($xBRZPathTipString, [Environment]::NewLine)
$xBRZPathTip.SetToolTip($xBRZPathLabel, $xBRZPathTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$xBRZPathTextBox = New-Object System.Windows.Forms.TextBox
$xBRZPathTextBox.Name = 'ScalerTestPath'
$xBRZPathTextBox.Size = New-Object System.Drawing.Size(328, 22)
$xBRZPathTextBox.Location = New-Object System.Drawing.Size(10, 265)
$xBRZPathTextBox.Text = $ScalerTestPath
$xBRZPathTextBox.AllowDrop = $true
$xBRZPathTextBox.Add_DragEnter({ $_.Effect = [Windows.Forms.DragDropEffects]::Copy })
$xBRZPathTextBox.Add_DragDrop({ GUI_UpdateFilePath_DragDrop -FileName 'ScalerTest.exe' })
$xBRZPathTextBox.Add_Leave({ GUI_UpdateFilePath_TextBox -FileName 'ScalerTest.exe' })
#----------------------------------------------------------------------------------------------------------------------------------------------
$xBRZPathButton = New-Object System.Windows.Forms.Button
$xBRZPathButton.Name = 'ScalerTestPath'
$xBRZPathButton.Size = New-Object System.Drawing.Size(24, 22)
$xBRZPathButton.Location = New-Object System.Drawing.Size(346, 263)
$xBRZPathButton.Text = '...'
$xBRZPathButton.Add_Click({ GUI_UpdateFilePath_Button -TextBox $xBRZPathTextBox -Description 'xBRZ' -FileName 'ScalerTest.exe' })
#----------------------------------------------------------------------------------------------------------------------------------------------
$PathsGroup.Controls.Add($xBRZPathLabel)
$PathsGroup.Controls.Add($xBRZPathTextBox)
$PathsGroup.Controls.Add($xBRZPathButton)
#==============================================================================================================================================================================================
#  CTT GUI - Waifu2x Path Selection
#==============================================================================================================================================================================================
$Waifu2xToolDL = New-Object System.Windows.Forms.Button
$Waifu2xToolDL.Size = New-Object System.Drawing.Size(10, 10)
$Waifu2xToolDL.Location = New-Object System.Drawing.Size(10, 292)
$Waifu2xToolDL.Visible = !$HidePathURLs
$Waifu2xToolDL.BackgroundImage = $WebBitmapB
$Waifu2xToolDL.FlatStyle = [Windows.Forms.FlatStyle]::Flat
$Waifu2xToolDL.FlatAppearance.BorderSize = 0
$Waifu2xToolDL.Add_Click({ OpenToolWebPage 'https://github.com/lltcggie/waifu2x-caffe/releases' })
$PathsGroup.Controls.Add($Waifu2xToolDL)
#----------------------------------------------------------------------------------------------------------------------------------------------
$Waifu2xPathLabel = New-Object System.Windows.Forms.Label
$Waifu2xPathLabel.Size = New-Object System.Drawing.Size(140, 14)
$Waifu2xPathLabel.Location = New-Object System.Drawing.Size($Tool_X, 290)
$Waifu2xPathLabel.Text = 'Waifu2x Caffe/CPP:'
$Waifu2xPathTip = New-Object System.Windows.Forms.ToolTip
$Waifu2xPathTip.InitialDelay = $ToolTipDelay
$Waifu2xPathTip.AutoPopDelay = $ToolTipDuration
$Waifu2xPathTipString = 'Allows upscaling textures with the waifu2x filter. There are two popular{0}'
$Waifu2xPathTipString += 'waifu2x applications for Windows, one is Waifu2x-Caffe, and the other is{0}'
$Waifu2xPathTipString += 'Waifu2x-CPP. Both versions of waifu2x are compatible with this script.{0}'
$Waifu2xPathTipString += '{0}'
$Waifu2xPathTipString += 'Required to use waifu2x in "Apply Upscaling Filter to All Textures".'
$Waifu2xPathTipString = [String]::Format($Waifu2xPathTipString, [Environment]::NewLine)
$Waifu2xPathTip.SetToolTip($Waifu2xPathLabel, $Waifu2xPathTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$Waifu2xPathTextBox = New-Object System.Windows.Forms.TextBox
$Waifu2xPathTextBox.Name = 'Waifu2xPath'
$Waifu2xPathTextBox.Size = New-Object System.Drawing.Size(328, 22)
$Waifu2xPathTextBox.Location = New-Object System.Drawing.Size(10, 305)
$Waifu2xPathTextBox.Text = $Waifu2xPath
$Waifu2xPathTextBox.AllowDrop = $true
$Waifu2xPathTextBox.Add_DragEnter({ $_.Effect = [Windows.Forms.DragDropEffects]::Copy })
$Waifu2xPathTextBox.Add_DragDrop({ GUI_UpdateFilePath_DragDrop -FileName @('waifu2x-caffe-cui.exe','waifu2x-converter_x64.exe') })
$Waifu2xPathTextBox.Add_Leave({ GUI_UpdateFilePath_TextBox -FileName @('waifu2x-caffe-cui.exe','waifu2x-converter_x64.exe') })
#----------------------------------------------------------------------------------------------------------------------------------------------
$Waifu2xPathButton = New-Object System.Windows.Forms.Button
$Waifu2xPathButton.Name = 'Waifu2xPath'
$Waifu2xPathButton.Size = New-Object System.Drawing.Size(24, 22)
$Waifu2xPathButton.Location = New-Object System.Drawing.Size(346, 303)
$Waifu2xPathButton.Text = '...'
$Waifu2xPathButton.Add_Click({ GUI_UpdateFilePath_Button -TextBox $Waifu2xPathTextBox -Description @('Caffe','CPP') -FileName @('waifu2x-caffe-cui.exe','waifu2x-converter_x64.exe') })
#----------------------------------------------------------------------------------------------------------------------------------------------
$PathsGroup.Controls.Add($Waifu2xPathLabel)
$PathsGroup.Controls.Add($Waifu2xPathTextBox)
$PathsGroup.Controls.Add($Waifu2xPathButton)
#==============================================================================================================================================================================================
#  CTT GUI: UPDATE TEMP FOLDER PATH
#==============================================================================================================================================================================================
function GUI_UpdateTempFolderPath_Finish($UpdatePath)
{
  # Users might think it's cool to put a final slash at the end. It's not cool.
  if ($UpdatePath.Substring(($UpdatePath.Length - 1), 1) -eq '\')
  {
    # If a slash was found, keep everything but the slash.
    $UpdatePath = $UpdatePath.Substring(0, ($UpdatePath.Length - 1))
  }
  # Update the temp folder with the new value.
  $global:TempFolder = $UpdatePath + '\CTT-PS_Temp'

  # Update the temp folder when the script is closed.
  $global:UpdateTempFolder = $true

  # Update the text box with the new path.
  $TempPathTextBox.Text = $TempFolder
}
#==============================================================================================================================================================================================
#  Updates the temporary folder path with a drag and drop.

function GUI_UpdateTempFolderPath_DragDrop()
{
  # Make sure there is data present before actually doing anything.
  if ($_.Data.GetDataPresent([Windows.Forms.DataFormats]::FileDrop))
  {
    # Create a list of the data to select the first item from the list.
    $DroppedPath = [string]($_.Data.GetData([Windows.Forms.DataFormats]::FileDrop))

    # Make sure the path is a folder and prevent the path from having any form of '~' in it.
    if ((Test-Path -LiteralPath $DroppedPath -PathType Container))
    {
      # Finish setting the TempFolder.
      GUI_UpdateTempFolderPath_Finish -UpdatePath $DroppedPath
    }
  }
}
#==============================================================================================================================================================================================
#  Updates the temporary folder path with the button.

function GUI_UpdateTempFolderPath_Button()
{
  # Display an "Open Folder" menu to get the path.
  $SelectedPath = Get-Folder -Message 'Select a new path for where Custom Texture Tool PS will create temporary files. Note that this path and all files it contains are destroyed every time the script is ran!'

  # Check to see if a folder was selected from the Open menu and test if that path exists.
  if (($SelectedPath -ne '') -and (TestPath -LiteralPath $SelectedPath))
  {
    # Finish setting the TempFolder.
    GUI_UpdateTempFolderPath_Finish -UpdatePath $SelectedPath
  }
}
#==============================================================================================================================================================================================
#  Updates the temporary folder path when modifying the text box value.

function GUI_UpdateTempFolderPath_TextBox()
{
  # Get the current value of the MasterPath.
  $CurrentPath = Get-Variable -Name $this.Name -ValueOnly
  $EnteredText = $this.Text

  # To avoid updating constantly, check to see if the text actually changed and that the path actually exists.
  if (($EnteredText -ne $CurrentPath) -and ($EnteredText -ne '') -and (TestPath -LiteralPath $EnteredText))
  {
    # Finish setting the TempFolder.
    GUI_UpdateTempFolderPath_Finish -UpdatePath $EnteredText

    # We're done here, get out.
    return
  }
  # Set the textbox text back to the MasterPath.
  $this.Text = $CurrentPath
}
#==============================================================================================================================================================================================
#  CTT GUI - Temp Path Selection
#==============================================================================================================================================================================================
$TempPathLabel = New-Object System.Windows.Forms.Label
$TempPathLabel.Size = New-Object System.Drawing.Size(140, 14)
$TempPathLabel.Location = New-Object System.Drawing.Size(10, 330)
$TempPathLabel.Text = 'Temporary Folder:'
$TempPathTip = New-Object System.Windows.Forms.ToolTip
$TempPathTip.InitialDelay = $ToolTipDelay
$TempPathTip.AutoPopDelay = $ToolTipDuration
$TempPathTipString = 'When temporary textures need to be generated, this is the folder they will{0}'
$TempPathTipString += 'be created. Temporary files will always be deleted when they are no longer{0}'
$TempPathTipString += 'needed, and are wiped out on every execution/completion of one of the scripts{0}'
$TempPathTipString += 'options. The default location is "\AppData\Local\Temp\CTT-PS_Temp", but can{0}'
$TempPathTipString += 'be changed to anywhere. This is useful if a user has trouble creating content{0}'
$TempPathTipString += 'in the AppData folder, or just simply wants to relocate the Temp folder.'
$TempPathTipString = [String]::Format($TempPathTipString, [Environment]::NewLine)
$TempPathTip.SetToolTip($TempPathLabel, $TempPathTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$TempPathTextBox = New-Object System.Windows.Forms.TextBox
$TempPathTextBox.Name = 'TempFolder'
$TempPathTextBox.Size = New-Object System.Drawing.Size(328, 22)
$TempPathTextBox.Location = New-Object System.Drawing.Size(10, 345)
$TempPathTextBox.Text = $TempFolder
$TempPathTextBox.AllowDrop = $true
$TempPathTextBox.Add_DragEnter({$_.Effect = [Windows.Forms.DragDropEffects]::Copy})
$TempPathTextBox.Add_DragDrop({ GUI_UpdateTempFolderPath_DragDrop })
$TempPathTextBox.Add_Leave({ GUI_UpdateTempFolderPath_TextBox })
#----------------------------------------------------------------------------------------------------------------------------------------------
$TempPathButton = New-Object System.Windows.Forms.Button
$TempPathButton.Name = 'TempFolder'
$TempPathButton.Size = New-Object System.Drawing.Size(24, 22)
$TempPathButton.Location = New-Object System.Drawing.Size(346, 343)
$TempPathButton.Text = '...'
$TempPathButton.Add_Click({ GUI_UpdateTempFolderPath_Button })
#----------------------------------------------------------------------------------------------------------------------------------------------
$PathsGroup.Controls.Add($TempPathLabel)
$PathsGroup.Controls.Add($TempPathTextBox)
$PathsGroup.Controls.Add($TempPathButton)
#==============================================================================================================================================================================================
# CTT GUI - Texture Options
#==============================================================================================================================================================================================
$OptionsGroup = New-Object System.Windows.Forms.GroupBox
$OptionsGroup.Size = New-Object System.Drawing.Size(380, 88)
$OptionsGroup.Location = New-Object System.Drawing.Size(400, 5)
$OptionsGroup.Text = ' Texture Options '
$MainDialog.Controls.Add($OptionsGroup)
$OptionsGroupGroupTip = New-Object System.Windows.Forms.ToolTip
$OptionsGroupGroupTip.InitialDelay = $ToolTipDelay
$OptionsGroupGroupTip.AutoPopDelay = $ToolTipDuration
$OptionsGroupGroupTipString = 'These options affect the way the script generates textures.'
$OptionsGroupGroupTip.SetToolTip($OptionsGroup, $OptionsGroupGroupTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
function ToggleNonDolphinMipMap()
{
  # Allow all Images must be enabled to use the DDS Internal MipMap option for Non-Dolphin textures.
  if (!$this.Checked)
  {
    $DDSNonDolphinMipMapCheck.Checked = $false
  }
  $DDSNonDolphinMipMapCheck.Enabled = $this.Checked
}
#----------------------------------------------------------------------------------------------------------------------------------------------
# Allow All Images
$AllowAllImagesCheck = New-Object System.Windows.Forms.CheckBox
$AllowAllImagesCheck.Name = 'AllowAllImages'
$AllowAllImagesCheck.Size = New-Object System.Drawing.Size(170, 18)
$AllowAllImagesCheck.Location = New-Object System.Drawing.Size(10, 16)
$AllowAllImagesCheck.Checked = $AllowAllImages
$AllowAllImagesCheck.Text = ' Allow All Images   ----------->'
$AllowAllImagesCheck.Add_CheckStateChanged({ GUI_UpdateCheckBoxState ; ToggleNonDolphinMipMap })
$OptionsGroup.Controls.Add($AllowAllImagesCheck)
$AllowAllTip = New-Object System.Windows.Forms.ToolTip
$AllowAllTip.InitialDelay = $ToolTipDelay
$AllowAllTip.AutoPopDelay = $ToolTipDuration
$AllowAllTipString = 'Allows any PNG/DDS/JPG image to pass validation by ignoring the{0}'
$AllowAllTipString += '"tex1" prefix used by Dolphin textures. This works well enough that{0}'
$AllowAllTipString += 'most options can be used to convert, scale, or filter images. Images{0}'
$AllowAllTipString += 'will not be created with mipmaps unless at least a single mipmap is{0}'
$AllowAllTipString += 'included, or the option "Force Create MipMaps" is enabled.{0}'
$AllowAllTipString += '{0}'
$AllowAllTipString += 'To create these images with mipmaps (or custom mipmaps), supply{0}'
$AllowAllTipString += 'a mipmap chain using individual images, with each image containing{0}'
$AllowAllTipString += 'a "_mip#" suffix (ex: image.png, image_mip1.png, image_mip2.png).{0}'
$AllowAllTipString += 'Including even a single mipmap generates all mipmap levels.{0}'
$AllowAllTipString += '{0}'
$AllowAllTipString += 'This option should not be used with Dolphin texture packs. It exists{0}'
$AllowAllTipString += 'solely to allow this script to work with PC game texture packs.'
$AllowAllTipString = [String]::Format($AllowAllTipString, [Environment]::NewLine)
$AllowAllTip.SetToolTip($AllowAllImagesCheck, $AllowAllTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Force DDS Internal MipMaps for Non-Dolphin Images
$DDSNonDolphinMipMapCheck = New-Object System.Windows.Forms.CheckBox
$DDSNonDolphinMipMapCheck.Name = 'ForceCreateMipMaps'
$DDSNonDolphinMipMapCheck.Size = New-Object System.Drawing.Size(180, 18)
$DDSNonDolphinMipMapCheck.Location = New-Object System.Drawing.Size(185, 16)
$DDSNonDolphinMipMapCheck.Checked = $ForceCreateMipMaps
$DDSNonDolphinMipMapCheck.Enabled = $AllowAllImages
$DDSNonDolphinMipMapCheck.Text = ' Force Create MipMaps'
$DDSNonDolphinMipMapCheck.Add_CheckStateChanged({ GUI_UpdateCheckBoxState})
$OptionsGroup.Controls.Add($DDSNonDolphinMipMapCheck)
$DDSNonDolphinMipMapTip = New-Object System.Windows.Forms.ToolTip
$DDSNonDolphinMipMapTip.InitialDelay = $ToolTipDelay
$DDSNonDolphinMipMapTip.AutoPopDelay = $ToolTipDuration
$DDSNonDolphinMipMapTipString = 'This option does not affect Dolphin (tex1) textures, it only{0}'
$DDSNonDolphinMipMapTipString += 'affects images that pass validation with "Allow All Images".{0}'
$DDSNonDolphinMipMapTipString += 'Use the MipMap Options found below for Dolphin textures,{0}'
$DDSNonDolphinMipMapTipString += 'but keep in mind they are not limited to Dolphin textures.{0}'
$DDSNonDolphinMipMapTipString += '{0}'
$DDSNonDolphinMipMapTipString += 'When this option is enabled, it will force mipmaps when{0}'
$DDSNonDolphinMipMapTipString += 'creating non-Dolphin images using any Standard/Advanced{0}'
$DDSNonDolphinMipMapTipString += 'option that creates images. This option will override using{0}'
$DDSNonDolphinMipMapTipString += 'custom mipmaps if they are provided with the texture.'
$DDSNonDolphinMipMapTipString = [String]::Format($DDSNonDolphinMipMapTipString, [Environment]::NewLine)
$DDSNonDolphinMipMapTip.SetToolTip($DDSNonDolphinMipMapCheck, $DDSNonDolphinMipMapTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Adds the option "Add Tool..." to the menu if all tools are not already added.
function CheckAddDDSToolOption()
{
  # Set up the series of checks in a variable array.
  $Conditions = New-Object bool[] 3

  # Go through and store the result of each check into the array.
  $Conditions[0] = $DDSCreatorCombo.Items.Contains('TexConv')
  $Conditions[1] = $DDSCreatorCombo.Items.Contains('Compressonator')
  $Conditions[2] = $DDSCreatorCombo.Items.Contains('DDS Utilities')

  # Test the array of conditions.
  if (!(TestBooleanArray -Array $Conditions))
  {
    # Add the item to allow adding more tools.
    $DDSCreatorCombo.Items.Add('Add Tool...') | Out-Null
  }
}
#----------------------------------------------------------------------------------------------------------------------------------------------
function DDSToolSelection()
{
  # If selecting an existing tool.
  if ($this.SelectedItem -ne 'Add Tool...')
  {
    # Simply update the variable tied to the combo box.
    GUI_UpdateComboBoxState -NewValue $this.SelectedItem
  }
  # Adding a tool is a bit more complex.
  else
  {
    # Create empty arrays based for the tools that aren't already added.
    $FileNameArray    = @()
    $DescriptionArray = @()

    # Build the file name and description arrays based on the tools that aren't already added.
    if (!(TestPath -LiteralPath $TexConvTool))    { $DescriptionArray += 'TexConv'        ; $FileNameArray += 'texconv.exe'           }
    if (!(TestPath -LiteralPath $Compressonator)) { $DescriptionArray += 'Compressonator' ; $FileNameArray += 'CompressonatorCLI.exe' }
    if (!(TestPath -LiteralPath $DDSUtilities))   { $DescriptionArray += 'DDS Utilities'  ; $FileNameArray += 'nvdxt.exe'             }

    # Display an "Open Folder" menu to get the path. Get-FileName already handles arrays so no need to worry about extra shit.
    $SelectedPath = Get-FileName -Path 'C:\' -Description $DescriptionArray -FileName $FileNameArray

    # Check to see if a folder was selected from the Open menu and test if that path exists.
    if (($SelectedPath -ne '') -and (TestPath -LiteralPath $SelectedPath))
    {
      # Get the name of the tool so parameters for it can be set up.
      $ToolName = (Get-Item -LiteralPath $SelectedPath).BaseName

      # Set up parameters based on the selected tool.
      switch ($ToolName)
      {
        # We'll need the name of the tool in the list, the textbox it is tied to in the paths menu, and the name of the variable that stored the value.
        'texconv'           { $Tool = 'TexConv'        ; $TextBox = $TexConvToolTextBox    ; $VarName = 'TexConvTool'    }
        'CompressonatorCLI' { $Tool = 'Compressonator' ; $TextBox = $CompressonatorTextBox ; $VarName = 'Compressonator' }
        'nvdxt'             { $Tool = 'DDS Utilities'  ; $TextBox = $DDSUtilitiesTextBox   ; $VarName = 'DDSUtilities'   }
      }
      # Make sure the tool is not already on the list.
      if (!($this.Items.Contains($Tool)))
      {
        # Call the function that is used when updating paths.
        GUI_UpdateFilePath_Finish -TextBox $TextBox -VarName $VarName -ToolPath $SelectedPath
      }
      # Force the selected item to recently added tool.
      $this.SelectedItem = $Tool
    }
    # If nothing was selected.
    else
    {
      # Force the currently selected item to the previously selected item.
      $this.SelectedItem = $SelectedDDSTool
    }
  }
  # Update the currently selected tool.
  $global:SelectedDDSTool = $this.SelectedItem
}
#----------------------------------------------------------------------------------------------------------------------------------------------
# DDS Tool Selection
$DDSCreatorCombo = New-Object System.Windows.Forms.ComboBox
$DDSCreatorCombo.Name = 'DDSCreatorTool'
$DDSCreatorCombo.Size = New-Object System.Drawing.Size(102, 20)
$DDSCreatorCombo.Location = New-Object System.Drawing.Size(10, 37)
if (TestPath -LiteralPath $TexConvTool)    { $DDSCreatorCombo.Items.Add('TexConv') | Out-Null }
if (TestPath -LiteralPath $Compressonator) { $DDSCreatorCombo.Items.Add('Compressonator') | Out-Null }
if (TestPath -LiteralPath $DDSUtilities)   { $DDSCreatorCombo.Items.Add('DDS Utilities') | Out-Null }
$DDSCreatorCombo.Items.Add('ImageMagick') | Out-Null

# Adds the option "Add Tool..." to the menu if all tools are not already added.
CheckAddDDSToolOption

# If the tool has been added to the list, and it's set to the selected tool.
if ($DDSCreatorCombo.Items.Contains($DDSCreatorTool))
{
  # It should be safe to set the current selection to the previously selected tool.
  $DDSCreatorCombo.SelectedItem = $global:SelectedDDSTool = $DDSCreatorTool
}
# The tool has not been already added to the list.
else
{
  # Default the tool to ImageMagick.
  $DDSCreatorCombo.SelectedItem = $global:SelectedDDSTool = $global:DDSCreatorTool = 'ImageMagick'
}
$DDSCreatorCombo.Add_SelectedIndexChanged({ DDSToolSelection })
$DDSCreatorCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$OptionsGroup.Controls.Add($DDSCreatorCombo)
$DDSCreatorLabel = New-Object System.Windows.Forms.Label
$DDSCreatorLabel.Size = New-Object System.Drawing.Size(100, 16)
$DDSCreatorLabel.Location = New-Object System.Drawing.Size(114, 40)
$DDSCreatorLabel.Text = 'DDS Creation Tool'
$OptionsGroup.Controls.Add($DDSCreatorLabel)
$DDSCreatorTip = New-Object System.Windows.Forms.ToolTip
$DDSCreatorTip.InitialDelay = $ToolTipDelay
$DDSCreatorTip.AutoPopDelay = $ToolTipDuration
$DDSCreatorTipString  = 'Allows selecting the preferred program used to generate DDS textures.{0}'
$DDSCreatorTipString += 'The script will usually select the appropriate program if available, but{0}'
$DDSCreatorTipString += 'this option can be used to force a program in certain situations.{0}'
$DDSCreatorTipString += '{0}'
$DDSCreatorTipString += 'TexConv: Uses texconv.exe to create textures. This program is faster{0}'
$DDSCreatorTipString += 'than the others when creating DXT1/DXT5 textures, but at much{0}'
$DDSCreatorTipString += 'lower quality. It can also create nice quality BC7 textures.{0}'
$DDSCreatorTipString += '{0}'
$DDSCreatorTipString += 'Compressonator: Uses CompressonatorCLI.exe to create DDS textures.{0}'
$DDSCreatorTipString += 'Creates higher quality DXT1/DXT5 textures than DDS Utilities in most{0}'
$DDSCreatorTipString += 'cases. Creates very high quality BC7 textures.{0}'
$DDSCreatorTipString += '{0}'
$DDSCreatorTipString += 'DDS Utilities: Uses nvdxt.exe to create textures. It can create both DXT1{0}'
$DDSCreatorTipString += 'and DXT5 textures, but can not create BC7 or ARGB32 textures. Quality{0}'
$DDSCreatorTipString += 'is higher than TexConv, but not as high of quality as Compressonator.{0}'
$DDSCreatorTipString += '{0}'
$DDSCreatorTipString += 'ImageMagick: Uses magick.exe to create DDS textures. I do not suggest{0}'
$DDSCreatorTipString += 'using ImageMagick to create DXT1/DXT5 textures as the quality is bad.{0}'
$DDSCreatorTipString += 'It does however create perfect quality uncompressed ARGB32 textures.{0}'
$DDSCreatorTipString += '{0}'
$DDSCreatorTipString += 'All programs are useful depending on the users goals. If the selected{0}'
$DDSCreatorTipString += 'program fails to generate an image, it will fall back to another.'
$DDSCreatorTipString = [String]::Format($DDSCreatorTipString, [Environment]::NewLine)
$DDSCreatorTip.SetToolTip($DDSCreatorLabel, $DDSCreatorTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
function ToggleFallbackVisibility()
{
  if ($this.SelectedItem -eq 'User Defined')
  {
    $DDSFBCCombo.Visible = $true
    $DDSFBCLabel.Visible = $true
    $DDSFlagsCombo.Visible = $true
    $DDSFlagsLabel.Visible = $true
  }
  else
  {
    $DDSFBCCombo.Visible = $false
    $DDSFBCLabel.Visible = $false
    $DDSFlagsCombo.Visible = $false
    $DDSFlagsLabel.Visible = $false
  }
}
#----------------------------------------------------------------------------------------------------------------------------------------------
# DDS Block Compression
$DDSBCCombo = New-Object System.Windows.Forms.ComboBox
$DDSBCCombo.Name = 'DDSBlkCompress'
$DDSBCCombo.Size = New-Object System.Drawing.Size(102, 20)
$DDSBCCombo.Location = New-Object System.Drawing.Size(10, 61)
$DDSBCCombo.Items.Add('DXT1/DXT5') | Out-Null
$DDSBCCombo.Items.Add('DXT5') | Out-Null
if (TestPath -LiteralPath $TexConvTool)
{
  $DDSBCCombo.Items.Add('BC7') | Out-Null
}
$DDSBCCombo.Items.Add('ARGB32') | Out-Null
$DDSBCCombo.Items.Add('User Defined') | Out-Null

# If BC7 was selected in a previous run and it was successfully added to the list.
if ($DDSBCCombo.Items.Contains($DDSBlkCompress))
{
  # It should be safe to set the current selection to the previously selected tool.
  $DDSBCCombo.SelectedItem = $DDSBlkCompress
}
# If set to BC7 in a previous run and the required tool is not found.
else
{
  # Set the text to DXT1/DXT5 and update the variable.
  $DDSBCCombo.SelectedItem = $global:DDSBlkCompress = 'DXT1/DXT5'
}
$DDSBCCombo.Add_SelectedIndexChanged({ GUI_UpdateComboBoxState -NewValue $this.SelectedItem ; ToggleFallbackVisibility })
$DDSBCCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$OptionsGroup.Controls.Add($DDSBCCombo)
$DDSBCLabel = New-Object System.Windows.Forms.Label
$DDSBCLabel.Size = New-Object System.Drawing.Size(100, 16)
$DDSBCLabel.Location = New-Object System.Drawing.Size(114, 64)
$DDSBCLabel.Text = 'DDS Compression'
$OptionsGroup.Controls.Add($DDSBCLabel)
$DDSBCTip = New-Object System.Windows.Forms.ToolTip
$DDSBCTip.InitialDelay = $ToolTipDelay
$DDSBCTip.AutoPopDelay = $ToolTipDuration
$DDSBCTipString = 'Allows selecting the DDS block compression format.{0}'
$DDSBCTipString += '{0}'
$DDSBCTipString += 'DXT1/DXT5: Textures with transparency are created {0}'
$DDSBCTipString += 'with DXT5/BC3 compression. Fully opaque textures{0}'
$DDSBCTipString += 'are created with DXT1/BC1 compression.{0}'
$DDSBCTipString += '{0}'
$DDSBCTipString += 'DXT5: Create textures with DXT5/BC3 compression.{0}'
$DDSBCTipString += 'This may yield slightly higher quality for opaque{0}'
$DDSBCTipString += 'textures, but the resulting file size is doubled.{0}'
$DDSBCTipString += '{0}'
$DDSBCTipString += 'BC7: Create textures using BC7 compression. The{0}'
$DDSBCTipString += 'overall quality of this format is superior to the other{0}'
$DDSBCTipString += 'available formats, approaching near PNG quality.{0}'
$DDSBCTipString += '{0}'
$DDSBCTipString += 'ARGB32: Create uncompressed DDS textures. This has{0}'
$DDSBCTipString += 'the highest quality, but consumes 4x the amount of{0}'
$DDSBCTipString += 'resources (VRAM/disk space) as DXT5 or BC7.{0}'
$DDSBCTipString += '{0}'
$DDSBCTipString += 'User Defined: Compression is specified by a flag in the{0}'
$DDSBCTipString += 'texture name or path to the texture. Available flags are:{0}'
$DDSBCTipString += '_DXTC (or _DXTN), _DXT5 (or _BC3), _BC7, and _ARGB32.{0}'
$DDSBCTipString += '{0}'
$DDSBCTipString += '[Ex1:] Image in C:\World_BC7\tex.png > BC7{0}'
$DDSBCTipString += '[Ex2:] Image in C:\_BC3\World\tex.png > DXT5{0}'
$DDSBCTipString += '[Ex3:] Image in C:\World\tex_DXTC.png > DXT1/DXT5{0}'
$DDSBCTipString += '{0}'
$DDSBCTipString += 'If a flag is not found, the fallback compression is used.'
$DDSBCTipString = [String]::Format($DDSBCTipString, [Environment]::NewLine)
$DDSBCTip.SetToolTip($DDSBCLabel, $DDSBCTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# DDS Flags
$DDSFlagsCombo = New-Object System.Windows.Forms.ComboBox
$DDSFlagsCombo.Name = 'DDSFlagRemoval'
$DDSFlagsCombo.Size = New-Object System.Drawing.Size(82, 20)
$DDSFlagsCombo.Location = New-Object System.Drawing.Size(214, 37)
$DDSFlagsCombo.Items.Add('New & Base') | Out-Null
$DDSFlagsCombo.Items.Add('New Pack') | Out-Null
$DDSFlagsCombo.Items.Add('None') | Out-Null
$DDSFlagsCombo.SelectedItem = $DDSFlagRemoval
$DDSFlagsCombo.Add_SelectedIndexChanged({ GUI_UpdateComboBoxState -NewValue $this.SelectedItem })
$DDSFlagsCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$DDSFlagsCombo.Visible = ($DDSBlkCompress -eq 'User Defined')
$OptionsGroup.Controls.Add($DDSFlagsCombo)
$DDSFlagsLabel = New-Object System.Windows.Forms.Label
$DDSFlagsLabel.Size = New-Object System.Drawing.Size(80, 16)
$DDSFlagsLabel.Location = New-Object System.Drawing.Size(298, 40)
$DDSFlagsLabel.Text = 'Flag Removal'
$DDSFlagsLabel.Visible = ($DDSBlkCompress -eq 'User Defined')
$OptionsGroup.Controls.Add($DDSFlagsLabel)
$DDSFlagsTip = New-Object System.Windows.Forms.ToolTip
$DDSFlagsTip.InitialDelay = $ToolTipDelay
$DDSFlagsTip.AutoPopDelay = $ToolTipDuration
$DDSFlagsTipString = 'If DDS Compression is set to "User Defined", and the operation {0}'
$DDSFlagsTipString += 'is set to either "Standard" options "Convert" or "Rescale", this{0}'
$DDSFlagsTipString += 'option can automatically remove any user defined flags.{0}'
$DDSFlagsTipString += '{0}'
$DDSFlagsTipString += 'New & Base - Remove flags from the base and generated pack.{0}'
$DDSFlagsTipString += 'New Pack - Only remove flags from the generated pack.{0}'
$DDSFlagsTipString += 'None - Do not remove flags from either packs.{0}'
$DDSFlagsTipString += '{0}'
$DDSFlagsTipString += 'The list of user defined flags that are automatically removed:{0}'
$DDSFlagsTipString += '_DXTC (or _DXTN), _DXT5 (or _BC3), _BC7, and _ARGB32.'
$DDSFlagsTipString = [String]::Format($DDSFlagsTipString, [Environment]::NewLine)
$DDSFlagsTip.SetToolTip($DDSFlagsLabel, $DDSFlagsTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# DDS Fallback Compression
$DDSFBCCombo = New-Object System.Windows.Forms.ComboBox
$DDSFBCCombo.Name = 'FallbackCompress'
$DDSFBCCombo.Size = New-Object System.Drawing.Size(82, 20)
$DDSFBCCombo.Location = New-Object System.Drawing.Size(214, 61)
$DDSFBCCombo.Items.Add('DXT1/DXT5') | Out-Null
$DDSFBCCombo.Items.Add('DXT5') | Out-Null
if (TestPath -LiteralPath $TexConvTool)
{
  $DDSFBCCombo.Items.Add('BC7') | Out-Null
}
$DDSFBCCombo.Items.Add('ARGB32') | Out-Null
# If BC7 was selected in a previous run and it was successfully added to the list.
if ($DDSFBCCombo.Items.Contains($FallbackCompress))
{
  # It should be safe to set the current selection to the previously selected tool.
  $DDSFBCCombo.SelectedItem = $FallbackCompress
}
# If set to BC7 in a previous run and the required tool is not found.
else
{
  # Set the text to DXT1/DXT5 and update the variable.
  $global:FallbackCompress = 'DXT1/DXT5'
  $DDSFBCCombo.SelectedItem = 'DXT1/DXT5'
}
$DDSFBCCombo.Add_SelectedIndexChanged({ GUI_UpdateComboBoxState -NewValue $this.SelectedItem })
$DDSFBCCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$DDSFBCCombo.Visible = ($DDSBlkCompress -eq 'User Defined')
$OptionsGroup.Controls.Add($DDSFBCCombo)
$DDSFBCLabel = New-Object System.Windows.Forms.Label
$DDSFBCLabel.Size = New-Object System.Drawing.Size(80, 16)
$DDSFBCLabel.Location = New-Object System.Drawing.Size(298, 64)
$DDSFBCLabel.Text = 'DDS Fallback'
$DDSFBCLabel.Visible = ($DDSBlkCompress -eq 'User Defined')
$OptionsGroup.Controls.Add($DDSFBCLabel)
$DDSFBCTip = New-Object System.Windows.Forms.ToolTip
$DDSFBCTip.InitialDelay = $ToolTipDelay
$DDSFBCTip.AutoPopDelay = $ToolTipDuration
$DDSFBCTipString = 'If a compression type flag is not found in the path to the texture,{0}'
$DDSFBCTipString += 'use the compression type specified here on the image instead. This{0}'
$DDSFBCTipString += 'option is only usable/visible with "User Defined" compression.{0}'
$DDSFBCTipString += '{0}'
$DDSFBCTipString += 'User Definable Flags:{0}'
$DDSFBCTipString += '_DXTC (or _DXTN): Works like the DXT1/DXT5 option.{0}'
$DDSFBCTipString += '_DXT5 (or _BC3): Creates textures with DXT5 compression.{0}'
$DDSFBCTipString += '_BC7: Creates textures with BC7 compression.{0}'
$DDSFBCTipString += '_ARGB32: Creates uncompressed DDS textures.{0}'
$DDSFBCTipString += '{0}'
$DDSFBCTipString += 'Examples:{0}'
$DDSFBCTipString += 'C:\Textures\Evironment_BC7\ - Convert textures in this path to BC7.{0}'
$DDSFBCTipString += 'C:\Textures\UI_ARGB32\ - Convert textures in this path to ARGB32.{0}'
$DDSFBCTipString += 'C:\Textures\_ARGB32\UI\ - Same effect as above example.{0}'
$DDSFBCTipString += '{0}'
$DDSFBCTipString += 'Texture paths that do not have a flag use the fallback type set here.'
$DDSFBCTipString = [String]::Format($DDSFBCTipString, [Environment]::NewLine)
$DDSFBCTip.SetToolTip($DDSFBCLabel, $DDSFBCTipString)
#==============================================================================================================================================================================================
#  CTT GUI - MipMap Options
#==============================================================================================================================================================================================
$MipMapGroup = New-Object System.Windows.Forms.GroupBox
$MipMapGroup.Size = New-Object System.Drawing.Size(380, 80)
$MipMapGroup.Location = New-Object System.Drawing.Size(400, 98)
$MipMapGroup.Text = ' MipMap Options '
$MainDialog.Controls.Add($MipMapGroup)
$MipMapGroupTip = New-Object System.Windows.Forms.ToolTip
$MipMapGroupTip.InitialDelay = $ToolTipDelay
$MipMapGroupTip.AutoPopDelay = $ToolTipDuration
$MipMapGroupTipString = 'These options affect the way the script generates mipmaps.'
$MipMapGroupTipString = [String]::Format($MipMapGroupTipString, [Environment]::NewLine)
$MipMapGroupTip.SetToolTip($MipMapGroup, $MipMapGroupTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
function ToggleMissingOption()
{
  # Do not allow "Force New MipMaps" to be enabled with "Create From Top Level".
  if ($this.Checked)
  {
    $FinalMipMapCheck.Checked = $false
    $FinalMipMapCheck.Enabled = $false
    $MipMapTopLevelBase = $false
    return
  }
  $FinalMipMapCheck.Enabled = $true
}
#----------------------------------------------------------------------------------------------------------------------------------------------
# Force New MipMaps
$ForceNewMipsCheck = New-Object System.Windows.Forms.CheckBox
$ForceNewMipsCheck.Name = 'ForceNewMipMaps'
$ForceNewMipsCheck.Size = New-Object System.Drawing.Size(130, 16)
$ForceNewMipsCheck.Location = New-Object System.Drawing.Size(10, 18)
$ForceNewMipsCheck.Checked = $ForceNewMipMaps
$ForceNewMipsCheck.Text = ' Force New MipMaps'
$ForceNewMipsCheck.Add_CheckStateChanged({ GUI_UpdateCheckBoxState ; ToggleMissingOption })
$MipMapGroup.Controls.Add($ForceNewMipsCheck)
$ForceNewMipsTip = New-Object System.Windows.Forms.ToolTip
$ForceNewMipsTip.InitialDelay = $ToolTipDelay
$ForceNewMipsTip.AutoPopDelay = $ToolTipDuration
$ForceNewMipsTipString = 'When mipmaps are generated, this forces the script{0}'
$ForceNewMipsTipString += 'to ignore all mipmaps provided with the pack and{0}'
$ForceNewMipsTipString += 'generate new ones from the top level (base texture).{0}'
$ForceNewMipsTipString += '{0}'
$ForceNewMipsTipString += 'Note that this option will NOT preserve any dynamic{0}'
$ForceNewMipsTipString += 'mipmap effects (different mipmaps on lower layers).'
$ForceNewMipsTipString = [String]::Format($ForceNewMipsTipString, [Environment]::NewLine)
$ForceNewMipsTip.SetToolTip($ForceNewMipsCheck, $ForceNewMipsTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
function ToggleForceNewOption()
{
  # Do not allow "Force New MipMaps" to be enabled with "Create From Top Level".
  if ($this.Checked)
  {
    $ForceNewMipsCheck.Checked = $false
    $ForceNewMipsCheck.Enabled = $false
    $ForceNewMipMaps = $false
    return
  }
  $ForceNewMipsCheck.Enabled = $true
}
#----------------------------------------------------------------------------------------------------------------------------------------------
# Create From Top Level
$FinalMipMapCheck = New-Object System.Windows.Forms.CheckBox
$FinalMipMapCheck.Name = 'MipMapTopLevelBase'
$FinalMipMapCheck.Size = New-Object System.Drawing.Size(185, 16)
$FinalMipMapCheck.Location = New-Object System.Drawing.Size(10, 38)
$FinalMipMapCheck.Checked = $MipMapTopLevelBase
$FinalMipMapCheck.Text = ' Create From Top Level'
$FinalMipMapCheck.Add_CheckStateChanged({ GUI_UpdateCheckBoxState ; ToggleForceNewOption })
$FinalMipMapCheck.Enabled = !$ForceNewMipMaps
$MipMapGroup.Controls.Add($FinalMipMapCheck)
$FinalMipMapTip = New-Object System.Windows.Forms.ToolTip
$FinalMipMapTip.InitialDelay = $ToolTipDelay
$FinalMipMapTip.AutoPopDelay = $ToolTipDuration
$FinalMipMapTipString = 'When missing mipmaps are generated, the script will{0}'
$FinalMipMapTipString += 'use the lowest provided mipmap level as a base to{0}'
$FinalMipMapTipString += 'generate the missing levels. This option will instead{0}'
$FinalMipMapTipString += 'use the top level (base texture) as the mipmap base.{0}'
$FinalMipMapTipString += '{0}'
$FinalMipMapTipString += 'This option should not be used in most cases. Using{0}'
$FinalMipMapTipString += "the top level can break the artist's intended effects."
$FinalMipMapTipString = [String]::Format($FinalMipMapTipString, [Environment]::NewLine)
$FinalMipMapTip.SetToolTip($FinalMipMapCheck, $FinalMipMapTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$DDSMipMapCheck = New-Object System.Windows.Forms.CheckBox
$DDSMipMapCheck.Name = 'ExternalDDSMipMaps'
$DDSMipMapCheck.Size = New-Object System.Drawing.Size(185, 16)
$DDSMipMapCheck.Location = New-Object System.Drawing.Size(10, 58)
$DDSMipMapCheck.Checked = $ExternalDDSMipMaps
$DDSMipMapCheck.Text = ' External DDS MipMaps'
$DDSMipMapCheck.Add_CheckStateChanged({ GUI_UpdateCheckBoxState })
$MipMapGroup.Controls.Add($DDSMipMapCheck)
$DDSMipMapTip = New-Object System.Windows.Forms.ToolTip
$DDSMipMapTip.InitialDelay = $ToolTipDelay
$DDSMipMapTip.AutoPopDelay = $ToolTipDuration
$DDSMipMapTipString = 'When DDS textures are created, this option will create all{0}'
$DDSMipMapTipString += 'mipmap levels externally from the DDS texture in separate{0}'
$DDSMipMapTipString += 'image files, rather than all images within a single file.'
$DDSMipMapTipString = [String]::Format($DDSMipMapTipString, [Environment]::NewLine)
$DDSMipMapTip.SetToolTip($DDSMipMapCheck, $DDSMipMapTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
function ToggleMaxMipMapOption()
{
  # Do not allow "Force New MipMaps" to be enabled with "Create From Top Level".
  $MaxMipMapNumBox.Enabled = $this.Checked
}
#----------------------------------------------------------------------------------------------------------------------------------------------
$MaxMipMapCheck = New-Object System.Windows.Forms.CheckBox
$MaxMipMapCheck.Name = 'MaxMipMapEnabled'
$MaxMipMapCheck.Size = New-Object System.Drawing.Size(130, 16)
$MaxMipMapCheck.Location = New-Object System.Drawing.Size(185, 18)
$MaxMipMapCheck.Checked = $MaxMipMapEnabled
$MaxMipMapCheck.Text = ' Max MipMap Levels'
$MaxMipMapCheck.Add_CheckStateChanged({ GUI_UpdateCheckBoxState ; ToggleMaxMipMapOption })
$MipMapGroup.Controls.Add($MaxMipMapCheck)
$MaxMipMapTip = New-Object System.Windows.Forms.ToolTip
$MaxMipMapTip.InitialDelay = $ToolTipDelay
$MaxMipMapTip.AutoPopDelay = $ToolTipDuration
$MaxMipMapTipString =  'Forces the number of mipmap levels. When this is disabled,{0}'
$MaxMipMapTipString += 'mipmaps will always be generated down to 1x1 dimensions.{0}'
$MaxMipMapTipString += '{0}'
$MaxMipMapTipString += 'Compressonator fails when trying to generate a single DDS{0}'
$MaxMipMapTipString += 'internal mipmap when custom mipmaps are not provided,{0}'
$MaxMipMapTipString += 'so use another program in this case (like TexConv). This can{0}'
$MaxMipMapTipString += 'be worked around by supplying a single custom mipmap{0}'
$MaxMipMapTipString += 'and keeping the "Force New MipMaps" option disabled.'
$MaxMipMapTipString = [String]::Format($MaxMipMapTipString, [Environment]::NewLine)
$MaxMipMapTip.SetToolTip($MaxMipMapCheck, $MaxMipMapTipString)
$MaxMipMapNumBox = New-Object System.Windows.Forms.NumericUpDown
$MaxMipMapNumBox.Name = 'MaxMipMapLevels'
$MaxMipMapNumBox.Size = New-Object System.Drawing.Size(36, 10)
$MaxMipMapNumBox.Location = New-Object System.Drawing.Size(315, 15)
$MaxMipMapNumBox.DecimalPlaces = 0
$MaxMipMapNumBox.Value = $MaxMipMapLevels
$MaxMipMapNumBox.Minimum = 0
$MaxMipMapNumBox.Maximum = 9
$MaxMipMapNumBox.Increment = 1
$MaxMipMapNumBox.Add_ValueChanged({ GUI_UpdateNumericUpDown -TypeDefinition 'integer' })
$MaxMipMapNumBox.Enabled = $MaxMipMapEnabled
$MipMapGroup.Controls.Add($MaxMipMapNumBox)
#==============================================================================================================================================================================================
# CTT GUI - CTT-PS Options
#==============================================================================================================================================================================================
$CTTOptionsGroup = New-Object System.Windows.Forms.GroupBox
$CTTOptionsGroup.Size = New-Object System.Drawing.Size(380, 201)
$CTTOptionsGroup.Location = New-Object System.Drawing.Size(400, 183)
$CTTOptionsGroup.Text = ' Preferences '
$MainDialog.Controls.Add($CTTOptionsGroup)
$CTTOptionsGroupTip = New-Object System.Windows.Forms.ToolTip
$CTTOptionsGroupTip.InitialDelay = $ToolTipDelay
$CTTOptionsGroupTip.AutoPopDelay = $ToolTipDuration
$CTTOptionsGroupTipString = 'These options affect PowerShell and the CTT-PS GUI. They do{0}'
$CTTOptionsGroupTipString += 'not affect texture generation and exist solely for preference.'
$CTTOptionsGroupTipString = [String]::Format($CTTOptionsGroupTipString, [Environment]::NewLine)
$CTTOptionsGroupTip.SetToolTip($CTTOptionsGroup, $CTTOptionsGroupTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Disable Log File
$DisableLogCheck = New-Object System.Windows.Forms.CheckBox
$DisableLogCheck.Name = 'CreateLogFile'
$DisableLogCheck.Size = New-Object System.Drawing.Size(300, 16)
$DisableLogCheck.Location = New-Object System.Drawing.Size(12, 18)
$DisableLogCheck.Checked = $CreateLogFile
$DisableLogCheck.Text = ' Create a log file of all textures processed'
$DisableLogCheck.Add_CheckStateChanged({ GUI_UpdateCheckBoxState })
$CTTOptionsGroup.Controls.Add($DisableLogCheck)
$DisableLogTip = New-Object System.Windows.Forms.ToolTip
$DisableLogTip.InitialDelay = $ToolTipDelay
$DisableLogTip.AutoPopDelay = $ToolTipDuration
$DisableLogTipString = 'When an option is executed with the "Start" button, create{0}'
$DisableLogTipString += 'a log of all textures processed and all operations performed.'
$DisableLogTipString = [String]::Format($DisableLogTipString, [Environment]::NewLine)
$DisableLogTip.SetToolTip($DisableLogCheck, $DisableLogTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# PS Double Click
function GUI_PSDoubleClickCheckBoxState()
{
  # Create a temporary folder to create the registry mod.
  $TempRegPath = CreatePath -LiteralPath ($TempFolder + '\RegMod\')

  # Set the path to the registry mod.
  $TempRegFile = $TempRegPath + 'ctt-ps_regmod.reg'

  # Begin to create the reg file.
  Add-Content -LiteralPath $TempRegFile -Value 'Windows Registry Editor Version 5.00'
  Add-Content -LiteralPath $TempRegFile -Value ''
  Add-Content -LiteralPath $TempRegFile -Value '[HKEY_LOCAL_MACHINE\SOFTWARE\Classes\Microsoft.PowerShellScript.1\Shell]'

  # Get the current state of the value in the registry.
  $PS_DC_State = (Get-ItemProperty -LiteralPath "HKLM:\Software\Classes\Microsoft.PowerShellScript.1\Shell").'(default)'

  # Check the current state and add the value to the registry.
  if ($PS_DC_State -eq '0')
  {
    Add-Content -LiteralPath $TempRegFile -Value '@="Open"'
  }
  else
  {
    Add-Content -LiteralPath $TempRegFile -Value '@="0"'
  }
  # Execute the registry file.
  regedit /s $TempRegFile
}
#----------------------------------------------------------------------------------------------------------------------------------------------
$PSDoubleClick = ((Get-ItemProperty -LiteralPath "HKLM:\Software\Classes\Microsoft.PowerShellScript.1\Shell").'(default)' -eq '0')
$PSDoubleCLickCheck = New-Object System.Windows.Forms.CheckBox
$PSDoubleCLickCheck.Name = 'PSDoubleClick'
$PSDoubleCLickCheck.Size = New-Object System.Drawing.Size(300, 16)
$PSDoubleCLickCheck.Location = New-Object System.Drawing.Size(12, 37)
$PSDoubleCLickCheck.Checked = $PSDoubleClick
$PSDoubleCLickCheck.Text = ' Allow opening PowerShell scripts with a double click'
$PSDoubleCLickCheck.Add_CheckStateChanged({ GUI_PSDoubleClickCheckBoxState })
$CTTOptionsGroup.Controls.Add($PSDoubleCLickCheck)
$PSDoubleCLickTip = New-Object System.Windows.Forms.ToolTip
$PSDoubleCLickTip.InitialDelay = $ToolTipDelay
$PSDoubleCLickTip.AutoPopDelay = $ToolTipDuration
$PSDoubleCLickTipString = 'Allows opening PowerShell scripts with a double click. This requires{0}'
$PSDoubleCLickTipString += 'modification to the Windows registry, so toggling this checkbox will{0}'
$PSDoubleCLickTipString += 'update the "open" value for PowerShell scripts in the registry. This{0}'
$PSDoubleCLickTipString += 'may require pressing "OK" on Windows 7 if a pop-up dialog appears.'
$PSDoubleCLickTipString = [String]::Format($PSDoubleCLickTipString, [Environment]::NewLine)
$PSDoubleCLickTip.SetToolTip($PSDoubleCLickCheck, $PSDoubleCLickTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Disable Stored Options
function GUI_DisableStoredToggle()
{
  # Toggle the "enabled" state of the store path folders.
  $StoreInputCheck.Enabled  = $this.Checked
  $StoreOutputCheck.Enabled = $this.Checked

  # If Enable Storing is unchecked, force the store path options to false.
  if (!$this.Checked)
  {
    $global:StoreInputFolder  = $false
    $global:StoreOutputFolder = $false
    $StoreInputCheck.Checked  = $false
    $StoreOutputCheck.Checked = $false
  }
}
#----------------------------------------------------------------------------------------------------------------------------------------------
$EnableStoredCheck = New-Object System.Windows.Forms.CheckBox
$EnableStoredCheck.Name = 'EnableStoring'
$EnableStoredCheck.Size = New-Object System.Drawing.Size(280, 16)
$EnableStoredCheck.Location = New-Object System.Drawing.Size(12, 56)
$EnableStoredCheck.Checked = $EnableStoring
$EnableStoredCheck.Text = " Save any changes made to all options on exit"
$EnableStoredCheck.Add_CheckStateChanged({ GUI_UpdateCheckBoxState ; GUI_DisableStoredToggle })
$CTTOptionsGroup.Controls.Add($EnableStoredCheck)
$EnableStoredTip = New-Object System.Windows.Forms.ToolTip
$EnableStoredTip.InitialDelay = $ToolTipDelay
$EnableStoredTip.AutoPopDelay = $ToolTipDuration
$EnableStoredTipString = 'When the script is closed, changes that were made to options{0}'
$EnableStoredTipString += 'will be written to the script so they are remembered the next{0}'
$EnableStoredTipString += 'time the script is ran. This option disables that functionality.'
$EnableStoredTipString = [String]::Format($EnableStoredTipString, [Environment]::NewLine)
$EnableStoredTip.SetToolTip($EnableStoredCheck, $EnableStoredTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Toggle Top-Most Windows
$TopMostCheck = New-Object System.Windows.Forms.CheckBox
$TopMostCheck.Name = 'DisableTopMost'
$TopMostCheck.Size = New-Object System.Drawing.Size(280, 16)
$TopMostCheck.Location = New-Object System.Drawing.Size(12, 75)
$TopMostCheck.Checked = $DisableTopMost
$TopMostCheck.Text = ' Disable forcing the GUI as the top-most window'
$TopMostCheck.Add_CheckStateChanged({ GUI_UpdateCheckBoxState ; $MainDialog.Topmost = !$DisableTopMost })
$CTTOptionsGroup.Controls.Add($TopMostCheck)
$TopMostTip = New-Object System.Windows.Forms.ToolTip
$TopMostTip.InitialDelay = $ToolTipDelay
$TopMostTip.AutoPopDelay = $ToolTipDuration
$TopMostTipString = 'Disables forcing CTT-PS GUI over top of all other open windows.'
$TopMostTip.SetToolTip($TopMostCheck, $TopMostTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Auto-Hide Console
function GUI_ToggleConsole()
{
  # Toggle the PS Console depending on the check state.
  ShowPowerShellConsole -ShowConsole $this.Checked

  # Activate the main dialog so it doesn't fall behind the PS Console..
  $MainDialog.Activate()
}
#----------------------------------------------------------------------------------------------------------------------------------------------
$HideConsoleCheck = New-Object System.Windows.Forms.CheckBox
$HideConsoleCheck.Name = 'AlwaysShowConsole'
$HideConsoleCheck.Size = New-Object System.Drawing.Size(280, 16)
$HideConsoleCheck.Location = New-Object System.Drawing.Size(12, 94)
$HideConsoleCheck.Checked = $AlwaysShowConsole
$HideConsoleCheck.Text = ' Always show the PowerShell console window'
$HideConsoleCheck.Add_CheckStateChanged({ GUI_UpdateCheckBoxState ; GUI_ToggleConsole })
$CTTOptionsGroup.Controls.Add($HideConsoleCheck)
$HideConsoleCheckTip = New-Object System.Windows.Forms.ToolTip
$HideConsoleCheckTip.InitialDelay = $ToolTipDelay
$HideConsoleCheckTip.AutoPopDelay = $ToolTipDuration
$HideConsoleTipString = 'If disabled, hides the PowerShell console window while it is not{0}'
$HideConsoleTipString += 'in use, and only shows it while textures are being processed.'
$HideConsoleTipString = [String]::Format($HideConsoleTipString, [Environment]::NewLine)
$HideConsoleCheckTip.SetToolTip($HideConsoleCheck, $HideConsoleTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Auto-Center Console
$AutoCenterCheck = New-Object System.Windows.Forms.CheckBox
$AutoCenterCheck.Name = 'AutoCenterConsole'
$AutoCenterCheck.Size = New-Object System.Drawing.Size(280, 16)
$AutoCenterCheck.Location = New-Object System.Drawing.Size(12, 113)
$AutoCenterCheck.Checked = $AutoCenterConsole
$AutoCenterCheck.Text = ' Auto-center the PowerShell console on launch'
$AutoCenterCheck.Add_CheckStateChanged({ GUI_UpdateCheckBoxState })
$CTTOptionsGroup.Controls.Add($AutoCenterCheck)
$AutoCenterCheckTip = New-Object System.Windows.Forms.ToolTip
$AutoCenterCheckTip.InitialDelay = $ToolTipDelay
$AutoCenterCheckTip.AutoPopDelay = $ToolTipDuration
$AutoCenterCheckTipString = 'When CTT-PS is launched, the center of the screen is calculated and the {0}'
$AutoCenterCheckTipString += 'PowerShell console is moved to this location. Unchecking this option {0}'
$AutoCenterCheckTipString += 'will disable this functionality if this happens to cause issues.{0}'
$AutoCenterCheckTipString += '{0}'
$AutoCenterCheckTipString += 'This option will not work for Windows 7 users that have PowerShell v2.'
$AutoCenterCheckTipString = [String]::Format($AutoCenterCheckTipString, [Environment]::NewLine)
$AutoCenterCheckTip.SetToolTip($AutoCenterCheck, $AutoCenterCheckTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Disable PS X Button
$DisableXButtonCheck = New-Object System.Windows.Forms.CheckBox
$DisableXButtonCheck.Name = 'DisablePSXButton'
$DisableXButtonCheck.Size = New-Object System.Drawing.Size(280, 16)
$DisableXButtonCheck.Location = New-Object System.Drawing.Size(12, 132)
$DisableXButtonCheck.Checked = $DisablePSXButton
$DisableXButtonCheck.Text = " Disable the PowerShell console 'X' button"
$DisableXButtonCheck.Add_CheckStateChanged({ GUI_UpdateCheckBoxState ; PowershellButtonX -Disabled $this.Checked })
$CTTOptionsGroup.Controls.Add($DisableXButtonCheck)
$DisableXButtonCheckTip = New-Object System.Windows.Forms.ToolTip
$DisableXButtonCheckTip.InitialDelay = $ToolTipDelay
$DisableXButtonCheckTip.AutoPopDelay = $ToolTipDuration
$DisableXButtonCheckTipString = 'Disables the ability to press the "X" button to close the PowerShell {0}'
$DisableXButtonCheckTipString += 'console which also closes the script. This option exists because any {0}'
$DisableXButtonCheckTipString += 'options that were changed will not be updated if the script is closed {0}'
$DisableXButtonCheckTipString += 'in this way. If this functionality is preferred, uncheck this option.'
$DisableXButtonCheckTipString = [String]::Format($DisableXButtonCheckTipString, [Environment]::NewLine)
$DisableXButtonCheckTip.SetToolTip($DisableXButtonCheck, $DisableXButtonCheckTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# More Console Colors
$ConsoleColorsCheck = New-Object System.Windows.Forms.CheckBox
$ConsoleColorsCheck.Name = 'ConsoleColors'
$ConsoleColorsCheck.Size = New-Object System.Drawing.Size(260, 16)
$ConsoleColorsCheck.Location = New-Object System.Drawing.Size(12, 151)
$ConsoleColorsCheck.Checked = $ConsoleColors
$ConsoleColorsCheck.Text = ' Enable additional PowerShell console colors'
$ConsoleColorsCheck.Add_CheckStateChanged({ GUI_UpdateCheckBoxState })
$CTTOptionsGroup.Controls.Add($ConsoleColorsCheck)
$ConsoleColorsCheckTip = New-Object System.Windows.Forms.ToolTip
$ConsoleColorsCheckTip.InitialDelay = $ToolTipDelay
$ConsoleColorsCheckTip.AutoPopDelay = $ToolTipDuration
$ConsoleColorsTipString = 'Enable additional colors in the PowerShell console.'
$ConsoleColorsCheckTip.SetToolTip($ConsoleColorsCheck, $ConsoleColorsTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
function ChangeBackgroundColor([string]$ListItem)
{
  # Use the defaults that the console offers.
  if ($ListItem -eq 'Default')
  {
    # DarkMagenta is hideous in PowerShell v2.
    switch ($PSVersion.ToString())
    {
      '2'     { $ListItem = 'Black' }
      default { $ListItem = 'DarkMagenta' }
    }
  }
  # The host must be refreshed to see the change.
  [Console]::BackgroundColor = $ListItem
  Clear-Host
}
#----------------------------------------------------------------------------------------------------------------------------------------------
# Console Background Color
$BackgroundCombo = New-Object System.Windows.Forms.ComboBox
$BackgroundCombo.Name = 'BackgroundColor'
$BackgroundCombo.Size = New-Object System.Drawing.Size(94, 10)
$BackgroundCombo.Location = New-Object System.Drawing.Size(12, 172)
$BackgroundCombo.Items.Add('Default') | Out-Null
$BackgroundCombo.Items.Add('DarkMagenta') | Out-Null
$BackgroundCombo.Items.Add('DarkBlue') | Out-Null
$BackgroundCombo.Items.Add('DarkGreen') | Out-Null
$BackgroundCombo.Items.Add('DarkCyan') | Out-Null
$BackgroundCombo.Items.Add('DarkRed') | Out-Null
$BackgroundCombo.Items.Add('DarkGray') | Out-Null
$BackgroundCombo.Items.Add('Black') | Out-Null
$BackgroundCombo.SelectedItem = $BackgroundColor
$BackgroundCombo.Add_SelectedIndexChanged({ GUI_UpdateComboBoxState -NewValue $this.SelectedItem ; ChangeBackgroundColor -ListItem $this.SelectedItem })
$BackgroundCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
ChangeBackgroundColor -ListItem $BackgroundCombo.SelectedItem | Out-Null
$CTTOptionsGroup.Controls.Add($BackgroundCombo)
$BackgroundLabel = New-Object System.Windows.Forms.Label
$BackgroundLabel.Size = New-Object System.Drawing.Size(200, 16)
$BackgroundLabel.Location = New-Object System.Drawing.Size(108, 175)
$BackgroundLabel.Text = 'PowerShell Console Background Color'
$CTTOptionsGroup.Controls.Add($BackgroundLabel)
$BackgroundTip = New-Object System.Windows.Forms.ToolTip
$BackgroundTip.InitialDelay = $ToolTipDelay
$BackgroundTip.AutoPopDelay = $ToolTipDuration
$BackgroundTipString = 'Allows changing the background color of the console.'
$BackgroundTip.SetToolTip($BackgroundLabel, $BackgroundTipString)
#==============================================================================================================================================================================================
# CTT GUI - Create Option 1: Scan
#==============================================================================================================================================================================================
$ScanGroup = New-Object System.Windows.Forms.GroupBox
$ScanGroup.Size = New-Object System.Drawing.Size(380, 124)
$ScanGroup.Location = New-Object System.Drawing.Size(10, 260)
$ScanGroup.Text = ' Scan Textures Options '
$MainDialog.Controls.Add($ScanGroup)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Attempt Repairs
function S_RepairCheck()
{
  # This option enables/disables other options depending on its current check state.
  $S_ScaleFixNumBox.Enabled    = $this.Checked
  $S_ScaleFixLabel.Enabled     = $this.Checked
  $S_AspectFixNumBox.Enabled   = $this.Checked
  $S_AspectFixLabel.Enabled    = $this.Checked
}
#----------------------------------------------------------------------------------------------------------------------------------------------
$S_RepairCheck = New-Object System.Windows.Forms.CheckBox
$S_RepairCheck.Name = 'RepairTextures'
$S_RepairCheck.Size = New-Object System.Drawing.Size(158, 16)
$S_RepairCheck.Location = New-Object System.Drawing.Size(10, 20)
$S_RepairCheck.Checked = $RepairTextures
$S_RepairCheck.Text = ' Attempt Repairs    ------->'
$S_RepairCheck.Add_CheckStateChanged({ GUI_UpdateCheckBoxState ; S_RepairCheck })
$ScanGroup.Controls.Add($S_RepairCheck)
$S_RepairTip = New-Object System.Windows.Forms.ToolTip
$S_RepairTip.InitialDelay = $ToolTipDelay
$S_RepairTip.AutoPopDelay = $ToolTipDuration
$S_RepairTipString = 'Attempts to repair textures with issues. Repaired textures can{0}'
$S_RepairTipString += 'be found in the Output Path in the folder "RepairedTextures".{0}'
$S_RepairTipString += '{0}'
$S_RepairTipString += 'Issues that can be fixed with this option are:{0}'
$S_RepairTipString += '- Uneven Scale - Scaling value mismatch between width/height.{0}'
$S_RepairTipString += "- Bad Width/Height - Dimensions don't match calculated values.{0}"
$S_RepairTipString += "- Bad Aspect Ratio - Texture aspect doesn't match original.{0}"
$S_RepairTipString += '- Bad MipMap Scale - MipMap dimensions are incorrect.{0}'
$S_RepairTipString += '- Missing MipMaps - Some or all MipMap levels are missing.{0}'
$S_RepairTipString += '{0}'
$S_RepairTipString += 'By default, the script error checks DDS internal mipmaps. It will{0}'
$S_RepairTipString += 'check external mipmaps if "External DDS MipMaps" is checked.'
$S_RepairTipString = [String]::Format($S_RepairTipString, [Environment]::NewLine)
$S_RepairTip.SetToolTip($S_RepairCheck, $S_RepairTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Copy Bad Textures
$S_CopyBadCheck = New-Object System.Windows.Forms.CheckBox
$S_CopyBadCheck.Name = 'CopyBadTextures'
$S_CopyBadCheck.Size = New-Object System.Drawing.Size(125, 16)
$S_CopyBadCheck.Location = New-Object System.Drawing.Size(10, 40)
$S_CopyBadCheck.Checked = $CopyBadTextures
$S_CopyBadCheck.Text = ' Copy Bad Textures'
$S_CopyBadCheck.Add_CheckStateChanged({ GUI_UpdateCheckBoxState })
$ScanGroup.Controls.Add($S_CopyBadCheck)
$S_CopyBadTip = New-Object System.Windows.Forms.ToolTip
$S_CopyBadTip.InitialDelay = $ToolTipDelay
$S_CopyBadTip.AutoPopDelay = $ToolTipDuration
$S_CopyBadTipString = 'Copies textures that have issues to the Output Path in a{0}'
$S_CopyBadTipString += 'folder named "BrokenTextures".{0}'
$S_CopyBadTipString += '{0}'
$S_CopyBadTipString += 'If the option "Attempt Repairs" is enabled and a texture is{0}'
$S_CopyBadTipString += 'successfully repaired, then the texture will not be copied.'
$S_CopyBadTipString = [String]::Format($S_CopyBadTipString, [Environment]::NewLine)
$S_CopyBadTip.SetToolTip($S_CopyBadCheck, $S_CopyBadTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Hide OK Textures
function S_HideOkTextures()
{
  # When checked, also update all other "Hide OK Textures" checkboxes.
  $X_HideOKCheck.Checked = $this.Checked
  $Y_HideOKCheck.Checked = $this.Checked
}
#----------------------------------------------------------------------------------------------------------------------------------------------
$S_HideOKCheck = New-Object System.Windows.Forms.CheckBox
$S_HideOKCheck.Name = 'HideOKTextures'
$S_HideOKCheck.Size = New-Object System.Drawing.Size(120, 16)
$S_HideOKCheck.Location = New-Object System.Drawing.Size(10, 60)
$S_HideOKCheck.Checked = $HideOKTextures
$S_HideOKCheck.Text = ' Hide OK Textures'
$S_HideOKCheck.Add_CheckStateChanged({ GUI_UpdateCheckBoxState ; S_HideOkTextures })
$ScanGroup.Controls.Add($S_HideOKCheck)
$S_HideOKTip = New-Object System.Windows.Forms.ToolTip
$S_HideOKTip.InitialDelay = $ToolTipDelay
$S_HideOKTip.AutoPopDelay = $ToolTipDuration
$S_HideOKTipString = 'Textures that have no issues are flagged as "OK". This option{0}'
$S_HideOKTipString += 'prevents these textures from showing up in the log file.'
$S_HideOKTipString = [String]::Format($S_HideOKTipString, [Environment]::NewLine)
$S_HideOKTip.SetToolTip($S_HideOKCheck, $S_HideOKTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Ignore Duplicates
$S_IgnoreDupesCheck = New-Object System.Windows.Forms.CheckBox
$S_IgnoreDupesCheck.Name = 'IgnoreDuplicates'
$S_IgnoreDupesCheck.Size = New-Object System.Drawing.Size(120, 16)
$S_IgnoreDupesCheck.Location = New-Object System.Drawing.Size(10, 80)
$S_IgnoreDupesCheck.Checked = $IgnoreDuplicates
$S_IgnoreDupesCheck.Text = ' Ignore Duplicates'
$S_IgnoreDupesCheck.Add_CheckStateChanged({ GUI_UpdateCheckBoxState })
$ScanGroup.Controls.Add($S_IgnoreDupesCheck)
$S_IgnoreDupesTip = New-Object System.Windows.Forms.ToolTip
$S_IgnoreDupesTip.InitialDelay = $ToolTipDelay
$S_IgnoreDupesTip.AutoPopDelay = $ToolTipDuration
$S_IgnoreDupesTipString = 'This option disables the script from finding duplicate textures{0}'
$S_IgnoreDupesTipString += 'and printing them to the log. It can be useful to hide duplicates{0}'
$S_IgnoreDupesTipString += 'to prevent log spam if a pack contains "Optional Textures" that{0}'
$S_IgnoreDupesTipString += 'has many textures with the same name/hash.'
$S_IgnoreDupesTipString = [String]::Format($S_IgnoreDupesTipString, [Environment]::NewLine)
$S_IgnoreDupesTip.SetToolTip($S_IgnoreDupesCheck, $S_IgnoreDupesTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Allow Not HD Textures
$S_AllowNotHDCheck = New-Object System.Windows.Forms.CheckBox
$S_AllowNotHDCheck.Name = 'AllowNotHD'
$S_AllowNotHDCheck.Size = New-Object System.Drawing.Size(140, 16)
$S_AllowNotHDCheck.Location = New-Object System.Drawing.Size(10, 100)
$S_AllowNotHDCheck.Checked = $AllowNotHD
$S_AllowNotHDCheck.Text = ' Allow NotHD Textures'
$S_AllowNotHDCheck.Add_CheckStateChanged({ GUI_UpdateCheckBoxState })
$ScanGroup.Controls.Add($S_AllowNotHDCheck)
$S_AllowNotHDTip = New-Object System.Windows.Forms.ToolTip
$S_AllowNotHDTip.InitialDelay = $ToolTipDelay
$S_AllowNotHDTip.AutoPopDelay = $ToolTipDuration
$S_AllowNotHDTipString = 'Allows textures that have the same dimensions as the original{0}'
$S_AllowNotHDTipString += 'texture to pass validation and get treated as an HD texture.'
$S_AllowNotHDTipString = [String]::Format($S_AllowNotHDTipString, [Environment]::NewLine)
$S_AllowNotHDTip.SetToolTip($S_AllowNotHDCheck, $S_AllowNotHDTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Scale-Fix Threshold
function S_ScaleFix()
{
  # ScaleThreshold can be found on multiple menus so update them all.
  $C_ScaleFixNumBox.Value = $ScaleThreshold
}
#----------------------------------------------------------------------------------------------------------------------------------------------
$S_ScaleFixNumBox = New-Object System.Windows.Forms.NumericUpDown
$S_ScaleFixNumBox.Name = 'ScaleThreshold'
$S_ScaleFixNumBox.Size = New-Object System.Drawing.Size(70, 10)
$S_ScaleFixNumBox.Location = New-Object System.Drawing.Size(174, 18)
$S_ScaleFixNumBox.DecimalPlaces = 2
$S_ScaleFixNumBox.Value = $ScaleThreshold
$S_ScaleFixNumBox.Minimum = 0.00
$S_ScaleFixNumBox.Maximum = 0.99
$S_ScaleFixNumBox.Increment = 0.01
$S_ScaleFixNumBox.Add_ValueChanged({ GUI_UpdateNumericUpDown -TypeDefinition 'decimal' ; S_ScaleFix })
$S_ScaleFixNumBox.Enabled = $RepairTextures
$S_ScaleFixLabel = New-Object System.Windows.Forms.Label
$S_ScaleFixLabel.Size = New-Object System.Drawing.Size(120, 22)
$S_ScaleFixLabel.Location = New-Object System.Drawing.Size(248, 20)
$S_ScaleFixLabel.Text = 'Scale-Fix Threshold'
$S_ScaleFixLabel.Enabled = $RepairTextures
$ScanGroup.Controls.Add($S_ScaleFixNumBox)
$ScanGroup.Controls.Add($S_ScaleFixLabel)
$S_ScaleFixTip = New-Object System.Windows.Forms.ToolTip
$S_ScaleFixTip.InitialDelay = $ToolTipDelay
$S_ScaleFixTip.AutoPopDelay = $ToolTipDuration
$S_ScaleFixTipString = 'Sets the minimum decimal value of the scale to auto-repair{0}'
$S_ScaleFixTipString += 'textures to the next highest integer scale.{0}'
$S_ScaleFixTipString += '{0}'
$S_ScaleFixTipString += 'Example: Scale-Fix Threshold = 0.45 will upscale 4.45-4.99{0}'
$S_ScaleFixTipString += 'to 5x scale, but downscale 4.01-4.44 to 4x scale.'
$S_ScaleFixTipString = [String]::Format($S_ScaleFixTipString, [Environment]::NewLine)
$S_ScaleFixTip.SetToolTip($S_ScaleFixLabel, $S_ScaleFixTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Aspect-Fix Threshold
$S_AspectFixNumBox = New-Object System.Windows.Forms.NumericUpDown
$S_AspectFixNumBox.Name = 'AspectThreshold'
$S_AspectFixNumBox.Size = New-Object System.Drawing.Size(70, 10)
$S_AspectFixNumBox.Location = New-Object System.Drawing.Size(174, 42)
$S_AspectFixNumBox.DecimalPlaces = 2
$S_AspectFixNumBox.Value = $AspectThreshold
$S_AspectFixNumBox.Minimum = 0.00
$S_AspectFixNumBox.Maximum = 0.99
$S_AspectFixNumBox.Increment = 0.01
$S_AspectFixNumBox.Add_ValueChanged({ GUI_UpdateNumericUpDown -TypeDefinition 'decimal' })
$S_AspectFixNumBox.Enabled = $RepairTextures
$S_AspectFixLabel = New-Object System.Windows.Forms.Label
$S_AspectFixLabel.Size = New-Object System.Drawing.Size(120, 22)
$S_AspectFixLabel.Location = New-Object System.Drawing.Size(248, 44)
$S_AspectFixLabel.Text = 'Aspect-Fix Threshold'
$S_AspectFixLabel.Enabled = $RepairTextures
$ScanGroup.Controls.Add($S_AspectFixNumBox)
$ScanGroup.Controls.Add($S_AspectFixLabel)
$S_AspectFixTip = New-Object System.Windows.Forms.ToolTip
$S_AspectFixTip.InitialDelay = $ToolTipDelay
$S_AspectFixTip.AutoPopDelay = $ToolTipDuration
$S_AspectFixTipString = 'Sets a minimum limit of aspect ratio difference between the original and{0}'
$S_AspectFixTipString += 'custom texture. Aspect is calculated from dividing the width by the height,{0}'
$S_AspectFixTipString += 'and both the original and custom texture should have identical aspects. The{0}'
$S_AspectFixTipString += 'value of Aspect-Fix Threshold is compared against the original texture aspect{0}'
$S_AspectFixTipString += 'minus the custom texture aspect. It is not suggested to use a value above 0.10.{0}'
$S_AspectFixTipString += '{0}'
$S_AspectFixTipString += 'Example: {0}'
$S_AspectFixTipString += 'Original = 200x32  - Aspect 6.25{0}'
$S_AspectFixTipString += 'Custom  = 800x130 - Aspect 6.15{0}'
$S_AspectFixTipString += 'Aspects 6.25 - 6.15 = 0.10 Aspect Difference{0}'
$S_AspectFixTipString += 'Minimum Aspect-Fix Threshold = 0.10 to Auto-Repair Texture'
$S_AspectFixTipString = [String]::Format($S_AspectFixTipString, [Environment]::NewLine)
$S_AspectFixTip.SetToolTip($S_AspectFixLabel, $S_AspectFixTipString)
#==============================================================================================================================================================================================
# Create Option 2: Convert Textures
#==============================================================================================================================================================================================
$ConvertGroup = New-Object System.Windows.Forms.GroupBox
$ConvertGroup.Size = New-Object System.Drawing.Size(380, 124)
$ConvertGroup.Location = New-Object System.Drawing.Size(10, 260)
$ConvertGroup.Text = ' Convert Textures Options '
$MainDialog.Controls.Add($ConvertGroup)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Output Format
$C_FormatCombo = New-Object System.Windows.Forms.ComboBox
$C_FormatCombo.Name = 'ConvertFormat'
$C_FormatCombo.Size = New-Object System.Drawing.Size(80, 10)
$C_FormatCombo.Location = New-Object System.Drawing.Size(10, 20)
$C_FormatCombo.Items.Add('PNG') | Out-Null
$C_FormatCombo.Items.Add('DDS') | Out-Null
$C_FormatCombo.Items.Add('JPG') | Out-Null
$C_FormatCombo.SelectedItem = ExtensionToText -FileExt $ConvertFormat
$C_FormatCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$C_FormatCombo.Add_SelectedIndexChanged({ GUI_UpdateComboBoxState -NewValue (Get-Variable -Name $this.SelectedItem -ValueOnly) })
$C_FormatLabel = New-Object System.Windows.Forms.Label
$C_FormatLabel.Size = New-Object System.Drawing.Size(90, 22)
$C_FormatLabel.Location = New-Object System.Drawing.Size(94, 23)
$C_FormatLabel.Text = 'Output Format'
$ConvertGroup.Controls.Add($C_FormatCombo)
$ConvertGroup.Controls.Add($C_FormatLabel)
$C_FormatTip = New-Object System.Windows.Forms.ToolTip
$C_FormatTip.InitialDelay = $ToolTipDelay
$C_FormatTip.AutoPopDelay = $ToolTipDuration
$C_FormatTipString = 'The output format that textures will be created.'
$C_FormatTipString = [String]::Format($C_FormatTipString, [Environment]::NewLine)
$C_FormatTip.SetToolTip($C_FormatLabel, $C_FormatTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Copy Non-Textures
function C_CopyNonCheck()
{
  # Also update this checkbox on the "Rescale" option.
  $R_CopyNonCheck.Checked = $this.Checked
}
#----------------------------------------------------------------------------------------------------------------------------------------------
$C_CopyNonCheck = New-Object System.Windows.Forms.CheckBox
$C_CopyNonCheck.Name = 'CopyNonTextures'
$C_CopyNonCheck.Size = New-Object System.Drawing.Size(130, 16)
$C_CopyNonCheck.Location = New-Object System.Drawing.Size(10, 48)
$C_CopyNonCheck.Checked = $CopyNonTextures
$C_CopyNonCheck.Text = ' Copy Non-Textures'
$C_CopyNonCheck.Add_CheckStateChanged({ GUI_UpdateCheckBoxState ; C_CopyNonCheck })
$ConvertGroup.Controls.Add($C_CopyNonCheck)
$C_CopyNonTip = New-Object System.Windows.Forms.ToolTip
$C_CopyNonTip.InitialDelay = $ToolTipDelay
$C_CopyNonTip.AutoPopDelay = $ToolTipDuration
$C_CopyNonTipString = 'Copies files that are not images (such as .txt) into the newly generated pack.'
$C_CopyNonTip.SetToolTip($C_CopyNonCheck, $C_CopyNonTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Auto-Repair Dimensions
function C_AutoRepair()
{
  # Toggle the "Scale-Fix Threshold" options.
  $C_ScaleFixLabel.Enabled  = $this.Checked
  $C_ScaleFixNumBox.Enabled = $this.Checked
}
#----------------------------------------------------------------------------------------------------------------------------------------------
$C_AutoRepairCheck = New-Object System.Windows.Forms.CheckBox
$C_AutoRepairCheck.Name = 'ConvertRepair'
$C_AutoRepairCheck.Size = New-Object System.Drawing.Size(150, 16)
$C_AutoRepairCheck.Location = New-Object System.Drawing.Size(192, 24)
$C_AutoRepairCheck.Checked = $ConvertRepair
$C_AutoRepairCheck.Text = ' Auto-Repair Dimensions'
$C_AutoRepairCheck.Add_CheckStateChanged({ GUI_UpdateCheckBoxState ; C_AutoRepair })
$ConvertGroup.Controls.Add($C_AutoRepairCheck)
$C_AutoRepairTip = New-Object System.Windows.Forms.ToolTip
$C_AutoRepairTip.InitialDelay = $ToolTipDelay
$C_AutoRepairTip.AutoPopDelay = $ToolTipDuration
$C_AutoRepairTipString = 'Attempts to repair textures with fractional scaling values. Enabling this option recalculates all dimensions{0}'
$C_AutoRepairTipString += 'by multiplying the original dimensions * lowest integer scale between width and height. Scale-Fix Threshold{0}'
$C_AutoRepairTipString += 'determines if this integer is rounded up or down based on the decimal value of the current scale.{0}'
$C_AutoRepairTipString += '{0}'
$C_AutoRepairTipString += 'Examples: {0}'
$C_AutoRepairTipString += 'Auto-Repair=True  Original=24x24 Custom=75x75 (scale 3.12) PNG-New=72x72 DDS-New=72x72 Correct=72x72{0}'
$C_AutoRepairTipString += 'Auto-Repair=False Original=24x24 Custom=75x75 (scale 3.12) PNG-New=75x75 DDS-New=76x76 Correct=72x72{0}'
$C_AutoRepairTipString += '{0}'
$C_AutoRepairTipString += 'Setting this option to "True" is useful to get the most accurate dimensions and fix bad scales/aspect ratios.{0}'
$C_AutoRepairTipString += 'Setting this option to "False" is useful when textures have very low scaling values or mismatched aspect ratios.'
$C_AutoRepairTipString = [String]::Format($C_AutoRepairTipString, [Environment]::NewLine)
$C_AutoRepairTip.SetToolTip($C_AutoRepairCheck, $C_AutoRepairTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Scale-Fix Threshold
function C_ScaleFix()
{
  # ScaleThreshold can be found on multiple menus so update them all.
  $S_ScaleFixNumBox.Value = $ScaleThreshold
}
#----------------------------------------------------------------------------------------------------------------------------------------------
$C_ScaleFixNumBox = New-Object System.Windows.Forms.NumericUpDown
$C_ScaleFixNumBox.Name = 'ScaleThreshold'
$C_ScaleFixNumBox.Size = New-Object System.Drawing.Size(50, 10)
$C_ScaleFixNumBox.Location = New-Object System.Drawing.Size(192, 46)
$C_ScaleFixNumBox.DecimalPlaces = 2
$C_ScaleFixNumBox.Value = $ScaleThreshold
$C_ScaleFixNumBox.Minimum = 0.00
$C_ScaleFixNumBox.Maximum = 0.99
$C_ScaleFixNumBox.Increment = 0.01
$C_ScaleFixNumBox.Add_ValueChanged({ GUI_UpdateNumericUpDown -TypeDefinition 'decimal' ; C_ScaleFix })
$C_ScaleFixNumBox.Enabled = $ConvertRepair
$ConvertGroup.Controls.Add($C_ScaleFixNumBox)
$C_ScaleFixLabel = New-Object System.Windows.Forms.Label
$C_ScaleFixLabel.Size = New-Object System.Drawing.Size(108, 22)
$C_ScaleFixLabel.Location = New-Object System.Drawing.Size(244, 49)
$C_ScaleFixLabel.Text = 'Scale-Fix Threshold'
$C_ScaleFixLabel.Enabled = $ConvertRepair
$ConvertGroup.Controls.Add($C_ScaleFixLabel)
$C_ScaleFixTip = New-Object System.Windows.Forms.ToolTip
$C_ScaleFixTip.InitialDelay = $ToolTipDelay
$C_ScaleFixTip.AutoPopDelay = $ToolTipDuration
$C_ScaleFixTipString = 'Sets the minimum decimal value of the scale to auto-repair{0}'
$C_ScaleFixTipString += 'textures to the next highest integer scale.{0}'
$C_ScaleFixTipString += '{0}'
$C_ScaleFixTipString += 'Example: Scale-Fix Threshold = 0.45 will upscale 4.45-4.99{0}'
$C_ScaleFixTipString += 'to 5x scale, but downscale 4.01-4.44 to 4x scale.'
$C_ScaleFixTipString = [String]::Format($C_ScaleFixTipString, [Environment]::NewLine)
$C_ScaleFixTip.SetToolTip($C_ScaleFixLabel, $C_ScaleFixTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Auto-Rename Output Pack
function C_AutoName()
{
  # Enable/disable the text box depending on the check state.
  $C_AutoNameTextBox.Enabled = $this.Checked 
  $C_AutoNameButton.Enabled  = $this.Checked 

  # If the box is checked and text has yet to be set.
  if (($this.Checked ) -and ($C_AutoNameTextBox.Text -eq ''))
  {
    # Set the textbox to the name of the deepest folder found in the master input path.
    $FindTexturePath = $MasterInputPath.Split('\')
    $C_AutoNameTextBox.Text = $FindTexturePath[-1]
    $global:AutoTextConvert = $FindTexturePath[-1]
  }
}
#----------------------------------------------------------------------------------------------------------------------------------------------
$global:AutoRenameConvert  = $false
$global:AutoTextConvert    = ''
#----------------------------------------------------------------------------------------------------------------------------------------------
$C_AutoNameCheck = New-Object System.Windows.Forms.Checkbox
$C_AutoNameCheck.Name = 'AutoRenameConvert'
$C_AutoNameCheck.Size = New-Object System.Drawing.Size(150, 16)
$C_AutoNameCheck.Location = New-Object System.Drawing.Size(192, 74)
$C_AutoNameCheck.Checked = $AutoRenameConvert
$C_AutoNameCheck.Text = ' Auto-Rename Output:'
$C_AutoNameCheck.Add_CheckStateChanged({ GUI_UpdateCheckBoxState ; C_AutoName })
$ConvertGroup.Controls.Add($C_AutoNameCheck)
$C_AutoNameTextBox = New-Object System.Windows.Forms.TextBox
$C_AutoNameTextBox.Name = 'AutoTextConvert'
$C_AutoNameTextBox.Size = New-Object System.Drawing.Size(150, 20)
$C_AutoNameTextBox.Location = New-Object System.Drawing.Size(192, 92)
$C_AutoNameTextBox.Text = ''
$C_AutoNameTextBox.Enabled = $AutoRenameConvert
$C_AutoNameTextBox.Add_Leave({ GUI_VerifyAutoNameText })
$ConvertGroup.Controls.Add($C_AutoNameTextBox)
$C_AutoNameTip = New-Object System.Windows.Forms.ToolTip
$C_AutoNameTip.InitialDelay = $ToolTipDelay
$C_AutoNameTip.AutoPopDelay = $ToolTipDuration
$C_AutoNameTipString = 'Automatically renames the "ConvertedTextures" folder to the specified text{0}'
$C_AutoNameTipString += 'entered here. If no value is entered, the folder will not be renamed. This{0}'
$C_AutoNameTipString += "should usually be the first 3 letters of the texture pack's GameID."
$C_AutoNameTipString = [String]::Format($C_AutoNameTipString, [Environment]::NewLine)
$C_AutoNameTip.SetToolTip($C_AutoNameCheck, $C_AutoNameTipString)
$C_AutoNameButton = New-Object System.Windows.Forms.Button
$C_AutoNameButton.Size = New-Object System.Drawing.Size(20, 20)
$C_AutoNameButton.Location = New-Object System.Drawing.Size(348, 92)
$C_AutoNameButton.Text = '-'
$C_AutoNameButton.Enabled = $AutoRenameConvert
$C_AutoNameButton.Add_Click({ $C_AutoNameTextBox.Text = '' ; $global:AutoTextConvert = '' })
$ConvertGroup.Controls.Add($C_AutoNameButton)
#==============================================================================================================================================================================================
# CTT GUI - Create Option 3: Rescale Textures
#==============================================================================================================================================================================================
$RescaleGroup = New-Object System.Windows.Forms.GroupBox
$RescaleGroup.Size = New-Object System.Drawing.Size(380, 124)
$RescaleGroup.Location = New-Object System.Drawing.Size(10, 260)
$RescaleGroup.Text = ' Rescale Textures Options '
$MainDialog.Controls.Add($RescaleGroup)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Rescale Factor
$R_FactorNumBox = New-Object System.Windows.Forms.NumericUpDown
$R_FactorNumBox.Name = 'RescaleFactor'
$R_FactorNumBox.Size = New-Object System.Drawing.Size(80, 10)
$R_FactorNumBox.Location = New-Object System.Drawing.Size(10, 20)
$R_FactorNumBox.DecimalPlaces = 2
$R_FactorNumBox.Value = $RescaleFactor
$R_FactorNumBox.Minimum = 0.01
$R_FactorNumBox.Maximum = 16.00
$R_FactorNumBox.Increment = 1.00
$R_FactorNumBox.Add_ValueChanged({ GUI_UpdateNumericUpDown -TypeDefinition 'decimal' })
$R_FactorLabel = New-Object System.Windows.Forms.Label
$R_FactorLabel.Size = New-Object System.Drawing.Size(100, 22)
$R_FactorLabel.Location = New-Object System.Drawing.Size(92, 22)
$R_FactorLabel.Text = 'Rescale Factor'
$RescaleGroup.Controls.Add($R_FactorNumBox)
$RescaleGroup.Controls.Add($R_FactorLabel)
$R_FactorTip = New-Object System.Windows.Forms.ToolTip
$R_FactorTip.InitialDelay = $ToolTipDelay
$R_FactorTip.AutoPopDelay = $ToolTipDuration
$R_FactorTipString = 'The multiplicand that is used to rescale textures. The new{0}'
$R_FactorTipString += 'dimensions of the custom texture are calculated using{0}'
$R_FactorTipString += 'the equation: (Original Dimensions * Rescale Factor).{0}'
$R_FactorTipString += '{0}'
$R_FactorTipString += 'Decimal values are NOT suggested for Dolphin textures!'
$R_FactorTipString = [String]::Format($R_FactorTipString, [Environment]::NewLine)
$R_FactorTip.SetToolTip($R_FactorLabel, $R_FactorTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Output Format
$R_FormatCombo = New-Object System.Windows.Forms.ComboBox
$R_FormatCombo.Name = 'RescaleFormat'
$R_FormatCombo.Size = New-Object System.Drawing.Size(80, 28)
$R_FormatCombo.Location = New-Object System.Drawing.Size(10, 45)
$R_FormatCombo.Items.Add('PNG') | Out-Null
$R_FormatCombo.Items.Add('DDS') | Out-Null
$R_FormatCombo.Items.Add('JPG') | Out-Null
$R_FormatCombo.SelectedItem = ExtensionToText -FileExt $RescaleFormat
$R_FormatCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$R_FormatCombo.Add_SelectedIndexChanged({ GUI_UpdateComboBoxState -NewValue (Get-Variable -Name $this.SelectedItem -ValueOnly) })
$R_FormatLabel = New-Object System.Windows.Forms.Label
$R_FormatLabel.Size = New-Object System.Drawing.Size(100, 22)
$R_FormatLabel.Location = New-Object System.Drawing.Size(92, 48)
$R_FormatLabel.Text = 'Output Format'
$RescaleGroup.Controls.Add($R_FormatCombo)
$RescaleGroup.Controls.Add($R_FormatLabel)
$R_FormatTip = New-Object System.Windows.Forms.ToolTip
$R_FormatTip.InitialDelay = $ToolTipDelay
$R_FormatTip.AutoPopDelay = $ToolTipDuration
$R_FormatTipString = 'The output format that textures will be created.'
$R_FormatTipString = [String]::Format($R_FormatTipString, [Environment]::NewLine)
$R_FormatTip.SetToolTip($R_FormatLabel, $R_FormatTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Rescale Condition
$R_ScalingCombo = New-Object System.Windows.Forms.ComboBox
$R_ScalingCombo.Name = 'RescaleScaling'
$R_ScalingCombo.Size = New-Object System.Drawing.Size(80, 28)
$R_ScalingCombo.Location = New-Object System.Drawing.Size(192, 20)
$R_ScalingCombo.Items.Add('Always') | Out-Null
$R_ScalingCombo.Items.Add('Downscale') | Out-Null
$R_ScalingCombo.Items.Add('Upscale') | Out-Null
$R_ScalingCombo.SelectedItem = $RescaleScaling
$R_ScalingCombo.Add_SelectedIndexChanged({ GUI_UpdateComboBoxState -NewValue $this.SelectedItem })
$R_ScalingCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$R_ScalingLabel = New-Object System.Windows.Forms.Label
$R_ScalingLabel.Size = New-Object System.Drawing.Size(100, 22)
$R_ScalingLabel.Location = New-Object System.Drawing.Size(274, 23)
$R_ScalingLabel.Text = 'Rescale Condition'
$RescaleGroup.Controls.Add($R_ScalingCombo)
$RescaleGroup.Controls.Add($R_ScalingLabel)
$R_ScalingTip = New-Object System.Windows.Forms.ToolTip
$R_ScalingTip.InitialDelay = $ToolTipDelay
$R_ScalingTip.AutoPopDelay = $ToolTipDuration
$R_ScalingTipString = 'Filters which textures are rescaled. The value entered for the{0}'
$R_ScalingTipString += "Rescale Factor is compared against the texture's current scale{0}"
$R_ScalingTipString += 'and only allows a rescale to take place if the condition is met.{0}'
$R_ScalingTipString += '{0}'
$R_ScalingTipString += 'Always: Textures will always be rescaled in either direction.{0}'
$R_ScalingTipString += '{0}'
$R_ScalingTipString += "Downscale: Only rescale textures with a scale that is greater{0}"
$R_ScalingTipString += "than the Rescale Factor. Prevents upscaling smaller textures.{0}"
$R_ScalingTipString += "{0}"
$R_ScalingTipString += "Upscale: Only rescale textures with a scale that is lesser{0}"
$R_ScalingTipString += "than the Rescale Factor. Prevents downscaling larger textures."
$R_ScalingTipString = [String]::Format($R_ScalingTipString, [Environment]::NewLine)
$R_ScalingTip.SetToolTip($R_ScalingLabel, $R_ScalingTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Copy Non-Textures
function R_CopyNonCheck()
{
  # Also update this checkbox on the "Convert" option.
  $C_CopyNonCheck.Checked = $this.Checked
}
#----------------------------------------------------------------------------------------------------------------------------------------------
$R_CopyNonCheck = New-Object System.Windows.Forms.CheckBox
$R_CopyNonCheck.Name = 'CopyNonTextures'
$R_CopyNonCheck.Size = New-Object System.Drawing.Size(130, 16)
$R_CopyNonCheck.Location = New-Object System.Drawing.Size(10, 72)
$R_CopyNonCheck.Checked = $CopyNonTextures
$R_CopyNonCheck.Text = ' Copy Non-Textures'
$R_CopyNonCheck.Add_CheckStateChanged({ GUI_UpdateCheckBoxState ; R_CopyNonCheck})
$RescaleGroup.Controls.Add($R_CopyNonCheck)
$R_CopyNonTip = New-Object System.Windows.Forms.ToolTip
$R_CopyNonTip.InitialDelay = $ToolTipDelay
$R_CopyNonTip.AutoPopDelay = $ToolTipDuration
$R_CopyNonTipString = 'Copies files that are not images (such as .txt) into the newly generated pack.'
$R_CopyNonTip.SetToolTip($R_CopyNonCheck, $R_CopyNonTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Manual Rescale
$R_ManualCheck = New-Object System.Windows.Forms.CheckBox
$R_ManualCheck.Name = 'ManualRescale'
$R_ManualCheck.Size = New-Object System.Drawing.Size(130, 16)
$R_ManualCheck.Location = New-Object System.Drawing.Size(192, 50)
$R_ManualCheck.Checked = $ManualRescale
$R_ManualCheck.Text = ' Manual Rescale'
$R_ManualCheck.Add_CheckStateChanged({ GUI_UpdateCheckBoxState })
$RescaleGroup.Controls.Add($R_ManualCheck)
$R_ManualTip = New-Object System.Windows.Forms.ToolTip
$R_ManualTip.InitialDelay = $ToolTipDelay
$R_ManualTip.AutoPopDelay = $ToolTipDuration
$R_ManualTipString = 'This option allows rescaling each texture individually with a different integer{0}'
$R_ManualTipString += 'scale chosen by the user. Very large scaling values from 1-100 are allowed to be{0}'
$R_ManualTipString += 'set in this mode so choose reasonable values. The amount that was entered for{0}'
$R_ManualTipString += '"Rescale Factor" acts as a default value, which will be used if no value is entered{0}'
$R_ManualTipString += 'when prompted.{0}'
$R_ManualTipString += '{0}'
$R_ManualTipString += 'It is NOT suggested to use this option on packs with a lot of textures as it will{0}'
$R_ManualTipString += 'take forever to rescale them all. The purpose of this option is to rescale a folder{0}'
$R_ManualTipString += 'with only a few textures that require different scaling values.'
$R_ManualTipString = [String]::Format($R_ManualTipString, [Environment]::NewLine)
$R_ManualTip.SetToolTip($R_ManualCheck, $R_ManualTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Auto-Rename Output Pack
function R_AutoName()
{
  # Enable/disable the text box depending on the check state.
  $R_AutoNameTextBox.Enabled = $this.Checked 
  $R_AutoNameButton.Enabled  = $this.Checked 

  # If the box is checked and text has yet to be set.
  if (($this.Checked ) -and ($R_AutoNameTextBox.Text -eq ''))
  {
    # Set the textbox to the name of the deepest folder found in the master input path.
    $FindTexturePath = $MasterInputPath.Split('\')
    $R_AutoNameTextBox.Text = $FindTexturePath[-1]
    $global:AutoTextRescale = $FindTexturePath[-1]
  }
}
#----------------------------------------------------------------------------------------------------------------------------------------------
function GUI_VerifyAutoNameText()
{
  # Do not allow illegal characters, only alpha-numeric values and spaces.
  if ($this.Text -match "^[a-zA-Z0-9- ]+$")
  {
    Set-Variable -Name $this.Name -Value $this.Text -Scope 'Global'
  }
  # If the text was illegal clear the text box and reset the variable.
  else
  {
    $this.Text = ''
    Set-Variable -Name $this.Name -Value '' -Scope 'Global'
  }
}
#----------------------------------------------------------------------------------------------------------------------------------------------
$global:AutoRenameRescale  = $false
$global:AutoTextRescale    = ''
#----------------------------------------------------------------------------------------------------------------------------------------------
$R_AutoNameCheck = New-Object System.Windows.Forms.Checkbox
$R_AutoNameCheck.Name = 'AutoRenameRescale'
$R_AutoNameCheck.Size = New-Object System.Drawing.Size(150, 16)
$R_AutoNameCheck.Location = New-Object System.Drawing.Size(192, 74)
$R_AutoNameCheck.Checked = $AutoRenameRescale
$R_AutoNameCheck.Text = ' Auto-Rename Output:'
$R_AutoNameCheck.Add_CheckStateChanged({ GUI_UpdateCheckBoxState ; R_AutoName })
$R_AutoNameTextBox = New-Object System.Windows.Forms.TextBox
$R_AutoNameTextBox.Name = 'AutoTextRescale'
$R_AutoNameTextBox.Size = New-Object System.Drawing.Size(150, 20)
$R_AutoNameTextBox.Location = New-Object System.Drawing.Size(192, 92)
$R_AutoNameTextBox.Text = ''
$R_AutoNameTextBox.Enabled = $AutoRenameRescale
$R_AutoNameTextBox.Add_Leave({ GUI_VerifyAutoNameText })
$RescaleGroup.Controls.Add($R_AutoNameCheck)
$RescaleGroup.Controls.Add($R_AutoNameTextBox)
$R_AutoNameTip = New-Object System.Windows.Forms.ToolTip
$R_AutoNameTip.InitialDelay = $ToolTipDelay
$R_AutoNameTip.AutoPopDelay = $ToolTipDuration
$R_AutoNameTipString = 'Automatically renames the "RescaledTextures" folder to the specified text{0}'
$R_AutoNameTipString += 'entered here. If no value is entered, the folder will not be renamed. This{0}'
$R_AutoNameTipString += "should usually be the first 3 letters of the texture pack's GameID."
$R_AutoNameTipString = [String]::Format($R_AutoNameTipString, [Environment]::NewLine)
$R_AutoNameTip.SetToolTip($R_AutoNameCheck, $R_AutoNameTipString)
$R_AutoNameButton = New-Object System.Windows.Forms.Button
$R_AutoNameButton.Size = New-Object System.Drawing.Size(20, 20)
$R_AutoNameButton.Location = New-Object System.Drawing.Size(348, 92)
$R_AutoNameButton.Text = '-'
$R_AutoNameButton.Enabled = $AutoRenameRescale
$R_AutoNameButton.Add_Click({ $R_AutoNameTextBox.Text = '' ; $global:AutoTextRescale = '' })
$RescaleGroup.Controls.Add($R_AutoNameButton)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Create Option 4: Watermark Textures
#----------------------------------------------------------------------------------------------------------------------------------------------
$WatermarkGroup = New-Object System.Windows.Forms.GroupBox
$WatermarkGroup.Size = New-Object System.Drawing.Size(380, 124)
$WatermarkGroup.Location = New-Object System.Drawing.Size(10, 260)
$WatermarkGroup.Text = ' Watermark Options '
$MainDialog.Controls.Add($WatermarkGroup)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Text Length
$W_TextLengthNumBox = New-Object System.Windows.Forms.NumericUpDown
$W_TextLengthNumBox.Name = 'WM_Length'
$W_TextLengthNumBox.Size = New-Object System.Drawing.Size(82, 10)
$W_TextLengthNumBox.Location = New-Object System.Drawing.Size(10, 20)
$W_TextLengthNumBox.DecimalPlaces = 0
$W_TextLengthNumBox.Value = $WM_Length
$W_TextLengthNumBox.Minimum = 0
$W_TextLengthNumBox.Maximum = 22
$W_TextLengthNumBox.Increment = 1
$W_TextLengthNumBox.Add_ValueChanged({ GUI_UpdateNumericUpDown -TypeDefinition 'integer' })
$W_TextLengthLabel = New-Object System.Windows.Forms.Label
$W_TextLengthLabel.Size = New-Object System.Drawing.Size(70, 22)
$W_TextLengthLabel.Location = New-Object System.Drawing.Size(93, 22)
$W_TextLengthLabel.Text = 'Text Length'
$WatermarkGroup.Controls.Add($W_TextLengthNumBox)
$WatermarkGroup.Controls.Add($W_TextLengthLabel)
$W_TextLengthTip = New-Object System.Windows.Forms.ToolTip
$W_TextLengthTip.InitialDelay = $ToolTipDelay
$W_TextLengthTip.AutoPopDelay = $ToolTipDuration
$W_TextLengthTipString = 'Defines how many characters to pull from the end of the texture{0}'
$W_TextLengthTipString += 'name to display on the texture as a watermark. If a value of 0 is{0}'
$W_TextLengthTipString += 'entered, then the script will use the entire name of the texture. If{0}'
$W_TextLengthTipString += 'a value of 1-5 is entered, than a value of 6 will be forced internally.'
$W_TextLengthTipString = [String]::Format($W_TextLengthTipString, [Environment]::NewLine)
$W_TextLengthTip.SetToolTip($W_TextLengthLabel, $W_TextLengthTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Font Size
$W_FontSizeNumBox = New-Object System.Windows.Forms.NumericUpDown
$W_FontSizeNumBox.Name = 'WM_FontSize'
$W_FontSizeNumBox.Size = New-Object System.Drawing.Size(82, 10)
$W_FontSizeNumBox.Location = New-Object System.Drawing.Size(10, 44)
$W_FontSizeNumBox.DecimalPlaces = 0
$W_FontSizeNumBox.Value = $WM_FontSize
$W_FontSizeNumBox.Minimum = 1
$W_FontSizeNumBox.Maximum = 20
$W_FontSizeNumBox.Increment = 1
$W_FontSizeNumBox.Add_ValueChanged({ GUI_UpdateNumericUpDown -TypeDefinition 'integer' })
$W_FontSizeLabel = New-Object System.Windows.Forms.Label
$W_FontSizeLabel.Size = New-Object System.Drawing.Size(60, 22)
$W_FontSizeLabel.Location = New-Object System.Drawing.Size(93, 47)
$W_FontSizeLabel.Text = 'Font Size'
$WatermarkGroup.Controls.Add($W_FontSizeNumBox)
$WatermarkGroup.Controls.Add($W_FontSizeLabel)
$W_FontSizeTip = New-Object System.Windows.Forms.ToolTip
$W_FontSizeTip.InitialDelay = $ToolTipDelay
$W_FontSizeTip.AutoPopDelay = $ToolTipDuration
$W_FontSizeTipString = 'Defines the size of the font that will be used for the watermark. This{0}'
$W_FontSizeTipString += 'is not the fonts actual size, it is instead a multiplier used to scale the{0}'
$W_FontSizeTipString += 'font using the formula (NewWidth / 128 * FontSize). This ensures{0}'
$W_FontSizeTipString += 'that the font remains a constant size across all textures.'
$W_FontSizeTipString = [String]::Format($W_FontSizeTipString, [Environment]::NewLine)
$W_FontSizeTip.SetToolTip($W_FontSizeLabel, $W_FontSizeTipString)
#==============================================================================================================================================================================================
#  Allows selecting a color for the text or background when using the "Create Watermark" option.

function GUI_ShowColorDialog()
{
  # Create and show a color dialog to the user.
  $ColorDialog = New-Object System.Windows.Forms.ColorDialog
  $Selection = $ColorDialog.ShowDialog()

  # Check to see if the color selection passed when the dialog was closed.
  if ($Selection -eq 'OK')
  {
    # Get the old color that is stored in the variable name pulled from the button.
    $OldColor = Get-Variable -Name $this.Name -ValueOnly

    # Compile the color into HTML format by converting each value to hexadecimal.
    $NewColor = '#' + $ColorDialog.Color.R.ToString('X2') + $ColorDialog.Color.G.ToString('X2') + $ColorDialog.Color.B.ToString('X2')

    # Update the text and the color displayed on the button.
    $this.Text = $NewColor
    $this.BackColor = $NewColor

    # Update the script with the new color value.
    Set-Variable -Name $this.Name -Value $NewColor -Scope 'Global'
  }
}
#----------------------------------------------------------------------------------------------------------------------------------------------
# Font FG Color
$W_FGColorButton = New-Object System.Windows.Forms.Button
$W_FGColorButton.Name = 'WM_FontColor'
$W_FGColorButton.Size = New-Object System.Drawing.Size(80, 22)
$W_FGColorButton.Location = New-Object System.Drawing.Size(10, 68)
$W_FGColorButton.Text = $WM_FontColor
$W_FGColorButton.BackColor = $WM_FontColor
$W_FGColorButton.Add_Click({ GUI_ShowColorDialog })
$W_FGColorLabel = New-Object System.Windows.Forms.Label
$W_FGColorLabel.Size = New-Object System.Drawing.Size(108, 22)
$W_FGColorLabel.Location = New-Object System.Drawing.Size(93, 72)
$W_FGColorLabel.Text = 'Font FG Color'
$WatermarkGroup.Controls.Add($W_FGColorButton)
$WatermarkGroup.Controls.Add($W_FGColorLabel)
$W_FGColorTip = New-Object System.Windows.Forms.ToolTip
$W_FGColorTip.InitialDelay = $ToolTipDelay
$W_FGColorTip.AutoPopDelay = $ToolTipDuration
$W_FGColorTipString = 'Defines the color of the font used for the watermark.'
$W_FGColorTip.SetToolTip($W_FGColorLabel, $W_FGColorTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Font BG Color
$W_BGColorButton = New-Object System.Windows.Forms.Button
$W_BGColorButton.Name = 'WM_BGColor'
$W_BGColorButton.Size = New-Object System.Drawing.Size(80, 22)
$W_BGColorButton.Location = New-Object System.Drawing.Size(10, 94)
$W_BGColorButton.Text = $WM_BGColor
$W_BGColorButton.BackColor = $WM_BGColor
$W_BGColorButton.Add_Click({ GUI_ShowColorDialog })
$W_BGColorLabel = New-Object System.Windows.Forms.Label
$W_BGColorLabel.Size = New-Object System.Drawing.Size(108, 20)
$W_BGColorLabel.Location = New-Object System.Drawing.Size(93, 98)
$W_BGColorLabel.Text = 'Font BG Color'
$WatermarkGroup.Controls.Add($W_BGColorButton)
$WatermarkGroup.Controls.Add($W_BGColorLabel)
$W_BGColorTip = New-Object System.Windows.Forms.ToolTip
$W_BGColorTip.InitialDelay = $ToolTipDelay
$W_BGColorTip.AutoPopDelay = $ToolTipDuration
$W_BGColorTipString = 'Defines the color of the background that surrounds the font used for the watermark.'
$W_BGColorTip.SetToolTip($W_BGColorLabel, $W_BGColorTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Font Face
$W_FontFaceCombo = New-Object System.Windows.Forms.ComboBox
$W_FontFaceCombo.Name = 'WM_FontFace'
$W_FontFaceCombo.Size = New-Object System.Drawing.Size(120, 10)
$W_FontFaceCombo.Location = New-Object System.Drawing.Size(192, 20)
$W_FontFaceCombo.Items.Add('Arial-Bold') | Out-Null
$W_FontFaceCombo.Items.Add('Comic-Sans-MS-Bold') | Out-Null
$W_FontFaceCombo.Items.Add('Courier-New-Bold') | Out-Null
$W_FontFaceCombo.Items.Add('Georgia-Bold') | Out-Null
$W_FontFaceCombo.Items.Add('Lucida-Console') | Out-Null
$W_FontFaceCombo.Items.Add('Sylfaen') | Out-Null
$W_FontFaceCombo.Items.Add('Times-New-Roman-Bold') | Out-Null
$W_FontFaceCombo.Items.Add('Trebuchet-MS-Bold') | Out-Null
$W_FontFaceCombo.Items.Add('Verdana-Bold') | Out-Null 
$W_FontFaceCombo.SelectedItem = $WM_FontFace
$W_FontFaceCombo.Add_SelectedIndexChanged({ GUI_UpdateComboBoxState -NewValue $this.SelectedItem })
$W_FontFaceCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$W_FontFaceLabel = New-Object System.Windows.Forms.Label
$W_FontFaceLabel.Size = New-Object System.Drawing.Size(60, 22)
$W_FontFaceLabel.Location = New-Object System.Drawing.Size(314, 22)
$W_FontFaceLabel.Text = 'Font Face'
$WatermarkGroup.Controls.Add($W_FontFaceCombo)
$WatermarkGroup.Controls.Add($W_FontFaceLabel)
$W_FontFaceTip = New-Object System.Windows.Forms.ToolTip
$W_FontFaceTip.InitialDelay = $ToolTipDelay
$W_FontFaceTip.AutoPopDelay = $ToolTipDuration
$W_FontFaceTipString = 'Defines the font that will be used for the texture watermark.'
$W_FontFaceTip.SetToolTip($W_FontFaceLabel, $W_FontFaceTipString)
#==============================================================================================================================================================================================
# Create Option 5: Material Textures
#==============================================================================================================================================================================================
$MaterialGroup = New-Object System.Windows.Forms.GroupBox
$MaterialGroup.Location = New-Object System.Drawing.Size(10, 260)
$MaterialGroup.Size = New-Object System.Drawing.Size(380, 124)
$MaterialGroup.Text = ' Ishiiruka Tool Options '
$MainDialog.Controls.Add($MaterialGroup)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Material Output Format
$M_FormatCombo = New-Object System.Windows.Forms.ComboBox
$M_FormatCombo.Name = 'IshiirukaFormat'
$M_FormatCombo.Size = New-Object System.Drawing.Size(72, 10)
$M_FormatCombo.Location = New-Object System.Drawing.Size(10, 20)
$M_FormatCombo.Items.Add('PNG') | Out-Null
$M_FormatCombo.Items.Add('DDS') | Out-Null
$M_FormatCombo.SelectedItem = ExtensionToText -FileExt $IshiirukaFormat
$M_FormatCombo.Add_SelectedIndexChanged({ GUI_UpdateComboBoxState -NewValue (Get-Variable -Name $this.SelectedItem -ValueOnly) })
$M_FormatCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$MaterialGroup.Controls.Add($M_FormatCombo)
$M_FormatLabel = New-Object System.Windows.Forms.Label
$M_FormatLabel.Size = New-Object System.Drawing.Size(100, 22)
$M_FormatLabel.Location = New-Object System.Drawing.Size(84, 23)
$M_FormatLabel.Text = 'Output Format'
$MaterialGroup.Controls.Add($M_FormatLabel)
$M_FormatTip = New-Object System.Windows.Forms.ToolTip
$M_FormatTip.InitialDelay = $ToolTipDelay
$M_FormatTip.AutoPopDelay = $ToolTipDuration
$M_FormatTipString = 'The output format of the textures and material{0}'
$M_FormatTipString += 'maps that are created with Ishiiruka Tool.'
$M_FormatTipString = [String]::Format($M_FormatTipString, [Environment]::NewLine)
$M_FormatTip.SetToolTip($M_FormatLabel, $M_FormatTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Because the warning label variable is not yet declared, toggle it in a function.
function GUI_MaterialWarningToggle()
{
  $M_InPlaceWarning.Visible = $this.Checked
}
#----------------------------------------------------------------------------------------------------------------------------------------------
# Create In-Place
$M_InPlaceCheck = New-Object System.Windows.Forms.CheckBox
$M_InPlaceCheck.Name = 'InPlaceMaterial'
$M_InPlaceCheck.Size = New-Object System.Drawing.Size(170, 16)
$M_InPlaceCheck.Location = New-Object System.Drawing.Size(192, 24)
$M_InPlaceCheck.Checked = $InPlaceMaterial
$M_InPlaceCheck.Text = ' Create Materials In-Place'
$M_InPlaceCheck.Add_CheckStateChanged({ GUI_UpdateCheckBoxState ; GUI_MaterialWarningToggle })
$MaterialGroup.Controls.Add($M_InPlaceCheck)
$M_InPlaceTip = New-Object System.Windows.Forms.ToolTip
$M_InPlaceTip.InitialDelay = $ToolTipDelay
$M_InPlaceTip.AutoPopDelay = $ToolTipDuration
$M_InPlaceTipString = 'Creates materials within the texture pack itself{0}'
$M_InPlaceTipString += 'rather than the selected output folder. This will{0}'
$M_InPlaceTipString += 'overwrite the texture and remove accompanying{0}'
$M_InPlaceTipString += 'bump/spec/lum/nrm textures that are found.'
$M_InPlaceTipString = [String]::Format($M_InPlaceTipString, [Environment]::NewLine)
$M_InPlaceTip.SetToolTip($M_InPlaceCheck, $M_InPlaceTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# In-Place Warning Label
$M_InPlaceWarning = New-Object System.Windows.Forms.Label
$M_InPlaceWarning.Size = New-Object System.Drawing.Size(360, 60)
$M_InPlaceWarning.Location = New-Object System.Drawing.Size(10, 58)
$M_InPlaceWarningText = 'Warning: This option will create a combined material from any bump/spec/lum/nrm textures that are found, but it will destroy them in '
$M_InPlaceWarningText += 'the process and replace them with the generated (.mat) texture. If these textures are to be kept, then disable "Create Materials In-Place".'
$M_InPlaceWarning.Text = $M_InPlaceWarningText
$M_InPlaceWarning.ForeColor = '#901616'
$M_InPlaceWarning.Visible = $InPlaceMaterial
$MaterialGroup.Controls.Add($M_InPlaceWarning)
#----------------------------------------------------------------------------------------------------------------------------------------------
$IshiiPathLabelB = New-Object System.Windows.Forms.Label
$IshiiPathLabelB.Size = New-Object System.Drawing.Size(140, 14)
$IshiiPathLabelB.Location = New-Object System.Drawing.Size(10, 80)
$IshiiPathLabelB.Text = 'Ishiiruka Tool Path:'
$IshiiPathTipB = New-Object System.Windows.Forms.ToolTip
$IshiiPathTipB.InitialDelay = $ToolTipDelay
$IshiiPathTipB.AutoPopDelay = $ToolTipDuration
$IshiiPathTipB.SetToolTip($IshiiPathLabelB, $IshiiPathTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$IshiiPathTextBoxB = New-Object System.Windows.Forms.TextBox
$IshiiPathTextBoxB.Name = 'IshiirukaTool'
$IshiiPathTextBoxB.Size = New-Object System.Drawing.Size(328, 22)
$IshiiPathTextBoxB.Location = New-Object System.Drawing.Size(10, 95)
$IshiiPathTextBoxB.Text = $IshiirukaTool
$IshiiPathTextBoxB.AllowDrop = $true
$IshiiPathTextBoxB.Add_DragEnter({ $_.Effect = [Windows.Forms.DragDropEffects]::Copy })
$IshiiPathTextBoxB.Add_DragDrop({ GUI_UpdateFilePath_DragDrop -FileName 'TextureEncoder.exe'})
$IshiiPathTextBoxB.Add_Leave({ GUI_UpdateFilePath_TextBox -FileName 'TextureEncoder.exe' })
#----------------------------------------------------------------------------------------------------------------------------------------------
$IshiiPathButtonB = New-Object System.Windows.Forms.Button
$IshiiPathButtonB.Name = 'IshiirukaTool'
$IshiiPathButtonB.Size = New-Object System.Drawing.Size(24, 22)
$IshiiPathButtonB.Location = New-Object System.Drawing.Size(346, 93)
$IshiiPathButtonB.Text = '...'
$IshiiPathButtonB.Add_Click({ GUI_UpdateFilePath_Button -TextBox $IshiiPathTextBoxB -Description 'Ishiiruka Tool' -FileName 'TextureEncoder.exe' })
#----------------------------------------------------------------------------------------------------------------------------------------------
$MaterialGroup.Controls.Add($IshiiPathLabelB)
$MaterialGroup.Controls.Add($IshiiPathTextBoxB)
$MaterialGroup.Controls.Add($IshiiPathButtonB)
#==============================================================================================================================================================================================
# Create Option 6: OptiPNG Textures
#==============================================================================================================================================================================================
$OptiPNGGroup = New-Object System.Windows.Forms.GroupBox
$OptiPNGGroup.Size = New-Object System.Drawing.Size(380, 124)
$OptiPNGGroup.Location = New-Object System.Drawing.Size(10, 260)
$OptiPNGGroup.Text = ' OptiPNG Options '
$MainDialog.Controls.Add($OptiPNGGroup)
#----------------------------------------------------------------------------------------------------------------------------------------------
# OptiPNG Tests
$O_TestsNumBox = New-Object System.Windows.Forms.NumericUpDown
$O_TestsNumBox.Name = 'OptiPNGTests'
$O_TestsNumBox.Size = New-Object System.Drawing.Size(72, 10)
$O_TestsNumBox.Location = New-Object System.Drawing.Size(10, 20)
$O_TestsNumBox.DecimalPlaces = 0
$O_TestsNumBox.Value = $OptiPNGTests
$O_TestsNumBox.Minimum = 1
$O_TestsNumBox.Maximum = 20
$O_TestsNumBox.Increment = 1
$O_TestsNumBox.Add_ValueChanged({ GUI_UpdateNumericUpDown -TypeDefinition 'integer' })
$O_TestsLabel = New-Object System.Windows.Forms.Label
$O_TestsLabel.Size = New-Object System.Drawing.Size(100, 22)
$O_TestsLabel.Location = New-Object System.Drawing.Size(84, 23)
$O_TestsLabel.Text = 'Tests Performed'
$OptiPNGGroup.Controls.Add($O_TestsNumBox)
$OptiPNGGroup.Controls.Add($O_TestsLabel)
$O_TestsTip = New-Object System.Windows.Forms.ToolTip
$O_TestsTip.InitialDelay = $ToolTipDelay
$O_TestsTip.AutoPopDelay = $ToolTipDuration
$O_TestsTipString = 'Sets the number of tests that OptiPNG runs on textures in an attempt{0}'
$O_TestsTipString += 'to optimize them. The more tests that are ran, the higher the chance{0}'
$O_TestsTipString += 'of getting a smaller texture. But each test will significanly increase the{0}'
$O_TestsTipString += 'time it takes for OptiPNG to optimize a texture. It is not suggested to{0}'
$O_TestsTipString += 'go above 3 tests which is usually overkill in itself.'
$O_TestsTipString = [String]::Format($O_TestsTipString, [Environment]::NewLine)
$O_TestsTip.SetToolTip($O_TestsLabel, $O_TestsTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Create In-Place
$O_InPlaceCheck = New-Object System.Windows.Forms.CheckBox
$O_InPlaceCheck.Name = 'InPlaceOptiPNG'
$O_InPlaceCheck.Size = New-Object System.Drawing.Size(170, 16)
$O_InPlaceCheck.Location = New-Object System.Drawing.Size(192, 24)
$O_InPlaceCheck.Checked = $InPlaceOptiPNG
$O_InPlaceCheck.Text = ' Optimize Textures In-Place'
$O_InPlaceCheck.Add_CheckStateChanged({ GUI_UpdateCheckBoxState })
$OptiPNGGroup.Controls.Add($O_InPlaceCheck)
$O_InPlaceTip = New-Object System.Windows.Forms.ToolTip
$O_InPlaceTip.InitialDelay = $ToolTipDelay
$O_InPlaceTip.AutoPopDelay = $ToolTipDuration
$O_InPlaceTipString = 'Overwrites the old texture with the optimized texture within the{0}'
$O_InPlaceTipString += 'texture pack rather than recreate it within the "OptimizedTextures"{0}'
$O_InPlaceTipString += 'output folder. This option is safe to use freely.'
$O_InPlaceTipString = [String]::Format($O_InPlaceTipString, [Environment]::NewLine)
$O_InPlaceTip.SetToolTip($O_InPlaceCheck, $O_InPlaceTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$OptiPathLabelB = New-Object System.Windows.Forms.Label
$OptiPathLabelB.Size = New-Object System.Drawing.Size(140, 14)
$OptiPathLabelB.Location = New-Object System.Drawing.Size(10, 80)
$OptiPathLabelB.Text = 'OptiPNG Path:'
$OptiPathTipB = New-Object System.Windows.Forms.ToolTip
$OptiPathTipB.InitialDelay = $ToolTipDelay
$OptiPathTipB.AutoPopDelay = $ToolTipDuration
$OptiPathTipB.SetToolTip($OptiPathLabelB, $OptiPathTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$OptiPathTextBoxB = New-Object System.Windows.Forms.TextBox
$OptiPathTextBoxB.Name = 'OptiPNGPath'
$OptiPathTextBoxB.Size = New-Object System.Drawing.Size(328, 22)
$OptiPathTextBoxB.Location = New-Object System.Drawing.Size(10, 95)
$OptiPathTextBoxB.Text = $OptiPNGPath
$OptiPathTextBoxB.AllowDrop = $true
$OptiPathTextBoxB.Add_DragEnter({ $_.Effect = [Windows.Forms.DragDropEffects]::Copy })
$OptiPathTextBoxB.Add_DragDrop({ GUI_UpdateFilePath_DragDrop -FileName 'optipng.exe' })
$OptiPathTextBoxB.Add_Leave({ GUI_UpdateFilePath_TextBox -FileName 'optipng.exe' })
#----------------------------------------------------------------------------------------------------------------------------------------------
$OptiPathButtonB = New-Object System.Windows.Forms.Button
$OptiPathButtonB.Name = 'OptiPNGPath'
$OptiPathButtonB.Size = New-Object System.Drawing.Size(24, 22)
$OptiPathButtonB.Location = New-Object System.Drawing.Size(346, 93)
$OptiPathButtonB.Text = '...'
$OptiPathButtonB.Add_Click({ GUI_UpdateFilePath_Button -TextBox $OptiPathTextBoxB -Description 'OptiPNG' -FileName 'optipng.exe' })
#----------------------------------------------------------------------------------------------------------------------------------------------
$OptiPNGGroup.Controls.Add($OptiPathLabelB)
$OptiPNGGroup.Controls.Add($OptiPathTextBoxB)
$OptiPNGGroup.Controls.Add($OptiPathButtonB)
#==============================================================================================================================================================================================
# Create Option 7: Upscale Filter
#==============================================================================================================================================================================================
#  Because so much happens when the combo box for filters is changed, it has its very own function.

function GUI_UpdateFilterComboBoxState()
{
  # Default the maximum upscale factor to 8x.
  $U_FactorNumBox.Maximum = 8

  # If selecting an existing tool.
  if ($this.SelectedItem -eq 'Add Filter...')
  {
    # Create empty arrays based for the tools that aren't already added.
    $FileNameArray    = @()
    $DescriptionArray = @()

    # Build the file name and description arrays based on the tools that aren't already added.
    if (!(TestPath -LiteralPath $ScalerTestPath)) { $DescriptionArray += 'xBRZ ScalerTest' ; $FileNameArray += 'ScalerTest.exe'            }

    if (!(TestPath -LiteralPath $Waifu2xPath))    {
                                                    $DescriptionArray += 'Waifu2x-Caffe'   ; $FileNameArray += 'waifu2x-caffe-cui.exe'
                                                    $DescriptionArray += 'Waifu2x-CPP'     ; $FileNameArray += 'waifu2x-converter_x64.exe'
                                                  }
    # Display an "Open Folder" menu to get the path. Get-FileName already handles arrays so no need to worry about extra shit.
    $SelectedPath = Get-FileName -Path 'C:\' -Description $DescriptionArray -FileName $FileNameArray

    # Check to see if a folder was selected from the Open menu and test if that path exists.
    if (($SelectedPath -ne '') -and (TestPath -LiteralPath $SelectedPath))
    {
      # Get the name of the tool so parameters for it can be set up.
      $ToolName = (Get-Item -LiteralPath $SelectedPath).BaseName

      # Set up parameters based on the selected tool.
      switch ($ToolName)
      {
        # We'll need the name of the tool in the list, the textbox it is tied to in the paths menu, and the name of the variable that stored the value.
        'ScalerTest'            { $Tool = 'xBRZ'    ; $TextBox = $xBRZPathTextBox    ; $VarName = 'ScalerTestPath' }
        'waifu2x-caffe-cui'     { $Tool = 'Waifu2x' ; $TextBox = $Waifu2xPathTextBox ; $VarName = 'Waifu2xPath' }
        'waifu2x-converter_x64' { $Tool = 'Waifu2x' ; $TextBox = $Waifu2xPathTextBox ; $VarName = 'Waifu2xPath' }
      }
      # Make sure the tool is not already on the list.
      if (!($this.Items.Contains($Tool)))
      {
        # Call the function that is used when updating paths.
        GUI_UpdateFilePath_Finish -TextBox $TextBox -VarName $VarName -ToolPath $SelectedPath
      }
      # Force the selected item to recently added tool.
      $this.SelectedItem = $Tool
    }
    # If nothing was selected.
    else
    {
      # Force the currently selected item to the previously selected item.
      $this.SelectedItem = $SelectedFilter
    }
  }
  # xBRZ has a limit of 6x as an upscaling integer so limit the upscaling value.
  elseif ($this.SelectedItem -eq 'xBRZ')
  {
    $U_FactorNumBox.Maximum = 6
  }
  # Check to see if waifu2x was selected as the filter.
  elseif ($this.SelectedItem -eq 'Waifu2x')
  {
    # Test if the path to waifu2x is valid to avoid errors.
    if (TestPath -LiteralPath $Waifu2xPath)
    {
      # Get the name of the selected Waifu2x application.
      $global:Waifu2xApp = [string](Get-ChildItem -LiteralPath $Waifu2xPath).Name

      # Update the visibility of all waifu2x options.
      GUI_UpdateWaifu2xSelection
    }
    # Also show all the other additional options regardless if the path is valid or not.
    $U_WF2XModeCombo.Show()
    $U_WF2XModeLabel.Show()
    $U_WF2XNoiseBox.Show()
    $U_WF2XNoiseLabel.Show()
    $U_WF2XGPUCheck.Show()
    
    # Enable/disable the upscale factor and noise reduction fields based on their current selection.
    $U_FactorNumBox.Enabled = ($U_WF2XModeCombo.SelectedItem -ne 'Noise')
    $U_FactorLabel.Enabled = ($U_WF2XModeCombo.SelectedItem -ne 'Noise')
    $U_WF2XNoiseBox.Enabled = ($U_WF2XModeCombo.SelectedItem -ne 'Scale')
    $U_WF2XNoiseLabel.Enabled = ($U_WF2XModeCombo.SelectedItem -ne 'Scale')
  }
  # If any other filter is selected.
  else
  {
    # Hide the waifu2x specific options
    $U_WF2XModeCombo.Hide()
    $U_WF2XModeLabel.Hide()
    $U_WF2XNoiseBox.Hide()
    $U_WF2XNoiseLabel.Hide()
    $U_WF2XGPUCheck.Hide()
    $U_WF2XOpenCLCheck.Hide()
    $U_WF2XModelCombo.Hide()
    $U_WF2XModelLabel.Hide()

    # Always enable the rescale factor.
    $U_FactorNumBox.Enabled = $true
    $U_FactorLabel.Enabled = $true
  }
  # Store the current selected filter to compare to the new value.
  $global:SelectedFilter = $this.SelectedItem
  $global:FilterSelected = $this.SelectedItem
}
#----------------------------------------------------------------------------------------------------------------------------------------------
# Adds the option "Add Tool..." to the menu if all tools are not already added.
function CheckAddFilterOption()
{
  # Set up the series of checks in a variable array.
  $Conditions = New-Object bool[] 2

  # Go through and store the result of each check into the array.
  $Conditions[0] = $U_FilterCombo.Items.Contains('xBRZ')
  $Conditions[1] = $U_FilterCombo.Items.Contains('Waifu2x')

  # Test the array of conditions.
  if (!(TestBooleanArray -Array $Conditions))
  {
    # Add the item to allow adding more tools.
    $U_FilterCombo.Items.Add('Add Filter...') | Out-Null
  }
}
#----------------------------------------------------------------------------------------------------------------------------------------------
# Upscaling Filter
$UpscaleFilterGroup = New-Object System.Windows.Forms.GroupBox
$UpscaleFilterGroup.Size = New-Object System.Drawing.Size(380, 124)
$UpscaleFilterGroup.Location = New-Object System.Drawing.Size(10, 260)
$UpscaleFilterGroup.Text = ' Upscale Filter Options '
$MainDialog.Controls.Add($UpscaleFilterGroup)
#----------------------------------------------------------------------------------------------------------------------------------------------
$U_FilterCombo = New-Object System.Windows.Forms.ComboBox
$U_FilterCombo.Name = 'FilterSelected'
$U_FilterCombo.Size = New-Object System.Drawing.Size(72, 10)
$U_FilterCombo.Location = New-Object System.Drawing.Size(10, 20)
if (TestPath -LiteralPath $ScalerTestPath)  { $U_FilterCombo.Items.Add('xBRZ') | Out-Null }
if (TestPath -LiteralPath $Waifu2xPath)     { $U_FilterCombo.Items.Add('Waifu2x') | Out-Null }
$U_FilterCombo.Items.Add('Point') | Out-Null
$U_FilterCombo.Items.Add('Cubic') | Out-Null
$U_FilterCombo.Items.Add('Lancoz') | Out-Null
# Adds the option "Add Filter..." to the menu if all tools are not already added.
CheckAddFilterOption
$U_FilterCombo.SelectedItem = $global:SelectedFilter = $FilterSelected
$U_FilterCombo.Add_SelectedIndexChanged({ GUI_UpdateFilterComboBoxState })
$U_FilterCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$U_FilterLabel = New-Object System.Windows.Forms.Label
$U_FilterLabel.Size = New-Object System.Drawing.Size(96, 22)
$U_FilterLabel.Location = New-Object System.Drawing.Size(84, 22)
$U_FilterLabel.Text = 'Upscale Filter'
$UpscaleFilterGroup.Controls.Add($U_FilterCombo)
$UpscaleFilterGroup.Controls.Add($U_FilterLabel)
$U_FilterTip = New-Object System.Windows.Forms.ToolTip
$U_FilterTip.InitialDelay = $ToolTipDelay
$U_FilterTip.AutoPopDelay = $ToolTipDuration
$U_FilterTipString = 'Sets the upscaling filter that will be applied to{0}'
$U_FilterTipString += 'all textures. xBRZ and Waifu2x require a proper{0}'
$U_FilterTipString += 'path set to these tools in the Options menu.'
$U_FilterTipString = [String]::Format($U_FilterTipString, [Environment]::NewLine)
$U_FilterTip.SetToolTip($U_FilterLabel, $U_FilterTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
function UpscaleFactorInitialState()
{
  # If waifu2x is selected at boot, and "Noise" was selected as the mode.
  if (($FilterSelected -eq 'Waifu2x') -and ($Waifu2xCMode -eq 'Noise'))
  {
    # Initially disable the upscale factor field since it has no effect.
    return $false
  }
  # For all other filters, or if waifu2x is set in "Scale" or "Noise-Scale", enable the fields.
  return $true
}
#----------------------------------------------------------------------------------------------------------------------------------------------
# Upscale Factor
$U_FactorNumBox = New-Object System.Windows.Forms.NumericUpDown
$U_FactorNumBox.Name = 'FilterNewScale'
$U_FactorNumBox.Size = New-Object System.Drawing.Size(72, 10)
$U_FactorNumBox.Location = New-Object System.Drawing.Size(10, 44)
$U_FactorNumBox.DecimalPlaces = 0
$U_FactorNumBox.Value = $FilterNewScale
$U_FactorNumBox.Minimum = 2
if ($FilterSelected -eq 'xBRZ') { $U_FactorNumBox.Maximum = 6 }
else { $U_FactorNumBox.Maximum = 8 }
$U_FactorNumBox.Increment = 1
$U_FactorNumBox.Add_ValueChanged({ GUI_UpdateNumericUpDown -TypeDefinition 'integer' })
$U_FactorNumBox.Enabled = UpscaleFactorInitialState
$U_FactorLabel = New-Object System.Windows.Forms.Label
$U_FactorLabel.Size = New-Object System.Drawing.Size(96, 22)
$U_FactorLabel.Location = New-Object System.Drawing.Size(84, 47)
$U_FactorLabel.Text = 'Upscale Factor'
$U_FactorLabel.Enabled = UpscaleFactorInitialState
$UpscaleFilterGroup.Controls.Add($U_FactorNumBox)
$UpscaleFilterGroup.Controls.Add($U_FactorLabel)
$U_FactorTip = New-Object System.Windows.Forms.ToolTip
$U_FactorTip.InitialDelay = $ToolTipDelay
$U_FactorTip.AutoPopDelay = $ToolTipDuration
$U_FactorTipString = 'The factor to upscale the image. The resulting image{0}'
$U_FactorTipString += 'size is the product of (Dimensions * Upscale Factor).{0}'
$U_FactorTipString += '{0}'
$U_FactorTipString += 'While most filters allow setting a maximum value of 8,{0}'
$U_FactorTipString += 'xBRZ will only allow a maximum value of 6.'
$U_FactorTipString = [String]::Format($U_FactorTipString, [Environment]::NewLine)
$U_FactorTip.SetToolTip($U_FactorLabel, $U_FactorTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Upscale Output Format
$U_FormatCombo = New-Object System.Windows.Forms.ComboBox
$U_FormatCombo.Name = 'UpscaleFormat'
$U_FormatCombo.Size = New-Object System.Drawing.Size(72, 10)
$U_FormatCombo.Location = New-Object System.Drawing.Size(10, 68)
$U_FormatCombo.Items.Add('PNG') | Out-Null
$U_FormatCombo.Items.Add('DDS') | Out-Null
$U_FormatCombo.SelectedItem = ExtensionToText -FileExt $UpscaleFormat
$U_FormatCombo.Add_SelectedIndexChanged({ GUI_UpdateComboBoxState -NewValue (Get-Variable -Name $this.SelectedItem -ValueOnly) })
$U_FormatCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$UpscaleFilterGroup.Controls.Add($U_FormatCombo)
$U_UpscaleFormatLabel = New-Object System.Windows.Forms.Label
$U_UpscaleFormatLabel.Size = New-Object System.Drawing.Size(100, 22)
$U_UpscaleFormatLabel.Location = New-Object System.Drawing.Size(84, 71)
$U_UpscaleFormatLabel.Text = 'Output Format'
$UpscaleFilterGroup.Controls.Add($U_UpscaleFormatLabel)
$U_UpscaleFormatTip = New-Object System.Windows.Forms.ToolTip
$U_UpscaleFormatTip.InitialDelay = $ToolTipDelay
$U_UpscaleFormatTip.AutoPopDelay = $ToolTipDuration
$U_UpscaleFormatTipString = 'The output format that textures will be created.'
$U_UpscaleFormatTipString = [String]::Format($U_UpscaleFormatTipString, [Environment]::NewLine)
$U_UpscaleFormatTip.SetToolTip($U_UpscaleFormatLabel, $U_UpscaleFormatTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Seamless Method
$U_SeamlessCombo = New-Object System.Windows.Forms.ComboBox
$U_SeamlessCombo.Name = 'SeamlessMethod'
$U_SeamlessCombo.Size = New-Object System.Drawing.Size(72, 10)
$U_SeamlessCombo.Location = New-Object System.Drawing.Size(10, 93)
$U_SeamlessCombo.Items.Add('Opaque') | Out-Null
$U_SeamlessCombo.Items.Add('All') | Out-Null
$U_SeamlessCombo.Items.Add('Disable') | Out-Null
$U_SeamlessCombo.SelectedItem = $SeamlessMethod
$U_SeamlessCombo.Add_SelectedIndexChanged({ GUI_UpdateComboBoxState -NewValue $this.SelectedItem })
$U_SeamlessCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$U_SeamlessLabel = New-Object System.Windows.Forms.Label
$U_SeamlessLabel.Size = New-Object System.Drawing.Size(96, 22)
$U_SeamlessLabel.Location = New-Object System.Drawing.Size(84, 96)
$U_SeamlessLabel.Text = 'Seamless Method'
$UpscaleFilterGroup.Controls.Add($U_SeamlessCombo)
$UpscaleFilterGroup.Controls.Add($U_SeamlessLabel)
$U_SeamlessTip = New-Object System.Windows.Forms.ToolTip
$U_SeamlessTip.InitialDelay = $ToolTipDelay
$U_SeamlessTip.AutoPopDelay = $ToolTipDuration
$U_SeamlessTipString = 'It should be noted that this option will not break non-seamless textures in{0}'
$U_SeamlessTipString += 'any way, but does have the possiblity to slow down the conversion.{0}'
$U_SeamlessTipString += '{0}'
$U_SeamlessTipString += 'The "Seamless Method" is a technique that involves tiling a texture 9 times{0}'
$U_SeamlessTipString += 'in a 3x3 grid, then applies the selected upscaling filter to the tiled texture.{0}'
$U_SeamlessTipString += 'After the tiled texture is filtered, the outer 8 tiles are cropped away. This{0}'
$U_SeamlessTipString += 'prevents the resulting texture from creating visible seams when it is tiled{0}'
$U_SeamlessTipString += 'in-game because it gives the upscaling filter neighboring pixels to work with{0}'
$U_SeamlessTipString += 'along the edges of the texture.{0}'
$U_SeamlessTipString += '{0}'
$U_SeamlessTipString += 'This option is only useful for seamless textures, as it adds processing time{0}'
$U_SeamlessTipString += 'when upscaling the texture. The outer tiles have some percentage cropped{0}'
$U_SeamlessTipString += 'to increase the speed which is configurable below this option. Most textures{0}'
$U_SeamlessTipString += 'that are seamless have no transparent pixels, but this is not always true so{0}'
$U_SeamlessTipString += 'when to apply this method is configurable.{0}'
$U_SeamlessTipString += '{0}'
$U_SeamlessTipString += 'Opaque: Only apply this method to textures that have no transparent pixels.{0}'
$U_SeamlessTipString += 'All: Apply this method to all textures even if they have transparent pixels.{0}'
$U_SeamlessTipString += 'Disable: Do not apply the seamless method to any textures.'
$U_SeamlessTipString = [String]::Format($U_SeamlessTipString, [Environment]::NewLine)
$U_SeamlessTip.SetToolTip($U_SeamlessLabel, $U_SeamlessTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
function Waif2xOptionsToggle()
{
  # Disable certain options depending on the conversion mode set.
  switch ($this.SelectedItem)
  {
    # When in scale mode, disable the noise reduction fields.
    Scale   { $U_FactorNumBox.Enabled = $true
              $U_FactorLabel.Enabled = $true
              $U_WF2XNoiseBox.Enabled = $false
              $U_WF2XNoiseLabel.Enabled = $false
            }
    # When in noise mode, disable the upscale factor fields.
    Noise   { $U_FactorNumBox.Enabled = $false
              $U_FactorLabel.Enabled = $false
              $U_WF2XNoiseBox.Enabled = $true
              $U_WF2XNoiseLabel.Enabled = $true
            }
    # When in noise-scale, enable both upscale factor and noise reduction.
    default { $U_FactorNumBox.Enabled = $true
              $U_FactorLabel.Enabled = $true
              $U_WF2XNoiseBox.Enabled = $true
              $U_WF2XNoiseLabel.Enabled = $true
            }
  }
}
#----------------------------------------------------------------------------------------------------------------------------------------------
# Waifu2x Conversion Mode
$U_WF2XModeCombo = New-Object System.Windows.Forms.ComboBox
$U_WF2XModeCombo.Name = 'Waifu2xCMode'
$U_WF2XModeCombo.Size = New-Object System.Drawing.Size(94, 10)
$U_WF2XModeCombo.Location = New-Object System.Drawing.Size(184, 20)
$U_WF2XModeCombo.Items.Add('Scale') | Out-Null
$U_WF2XModeCombo.Items.Add('Noise') | Out-Null
$U_WF2XModeCombo.Items.Add('Noise_Scale') | Out-Null
$U_WF2XModeCombo.SelectedItem = $Waifu2xCMode
$U_WF2XModeCombo.Add_SelectedIndexChanged({ GUI_UpdateComboBoxState -NewValue $this.SelectedItem ; Waif2xOptionsToggle })
$U_WF2XModeCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$U_WF2XModeLabel = New-Object System.Windows.Forms.Label
$U_WF2XModeLabel.Size = New-Object System.Drawing.Size(96, 22)
$U_WF2XModeLabel.Location = New-Object System.Drawing.Size(278, 22)
$U_WF2XModeLabel.Text = 'Conversion Mode'
$UpscaleFilterGroup.Controls.Add($U_WF2XModeCombo)
$UpscaleFilterGroup.Controls.Add($U_WF2XModeLabel)
$U_WF2XModeTip = New-Object System.Windows.Forms.ToolTip
$U_WF2XModeTip.InitialDelay = $ToolTipDelay
$U_WF2XModeTip.AutoPopDelay = $ToolTipDuration
$U_WF2XModeTipString = 'This option tells waifu2x when to upscale and when to apply noise reduction. {0}'
$U_WF2XModeTipString += '{0}'
$U_WF2XModeTipString += 'Scale: Upscale the image, but do not apply noise reduction. {0}'
$U_WF2XModeTipString += 'Noise: Apply noise reduction, but do not upscale the image. {0}'
$U_WF2XModeTipString += 'Noise-Scale: Upscale and apply noise reduction to the image. {0}'
$U_WF2XModeTipString += '{0}'
$U_WF2XModeTipString += 'Upscale Factor/Noise Reduction only work in the respective modes.'
$U_WF2XModeTipString = [String]::Format($U_WF2XModeTipString, [Environment]::NewLine)
$U_WF2XModeTip.SetToolTip($U_WF2XModeLabel, $U_WF2XModeTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
function InitialWaifu2xMaximum()
{
  # Waifu2x Caffe allows a maximum of 3 for noise reduction.
  if ($Waifu2xApp -eq 'waifu2x-caffe-cui.exe')
  {
    # So if it's found, return 3 for the maximum value.
    return 3
  }
  # Waifu2x CPP only allows 2, so return that.
  return 2
}
#----------------------------------------------------------------------------------------------------------------------------------------------
# Waifu2x Noise Reduction
$U_WF2XNoiseBox = New-Object System.Windows.Forms.NumericUpDown
$U_WF2XNoiseBox.Name = 'Waifu2xNoise'
$U_WF2XNoiseBox.Size = New-Object System.Drawing.Size(94, 10)
$U_WF2XNoiseBox.Location = New-Object System.Drawing.Size(184, 44)
$U_WF2XNoiseBox.DecimalPlaces = 0
$U_WF2XNoiseBox.Value = $Waifu2xNoise
$U_WF2XNoiseBox.Minimum = 1
$U_WF2XNoiseBox.Maximum = InitialWaifu2xMaximum
$U_WF2XNoiseBox.Increment = 1
$U_WF2XNoiseBox.Add_ValueChanged({ GUI_UpdateNumericUpDown -TypeDefinition 'integer' })
$U_WF2XNoiseBox.Enabled = ($Waifu2xCMode -ne 'Scale')
$U_WF2XNoiseLabel = New-Object System.Windows.Forms.Label
$U_WF2XNoiseLabel.Size = New-Object System.Drawing.Size(94, 22)
$U_WF2XNoiseLabel.Location = New-Object System.Drawing.Size(278, 47)
$U_WF2XNoiseLabel.Text = 'Noise Reduction'
$U_WF2XNoiseLabel.Enabled = ($Waifu2xCMode -ne 'Scale')
$UpscaleFilterGroup.Controls.Add($U_WF2XNoiseBox)
$UpscaleFilterGroup.Controls.Add($U_WF2XNoiseLabel)
$U_WF2XNoiseTip = New-Object System.Windows.Forms.ToolTip
$U_WF2XNoiseTip.InitialDelay = $ToolTipDelay
$U_WF2XNoiseTip.AutoPopDelay = $ToolTipDuration
$U_WF2XNoiseTipString = 'The amount of noise reduction to apply to the image. The higher the value, the{0}'
$U_WF2XNoiseTipString += 'smoother the resulting image will be. Waifu2x-CPP only supports a value up to 2,{0}'
$U_WF2XNoiseTipString += 'while Waifu2x-Caffe supports a value of 3. If 3 is selected when using this with{0}'
$U_WF2XNoiseTipString += 'Waifu2x-CPP, it will automatically set the value back to 2 before processing the{0}'
$U_WF2XNoiseTipString += 'textures. This option has no effect when the "Conversion Mode" is set to "Scale".'
$U_WF2XNoiseTipString = [String]::Format($U_WF2XNoiseTipString, [Environment]::NewLine)
$U_WF2XNoiseTip.SetToolTip($U_WF2XNoiseLabel, $U_WF2XNoiseTipString)
#==============================================================================================================================================================================================
# Converts menu strings into CLI strings and vice versa.

function GUI_FlipWaifu2xModelName([string]$ModelName)
{
  # Which ever version of the model is given, give back the opposite.
  switch ($ModelName)
  {
    # -- Anime style art model.
    '2D Illust (RGB)'               { return 'anime_style_art_rgb' }
    'anime_style_art_rgb'           { return '2D Illust (RGB)' }

    # -- High quality anime style art model.
    '2D Illust (UpRGB)'             { return 'upconv_7_anime_style_art_rgb'}
    'upconv_7_anime_style_art_rgb'  { return '2D Illust (UpRGB)'}

    # -- Simple anime style art model.
    'anime_style_art'               { return '2D Illust (Y)' }
    '2D Illust (Y)'                 { return 'anime_style_art' }

    # -- Photo model
    'Photo (Standard)'              { return 'photo' }
    'photo'                         { return 'Photo (Standard)' }

    # -- High quality photo model.
    'Photo (UpPhoto)'               { return 'upconv_7_photo' }
    'upconv_7_photo'                { return 'Photo (UpPhoto)' }
  }
}
#----------------------------------------------------------------------------------------------------------------------------------------------
# Waifu2x Upscale Model (Caffe Only)
$U_WF2XModelCombo = New-Object System.Windows.Forms.ComboBox
$U_WF2XModelCombo.Name = 'Waifu2xModel'
$U_WF2XModelCombo.Size = New-Object System.Drawing.Size(94, 10)
$U_WF2XModelCombo.Location = New-Object System.Drawing.Size(184, 96)
$U_WF2XModelCombo.Items.Add('2D Illust (RGB)') | Out-Null
$U_WF2XModelCombo.Items.Add('2D Illust (UpRGB)') | Out-Null
$U_WF2XModelCombo.Items.Add('2D Illust (Y)') | Out-Null
$U_WF2XModelCombo.Items.Add('Photo (Standard)') | Out-Null
$U_WF2XModelCombo.Items.Add('Photo (UpPhoto)') | Out-Null
$U_WF2XModelCombo.SelectedItem = GUI_FlipWaifu2xModelName -ModelName $Waifu2xModel
$U_WF2XModelCombo.Add_SelectedIndexChanged({ GUI_UpdateComboBoxState -NewValue (GUI_FlipWaifu2xModelName -ModelName $this.SelectedItem) })
$U_WF2XModelCombo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$U_WF2XModelLabel = New-Object System.Windows.Forms.Label
$U_WF2XModelLabel.Size = New-Object System.Drawing.Size(94, 22)
$U_WF2XModelLabel.Location = New-Object System.Drawing.Size(278, 98)
$U_WF2XModelLabel.Text = 'Upscale Model'
$UpscaleFilterGroup.Controls.Add($U_WF2XModelCombo)
$UpscaleFilterGroup.Controls.Add($U_WF2XModelLabel)
$U_WF2XModelTip = New-Object System.Windows.Forms.ToolTip
$U_WF2XModelTip.InitialDelay = $ToolTipDelay
$U_WF2XModelTip.AutoPopDelay = $ToolTipDuration
$U_WF2XModelTipString = 'Allows selecting the model that waifu2x-Caffe uses. The names{0}'
$U_WF2XModelTipString += 'used on this GUI match those found on the GUI of waif2x-Caffe.{0}'
$U_WF2XModelTipString += '{0}'
$U_WF2XModelTipString += '2D Illust (RGB): 2-dimensional image model for converting RGB.{0}'
$U_WF2XModelTipString += 'Internally uses the model "anime_style_art_rgb". {0}'
$U_WF2XModelTipString += '{0}'
$U_WF2XModelTipString += '2D Illust (UpRGB): Higher quality than the previous. Uses more{0}'
$U_WF2XModelTipString += 'VRAM. Internally uses the model "upconv_7_anime_style_art_rgb".{0}'
$U_WF2XModelTipString += '{0}'
$U_WF2XModelTipString += '2D Illust (Y): 2-dimensional illustration model that converts only{0}'
$U_WF2XModelTipString += 'the luminance. Internally uses the model "anime_style_art".{0}'
$U_WF2XModelTipString += '{0}'
$U_WF2XModelTipString += 'Photo (Standard): Standard model for photography or animation.{0}'
$U_WF2XModelTipString += 'Internally uses the model "photo".{0}'
$U_WF2XModelTipString += '{0}'
$U_WF2XModelTipString += 'Photo (UpPhoto): Higher quality than the previous. Uses more{0}'
$U_WF2XModelTipString += 'VRAM. Internally uses the model "upconv_7_photo".'
$U_WF2XModelTipString = [String]::Format($U_WF2XModelTipString, [Environment]::NewLine)
$U_WF2XModelTip.SetToolTip($U_WF2XModelLabel, $U_WF2XModelTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Waifu2x Disable GPU
function U_WF2XGPU()
{
  # Waifu2x can disable the GPU, but this can not be done with OpenCL enabled.
  if (($this.Checked) -and ($U_WF2XOpenCLCheck.Checked) -and ($U_WF2XOpenCLCheck.Visible))
  {
    $U_WF2XOpenCLCheck.Checked = $false
  }
}
#----------------------------------------------------------------------------------------------------------------------------------------------
$U_WF2XGPUCheck = New-Object System.Windows.Forms.CheckBox
$U_WF2XGPUCheck.Name = 'Waifu2xNoGPU'
$U_WF2XGPUCheck.Size = New-Object System.Drawing.Size(100, 16)
$U_WF2XGPUCheck.Location = New-Object System.Drawing.Size(184, 72)
$U_WF2XGPUCheck.Checked = $Waifu2xNoGPU
$U_WF2XGPUCheck.Text = ' Disable GPU'
$U_WF2XGPUCheck.Add_CheckStateChanged({ GUI_UpdateCheckBoxState ; U_WF2XGPU })
$UpscaleFilterGroup.Controls.Add($U_WF2XGPUCheck)
$U_WF2XGPUTip = New-Object System.Windows.Forms.ToolTip
$U_WF2XGPUTip.InitialDelay = $ToolTipDelay
$U_WF2XGPUTip.AutoPopDelay = $ToolTipDuration
$U_WF2XGPUTipString = 'Force using the CPU instead of the GPU. Waifu2x relies on nvidia CUDA, so this{0}'
$U_WF2XGPUTipString += 'option should only be used if a nvidia GPU is not available. Using the CPU is{0}'
$U_WF2XGPUTipString += 'much slower, but allows using Waifu2x with other GPU vendors (such as Intel).{0}'
$U_WF2XGPUTipString += '{0}'
$U_WF2XGPUTipString += 'AMD GPU users can instead use OpenCL with Waifu2x-CPP. This is much faster{0}'
$U_WF2XGPUTipString += 'than using the CPU, but it still will not be as fast as nvidia CUDA. This option{0}'
$U_WF2XGPUTipString += 'can not be enabled with "Enable OpenCL" and is forced off if using Waifu2x-CPP.'
$U_WF2XGPUTipString = [String]::Format($U_WF2XGPUTipString, [Environment]::NewLine)
$U_WF2XGPUTip.SetToolTip($U_WF2XGPUCheck, $U_WF2XGPUTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Waifu2x OpenCL (CPP Only)
function U_WF2XOpenCL()
{
  # Waifu2x-CPP can use OpenCL, but this can not be used with "Disable GPU".
  if (($this.Checked) -and ($U_WF2XGPUCheck.Checked))
  {
    $U_WF2XGPUCheck.Checked = $false
  }
}
#----------------------------------------------------------------------------------------------------------------------------------------------
$U_WF2XOpenCLCheck = New-Object System.Windows.Forms.CheckBox
$U_WF2XOpenCLCheck.Name = 'Waifu2xOpenCL'
$U_WF2XOpenCLCheck.Size = New-Object System.Drawing.Size(110, 16)
$U_WF2XOpenCLCheck.Location = New-Object System.Drawing.Size(184, 96)
$U_WF2XOpenCLCheck.Checked = $Waifu2xOpenCL
$U_WF2XOpenCLCheck.Text = ' Enable OpenCL'
$U_WF2XOpenCLCheck.Add_CheckStateChanged({ GUI_UpdateCheckBoxState ; U_WF2XOpenCL })
$UpscaleFilterGroup.Controls.Add($U_WF2XOpenCLCheck)
$U_WF2XOpenCLTip = New-Object System.Windows.Forms.ToolTip
$U_WF2XOpenCLTip.InitialDelay = $ToolTipDelay
$U_WF2XOpenCLTip.AutoPopDelay = $ToolTipDuration
$U_WF2XOpenCLTipString = 'If a nvidia GPU is not available, Waifu2x-CPP can attempt to use OpenCL to speed up{0}'
$U_WF2XOpenCLTipString += 'the upscaling process when compared to using the CPU. This option should be enabled{0}'
$U_WF2XOpenCLTipString += 'if the system is using an AMD GPU, and may work with some Intel integrated chipsets. '
$U_WF2XOpenCLTipString = [String]::Format($U_WF2XOpenCLTipString, [Environment]::NewLine)
$U_WF2XOpenCLTip.SetToolTip($U_WF2XOpenCLCheck, $U_WF2XOpenCLTipString)
#==============================================================================================================================================================================================
# It got annoying to track the visibility and position of these all over the place. So now it has its own function.

function GUI_UpdateWaifu2xSelection()
{
  # Caffe does not use OpenCL, but can configure a model. Also it has a noise reduction maximum of 3.
  if ($Waifu2xApp -eq 'waifu2x-caffe-cui.exe')
  {
    $U_WF2XOpenCLCheck.Hide()
    $U_WF2XModelCombo.Show()
    $U_WF2XModelLabel.Show()
    $U_WF2XGPUCheck.Location = New-Object System.Drawing.Size(184, 96)
    $U_WF2XModelCombo.Location = New-Object System.Drawing.Size(184, 68)
    $U_WF2XModelLabel.Location = New-Object System.Drawing.Size(278, 71)
    $U_WF2XNoiseBox.Maximum = 3
  }
  # CPP does use OpenCL, but can't configure a model. Also it has a noise reduction maximum of 2.
  elseif ($Waifu2xApp -eq 'waifu2x-converter_x64.exe')
  {
    $U_WF2XModelCombo.Hide()
    $U_WF2XModelLabel.Hide()
    $U_WF2XOpenCLCheck.Show()
    $U_WF2XGPUCheck.Location = New-Object System.Drawing.Size(184, 72)
    $U_WF2XModelCombo.Location = New-Object System.Drawing.Size(184, 96)
    $U_WF2XModelLabel.Location = New-Object System.Drawing.Size(278, 98)
    $U_WF2XNoiseBox.Maximum = 2
  }
}
#----------------------------------------------------------------------------------------------------------------------------------------------
# Updates the visibility and position of some options depending on which waifu2x is selected (caffe or cpp).
GUI_UpdateWaifu2xSelection
#----------------------------------------------------------------------------------------------------------------------------------------------
# If Waifu2x is not the selected filter, then hide all waifu2x options from the user.
if ($FilterSelected -ne 'Waifu2x')
{
  $U_WF2XModeCombo.Hide()
  $U_WF2XModeLabel.Hide()
  $U_WF2XNoiseBox.Hide()
  $U_WF2XNoiseLabel.Hide()
  $U_WF2XGPUCheck.Hide()
  $U_WF2XOpenCLCheck.Hide()
  $U_WF2XModelCombo.Hide()
  $U_WF2XModelLabel.Hide()
}
#==============================================================================================================================================================================================
# Create Option 8: Calculate Textures VRAM Requirement
#==============================================================================================================================================================================================
function GUI_UpdateVRAMFolderPath_Finish($UpdatePath)
{
  # Users might think it's cool to put a final slash at the end. It's not cool.
  if ($UpdatePath.Substring(($UpdatePath.Length - 1), 1) -eq '\')
  {
    # If a slash was found, keep everything but the slash.
    $UpdatePath = $UpdatePath.Substring(0, ($UpdatePath.Length - 1))
  }
  # Update the temp folder with the new value.
  $global:VRAMPackPath = $UpdatePath

  # Update the text box with the new path.
  $VRAMPathTextBox.Text = $UpdatePath
}
#----------------------------------------------------------------------------------------------------------------------------------------------
function GUI_UpdateVRAMFolderPath_DragDrop()
{
  # Make sure there is data present before actually doing anything.
  if ($_.Data.GetDataPresent([Windows.Forms.DataFormats]::FileDrop))
  {
    # Create a list of the data to select the first item from the list.
    $DroppedPath = [string]($_.Data.GetData([Windows.Forms.DataFormats]::FileDrop))

    # Make sure the path is a folder and prevent the path from having any form of '~' in it.
    if ((Test-Path -LiteralPath $DroppedPath -PathType Container))
    {
      # Finish setting the TempFolder.
      GUI_UpdateVRAMFolderPath_Finish -UpdatePath $DroppedPath
    }
  }
}
#----------------------------------------------------------------------------------------------------------------------------------------------
function GUI_UpdateVRAMFolderPath_Button()
{
  # Display an "Open Folder" menu to get the path.
  $SelectedPath = Get-Folder -Message 'Select a path for where Custom Texture Tool PS will search for textures to calculate VRAM usage.'

  # Check to see if a folder was selected from the Open menu and test if that path exists.
  if (($SelectedPath -ne '') -and (TestPath -LiteralPath $SelectedPath))
  {
    # Finish setting the TempFolder.
    GUI_UpdateVRAMFolderPath_Finish -UpdatePath $SelectedPath
  }
}
#----------------------------------------------------------------------------------------------------------------------------------------------
function GUI_UpdateVRAMFolderPath_TextBox()
{
  # Get the current value of the MasterPath.
  $CurrentPath = Get-Variable -Name $this.Name -ValueOnly
  $EnteredText = $this.Text

  # To avoid updating constantly, check to see if the text actually changed and that the path actually exists.
  if (($EnteredText -ne $CurrentPath) -and ($EnteredText -ne '') -and (TestPath -LiteralPath $EnteredText))
  {
    # Finish setting the TempFolder.
    GUI_UpdateVRAMFolderPath_Finish -UpdatePath $EnteredText

    # We're done here, get out.
    return
  }
  # Set the textbox text back to the MasterPath.
  $this.Text = $CurrentPath
}
#----------------------------------------------------------------------------------------------------------------------------------------------
$VRAMGroup = New-Object System.Windows.Forms.GroupBox
$VRAMGroup.Size = New-Object System.Drawing.Size(380, 124)
$VRAMGroup.Location = New-Object System.Drawing.Size(10, 260)
$VRAMGroup.Text = ' Calculate VRAM: '
$MainDialog.Controls.Add($VRAMGroup)
#----------------------------------------------------------------------------------------------------------------------------------------------
$VRAMDescription = New-Object System.Windows.Forms.Label
$VRAMDescription.Size = New-Object System.Drawing.Size(360, 50)
$VRAMDescription.Location = New-Object System.Drawing.Size(10, 24)
$VRAMDescriptionString = "Scans a folder and all subfolders for textures and reports the amount of VRAM the textures will consume. This path "
$VRAMDescriptionString += 'is unique and separate from the main Texture Path so generated folders can be scanned.'
$VRAMDescription.Text = $VRAMDescriptionString
$VRAMGroup.Controls.Add($VRAMDescription)
#----------------------------------------------------------------------------------------------------------------------------------------------
$global:VRAMPackPath = ''
#----------------------------------------------------------------------------------------------------------------------------------------------
$VRAMPathLabel = New-Object System.Windows.Forms.Label
$VRAMPathLabel.Size = New-Object System.Drawing.Size(300, 14)
$VRAMPathLabel.Location = New-Object System.Drawing.Size(10, 80)
$VRAMPathLabel.Text = 'Texture Path  -  Add with the button or drag and drop:'
$VRAMGroup.Controls.Add($VRAMPathLabel)
$VRAMPathLabelTip = New-Object System.Windows.Forms.ToolTip
$VRAMPathLabelTip.InitialDelay = $ToolTipDelay
$VRAMPathLabelTip.AutoPopDelay = $ToolTipDuration
$VRAMPathLabelTipString = 'The path to the textures to calculate VRAM usage.'
$VRAMPathLabelTip.SetToolTip($VRAMPathLabel, $VRAMPathLabelTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$VRAMPathTextBox = New-Object System.Windows.Forms.TextBox
$VRAMPathTextBox.Name = 'VRAMPackPath'
$VRAMPathTextBox.Size = New-Object System.Drawing.Size(328, 22)
$VRAMPathTextBox.Location = New-Object System.Drawing.Size(10, 95)
$VRAMPathTextBox.Text = $VRAMPackPath
$VRAMPathTextBox.AllowDrop = $true
$VRAMPathTextBox.Add_DragEnter({ $_.Effect = [Windows.Forms.DragDropEffects]::Copy })
$VRAMPathTextBox.Add_DragDrop({ GUI_UpdateVRAMFolderPath_DragDrop })
$VRAMPathTextBox.Add_Leave({ GUI_UpdateVRAMFolderPath_TextBox })
$VRAMGroup.Controls.Add($VRAMPathTextBox)
#----------------------------------------------------------------------------------------------------------------------------------------------
$VRAMPathButton = New-Object System.Windows.Forms.Button
$VRAMPathButton.Name = 'VRAMPackPath'
$VRAMPathButton.Size = New-Object System.Drawing.Size(24, 22)
$VRAMPathButton.Location = New-Object System.Drawing.Size(346, 93)
$VRAMPathButton.Text = '...'
$VRAMPathButton.Add_Click({ GUI_UpdateVRAMFolderPath_Button })
$VRAMGroup.Controls.Add($VRAMPathButton)
#==============================================================================================================================================================================================
#  Create Advanced Option 1: Generate New MipMaps
#==============================================================================================================================================================================================
$GenNewMipMapsGroup = New-Object System.Windows.Forms.GroupBox
$GenNewMipMapsGroup.Size = New-Object System.Drawing.Size(380, 124)
$GenNewMipMapsGroup.Location = New-Object System.Drawing.Size(10, 260)
$GenNewMipMapsGroup.Text = ' Description '
$MainDialog.Controls.Add($GenNewMipMapsGroup)
#----------------------------------------------------------------------------------------------------------------------------------------------
$GenNewMipMapsLabel = New-Object System.Windows.Forms.Label
$GenNewMipMapsLabel.Size = New-Object System.Drawing.Size(360, 66)
$GenNewMipMapsLabel.Location = New-Object System.Drawing.Size(10, 24)
$GenNewMipMapsString = 'This option generates new mipmaps within the texture pack itself. Dynamic mipmaps are preserved unless the "Force New Mipmaps" option is ticked. '
$GenNewMipMapsString += 'Care must be taken with this option as textures with incorrect dimensions will have incorrect mipmaps. If in doubt, use "Scan Texture For Issues" '
$GenNewMipMapsString += 'and check "Auto-Repair".'
$GenNewMipMapsLabel.Text = $GenNewMipMapsString
$GenNewMipMapsGroup.Controls.Add($GenNewMipMapsLabel)
#==============================================================================================================================================================================================
#  Create Advanced Option 2: Remove Invalid MipMaps
#==============================================================================================================================================================================================
$InvalidMipMapsGroup = New-Object System.Windows.Forms.GroupBox
$InvalidMipMapsGroup.Size = New-Object System.Drawing.Size(380, 124)
$InvalidMipMapsGroup.Location = New-Object System.Drawing.Size(10, 260)
$InvalidMipMapsGroup.Text = ' Description '
$MainDialog.Controls.Add($InvalidMipMapsGroup)
#----------------------------------------------------------------------------------------------------------------------------------------------
$InvalidMipMapsLabel = New-Object System.Windows.Forms.Label
$InvalidMipMapsLabel.Size = New-Object System.Drawing.Size(360, 66)
$InvalidMipMapsLabel.Location = New-Object System.Drawing.Size(10, 24)
$InvalidMipMapsString = 'Scans a texture pack for textures that contain mipmap levels that are not actually a mipmap texture and deletes them. This can find both external '
$InvalidMipMapsString += 'and internal mipmaps. Internal mipmaps are only searched for if the texture is a DDS texture.'
$InvalidMipMapsLabel.Text = $InvalidMipMapsString
$InvalidMipMapsGroup.Controls.Add($InvalidMipMapsLabel)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Hide OK Textures
function X_HideOkTextures()
{
  # When checked, also update all other "Hide OK Textures" checkboxes.
  $S_HideOKCheck.Checked = $this.Checked
  $Y_HideOKCheck.Checked = $this.Checked
}
#----------------------------------------------------------------------------------------------------------------------------------------------
$X_HideOKCheck = New-Object System.Windows.Forms.CheckBox
$X_HideOKCheck.Name = 'HideOKTextures'
$X_HideOKCheck.Size = New-Object System.Drawing.Size(120, 16)
$X_HideOKCheck.Location = New-Object System.Drawing.Size(12, 90)
$X_HideOKCheck.Checked = $HideOKTextures
$X_HideOKCheck.Text = ' Hide OK Textures'
$X_HideOKCheck.Add_CheckStateChanged({ GUI_UpdateCheckBoxState ; X_HideOkTextures })
$InvalidMipMapsGroup.Controls.Add($X_HideOKCheck)
$X_HideOKTip = New-Object System.Windows.Forms.ToolTip
$X_HideOKTip.InitialDelay = $ToolTipDelay
$X_HideOKTip.AutoPopDelay = $ToolTipDuration
$X_HideOKTipString = 'Textures that do not have mipmaps removed are flagged as "OK".{0}'
$X_HideOKTipString += 'This option prevents these textures from showing up in the log file.'
$X_HideOKTipString = [String]::Format($X_HideOKTipString, [Environment]::NewLine)
$X_HideOKTip.SetToolTip($X_HideOKCheck, $X_HideOKTipString)
#==============================================================================================================================================================================================
#  Create Advanced Option 3: Extract DDS Internal MipMaps
#==============================================================================================================================================================================================
$ExtractMipMapGroup = New-Object System.Windows.Forms.GroupBox
$ExtractMipMapGroup.Size = New-Object System.Drawing.Size(380, 124)
$ExtractMipMapGroup.Location = New-Object System.Drawing.Size(10, 260)
$ExtractMipMapGroup.Text = ' Description '
$MainDialog.Controls.Add($ExtractMipMapGroup)
#----------------------------------------------------------------------------------------------------------------------------------------------
$ExtractMipMapLabel = New-Object System.Windows.Forms.Label
$ExtractMipMapLabel.Size = New-Object System.Drawing.Size(360, 66)
$ExtractMipMapLabel.Location = New-Object System.Drawing.Size(10, 24)
$ExtractMipMapString = 'Finds DDS textures that have internal mipmaps and extracts them directly into the texture pack, overwriting the old texture. This can '
$ExtractMipMapString += 'not be undone, so make sure to always have a backup of the texture pack when using any of these options.'
$ExtractMipMapLabel.Text = $ExtractMipMapString
$ExtractMipMapGroup.Controls.Add($ExtractMipMapLabel)
#==============================================================================================================================================================================================
#  Create Advanced Option 4: Remove Alpha Channel From Opaque Textures
#==============================================================================================================================================================================================
$RemoveAlphaGroup = New-Object System.Windows.Forms.GroupBox
$RemoveAlphaGroup.Size = New-Object System.Drawing.Size(380, 124)
$RemoveAlphaGroup.Location = New-Object System.Drawing.Size(10, 260)
$RemoveAlphaGroup.Text = ' Description '
$MainDialog.Controls.Add($RemoveAlphaGroup)
#----------------------------------------------------------------------------------------------------------------------------------------------
$RemoveAlphaLabel = New-Object System.Windows.Forms.Label
$RemoveAlphaLabel.Size = New-Object System.Drawing.Size(360, 66)
$RemoveAlphaLabel.Location = New-Object System.Drawing.Size(10, 24)
$RemoveAlphaString = "Textures that are found to have an alpha channel but don't actually contain any transparent pixels will have the alpha channel removed. "
$RemoveAlphaString += 'Although this option works with DDS textures, it is most useful for PNG textures. DDS textures created with this script will not have this issue.'
$RemoveAlphaLabel.Text = $RemoveAlphaString
$RemoveAlphaGroup.Controls.Add($RemoveAlphaLabel)
#----------------------------------------------------------------------------------------------------------------------------------------------
# Hide OK Textures
function Y_HideOkTextures()
{
  # When checked, also update all other "Hide OK Textures" checkboxes.
  $S_HideOKCheck.Checked = $this.Checked
  $X_HideOKCheck.Checked = $this.Checked
}
#----------------------------------------------------------------------------------------------------------------------------------------------
$Y_HideOKCheck = New-Object System.Windows.Forms.CheckBox
$Y_HideOKCheck.Name = 'HideOKTextures'
$Y_HideOKCheck.Size = New-Object System.Drawing.Size(120, 16)
$Y_HideOKCheck.Location = New-Object System.Drawing.Size(12, 90)
$Y_HideOKCheck.Checked = $HideOKTextures
$Y_HideOKCheck.Text = ' Hide OK Textures'
$Y_HideOKCheck.Add_CheckStateChanged({ GUI_UpdateCheckBoxState ; Y_HideOkTextures})
$RemoveAlphaGroup.Controls.Add($Y_HideOKCheck)
$Y_HideOKTip = New-Object System.Windows.Forms.ToolTip
$Y_HideOKTip.InitialDelay = $ToolTipDelay
$Y_HideOKTip.AutoPopDelay = $ToolTipDuration
$Y_HideOKTipString = 'Textures that do not have an alpha channel removed are flagged as "OK".{0}'
$Y_HideOKTipString += 'This option prevents these textures from showing up in the log file.'
$Y_HideOKTipString = [String]::Format($Y_HideOKTipString, [Environment]::NewLine)
$Y_HideOKTip.SetToolTip($Y_HideOKCheck, $Y_HideOKTipString)
#==============================================================================================================================================================================================
#  Create Advanced Option 5: Combine Multiple Textures
#==============================================================================================================================================================================================
function CombineTextures_UpdateName()
{
  # Make sure the input only contains letters, numbers, or spaces.
  if (($this.Text -ne '') -and ($this.Text -match "^[a-zA-Z0-9\s]+$"))
  {
    # If the check passed then update the name to be used.
    $global:CombinedName = $this.Text
  }
  # Update the text box with either the new name or the previous name if the above check failed.
  $this.Text = $CombinedName + $PNG
}
#----------------------------------------------------------------------------------------------------------------------------------------------
function CombineTextures_UpdateArray()
{
  # Create a new empty texture array using the current number of rows and columns.
  $NewTextureArray = New-Object 'string[,]' ([int]$TextureRows+1),([int]$TextureColumns+1)

  # Loop through all rows.
  for($row = 1; $row -le [int]$TextureRows; $row++)
  {
    # Loop through all columns.
    for($col = 1; $col -le [int]$TextureColumns; $col++)
    {
      # Check to see if an array was already created and the current element holds a value.
      if (($TextureArray -ne $null) -and ($TextureArray[$row,$col] -ne $null))
      {
        # If there was data in the old array then copy that data into the new array.
        $NewTextureArray[$row,$col] = $TextureArray[$row,$col]
      }
      # If the array did not exist, or the current element's value was empty.
      else
      {
        # Set the value to an empty string.
        $NewTextureArray[$row,$col] = ''
      }
    }
  }
  # Overwrite the old TextureArray with the new one.
  $global:TextureArray = $NewTextureArray
}
#----------------------------------------------------------------------------------------------------------------------------------------------
function GUI_TextureArray_UpdateCells()
{
  # Update the global variable pulled from $this.Name that holds the rows ($TextureRows) or columns ($TextureColumns).
  Set-Variable -Name $this.Name -Value $this.Value.ToString() -Scope 'Global'

  # Only update the texture array if this is done from the Combine Textures numeric up/down boxes, and not the Split Texture ones.
  if (($this.Name -eq 'TextureRows') -or ($this.Name -eq 'TextureColumns'))
  {
    # Update the texture array.
    CombineTextures_UpdateArray
  }
}
#----------------------------------------------------------------------------------------------------------------------------------------------
function GUI_CombineTextures_DialogUpdate([string]$ImageFile)
{
  # Split the clicked button name to represent the row and column. The button name matches the row and column seperated by a comma (Example: 2,3).
  $ButtonName = $this.Name.Split(',')
  $CurrentRow = [int]$ButtonName[0]
  $CurrentCol = [int]$ButtonName[1]

  # Set the image to the appropriate texture array.
  $global:TextureArray[$CurrentRow,$CurrentCol] = $ImageFile

  # Update the button with a preview of the image.
  $ImagePath            = [string](Get-ChildItem -LiteralPath $ImageFile)
  $DiplayImage          = [System.Drawing.Image]::FromFile($ImagePath)
  $this.BackgroundImage = $DiplayImage
  $this.Text            = ''

  # Update the default path to where the last texture was selected.
  $global:SelectionPath = [string](Get-ChildItem -LiteralPath $ImageFile).Directory
}
#----------------------------------------------------------------------------------------------------------------------------------------------
function GUI_CombineTextures_DialogButtonSelect()
{
  # Create an open file dialog to grab a PNG image.
  $SelectedFile = Get-FileName -Path $SelectionPath -Description 'PNG Image' -FileName '*.png'

  # Check if the image exists.
  if (TestPath -LiteralPath $SelectedFile)
  {
    # Add the texture to the array and update the button with a preview of the image.
    GUI_CombineTextures_DialogUpdate -ImageFile $SelectedFile
  }
}
#----------------------------------------------------------------------------------------------------------------------------------------------
function GUI_CombineTextures_DialogDragDrop()
{
  # Make sure there is data present before actually doing anything.
  if ($_.Data.GetDataPresent([Windows.Forms.DataFormats]::FileDrop))
  {
    # Create a list of the data to select the first item from the list.
    $DroppedFile   = $_.Data.GetData([Windows.Forms.DataFormats]::FileDrop)
    $FileExtension = [string](Get-ChildItem -LiteralPath $DroppedFile[0]).Extension

    # Make sure the file is a PNG image.
    if ($FileExtension -eq $PNG)
    {
      # Add the texture to the array and update the button with a preview of the image.
      GUI_CombineTextures_DialogUpdate -ImageFile $DroppedFile[0]
    }
  }
}
#----------------------------------------------------------------------------------------------------------------------------------------------
# Because it's easier to just destroy the dialog and recreate it every time its displayed.

function GUI_CombineTextures_DialogDisplay()
{
  # Set the size of the dialog depending on the number of textures in the array.
  $CombineDialogWidth  = 50 * [int]$TextureColumns
  $CombineDialogHeight = 80 + (50 * [int]$TextureRows)

  # Create the dialog that is displayed.
  $CombineDialog                 = New-Object System.Windows.Forms.Form
  $CombineDialog.Text            = "Combine Textures"
  $CombineDialog.Size            = New-Object System.Drawing.Size($CombineDialogWidth, $CombineDialogHeight)
  $CombineDialog.MinimumSize     = New-Object System.Drawing.Size(1, 1)
  $CombineDialog.MaximizeBox     = $false
  $CombineDialog.MinimizeBox     = $false
  $CombineDialog.AutoSize        = $true
  $CombineDialog.AutoSizeMode    = [System.Windows.Forms.AutoSizeMode]::GrowAndShrink
  $CombineDialog.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
  $CombineDialog.StartPosition   = "CenterScreen"
  $CombineDialog.KeyPreview      = $true
  $CombineDialog.Topmost = $True
  $CombineDialog.Add_KeyDown({ EscapeCloseDialog })
  $CombineDialog.Add_Shown({$CombineDialog.Activate()})

  # Create arrays, tips, and identifiers for the buttons.
  $global:CombineButton = @()
  $global:CombineTip = @()
  $i = 0

  # Set up the initial offsets for the buttons.
  $ButtonXOffset = 4
  $ButtonYOffset = 4

  # Loop through all rows.
  for($row = 1; $row -le [int]$TextureRows; $row++)
  {
    # And loop through all columns.
    for($col = 1; $col -le [int]$TextureColumns; $col++)
    {
      # Create the current button and add it to the dialog.
      $global:CombineButton += New-Object System.Windows.Forms.Button
      $CombineButton[$i].Location = New-Object System.Drawing.Size($ButtonXOffset, $ButtonYOffset)
      $CombineButton[$i].Size = New-Object System.Drawing.Size(50, 50)
      $CombineButton[$i].Name = ($row.ToString() + ',' + $col.ToString())
      $CombineButton[$i].Text = ($row.ToString() + ',' + $col.ToString())
      $CombineButton[$i].BackgroundImageLayout = 'Stretch'
      $CombineButton[$i].AllowDrop = $true
      $CombineButton[$i].Add_DragEnter({$_.Effect = [Windows.Forms.DragDropEffects]::Copy})
      $CombineButton[$i].Add_DragDrop({GUI_CombineTextures_DialogDragDrop})
      $CombineButton[$i].Add_Click({GUI_CombineTextures_DialogButtonSelect})
      $CombineDialog.Controls.Add($CombineButton[$i])

      # Add a tooltip to show the texture position.
      $global:CombineTip += New-Object System.Windows.Forms.ToolTip
      $CombineTip[$i].InitialDelay = 1000
      $CombineTip[$i].AutoPopDelay = 5000
      $CombineTipString = 'Row ' + $row + ', Column ' + $col
      $CombineTip[$i].SetToolTip($CombineButton[$i], $CombineTipString)

      # If a texture exists in the array then show the image on the current button.
      if ($TextureArray[$row,$col] -ne '')
      {
        # Update the button with a preview of the image.
        $ImagePath = $TextureArray[$row,$col]
        $DiplayImage = [System.Drawing.Image]::FromFile($ImagePath)
        $CombineButton[$i].BackgroundImage = $DiplayImage
        $CombineButton[$i].Text = ''
      }
      # Increment the offset and position variables.
      $ButtonXOffset += 50
      $i += 1
    }
    $ButtonXOffset = 4
    $ButtonYOffset += 50
  }
  # Create a "Close" button.
  $CloseButton = New-Object System.Windows.Forms.Button
  $CloseButton.Location = New-Object System.Drawing.Size(4, ($CombineDialogHeight - 60))
  $CloseButton.Size = New-Object System.Drawing.Size(60, 26)
  $CloseButton.Text = 'Done'
  $CloseButton.Add_Click({$CombineDialog.Close()})
  $CombineDialog.Controls.Add($CloseButton)
  $CloseButtonTip = New-Object System.Windows.Forms.ToolTip
  $CloseButtonTip.InitialDelay = $ToolTipDelay
  $CloseButtonTip.AutoPopDelay = $ToolTipDuration
  $CloseButtonTipString = 'Finish adding textures to the array.'
  $CloseButtonTip.SetToolTip($CloseButton, $CloseButtonTipString)

  # After the dialog is fully created, show it to the user.
  $CombineDialog.ShowDialog() | Out-Null
}
#----------------------------------------------------------------------------------------------------------------------------------------------
$CombineTextureGroup = New-Object System.Windows.Forms.GroupBox
$CombineTextureGroup.Size = New-Object System.Drawing.Size(380, 124)
$CombineTextureGroup.Location = New-Object System.Drawing.Size(10, 260)
$CombineTextureGroup.Text = ' Combine Texture Options '
$MainDialog.Controls.Add($CombineTextureGroup)
#----------------------------------------------------------------------------------------------------------------------------------------------
$CombineNameTextBox = New-Object System.Windows.Forms.TextBox
$CombineNameTextBox.Name = 'CombinedName'
$CombineNameTextBox.Size = New-Object System.Drawing.Size(150, 20)
$CombineNameTextBox.Location = New-Object System.Drawing.Size(126, 20)
$CombineNameTextBox.Text = $CombinedName + $PNG
$CombineNameTextBox.Add_Leave({ CombineTextures_UpdateName })
$CombineNameLabel = New-Object System.Windows.Forms.Label
$CombineNameLabel.Size = New-Object System.Drawing.Size(130, 22)
$CombineNameLabel.Location = New-Object System.Drawing.Size(10, 23)
$CombineNameLabel.Text = 'Texture Output Name'
$CombineTextureGroup.Controls.Add($CombineNameTextBox)
$CombineTextureGroup.Controls.Add($CombineNameLabel)
$CombineRowsTip = New-Object System.Windows.Forms.ToolTip
$CombineRowsTip.InitialDelay = $ToolTipDelay
$CombineRowsTip.AutoPopDelay = $ToolTipDuration
$CombineRowsTipString = 'The name of the final texture that is created from the texture array. It is not necessary to{0}'
$CombineRowsTipString += 'include a file extension in the name as it will be automatically added. Trying to force the file{0}'
$CombineRowsTipString += 'extension will not force the texture into a different format as the entire method of combining{0}'
$CombineRowsTipString += 'textures is limited to creating PNG files only.'
$CombineRowsTipString = [String]::Format($CombineRowsTipString, [Environment]::NewLine)
$CombineRowsTip.SetToolTip($CombineNameLabel, $CombineRowsTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$CombineRowsNumBox = New-Object System.Windows.Forms.NumericUpDown
$CombineRowsNumBox.Name = 'TextureRows'
$CombineRowsNumBox.Size = New-Object System.Drawing.Size(72, 10)
$CombineRowsNumBox.Location = New-Object System.Drawing.Size(10, 50)
$CombineRowsNumBox.DecimalPlaces = 0
$CombineRowsNumBox.Value = $TextureRows
$CombineRowsNumBox.Minimum = 1
$CombineRowsNumBox.Maximum = 18
$CombineRowsNumBox.Increment = 1
$CombineRowsNumBox.Add_ValueChanged({ GUI_TextureArray_UpdateCells })
$CombineRowsLabel = New-Object System.Windows.Forms.Label
$CombineRowsLabel.Size = New-Object System.Drawing.Size(82, 18)
$CombineRowsLabel.Location = New-Object System.Drawing.Size(84, 52)
$CombineRowsLabel.Text = 'Texture Rows'
$CombineTextureGroup.Controls.Add($CombineRowsNumBox)
$CombineTextureGroup.Controls.Add($CombineRowsLabel)
$CombineRowsTip = New-Object System.Windows.Forms.ToolTip
$CombineRowsTip.InitialDelay = $ToolTipDelay
$CombineRowsTip.AutoPopDelay = $ToolTipDuration
$CombineRowsTipString = 'The number of rows in the texture grid. This value (along with columns) is {0}'
$CombineRowsTipString += 'essential in calculating the correct number of cells the final texture will {0}'
$CombineRowsTipString += 'have. The number of textures in the final texture is simply (rows * colums).'
$CombineRowsTipString = [String]::Format($CombineRowsTipString, [Environment]::NewLine)
$CombineRowsTip.SetToolTip($CombineRowsLabel, $CombineRowsTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$CombineColumnsNumBox = New-Object System.Windows.Forms.NumericUpDown
$CombineColumnsNumBox.Name = 'TextureColumns'
$CombineColumnsNumBox.Size = New-Object System.Drawing.Size(72, 10)
$CombineColumnsNumBox.Location = New-Object System.Drawing.Size(190, 50)
$CombineColumnsNumBox.DecimalPlaces = 0
$CombineColumnsNumBox.Value = $TextureColumns
$CombineColumnsNumBox.Minimum = 1
$CombineColumnsNumBox.Maximum = 18
$CombineColumnsNumBox.Increment = 1
$CombineColumnsNumBox.Add_ValueChanged({ GUI_TextureArray_UpdateCells })
$CombineColumnsLabel = New-Object System.Windows.Forms.Label
$CombineColumnsLabel.Size = New-Object System.Drawing.Size(100, 18)
$CombineColumnsLabel.Location = New-Object System.Drawing.Size(266, 52)
$CombineColumnsLabel.Text = 'Texture Columns'
$CombineTextureGroup.Controls.Add($CombineColumnsNumBox)
$CombineTextureGroup.Controls.Add($CombineColumnsLabel)
$CombineColumnsTip = New-Object System.Windows.Forms.ToolTip
$CombineColumnsTip.InitialDelay = $ToolTipDelay
$CombineColumnsTip.AutoPopDelay = $ToolTipDuration
$CombineColumnsTipString = 'The number of columns in the texture grid. This value (along with rows) is {0}'
$CombineColumnsTipString += 'essential in calculating the correct number of cells the final texture will {0}'
$CombineColumnsTipString += 'have. The number of textures in the final texture is simply (rows * colums).'
$CombineColumnsTipString = [String]::Format($CombineColumnsTipString, [Environment]::NewLine)
$CombineColumnsTip.SetToolTip($CombineColumnsLabel, $CombineColumnsTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$CombineSelectButton = New-Object System.Windows.Forms.Button
$CombineSelectButton.Size = New-Object System.Drawing.Size(100, 28)
$CombineSelectButton.Location = New-Object System.Drawing.Size(138, 84)
$CombineSelectButton.Text = 'Select Textures'
$CombineSelectButton.Add_Click({ GUI_CombineTextures_DialogDisplay })
$CombineTextureGroup.Controls.Add($CombineSelectButton)
$CombineSelectTip = New-Object System.Windows.Forms.ToolTip
$CombineSelectTip.InitialDelay = $ToolTipDelay
$CombineSelectTip.AutoPopDelay = $ToolTipDuration
$CombineSelectTipString = 'Opens the button grid that allows adding textures into the texture array.{0}'
$CombineSelectTipString = 'It is also possible to drop textures onto the buttons to add them to the array.{0}'
$CombineSelectTipString += '{0}'
$CombineSelectTipString += 'Warning: The texture array is wiped out every time one of the Standard or{0}'
$CombineSelectTipString += 'Advanced options is selected, which removes all selected textures!'
$CombineSelectTipString = [String]::Format($CombineSelectTipString, [Environment]::NewLine)
$CombineSelectTip.SetToolTip($CombineSelectButton, $CombineSelectTipString)
#==============================================================================================================================================================================================
#  Create Advanced Option 6: Split Combined Multi-Texture
#==============================================================================================================================================================================================
$global:CTTDataFile = ''
$global:CombinedTexture = 'Select a texture to split into multiple textures...'
#----------------------------------------------------------------------------------------------------------------------------------------------
$SplitTextureGroup = New-Object System.Windows.Forms.GroupBox
$SplitTextureGroup.Size = New-Object System.Drawing.Size(380, 124)
$SplitTextureGroup.Location = New-Object System.Drawing.Size(10, 260)
$SplitTextureGroup.Text = ' Split Multi-Texture Options '
$MainDialog.Controls.Add($SplitTextureGroup)
#----------------------------------------------------------------------------------------------------------------------------------------------
$SplitTextureTextBox = New-Object System.Windows.Forms.TextBox
$SplitTextureTextBox.Name = 'CombinedTexture'
$SplitTextureTextBox.Size = New-Object System.Drawing.Size(320, 22)
$SplitTextureTextBox.Location = New-Object System.Drawing.Size(10, 20)
$SplitTextureTextBox.Text = $CombinedTexture
$SplitTextureTextBox.ReadOnly = $true
$SplitTextureTextBox.Add_Click({ GUI_UpdateFilePath_Button -TextBox $SplitTextureTextBox -Description 'PNG Image' -FileName '*.png' })
$SplitTextureGroup.Controls.Add($SplitTextureTextBox)
$SplitTextureTipA = New-Object System.Windows.Forms.ToolTip
$SplitTextureTipA.InitialDelay = $ToolTipDelay
$SplitTextureTipA.AutoPopDelay = $ToolTipDuration
$SplitTextureTipAString = 'The path to the texture that is to be split. Loading a CTT file will{0}'
$SplitTextureTipAString += 'fill this value in automatically, but the path may have changed so{0}'
$SplitTextureTipAString += 'this field will need to be updated in that case.'
$SplitTextureTipAString = [String]::Format($SplitTextureTipAString, [Environment]::NewLine)
$SplitTextureTipA.SetToolTip($SplitTextureTextBox, $SplitTextureTipAString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$SplitTextureButton = New-Object System.Windows.Forms.Button
$SplitTextureButton.Name = 'CombinedTexture'
$SplitTextureButton.Size = New-Object System.Drawing.Size(26, 22)
$SplitTextureButton.Location = New-Object System.Drawing.Size(342, 18)
$SplitTextureButton.Text = '...'
$SplitTextureButton.Add_Click({ GUI_UpdateFilePath_Button -TextBox $SplitTextureTextBox -Description 'PNG Image' -FileName '*.png' })
$SplitTextureGroup.Controls.Add($SplitTextureButton)
$SplitTextureTipB = New-Object System.Windows.Forms.ToolTip
$SplitTextureTipB.InitialDelay = $ToolTipDelay
$SplitTextureTipB.AutoPopDelay = $ToolTipDuration
$SplitTextureTipBString = 'The path to the texture that is to be split. Loading a CTT file will{0}'
$SplitTextureTipBString += 'fill this value in automatically, but the path may have changed so{0}'
$SplitTextureTipBString += 'this field will need to be updated in that case.'
$SplitTextureTipBString = [String]::Format($SplitTextureTipBString, [Environment]::NewLine)
$SplitTextureTipB.SetToolTip($SplitTextureButton, $SplitTextureTipBString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$SplitRowsNumBox = New-Object System.Windows.Forms.NumericUpDown
$SplitRowsNumBox.Name = 'CTextureRows'
$SplitRowsNumBox.Size = New-Object System.Drawing.Size(72, 10)
$SplitRowsNumBox.Location = New-Object System.Drawing.Size(10, 50)
$SplitRowsNumBox.DecimalPlaces = 0
$SplitRowsNumBox.Value = $CTextureRows
$SplitRowsNumBox.Minimum = 1
$SplitRowsNumBox.Maximum = 18
$SplitRowsNumBox.Increment = 1
$SplitRowsNumBox.Add_ValueChanged({ GUI_TextureArray_UpdateCells})
$SplitRowsLabel = New-Object System.Windows.Forms.Label
$SplitRowsLabel.Size = New-Object System.Drawing.Size(82, 18)
$SplitRowsLabel.Location = New-Object System.Drawing.Size(84, 52)
$SplitRowsLabel.Text = 'Texture Rows'
$SplitTextureGroup.Controls.Add($SplitRowsNumBox)
$SplitTextureGroup.Controls.Add($SplitRowsLabel)
$SplitRowsTip = New-Object System.Windows.Forms.ToolTip
$SplitRowsTip.InitialDelay = $ToolTipDelay
$SplitRowsTip.AutoPopDelay = $ToolTipDuration
$SplitRowsTipString = 'The number of rows in the texture grid. This value (along with columns) is essential{0}'
$SplitRowsTipString += 'in calculating the correct number of textures that will be split from the multi-texture.{0}'
$SplitRowsTipString += 'Loading a CTT file will fill this value in automatically, but a CTT file is not necessary{0}'
$SplitRowsTipString += 'if the number of rows and columns has already been calculated. The number of textures{0}'
$SplitRowsTipString += 'created from the final texture is simply (rows * colums). '
$SplitRowsTipString = [String]::Format($SplitRowsTipString, [Environment]::NewLine)
$SplitRowsTip.SetToolTip($SplitRowsLabel, $SplitRowsTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
$SplitColumnsNumBox = New-Object System.Windows.Forms.NumericUpDown
$SplitColumnsNumBox.Name = 'CTextureColumns'
$SplitColumnsNumBox.Size = New-Object System.Drawing.Size(72, 10)
$SplitColumnsNumBox.Location = New-Object System.Drawing.Size(190, 50)
$SplitColumnsNumBox.DecimalPlaces = 0
$SplitColumnsNumBox.Value = $CTextureColumns
$SplitColumnsNumBox.Minimum = 1
$SplitColumnsNumBox.Maximum = 18
$SplitColumnsNumBox.Increment = 1
$SplitColumnsNumBox.Add_ValueChanged({ GUI_TextureArray_UpdateCells })
$SplitColumnsLabel = New-Object System.Windows.Forms.Label
$SplitColumnsLabel.Size = New-Object System.Drawing.Size(100, 18)
$SplitColumnsLabel.Location = New-Object System.Drawing.Size(266, 52)
$SplitColumnsLabel.Text = 'Texture Columns'
$SplitTextureGroup.Controls.Add($SplitColumnsNumBox)
$SplitTextureGroup.Controls.Add($SplitColumnsLabel)
$SplitColumnsTip = New-Object System.Windows.Forms.ToolTip
$SplitColumnsTip.InitialDelay = $ToolTipDelay
$SplitColumnsTip.AutoPopDelay = $ToolTipDuration
$SplitColumnsTipString = 'The number of columns in the texture grid. This value (along with rows) is essential{0}'
$SplitColumnsTipString += 'in calculating the correct number of textures that will be split from the multi-texture.{0}'
$SplitColumnsTipString += 'Loading a CTT file will fill this value in automatically, but a CTT file is not necessary{0}'
$SplitColumnsTipString += 'if the number of rows and columns has already been calculated. The number of textures{0}'
$SplitColumnsTipString += 'created from the final texture is simply (rows * colums). '
$SplitColumnsTipString = [String]::Format($SplitColumnsTipString, [Environment]::NewLine)
$SplitColumnsTip.SetToolTip($SplitColumnsLabel, $SplitColumnsTipString)
#----------------------------------------------------------------------------------------------------------------------------------------------
function SplitTexture_LoadCTTFile()
{
  # Load the selected CTT file.
  $Load_CTTDataFile = Get-FileName -Path $SelectionPath -Description 'CTT File' -FileName '*.ctt'

  # Test the path to the CTT file.
  if (TestPath -LiteralPath $Load_CTTDataFile)
  {
    # Load the selected CTT file.
    $global:CTTDataFile = $Load_CTTDataFile

    # Get the content of the CTT file.
    $CTTContent = Get-Content -LiteralPath $CTTDataFile

    # Update the global variables based on what is found in the CTT file.
    $global:CombinedTexture = $CTTContent | Select-Object -Index 0
    $global:CTextureRows    = $CTTContent | Select-Object -Index 1
    $global:CTextureColumns = $CTTContent | Select-Object -Index 2

    # Update the values on the GUI.
    $SplitTextureTextBox.Text   = $CombinedTexture
    $SplitRowsNumBox.Value      = $CTextureRows
    $SplitColumnsNumBox.Value   = $CTextureColumns

    # Start reading from line 3.
    $Index = 3

    # Create an array to reference texture names.
    $global:CTextureArray = New-Object 'string[,]' ([int]$CTextureRows+1),([int]$CTextureColumns+1)

    # Loop through all rows.
    for($row = 1; $row -le [int]$CTextureRows; $row++)
    {
      # And loop through all columns.
      for($col = 1; $col -le [int]$CTextureColumns; $col++)
      {
        # Get the value of the current line.
        $CurrentLine = $CTTContent | Select-Object -Index $Index

        # Store the read texture in the current array.
        $CTextureArray[$row,$col] = $CurrentLine

        # Increment the index number.
        $Index++
      }
    }
    # The rest of the options do not need to be changed so lock them out.
    $SplitRowsNumBox.Enabled = $false
    $SplitRowsLabel.Enabled = $false
    $SplitColumnsNumBox.Enabled = $false
    $SplitColumnsLabel.Enabled = $false
    $SplitCTTButton.Text = 'Release CTT File'
  }
}
#----------------------------------------------------------------------------------------------------------------------------------------------
function SplitTexture_ReleaseCTTFile()
{
  # Reset the important variables so execution can not continue until a valid texture or CTT file is selected.
  $global:CTextureArray = $null
  $global:CombinedTexture = 'Select a texture to split into multiple textures...'
  $SplitTextureTextBox.Text = $CombinedTexture

  # Re-enable all options.
  $SplitRowsNumBox.Enabled = $true
  $SplitRowsLabel.Enabled = $true
  $SplitColumnsNumBox.Enabled = $true
  $SplitColumnsLabel.Enabled = $true
  $SplitCTTButton.Text = 'Load CTT File'
}
#----------------------------------------------------------------------------------------------------------------------------------------------
function SplitTexture_LoadCTTFileButtonClick()
{
  # Get really corny and run the correct function based on the button's current text.
  if ($SplitCTTButton.Text -eq 'Load CTT File')
  {
    SplitTexture_LoadCTTFile
  }
  elseif ($SplitCTTButton.Text -eq 'Release CTT File')
  {
    SplitTexture_ReleaseCTTFile
  }
}
#----------------------------------------------------------------------------------------------------------------------------------------------
$SplitCTTButton = New-Object System.Windows.Forms.Button
$SplitCTTButton.Size = New-Object System.Drawing.Size(112, 28)
$SplitCTTButton.Location = New-Object System.Drawing.Size(132, 84)
$SplitCTTButton.Text = 'Load CTT File'
$SplitCTTButton.Add_Click({ SplitTexture_LoadCTTFileButtonClick })
$SplitTextureGroup.Controls.Add($SplitCTTButton)
$SplitCTTTip = New-Object System.Windows.Forms.ToolTip
$SplitCTTTip.InitialDelay = $ToolTipDelay
$SplitCTTTip.AutoPopDelay = $ToolTipDuration
$SplitCTTTipString = 'If a multi-texture was created using the option "Combine Multiple Textures", the script will also generate a file with{0}'
$SplitCTTTipString += 'the texture name and a (.ctt) extension. This file holds the path to the texture, the number of columns and rows, and{0}'
$SplitCTTTipString += 'every texture hash/name that was used to generate the multi-texture. Loading a CTT file will automatically fill in the{0}'
$SplitCTTTipString += 'correct values for rows and columns, and when the texture is created all split textures will be renamed with the hash{0}'
$SplitCTTTipString += 'they had before being combined. The path will be where the texture was last generated, so it may need to be changed.{0}'
$SplitCTTTipString += '{0}'
$SplitCTTTipString += 'Note that a CTT file is not necessary to split an image, it just provides a shortcut to the correct number of rows and{0}'
$SplitCTTTipString += 'columns and automatically renames the individual textures after splitting the image. If a CTT is not selected, images{0}'
$SplitCTTTipString += 'will be renamed from the main texture + an incrementing integer, and dimensions will be calculated from rows/columns.'
$SplitCTTTipString = [String]::Format($SplitCTTTipString, [Environment]::NewLine)
$SplitCTTTip.SetToolTip($SplitCTTButton, $SplitCTTTipString)
#==============================================================================================================================================================================================
#  Create Advanced Option 7: Basic Image Viewer
#==============================================================================================================================================================================================
$global:CTTDataFile = ''
$global:CombinedTexture = 'Select a texture to split into multiple textures...'
#----------------------------------------------------------------------------------------------------------------------------------------------
$ImageViewerGroup = New-Object System.Windows.Forms.GroupBox
$ImageViewerGroup.Size = New-Object System.Drawing.Size(380, 124)
$ImageViewerGroup.Location = New-Object System.Drawing.Size(10, 260)
$ImageViewerGroup.Text = ' Description'
$MainDialog.Controls.Add($ImageViewerGroup)
#----------------------------------------------------------------------------------------------------------------------------------------------
$ImageViewerLabel = New-Object System.Windows.Forms.Label
$ImageViewerLabel.Size = New-Object System.Drawing.Size(360, 66)
$ImageViewerLabel.Location = New-Object System.Drawing.Size(10, 24)
$ImageViewerString = 'A simple image viewer that allows viewing images in various formats. To load an image into the viewer, simply drag and drop an image or group of images into the '
$ImageViewerString += 'window, or click on the window to manually select an image. While this will allow viewing any image, it will only display properties for Dolphin textures.'
$ImageViewerLabel.Text = $ImageViewerString
$ImageViewerGroup.Controls.Add($ImageViewerLabel)
#==============================================================================================================================================================================================
#  CTT GUI MAIN DIALOG - INITIAL VISIBILITY
#==============================================================================================================================================================================================
# Hide the Option groups and Global Options by default.
$StandardGroup.Hide()
$AdvancedGroup.Hide()
$OptionsGroup.Hide()
$MipMapGroup.Hide()
$CTTOptionsGroup.Hide()
$PathsGroup.Hide()

# Do this crap in a function so "$MenuGroups" is a local variable instead of sticking around until the script is closed.
function SetMenuVisibility()
{
  # Create an array to easily reference all standard and advanced options.
  $MenuGroups = New-Object Object[] 15

  # Standard Options
  $MenuGroups[0]  = $ScanGroup
  $MenuGroups[1]  = $ConvertGroup
  $MenuGroups[2]  = $RescaleGroup
  $MenuGroups[3]  = $WatermarkGroup
  $MenuGroups[4]  = $MaterialGroup
  $MenuGroups[5]  = $OptiPNGGroup
  $MenuGroups[6]  = $UpscaleFilterGroup
  $MenuGroups[7]  = $VRAMGroup

  # Advanced Options
  $MenuGroups[8]  = $ImageViewerGroup
  $MenuGroups[9]  = $GenNewMipMapsGroup
  $MenuGroups[10] = $InvalidMipMapsGroup
  $MenuGroups[11] = $ExtractMipMapGroup
  $MenuGroups[12] = $RemoveAlphaGroup
  $MenuGroups[13] = $CombineTextureGroup
  $MenuGroups[14] = $SplitTextureGroup

  # Initially hide all groups.
  for($i=0; $i -lt $MenuGroups.Length; $i++)
  {
    $MenuGroups[$i].Hide()
  }
  # Initially display a standard option if it was selected.
  if ($CurrentOptions -eq 'Standard')
  {
    $StandardGroup.Show()
    $CalcStored = [int]$StoredStandard
    $MenuGroups[$CalcStored].Show()
  }
  # Or show an advanced option.
  else
  {
    $AdvancedGroup.Show()
    $CalcStored = 8 + [int]$StoredAdvanced
    $MenuGroups[$CalcStored].Show()
  }
}
# Show the option that has been stored.
SetMenuVisibility
#==============================================================================================================================================================================================
#  CTT GUI - YES/NO DIALOG
#==============================================================================================================================================================================================
#  Shows a yes/no dialog and returns the button that was pressed.
function ShowYesNoDialog([int]$OffsetX, [int]$OffsetY, [string]$DisplayText, [bool]$PlayBeep=$true)
{
  if ($PlayBeep)
  {
    [System.Media.SystemSounds]::Beep.Play()
  }
  $YesNoLabel.Location = New-Object System.Drawing.Size($OffsetX, $OffsetY)
  $YesNoLabel.Text = $DisplayText
  $YesNoDialog.Add_Shown({$YesNoDialog.Activate()})
  $YesNoDialog.ShowDialog() | Out-Null
  return $YesNoChoice
}
#==============================================================================================================================================================================================
# Create the yes/no dialog.
$YesNoDialog = New-Object System.Windows.Forms.Form
$YesNoDialog.Font = $DialogFont
$YesNoDialog.Text = $ScriptName
$YesNoDialog.Size = New-Object System.Drawing.Size(320, 130)
$YesNoDialog.MaximumSize = New-Object System.Drawing.Size(320, 130)
$YesNoDialog.MinimumSize = New-Object System.Drawing.Size(320, 130)
$YesNoDialog.MaximizeBox = $false
$YesNoDialog.MinimizeBox = $false
$YesNoDialog.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Inherit
if ($WindowsVersion -ne '7')
{
  $YesNoDialog.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
}
$YesNoDialog.StartPosition = "CenterScreen"
$YesNoDialog.KeyPreview = $true
$YesNoDialog.Topmost = $true
DialogSetIcon $YesNoDialog
#==============================================================================================================================================================================================
# Display the question to ask.
$YesNoLabel = New-Object System.Windows.Forms.Label
$YesNoLabel.Size = New-Object System.Drawing.Size(300, 20)
$YesNoLabel.Location = New-Object System.Drawing.Size(10, 10)
$YesNoDialog.Controls.Add($YesNoLabel)
#==============================================================================================================================================================================================
# Create the "Yes" button.
$YesButton = New-Object System.Windows.Forms.Button
$YesButton.Size = New-Object System.Drawing.Size(80, 28)
$YesButton.Location = New-Object System.Drawing.Size(52, 48)
$YesButton.Text = 'Yes'
$YesButton.Add_Click({$global:YesNoChoice = $true ; $YesNoDialog.Close()})
$YesNoDialog.Controls.Add($YesButton)
#==============================================================================================================================================================================================
# Create the "No" button.
$NoButton = New-Object System.Windows.Forms.Button
$NoButton.Size = New-Object System.Drawing.Size(80, 28)
$NoButton.Location = New-Object System.Drawing.Size(170, 48)
$NoButton.Text = 'No'
$NoButton.Add_Click({$global:YesNoChoice = $false ; $YesNoDialog.Close()})
$YesNoDialog.Controls.Add($NoButton)
#==============================================================================================================================================================================================
#  CTT GUI - OK DIALOG
#==============================================================================================================================================================================================
#  Shows the OK dialog.
function ShowOKDialog([int]$OffsetX, [int]$OffsetY, [string]$DisplayText)
{
  [System.Media.SystemSounds]::Beep.Play()
  $OKLabel.Location = New-Object System.Drawing.Size($OffsetX, $OffsetY)
  $OKLabel.Text = $DisplayText
  $OKDialog.Add_Shown({$OKDialog.Activate()})
  $OKDialog.ShowDialog() | Out-Null
}
#==============================================================================================================================================================================================
# Create the OK dialog.
$OKDialog = New-Object System.Windows.Forms.Form
$OKDialog.Font = $DialogFont
$OKDialog.Text = $ScriptName
$OKDialog.Size = New-Object System.Drawing.Size(320, 130)
$OKDialog.MaximumSize = New-Object System.Drawing.Size(320, 130)
$OKDialog.MinimumSize = New-Object System.Drawing.Size(320, 130)
$OKDialog.MaximizeBox = $false
$OKDialog.MinimizeBox = $false
$OKDialog.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Inherit
if ($WindowsVersion -ne '7')
{
  $OKDialog.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
}
$OKDialog.StartPosition = "CenterScreen"
$OKDialog.KeyPreview = $true
$OKDialog.Topmost = $true
DialogSetIcon $OKDialog
#==============================================================================================================================================================================================
# Display the question to ask.
$OKLabel = New-Object System.Windows.Forms.Label
$OKLabel.Size = New-Object System.Drawing.Size(290, 30)
$OKLabel.Location = New-Object System.Drawing.Size(22, 10)
$OKDialog.Controls.Add($OKLabel)
#==============================================================================================================================================================================================
# Create the "OK" button.
$OKButton = New-Object System.Windows.Forms.Button
$OKButton.Size = New-Object System.Drawing.Size(80, 28)
$OKButton.Location = New-Object System.Drawing.Size(110, 48)
$OKButton.Text = 'OK'
$OKButton.Add_Click({$OKDialog.Close()})
$OKDialog.Controls.Add($OKButton)
#==============================================================================================================================================================================================
#  CTT GUI - HELP DIALOG
#==============================================================================================================================================================================================
function HelpDialogSetIcon($InputDialog)
{
  $B64 =  'iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH4QcIDA0RsFwxowAACuhJREFUWMOVl3uQVdWVx
          n97n9d9d0Nz+0Xz6IY0RAJIQBlMTKoEBRvHkBipvIjOaCQ61qRiJTKlmSlNnCIVk5nJOJWM41TFoow1SUgZFWgh3ahIgghSGA0C4WHTr9vv++h773nuPX9cOhkrGmtW1al96tQ+e631nXW+tT7
          BX7CRkRGampoYGBiQtm1npZRLgJuEEOuEEJ1Aw+Wtk8AZpdRvlVLPA2fOnz8/vm7dOq21pq+vj4ULF76nD/FeD3O5HM3NzTP3K03TvE9KeZ0Qok0IgZTyPQ/TWqOUQik1qJQ6GIbhYy0tLcf+U
          pLiAxD4sWmaXzUMAyFqW2fW9zOt9R/XMAyjMAwfa25u/vrU1BTFYpEFCxa8fwBDQ0O0trYyPDy8VEr5lGVZqw3D0IYUwvMDyuMjeKUCkeeBCtFKg1IgJRgSYTvEUvUk52SJx+OEkUIpRRAEJ4M
          g+HxbW9vpvr6+dwXxZ+kMDg5+zDTNPZZl1UspMaRg6Owpxs+eorFtPumGLKYTw5QSYRi1bFVEGCkCz6M4PsrYYD/ptgUsWnUVkdJEUYTv+2NBEKyfN2/emxcvXqS9vf1PAVy6dIn58+fT39+/1
          LKsI7Zt1xuGge+5nH35ADo/weK1H8cyLQQaqRTo2tta6dqKQAsBhsStupx7/VUqUciKrs+SzNQRRRGe5wWe57W1t7ePztTZuxAYGBg47jjOatM0KU2M8btnnqLOibP46mtqGYcRRGEN9plPMJO
          GYaKlAaaJNgwCpXnnzRMMDQ/x0Vu+ROO8hfi+j+u6Z13XXbt48eI8gLhw4QIdHR309fX92HGcr1qWReB5vPL4o6T9Kh9ZfxOmUogwQPse2vNQbgUdBOgoAinR0kDYFpg2ODGE7YBl46uQ068e4
          lIuxw33PcTsbCOu7+N53nc9z3ugs7NTC4Bz586tdBznZCwW045liEP//W9MvdLLVZ+6lWSyDhn4RJUqajqPkAaZdZ/AmddO9dwZ8kdeIioVwLLBshGxODgxZCIF8QT5sSHeOnIIPaeJjTt2Yjk
          O1WrVC4KgvaOjY1iePHlSSinvM00TyzTEWy8dYPAXP6EpGceqeqixHP7wAH7/BYz6LHM+/QUyq68h1tSKXPIRYtfeQFip4I/mcIcH8POTZD+5EdnUijfUT8ywSRYKFI8f5u0Xu5FSYpqmo7XeC
          WAmEonsZZKhXKnyxn/tJOsVSAcBamIUP/BR00UaPv8VnHntOLMbCIoFLv7PT6gcOoAQAmFZtVpwYiy9/zvkz59joncvhu0gkynSQZXM1DiHfvAtVmy8GSEEhmHcduzYsXsksERK2QYwdOoEwaU
          zZEpF4mMjhGM5/EsXEG3tWE1zScyaTVgqkuvdR7X7l8jAR/geqlQkKBZIrViDkAYDu3fh9r9DNTeITKSwx8eJVYuE5Ryvdf8cyzKQUpJKpW6TWuubhBBorek/dRTbdklIMEpjBLlB6q+/mZbNt
          9ScF/JMnj1F66YtJJevRhXzROUSUbWMmi6iwhCE5EN/+3copXAaW2jpugXccWwLMiYcef5xLNOYQaFLaq3XzVDnyB+OEjPAtEB7E8y990Fav3AnifkdRNMl+rqfZfaipUgpWfTtH5JcfhVqqkg
          0WcBpW0TbrbdDFJJsnceq7z3Oin/8Hrnnn0b5PhKIGVCZvMT46PgMpS8xgU6AKIqY7rtAQ1D7m6QLuT1PUnflVcjQp/jOBcZ3PkDl9ddYtvOHyHKJRQ/9gEs7H8IdHaLjO/+ClUkjVUR/Tw+Vg
          UtM/+41SkeeRZsaKcFWYFdDpsYGaV6wGK11s6m1bgBqnD1VQEaX6R2Q+3/KGS1Z+LVH6H/ga8Rc4FfP8XY1ZOnDjyCdGAv+6Z/BMGG6iHQr9PX0MnjXFzEtCONAqlafMgRTgqwq/PL0TMNKyii
          KLrfQEIGBCqhdl9nR2PdTLnRdjX3yFLYLjiuwn+tl4NH/QAcBlIpQmESXSgw8+TSjf3MnCWFjA2YCTFFzTgjSAxmAFoIoqrVuUyk1qbXOosBKziIcHiF0aigQgF1RpCoj6IrAj+qx4mksbSHOD
          SDCADwPlEKYJs5UmQwZ7OIoQQYogopDaAAm4ILAwI6lUEoRRVFZRlF0JooitBCkWhbjziDgA2WQFSAP2k+QmIZU0SK57Eoa/vXhGg0HHhoNWpF96Jtk796OpJ5YAWJVMKtghjXnoQFIm3S2hcv
          I58wwDH8bhuHHTdNkzhVryPXswfUh5YGMas7DIInZOJ/0XXdiOHHML21GxC1EpUT+FwcJfZ/s9s+gRseZ9cgOZGszhW8+iF2YwgZ8DUhwI6jrWEYmnaA0XcX3/dNmFEXPB0Fwv2maZK9YSX99F
          rcwRRiEhFWQgYXRMJemkz0owLCtGuRBwFjPCep/9GsMw2BE2jTe9Sn01BR1d29DKcXk/fcjKxWkhiBuME3Eqs/eju+HBEFAEATdMgzDM77vDyqlyHYswepcRj6eoBJL4BoxPGGT3HE3hcOvMXr
          jvRR7foMgovz629R/+2eYmSQi7jB718vkd7+IIEJPTDD73tuZ9dijhPEMQSxOORnH6lxO5zXX4gchrusyOTn5tLF27dpqQ0PDlbZtr4zZNnZbOxdefI60mcQwE1gyRkWa2E88y6xJH7P3BOUPz
          cUpe5i/OY1QGh0ppPIwDp5gbE6MuvYW1NQUiUXtTAvInT/LSMJm2d8/yKy57Xi+z/T09JMbNmz4mdy+fbt2Xfffy+VyGEQRrUs+TMutX2HMEpRScby6BNaR42jt48oK+sNtpK/soPriMaiUUJU
          iulxEVVxQHva3fsTQCy9BFDJ28g0u7t1LPm4Sv/pa5i5fQ6giKpVKFATBNwCM8+fPs3r16qFt27bNNgzjr2zDZNaCTkYG+/CG3sE0bQzLRAoLvyVLuG0TpV/1Yna/ilIuSvsEeLh4eNLDt0KKb
          7zFhFfmD088Qd6dotTRzqp7/oHE7FlUXZdyufxouVzec8cddyB6e3tZv349AIcPHz4xq65+lWUYlAsljn//QRJvvsUcmSKjbVLKxokkdigxtAY1M66HRAICQxEYipKhyOOSp0Jp0QJW7fgu6aY
          sXhAwVcgPT0xMLNqyZUv1XVPx0aNHKRWKSxOp5Mt16UyjKSWBF/D7Xf9J9eB+MmWftIyTFBY2JpY2akFQY81QSnxCytqnHFXIx8Fas5bOL99DuqkJX0UUSsXJQqGwpqur62JPTw8bNmz4UwAvv
          PACmzZt4sCBA8vj8fjrdemMZZsmoesxee4s/Xt+SeXIITJI4trCNk2kkn8UIQER1cijiI+94qO0/fVWsitXYScSuGFAcbo0Wa1W119//fUnZ5z/mS7Yv38/GzduZO/evY2pVOqVdDLVGYs5iEg
          TBSHF3DBDr/RQ/P1x9MQYMqx1jEgIRLqO1BUraP3EDTQs6kRKgTYkVc+jOF0ani4WP3bTzTdf/EBptm/fPrq6unjmmWfqM5nMjlgs9vW4E3Ns20YCQkh0pPGqFcJyARVpzFSaeDKFlAaKCK01X
          hBQrVYj1/e+PzE29vDWz32uOpPgB2rDgwcPct1117F7926RSqWaDcPY6TjObfF4HMswkVIiBAitEVKglUYhLsswH7c2/z8ZRdE33GplcsunP6O7u7u58cYb/3/i9P/aU7t2JeY0Nt7m2FaXNMw
          lhmE0CyGSl2ugrJTKRWFwOvCD7nyx+PTWrVsLAHv37mXz5s3ve+7/AttBhCt9A9OGAAAAAElFTkSuQmCC'

  # PowerShell doesn't care about the spaces in the string but remove them anyway. Makes it easier to export the icon if I want to.
  $B64 = [regex]::Replace($B64,'\s','')
  
  # Create a streaming image by streaming the base64 string.
  $Stream = [System.IO.MemoryStream][System.Convert]::FromBase64String($B64)
  $Bitmap = New-Object System.Drawing.Bitmap($Stream)

  # Convert the bitmap into an icon and display it on the dialog.
  $Icon = [System.Drawing.Icon]::FromHandle($Bitmap.GetHicon())
  $InputDialog.Icon = $Icon
  $Bitmap.Dispose()
}
#==============================================================================================================================================================================================
# Three icons represented as a base64 string, similar to CHM icons but slightly edited to be somewhat different.

$Book = 'iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH4QQbFyIVsFID5wAAAB1pVFh0Q29tbWVudAAAA
        AAAQ3JlYXRlZCB3aXRoIEdJTVBkLmUHAAAAsElEQVQ4y52TUQ6EIAwFX8neyx6tR8OTzX4oDYuCWTENsXYmjRQDNFtmhiQBNqv5rMBQ5PtMYn0HI9ivUNx2YsASfJKYJJ7AlaRIklf/S9A6TkH
        1+lpSWvKtpPTJfyTtv5Xxw5Mk2hMhQAWw8RTuJCN4GSQzuxynV5f7IYoIubu2bdO+75kXkHHORIYkIgKAWmvukjhQfgWj5CxKuAezfhT0ktbBHdjCZte5n7bVdf4CrHDWoesj1FcAAAAASUVOR
        K5CYII='
$Open = 'iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH4QQbFyQgsLtgQgAAAB1pVFh0Q29tbWVudAAAA
        AAAQ3JlYXRlZCB3aXRoIEdJTVBkLmUHAAAAuUlEQVQ4y82TXQ7EIAiEh6b3gpsJN+Nmsy9Lq/Zv+7aTkGiETzAjSIIk3J21fhMLAEQEzQwRQbzUKiJ0OJSKgrXWZE7s4f352iepKjITEYHW2lx
        UoLGD+SYzQ2ayIKMEgENECAAk5QBQ1YJMhfxGgCRCAiLC5f6JalRO+10PAF6Afgb8Xwe4BoTETQebmWBmow9ISrkxJNDYcOLCzSOqejRSDyll5uaFs8JtSHJvc4Y8yeEjoCBvfuMHBy2OPOGWr
        XsAAAAASUVORK5CYII='
$Page = 'iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH4QQbFyUyWhkgSwAAAB1pVFh0Q29tbWVudAAAA
        AAAQ3JlYXRlZCB3aXRoIEdJTVBkLmUHAAAAqUlEQVQ4y52TWw6FIAxEzxj3re6srGzuh4+AFDV3kgmGNOUwRdkGYNu2/eNBy7Ko27SNbdZ19Vg4InzUUHvqz9FhqtUnQU/6jcA+ulx+JJBoXB8
        UEU110sDYNG6vx1uDnkCiyaLW3AdobKXFmeY7PoDkZNx5gynbtDXI4TUDXQR/ZuAB7jiTNEQpH+2HDAyc99enDBqCUgoQQL3Wiv7VnL+zstk9yPtj4QddPLW+fTBKvAAAAABJRU5ErkJggg=='

# Crop any garbage space out of the string.
$Book = [regex]::Replace($Book,'\s','')
$Open = [regex]::Replace($Open,'\s','')
$Page = [regex]::Replace($Page,'\s','')

# Create a memory stream from the base64 strings.
$BookStream = [System.IO.MemoryStream][System.Convert]::FromBase64String($Book)
$OpenStream = [System.IO.MemoryStream][System.Convert]::FromBase64String($Open)
$PageStream = [System.IO.MemoryStream][System.Convert]::FromBase64String($Page)

# Create bitmap classes from the memory streams.
$BookBitmap = New-Object System.Drawing.Bitmap($BookStream)
$OpenBitmap = New-Object System.Drawing.Bitmap($OpenStream)
$PageBitmap = New-Object System.Drawing.Bitmap($PageStream)

# Convert the bitmaps into images
$BookImage = [System.Drawing.Image]$BookBitmap
$OpenImage = [System.Drawing.Image]$OpenBitmap
$PageImage = [System.Drawing.Image]$PageBitmap

# Construct the ImageList.
$HelpIcons = New-Object System.Windows.Forms.ImageList
$HelpIcons.ImageSize = New-Object System.Drawing.Size(16, 16)

# Add the images to the list.
$HelpIcons.Images.Add($BookImage)  # -Index 0 - Closed Book
$HelpIcons.Images.Add($OpenImage)  # -Index 1 - Open Book
$HelpIcons.Images.Add($PageImage)  # -Index 2 - Page
#==============================================================================================================================================================================================
$HelpDialog = New-Object System.Windows.Forms.Form
$HelpDialog.Text = ('CTT-PS Help')
$HelpDialog.Size = New-Object System.Drawing.Size(850, (600 + $HeightOffset))
$HelpDialog.MinimumSize = New-Object System.Drawing.Size(550, 300)
$HelpDialog.MaximizeBox = $true
$HelpDialog.MinimizeBox = $true
$HelpDialog.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Inherit
$HelpDialog.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::Sizable
$HelpDialog.StartPosition = "CenterScreen"
$HelpDialog.KeyPreview = $true
$HelpDialog.Font = $DialogFont
$HelpDialog.Add_KeyDown({ EscapeCloseDialog })
$HelpDialog.Add_FormClosing({$HelpDialog.Hide() ; $_.Cancel = $true})
$HelpDialog.Add_Shown({$HelpDialog.Activate()})
HelpDialogSetIcon $HelpDialog
#==============================================================================================================================================================================================
$HelpTopicsLabel = New-Object System.Windows.Forms.Label
$HelpTopicsLabel.Size = New-Object System.Drawing.Size(120, 18)
$HelpTopicsLabel.Location = New-Object System.Drawing.Size(8, 10)
$HelpTopicsLabel.Text = 'Help Topics:'
$HelpDialog.Controls.Add($HelpTopicsLabel)
#==============================================================================================================================================================================================
$HelpTopics = New-Object System.Windows.Forms.TreeView
$HelpTopics.ImageList = $HelpIcons
$HelpTopics.Size = New-Object System.Drawing.Size(260, 490)
$HelpTopics.Location = New-Object System.Drawing.Size(8, 30)
$HelpTopics.Anchor = ([System.Windows.Forms.AnchorStyles]::Top, [System.Windows.Forms.AnchorStyles]::Bottom, [System.Windows.Forms.AnchorStyles]::Left)
$HelpTopics.BeginUpdate()
#==============================================================================================================================================================================================
# Adds a main topic to the list.

function AddMainTopic([int]$NodeA, [int]$IconIndex, [string]$Topic)
{
  $HelpTopics.Nodes.Add($Topic) | Out-Null
  $HelpTopics.Nodes[$NodeA].ImageIndex = $IconIndex
  $HelpTopics.Nodes[$NodeA].SelectedImageIndex = $IconIndex
}
#----------------------------------------------------------------------------------------------------------------------------------------------
# Adds a sub-topic to the list, or a sub-topic of a sub-topic if $NodeC is present.

function AddHelpTopic([int]$NodeA, [int]$NodeB, [int]$NodeC=-1, [int]$IconIndex, [string]$Topic)
{
  if ($NodeC -lt 0)
  {
    $HelpTopics.Nodes[$NodeA].Nodes.Add($Topic) | Out-Null
    $HelpTopics.Nodes[$NodeA].Nodes[$NodeB].ImageIndex = $IconIndex
    $HelpTopics.Nodes[$NodeA].Nodes[$NodeB].SelectedImageIndex = $IconIndex
  }
  else
  {
    $HelpTopics.Nodes[$NodeA].Nodes[$NodeB].Nodes.Add($Topic) | Out-Null
    $HelpTopics.Nodes[$NodeA].Nodes[$NodeB].Nodes[$NodeC].ImageIndex = $IconIndex
    $HelpTopics.Nodes[$NodeA].Nodes[$NodeB].Nodes[$NodeC].SelectedImageIndex = $IconIndex
  }
}
#----------------------------------------------------------------------------------------------------------------------------------------------
# IconIndex 0 is the closed book. Used for expandable topics.
# IconIndex 1 is the open book. Used when a topic is expanded.
# IconIndex 2 is the page. Used for lowest tier of sub-topics.
#----------------------------------------------------------------------------------------------------------------------------------------------
# Create the introduction Help topics.
AddMainTopic -NodeA 0          -IconIndex 0 -Topic 'Introduction'
AddHelpTopic -NodeA 0 -NodeB 0 -IconIndex 2 -Topic 'Features'
AddHelpTopic -NodeA 0 -NodeB 1 -IconIndex 2 -Topic 'Quick Guide'
AddHelpTopic -NodeA 0 -NodeB 2 -IconIndex 2 -Topic 'Information'
#----------------------------------------------------------------------------------------------------------------------------------------------
# Create the Requirements Help topics.
AddMainTopic -NodeA 1          -IconIndex 0 -Topic 'Requirements'
AddHelpTopic -NodeA 1 -NodeB 0 -IconIndex 2 -Topic 'ImageMagick'
AddHelpTopic -NodeA 1 -NodeB 1 -IconIndex 2 -Topic 'DirectXTex TexConv'
AddHelpTopic -NodeA 1 -NodeB 2 -IconIndex 2 -Topic 'Compressonator'
AddHelpTopic -NodeA 1 -NodeB 3 -IconIndex 2 -Topic 'DDS Utilities'
AddHelpTopic -NodeA 1 -NodeB 4 -IconIndex 2 -Topic 'Ishiiruka Tool'
AddHelpTopic -NodeA 1 -NodeB 5 -IconIndex 2 -Topic 'OptiPNG'
AddHelpTopic -NodeA 1 -NodeB 6 -IconIndex 2 -Topic 'xBRZ ScalerTest'
AddHelpTopic -NodeA 1 -NodeB 7 -IconIndex 2 -Topic 'Waifu2x'
#----------------------------------------------------------------------------------------------------------------------------------------------
# Create the Main Window Help topics.
AddMainTopic -NodeA 2                   -IconIndex 0 -Topic 'Main Window'
AddHelpTopic -NodeA 2 -NodeB 0          -IconIndex 2 -Topic 'Texture Path'
AddHelpTopic -NodeA 2 -NodeB 1          -IconIndex 2 -Topic 'Output Path'
AddHelpTopic -NodeA 2 -NodeB 2          -IconIndex 2 -Topic 'Process Selected'
AddHelpTopic -NodeA 2 -NodeB 3          -IconIndex 0 -Topic 'Standard Options'
AddHelpTopic -NodeA 2 -NodeB 3 -NodeC 0 -IconIndex 2 -Topic 'Scan Dolphin Textures For Issues'
AddHelpTopic -NodeA 2 -NodeB 3 -NodeC 1 -IconIndex 2 -Topic 'Convert Textures to Another Format'
AddHelpTopic -NodeA 2 -NodeB 3 -NodeC 2 -IconIndex 2 -Topic 'Rescale Textures With New Scaling Factor'
AddHelpTopic -NodeA 2 -NodeB 3 -NodeC 3 -IconIndex 2 -Topic 'Add Identifying Watermark to All Textures'
AddHelpTopic -NodeA 2 -NodeB 3 -NodeC 4 -IconIndex 2 -Topic 'Create Material Maps With Ishiiruka Tool'
AddHelpTopic -NodeA 2 -NodeB 3 -NodeC 5 -IconIndex 2 -Topic 'Optimize PNG Textures With OptiPNG'
AddHelpTopic -NodeA 2 -NodeB 3 -NodeC 6 -IconIndex 2 -Topic 'Apply Upscaling Filter to All Textures'
AddHelpTopic -NodeA 2 -NodeB 4          -IconIndex 0 -Topic 'Advanced Options'
AddHelpTopic -NodeA 2 -NodeB 4 -NodeC 0 -IconIndex 2 -Topic 'Basic Image Viewer'
AddHelpTopic -NodeA 2 -NodeB 4 -NodeC 1 -IconIndex 2 -Topic 'Generate New MipMaps'
AddHelpTopic -NodeA 2 -NodeB 4 -NodeC 2 -IconIndex 2 -Topic 'Remove Invalid MipMaps'
AddHelpTopic -NodeA 2 -NodeB 4 -NodeC 3 -IconIndex 2 -Topic 'Extract DDS Internal MipMaps'
AddHelpTopic -NodeA 2 -NodeB 4 -NodeC 4 -IconIndex 2 -Topic 'Remove Alpha Channel From Opaque Textures'
AddHelpTopic -NodeA 2 -NodeB 4 -NodeC 5 -IconIndex 2 -Topic 'Combine Multiple Textures'
AddHelpTopic -NodeA 2 -NodeB 4 -NodeC 6 -IconIndex 2 -Topic 'Split Combined Multi-Texture'
#----------------------------------------------------------------------------------------------------------------------------------------------
# Create the Options Panel Help topics.
AddMainTopic -NodeA 3                   -IconIndex 0 -Topic 'Options Menu'
AddHelpTopic -NodeA 3 -NodeB 0          -IconIndex 0 -Topic 'Texture Options'
AddHelpTopic -NodeA 3 -NodeB 0 -NodeC 0 -IconIndex 2 -Topic 'Allow All Images'
AddHelpTopic -NodeA 3 -NodeB 0 -NodeC 1 -IconIndex 2 -Topic 'Force Create MipMaps'
AddHelpTopic -NodeA 3 -NodeB 0 -NodeC 2 -IconIndex 2 -Topic 'DDS Creation Tool'
AddHelpTopic -NodeA 3 -NodeB 0 -NodeC 3 -IconIndex 2 -Topic 'DDS Compression'
AddHelpTopic -NodeA 3 -NodeB 0 -NodeC 4 -IconIndex 2 -Topic 'Flag Removal'
AddHelpTopic -NodeA 3 -NodeB 0 -NodeC 5 -IconIndex 2 -Topic 'DDS Fallback'
AddHelpTopic -NodeA 3 -NodeB 1          -IconIndex 0 -Topic 'MipMap Options'
AddHelpTopic -NodeA 3 -NodeB 1 -NodeC 0 -IconIndex 2 -Topic 'Force New MipMaps'
AddHelpTopic -NodeA 3 -NodeB 1 -NodeC 1 -IconIndex 2 -Topic 'Create From Top Level'
AddHelpTopic -NodeA 3 -NodeB 1 -NodeC 2 -IconIndex 2 -Topic 'External DDS MipMaps'
AddHelpTopic -NodeA 3 -NodeB 1 -NodeC 3 -IconIndex 2 -Topic 'Max MipMap Levels'
AddHelpTopic -NodeA 3 -NodeB 2          -IconIndex 0 -Topic 'Preferences'
AddHelpTopic -NodeA 3 -NodeB 2 -NodeC 0 -IconIndex 2 -Topic 'Create a log file of all textures processed'
AddHelpTopic -NodeA 3 -NodeB 2 -NodeC 1 -IconIndex 2 -Topic 'Allow opening PowerShell scripts with a double click'
AddHelpTopic -NodeA 3 -NodeB 2 -NodeC 2 -IconIndex 2 -Topic 'Save any changes made to all options on exit'
AddHelpTopic -NodeA 3 -NodeB 2 -NodeC 3 -IconIndex 2 -Topic 'Disable forcing the GUI as the top-most window'
AddHelpTopic -NodeA 3 -NodeB 2 -NodeC 4 -IconIndex 2 -Topic 'Always show the PowerShell console window'
AddHelpTopic -NodeA 3 -NodeB 2 -NodeC 5 -IconIndex 2 -Topic 'Auto-center the PowerShell console on launch'
AddHelpTopic -NodeA 3 -NodeB 2 -NodeC 6 -IconIndex 2 -Topic 'Disable the PowerShell console "X" Button'
AddHelpTopic -NodeA 3 -NodeB 2 -NodeC 7 -IconIndex 2 -Topic 'Enable additional PowerShell console colors'
AddHelpTopic -NodeA 3 -NodeB 2 -NodeC 8 -IconIndex 2 -Topic 'PowerShell Console Background Color'
AddHelpTopic -NodeA 3 -NodeB 3          -IconIndex 2 -Topic 'Configure Paths'
AddHelpTopic -NodeA 3 -NodeB 4          -IconIndex 2 -Topic 'Restore Defaults'
AddHelpTopic -NodeA 3 -NodeB 5          -IconIndex 2 -Topic 'Import Stored Options'
#----------------------------------------------------------------------------------------------------------------------------------------------
# Create the Guides Help topics.
AddMainTopic -NodeA 4          -IconIndex 0 -Topic 'Guides'
AddHelpTopic -NodeA 4 -NodeB 0 -IconIndex 2 -Topic 'Creating DDS Packs'
AddHelpTopic -NodeA 4 -NodeB 1 -IconIndex 2 -Topic 'Rescaling Packs'
AddHelpTopic -NodeA 4 -NodeB 2 -IconIndex 2 -Topic 'MipMap Tutorial'
AddHelpTopic -NodeA 4 -NodeB 3 -IconIndex 2 -Topic 'Creating MipMaps with CTT-PS'
AddHelpTopic -NodeA 4 -NodeB 4 -IconIndex 2 -Topic 'Ishiiruka Tool and Material Maps'
#----------------------------------------------------------------------------------------------------------------------------------------------
# Create the Final sections.
AddMainTopic -NodeA 5 -IconIndex 2 -Topic 'Credits'
AddMainTopic -NodeA 6 -IconIndex 2 -Topic 'About'
#----------------------------------------------------------------------------------------------------------------------------------------------
# Toggles the closed/open book icons when the nodes are expanded/collapsed.
$HelpTopics.Add_AfterExpand({ $_.Node.ImageIndex = 1 ; $_.Node.SelectedImageIndex = 1 })
$HelpTopics.Add_AfterCollapse({ $_.Node.ImageIndex = 0 ; $_.Node.SelectedImageIndex = 0 })
#----------------------------------------------------------------------------------------------------------------------------------------------
# Set up the selection event and add the tree view to the help dialog.
$HelpTopics.Add_AfterSelect({ GUI_DisplayHelpTopic })
#----------------------------------------------------------------------------------------------------------------------------------------------
# Add the help topics treeview to the Help Dialog.
$HelpDialog.Controls.Add($HelpTopics)
#==============================================================================================================================================================================================
$HelpDescriptionLabel = New-Object System.Windows.Forms.Label
$HelpDescriptionLabel.Size = New-Object System.Drawing.Size(120, 18)
$HelpDescriptionLabel.Location = New-Object System.Drawing.Size(276, 10)
$HelpDescriptionLabel.Text = 'Description:'
$HelpDialog.Controls.Add($HelpDescriptionLabel)
#==============================================================================================================================================================================================
$HelpDescription = New-Object System.Windows.Forms.RichTextBox
$HelpDescription.Size = New-Object System.Drawing.Size(550, 490)
$HelpDescription.Location = New-Object System.Drawing.Size(276, 30)
$HelpDescription.ReadOnly = $true
$HelpDescription.BackColor = [System.Drawing.SystemColors]::Window
$HelpDescription.Font = $DialogFont
$HelpDescription.Text = 'I AM ERROR'
$HelpDescription.BulletIndent = 15
$HelpDescription.DetectUrls = $true
$HelpDescription.Anchor = ([System.Windows.Forms.AnchorStyles]::Top, [System.Windows.Forms.AnchorStyles]::Bottom, [System.Windows.Forms.AnchorStyles]::Left, [System.Windows.Forms.AnchorStyles]::Right)
$HelpDescription.Add_LinkClicked({[System.Diagnostics.Process]::Start($_.LinkText)})
$HelpDialog.Controls.Add($HelpDescription)
#==============================================================================================================================================================================================
$HelpCloseButton = New-Object System.Windows.Forms.Button
$HelpCloseButton.Size = New-Object System.Drawing.Size(80, 28)
$HelpCloseButton.Location = New-Object System.Drawing.Size(745, 524)
$HelpCloseButton.Text = 'Close'
$HelpCloseButton.Anchor = ([System.Windows.Forms.AnchorStyles]::Bottom, [System.Windows.Forms.AnchorStyles]::Right)
$HelpCloseButton.Add_Click({$HelpDialog.Hide()})
$HelpDialog.Controls.Add($HelpCloseButton)
#==============================================================================================================================================================================================
$HelpZoomInButton = New-Object System.Windows.Forms.Button
$HelpZoomInButton.Size = New-Object System.Drawing.Size(28, 28)
$HelpZoomInButton.Location = New-Object System.Drawing.Size(276, 524)
$HelpZoomInButton.Text = '+'
$HelpZoomInButton.Anchor = ([System.Windows.Forms.AnchorStyles]::Bottom, [System.Windows.Forms.AnchorStyles]::Left)
$HelpZoomInButton.Add_Click({ if ($HelpDescription.ZoomFactor -lt 4) {$HelpDescription.ZoomFactor = ($HelpDescription.ZoomFactor + 0.2)}})
$HelpDialog.Controls.Add($HelpZoomInButton)
#==============================================================================================================================================================================================
$HelpZoomOutButton = New-Object System.Windows.Forms.Button
$HelpZoomOutButton.Size = New-Object System.Drawing.Size(28, 28)
$HelpZoomOutButton.Location = New-Object System.Drawing.Size(310, 524)
$HelpZoomOutButton.Text = '-'
$HelpZoomOutButton.Anchor = ([System.Windows.Forms.AnchorStyles]::Bottom, [System.Windows.Forms.AnchorStyles]::Left)
$HelpZoomOutButton.Add_Click({ if ($HelpDescription.ZoomFactor -gt 0.5) {$HelpDescription.ZoomFactor = ($HelpDescription.ZoomFactor - 0.2)}})
$HelpDialog.Controls.Add($HelpZoomOutButton)
#==============================================================================================================================================================================================
$HelpResetZoomButton = New-Object System.Windows.Forms.Button
$HelpResetZoomButton.Size = New-Object System.Drawing.Size(28, 28)
$HelpResetZoomButton.Location = New-Object System.Drawing.Size(344, 524)
$HelpResetZoomButton.Text = '='
$HelpResetZoomButton.Anchor = ([System.Windows.Forms.AnchorStyles]::Bottom, [System.Windows.Forms.AnchorStyles]::Left)
$HelpResetZoomButton.Add_Click({ $HelpDescription.ZoomFactor = 1.0 })
$HelpDialog.Controls.Add($HelpResetZoomButton)
#==============================================================================================================================================================================================
#  CTT GUI: HELP DIALOG TOPICS
#==============================================================================================================================================================================================
function GUI_DisplayHelpTopic()
{
  # Convert the object into a string.
  $SelectedNode = $this.SelectedNode.ToString()

  # Reset all formatting before displaying the new description.
  $HelpDescription.SelectionStart = 0
  $HelpDescription.ScrollToCaret()
  $HelpDescription.SelectAll()
  #-----------------------------------------------------------------------------------------------------------------------------------------
  # Windows Vista/7
  if ($WindowsVersion -eq '7')
  {
    # Adjust the height depending on the DPI.
    switch ($MonitorDPI.ToString())
    {
      '120'   { $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 8)
                $FontSize10 = New-Object System.Drawing.Font('Tahoma', 8, [System.Drawing.FontStyle]::Bold)
                $FontSize11 = New-Object System.Drawing.Font('Tahoma', 9, [System.Drawing.FontStyle]::Bold)
                $FontSize12 = New-Object System.Drawing.Font('Tahoma', 10, [System.Drawing.FontStyle]::Bold)
                $FontSize13 = New-Object System.Drawing.Font('Tahoma', 11, [System.Drawing.FontStyle]::Bold)
              }
      default { $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10)
                $FontSize10 = New-Object System.Drawing.Font('Tahoma', 10, [System.Drawing.FontStyle]::Bold)
                $FontSize11 = New-Object System.Drawing.Font('Tahoma', 11, [System.Drawing.FontStyle]::Bold)
                $FontSize12 = New-Object System.Drawing.Font('Tahoma', 12, [System.Drawing.FontStyle]::Bold)
                $FontSize13 = New-Object System.Drawing.Font('Tahoma', 13, [System.Drawing.FontStyle]::Bold)
              }
    }
  }
  # Windows 8-10
  else
  {
    # Adjust the height depending on the DPI.
    switch ($MonitorDPI.ToString())
    {
      '120'   { $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 8)
                $FontSize10 = New-Object System.Drawing.Font('Tahoma', 8, [System.Drawing.FontStyle]::Bold)
                $FontSize11 = New-Object System.Drawing.Font('Tahoma', 9, [System.Drawing.FontStyle]::Bold)
                $FontSize12 = New-Object System.Drawing.Font('Tahoma', 10, [System.Drawing.FontStyle]::Bold)
                $FontSize13 = New-Object System.Drawing.Font('Tahoma', 11, [System.Drawing.FontStyle]::Bold)
              }
      default { $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10)
                $FontSize10 = New-Object System.Drawing.Font('Tahoma', 10, [System.Drawing.FontStyle]::Bold)
                $FontSize11 = New-Object System.Drawing.Font('Tahoma', 11, [System.Drawing.FontStyle]::Bold)
                $FontSize12 = New-Object System.Drawing.Font('Tahoma', 12, [System.Drawing.FontStyle]::Bold)
                $FontSize13 = New-Object System.Drawing.Font('Tahoma', 13, [System.Drawing.FontStyle]::Bold)
              }
    }
  }
  #-----------------------------------------------------------------------------------------------------------------------------------------
  # Find the matching node and set the description accordingly.
  if ($SelectedNode -eq 'TreeNode: Introduction')
  {
    $Text = "Custom Texture Tool PS{0}"
    $Text += "By Bighead"
    $Text += "{0}{0}"
    $Text += "This is a PowerShell script for Windows that makes use of the command line options of several external programs that "
    $Text += "can perform a variety of functions for custom textures used in Dolphin. It has evolved to a point where it can be used "
    $Text += "for almost any retexturing project (even PC games). The script acts as a front end to these programs providing an "
    $Text += "entirely new level of features geared towards retexturing projects that these programs do not provide on their own."
    $Text += "{0}{0}"
    $Text += "This script is compatible with PowerShell v2 and up. Some small features (such as automatically relocating the console "
    $Text += "window) rely on v3 and up. This means it has a minimum requirement of Windows Vista, but I don't think that will be much "
    $Text += "of a problem these days. PowerShell can be updated manually but this is not necessary. And while this script may work on "
    $Text += "32-bit operating systems, some registry references rely on the 64-bit version so I can't guarantee everything will work "
    $Text += "correctly. "
    $Text += "{0}{0}"
    $Text += "Because of the numerous amount of options available it may seem overwhelming to use at first. But fear not, it is "
    $Text += "actually quite simple to use and by now there should be enough documentation available that everything that it can "
    $Text += "do is explained in detail."
    $Text += "{0}{0}"
    $Text += "If there are any questions, concerns, bug reports, etc. then PM me on the dolphin forums. I can also be contacted via "
    $Text += "my email address at: bighead.0@gmail{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Custom Texture Tool PS")
    $HelpDescription.SelectionFont = $FontSize13
    $HelpDescription.Find("bighead.0@gmail")
    $HelpDescription.SelectionFont = $FontSize10
  }
  elseif ($SelectedNode -eq 'TreeNode: Features')
  {
    $HelpDescription.SelectionFont = $FontSize13
    $HelpDescription.SelectedText = "Features" + [Environment]::NewLine
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10)
    $HelpDescription.SelectedText = [Environment]::NewLine
    $HelpDescription.SelectedText = "Some of the most prominent features include:" + [Environment]::NewLine
    $HelpDescription.SelectedText = [Environment]::NewLine
    $HelpDescription.SelectionBullet = $true
    $HelpDescription.SelectedText = "Check textures for a variety of issues (scaling factors, aspect ratios, etc..)." + [Environment]::NewLine
    $HelpDescription.SelectedText = "Copy textures identified with issues to a folder for manual fixing." + [Environment]::NewLine
    $HelpDescription.SelectedText = "Auto-repair most textures that are identified with issues." + [Environment]::NewLine
    $HelpDescription.SelectedText = "Convert textures between PNG, DDS, and JPG formats." + [Environment]::NewLine
    $HelpDescription.SelectedText = "DDS textures can be created with DXT1, DXT5, or BC7 block compression." + [Environment]::NewLine
    $HelpDescription.SelectedText = "Rescale all textures at a fixed integer scale as PNG, DDS, or JPG. " + [Environment]::NewLine
    $HelpDescription.SelectedText = "Missing mipmaps are automatically generated when repairing/converting." + [Environment]::NewLine
    $HelpDescription.SelectedText = "Provide custom mipmaps or the script can be forced to generate new ones." + [Environment]::NewLine
    $HelpDescription.SelectedText = "The type of DDS mipmaps generated (internal/external) can be configured." + [Environment]::NewLine
    $HelpDescription.SelectedText = "Create material maps from color/bump/spec/lum/nrm textures." + [Environment]::NewLine
    $HelpDescription.SelectedText = "Existing material maps and/or materials are automatically handled when found." + [Environment]::NewLine
    $HelpDescription.SelectedText = "Optimize PNG file sizes using OptiPNG without breaking anything." + [Environment]::NewLine
    $HelpDescription.SelectedText = "Apply various upscaling filters to all textures including xBRZ and Waifu2x." + [Environment]::NewLine
    $HelpDescription.SelectionBullet = $false
  }
  elseif ($SelectedNode -eq 'TreeNode: Quick Guide')
  {
    $Text = "Quick Guide"
    $Text += "{0}{0}"
    $Text += "This section quickly explains which programs are needed to unlock all features without having to read anything else. The "
    $Text += 'paths to these programs can be set in the "Options" menu by pressing the "Configure Paths" button. Detailed descriptions of '
    $Text += 'these programs can be found in the "Requirements" section of this help document.'
    $Text += "{0}{0}"
    $Text += "Step 1: Required Programs"
    $Text += "{0}{0}"
    $Text += "Before doing anything, ImageMagick v7 (or v6) should be installed. After ImageMagick is installed, the script can be "
    $Text += "restarted and it will automatically detect its install location."
    $Text += "{0}{0}"
    $Text += "ImageMagick: This program is used in almost every option of this script.{0}"
    $Text += "http://www.imagemagick.org/script/download.php#windows"
    $Text += "{0}{0}"
    $Text += "Step 2: Optional Programs"
    $Text += "{0}{0}"
    $Text += "At this point almost everything the script can do will work except a few special features. These features do require "
    $Text += 'additional tools that must be configured in the options menu by pressing the "Configure Paths" button found on the '
    $Text += '"Options" menu.'
    $Text += "{0}{0}"
    $Text += "DirectXTex TexConv: Can create any type of DDS texture. Required for some features.{0}"
    $Text += "https://github.com/Microsoft/DirectXTex/releases {0}{0}"
    $Text += "Compressonator: Can create higher quality DDS textures than TexConv.{0}"
    $Text += "https://github.com/GPUOpen-Tools/Compressonator/releases {0}{0}"
    $Text += "DDS Utilities: Alternative program to create DDS textures. Can not create BC7 textures.{0}"
    $Text += "https://developer.nvidia.com/gameworksdownload#?dn=dds-utilities-8-31 {0}{0}"
    $Text += "Ishiiruka Tool: Required to create and work with Ishiiruka material map textures.{0}"
    $Text += "https://forums.dolphin-emu.org/Thread-unofficial-ishiiruka-dolphin-custom-version?pid=297815#pid297815 {0}{0}"
    $Text += "OptiPNG: Can reduce PNG file size.{0}"
    $Text += "http://optipng.sourceforge.net/ {0}{0}"
    $Text += "xBRZ ScalerTest: Upscales textures with xBRZ filter.{0}"
    $Text += "https://sourceforge.net/projects/xbrz/ {0}{0}"
    $Text += "Waifu2x: Upscales textures with waifu2x filter.{0}"
    $Text += "https://github.com/lltcggie/waifu2x-caffe/releases - Best with Nvidia GPU {0}"
    $Text += "https://github.com/tanakamura/waifu2x-converter-cpp - Best with AMD GPU"
    $Text += "{0}{0}"
    $Text += "Step 3: Done"
    $Text += "{0}{0}"
    $Text += "If all tools are installed, and all the paths to these tools are set, then all options of the script will be fully functional. I do suggest taking "
    $Text += "the time to read some of the other help topics as well, especially the 'Guides' section which goes into detail of how to perform some basic "
    $Text += "operations such as creating DDS packs or rescaling textures to have smaller dimensions to save on VRAM.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Quick Guide")
    $HelpDescription.SelectionFont = $FontSize13
    $HelpDescription.Find("Step 1: Required Programs")
    $HelpDescription.SelectionFont = $FontSize11
    $HelpDescription.Find("ImageMagick:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("DirectXTex TexConv:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Step 2: Optional Programs")
    $HelpDescription.SelectionFont = $FontSize11
    $HelpDescription.Find("Compressonator:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("DDS Utilities:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Ishiiruka Tool:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("OptiPNG:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("xBRZ ScalerTest:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Waifu2x:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Step 3: Done")
    $HelpDescription.SelectionFont = $FontSize11
  }
  elseif ($SelectedNode -eq 'TreeNode: Information')
  {
    $HelpDescription.SelectionFont = $FontSize13
    $HelpDescription.SelectedText = "Information" + [Environment]::NewLine
    $HelpDescription.SelectionFont = New-Object System.Drawing.Font('Tahoma', 10)
    $HelpDescription.SelectedText = [Environment]::NewLine
    $HelpDescription.SelectedText = "This section is a collection of random but useful information." + [Environment]::NewLine
    $HelpDescription.SelectedText = [Environment]::NewLine
    $HelpDescription.SelectionBullet = $true
    $HelpDescription.SelectedText = "ALWAYS BACKUP YOUR TEXTURE PACK. This script should be 100% safe, but I will not be held responsible for any issues that may occur." + [Environment]::NewLine
    $HelpDescription.SelectedText = "This script can not be in a base path that contains an apostrophe or the ~ symbol or it will not work! Sub-folders may contain an apostrophe, however." + [Environment]::NewLine
    $HelpDescription.SelectedText = "It is possible to force the script to skip a file or folder and all of its containing sub-folders by placing a ~ character in the file or folder name." + [Environment]::NewLine
    $HelpDescription.SelectedText = "This script is compatible with PNG, DDS, and JPG packs, but it is suggested to resolve all issues with PNG textures before converting to other formats." + [Environment]::NewLine
    $HelpDescription.SelectedText = "ImageMagick installation path is pulled from the registry when the script is launched. Manually changing this path removes this functionality." + [Environment]::NewLine
    $HelpDescription.SelectedText = "When performing any Standard or Advanced option, pressing the Spacebar can pause the current process, and pressing Escape can cancel the current process." + [Environment]::NewLine
    $HelpDescription.SelectedText = "The script will generate missing mipmaps from the last provided mipmap in a chain of mipmaps. It can also be forced to generate missing mipmaps from the top level." + [Environment]::NewLine
    $HelpDescription.SelectedText = "JPG textures will not be created from PNG/DDS textures that have an alpha channel. The reason for this is JPG does not support transparency." + [Environment]::NewLine
    $HelpDescription.SelectedText = "Ishiiruka material maps are exclusive to Ishiiruka and do not work in almost anything else, including the master branch of Dolphin and all image editors." + [Environment]::NewLine
    $HelpDescription.SelectedText = "If the script finds a DDS Ishiiruka color texture with a missing material, it will be 'repaired' using ImageMagick + Ishiiruka Tool to a compatible DDS format." + [Environment]::NewLine
    $HelpDescription.SelectionBullet = $false
  }
  elseif ($SelectedNode -eq 'TreeNode: Requirements')
  {
    $Text = "Requirements"
    $Text += "{0}{0}"
    $Text += "Minimum:"
    $Text += "{0}{0}"
    $Text += "- Windows Vista/7/8/10 x64{0}"
    $Text += "- PowerShell v2+ (for minor features v3+){0}"
    $Text += "- Microsoft .NET Framework v3.5+"
    $Text += "{0}{0}"
    $Text += "Required Programs:"
    $Text += "{0}{0}"
    $Text += "ImageMagick - The script will not function without it."
    $Text += "{0}{0}"
    $Text += "Optional Programs:"
    $Text += "{0}{0}"
    $Text += "DirectXTex TexConv - Creates textures in just about any possible format.{0}"
    $Text += "Compressonator - Alternative program to create higher quality DDS textures.{0}"
    $Text += "DDS Utilities - Creates nice DXT1/DXT5 textures. Can be used as a fallback path.{0}"
    $Text += "Ishiiruka Tool - Creates materials from bump/spec/lum/nrm or existing materials.{0}"
    $Text += "OptiPNG - Attempts to reduce the file size of PNG textures.{0}"
    $Text += "xBRZ ScalerTest - Allows upscaling textures with the xBRZ filter up to 6x.{0}"
    $Text += "waifu2x Caffe/CPP - Allows upscaling textures with the waifu2x filter up to 8x."
    $Text += "{0}{0}"
    $Text += "All DDS Generating programs are used as fallback paths if one fails in the order of: Selected Program > Compressonator > DDS Utilities > TexConv > ImageMagick.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Requirements")
    $HelpDescription.SelectionFont = $FontSize13
    $HelpDescription.Find("Minimum:")
    $HelpDescription.SelectionFont = $FontSize11
    $HelpDescription.Find("Required Programs:")
    $HelpDescription.SelectionFont = $FontSize11
    $HelpDescription.Find("ImageMagick")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("DirectXTex TexConv")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Optional Programs:")
    $HelpDescription.SelectionFont = $FontSize11
    $HelpDescription.Find("Compressonator")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("DDS Utilities")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Ishiiruka Tool")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("OptiPNG")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("xBRZ ScalerTest")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("waifu2x Caffe/CPP")
    $HelpDescription.SelectionFont = $FontSize10
  }
  elseif ($SelectedNode -eq 'TreeNode: ImageMagick')
  {
    $Text = "ImageMagick by ImageMagick Studio LLC"
    $Text += "{0}{0}"
    $Text += "http://www.imagemagick.org/script/download.php#windows"
    $Text += "{0}{0}"
    $Text += "Description:"
    $Text += "{0}{0}"
    $Text += "ImageMagick(r) is a software suite to create, edit, compose, or convert bitmap images. It can read and write images in a variety of formats (over 200) including PNG, JPEG, "
    $Text += "JPEG-2000, GIF, TIFF, DPX, EXR, WebP, Postscript, PDF, and SVG. Use ImageMagick to resize, flip, mirror, rotate, distort, shear and transform images, adjust image colors, "
    $Text += "apply various special effects, or draw text, lines, polygons, ellipses and B껩er curves."
    $Text += "{0}{0}"
    $Text += "Why it's needed:"
    $Text += "{0}{0}"
    $Text += "This is the program that makes this script possible. It supports command line processing and many features that other image processing programs lack. Custom Texture Tool PS "
    $Text += "makes use of it's ability to read data from and write PNG/JPG/DDS images. It is used for some of the lower tier upscaling filters such as 'Point' and 'Lancoz'. The Seamless Method "
    $Text += "when applying any upscaling filter and combining multiple textures is also made possible using ImageMagick's 'montage' ability. Applying watermarks to textures using the name is "
    $Text += "made possible using the 'paint' and 'composite' abilities. This doesn't even begin to fully cover its usage.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("ImageMagick")
    $HelpDescription.SelectionFont = $FontSize13
    $HelpDescription.Find("Description:")
    $HelpDescription.SelectionFont = $FontSize11
    $HelpDescription.Find("Why it's needed:")
    $HelpDescription.SelectionFont = $FontSize11
  }
  elseif ($SelectedNode -eq 'TreeNode: DirectXTex TexConv')
  {
    $Text = "DirectXTex TexConv by Microsoft"
    $Text += "{0}{0}"
    $Text += "https://github.com/Microsoft/DirectXTex"
    $Text += "{0}{0}"
    $Text += "Description:"
    $Text += "{0}{0}"
    $Text += "This DirectXTex sample is an implementation of the texconv command-line texture utility from the legacy DirectX SDK utilizing DirectXTex rather than D3DX. This tool loads "
    $Text += "an image and prepares it for runtime use by resizing, format conversion, mip-map generation, block-compression, and writes the result in a file format suited for runtime "
    $Text += "use. It can also be used for other image-to-image processing."
    $Text += "{0}{0}"
    $Text += "Why it's needed:"
    $Text += "{0}{0}"
    $Text += "DirectXTex TexConv is capable of creating DDS textures with any type of block compression. It is required by this script to create BC7 textures. While "
    $Text += "Compressonator can also BC7 textures, it is not nearly as advanced as TexConv and randomly fails to create some textures. TexConv is powerful in that it can "
    $Text += "also convert BC7 textures to other formats, which no other command line based program seems to offer.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("DirectXTex TexConv")
    $HelpDescription.SelectionFont = $FontSize13
    $HelpDescription.Find("Description:")
    $HelpDescription.SelectionFont = $FontSize11
    $HelpDescription.Find("Why it's needed:")
    $HelpDescription.SelectionFont = $FontSize11
  }
  elseif ($SelectedNode -eq 'TreeNode: Compressonator')
  {
    $Text = "Compressonator by AMD"
    $Text += "{0}{0}"
    $Text += "https://github.com/GPUOpen-Tools/Compressonator/releases"
    $Text += "{0}{0}"
    $Text += "Description:"
    $Text += "{0}{0}"
    $Text += "Compressonator is a set of tools to allow artists and developers to more easily create compressed texture image assets and easily visualize the quality impact of various "
    $Text += "compression technologies. It consists of a GUI application, a command line application and an SDK for easy integration into a developer tool chain."
    $Text += "{0}{0}"
    $Text += "Why it's needed:"
    $Text += "{0}{0}"
    $Text += "Compressonator arguably creates the highest quality DDS textures across all block compression types. If the path to Compressonator is set, it can serve as a replacement for "
    $Text += "TexConv. It can also be used to create BC7 textures, which may offer better quality than TexConv. Compressonator fails to create some images, but the script will fall back "
    $Text += "to other programs when this happens in the order of: Selected Program > Compressonator > DDS Utilities > TexConv > ImageMagick."
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Compressonator")
    $HelpDescription.SelectionFont = $FontSize13
    $HelpDescription.Find("Description:")
    $HelpDescription.SelectionFont = $FontSize11
    $HelpDescription.Find("Why it's needed:")
    $HelpDescription.SelectionFont = $FontSize11
  }
  elseif ($SelectedNode -eq 'TreeNode: DDS Utilities')
  {
    $Text = "DDS Utilities by Nvidia"
    $Text += "{0}{0}"
    $Text += "https://developer.nvidia.com/gameworksdownload#?dn=dds-utilities-8-31"
    $Text += "{0}{0}"
    $Text += "Description:"
    $Text += "{0}{0}"
    $Text += "A set of utilities for manipulating DDS image files, including: nvDXT, a command-line binary version of the nvDXT library, detach, a tool that extracts MIP levels from a "
    $Text += "DDS file, stitch, a tool that recombines MIP levels into a single DDS file and readDXT, which reads compressed images and writes TGA files."
    $Text += "{0}{0}"
    $Text += "Why it's needed:"
    $Text += "{0}{0}"
    $Text += "DDS Utilities used to serve as the backbone of DDS generation in this script, but it has been supersceded by better programs and better methods. It still creates nice "
    $Text += "quality DXT1/DXT5 textures though, so it is still available to use with the script. Compressonator can arguably create higher quality DXT1/DXT5 textures, but Compressonator "
    $Text += "also fails at creating images of certain sizes. If DDS Utilities is not found when creating DXT1/DXT5 images, the script instead uses TexConv in this situation, so resulting "
    $Text += "texture quality may suffer.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("DDS Utilities")
    $HelpDescription.SelectionFont = $FontSize13
    $HelpDescription.Find("Description:")
    $HelpDescription.SelectionFont = $FontSize11
    $HelpDescription.Find("Why it's needed:")
    $HelpDescription.SelectionFont = $FontSize11
  }
  elseif ($SelectedNode -eq 'TreeNode: Ishiiruka Tool')
  {
    $Text = "Ishiiruka Tool by Tino"
    $Text += "{0}{0}"
    $Text += "https://forums.dolphin-emu.org/Thread-unofficial-ishiiruka-dolphin-custom-version?pid=297815#pid297815"
    $Text += "{0}{0}"
    $Text += "Description:"
    $Text += "{0}{0}"
    $Text += "Since Ishiiiruka 436 support for normal mapping and phong lighting has been added. To Support this additional textures are required:{0}"
    $Text += "* Depth Texture: deviation distance from the plane. Values greater than 127 (byte) are above the surface. required for displacement mapping.{0}"
    $Text += "* -Name = <TextureID>.bump.extension"
    $Text += "* Normal Texture: normal map. Optional, if not present will be calculated from the bump texture.{0}"
    $Text += "* -Name = <TextureID>.nrm.extension{0}"
    $Text += "* Specular Texture : maps how polished is the surface of the material. A black (0) Texture will give as a result a opaque paper like material. White (255) will give a polished metallic like surface.{0}"
    $Text += "* -Name = <TextureID>.spec.extension{0}"
    $Text += "* Emissive Texture : maps the color of the light emitted by a material on every pixel on light emitting materials.{0}"
    $Text += "* -Name = <TextureID>.lum.extension{0}"
    $Text += "{0}"
    $Text += "But adding all this textures will take a huge hit in memory usage so I pack them in a single texture with the following format:{0}"
    $Text += "* Red Channel: Specular data 0-255 0=opaque 255=fully reflective specular exponent 64{0}"
    $Text += "* Green Channel: Normal Y component unsigned (reduced from [-1.0 1.0] to [0.0 1.0]){0}"
    $Text += "* Blue Channel: Bump map depth (reduced from [-1.0 1.0] to [0.0 1.0]){0}"
    $Text += "* Alpha Channel: Normal X component unsigned (reduced from [-1.0 1.0] to [0.0 1.0]){0}"
    $Text += "{0}"
    $Text += "This file has the .nrm sufix to make them compatible with raw normals to make testing easy.{0}"
    $Text += "{0}"
    $Text += "Why it's needed:"
    $Text += "{0}{0}"
    $Text += "Tino's material map format is proprietary to Dolphin Ishiiruka, so there isn't a tool in existence that can create these textures other than his Ishiiruka Tool. Fortunately "
    $Text += "he was very willing to add command line support so its functionality could be used with this script. {0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Ishiiruka Tool")
    $HelpDescription.SelectionFont = $FontSize13
    $HelpDescription.Find("Description:")
    $HelpDescription.SelectionFont = $FontSize11
    $HelpDescription.Find("Why it's needed:")
    $HelpDescription.SelectionFont = $FontSize11
  }
  elseif ($SelectedNode -eq 'TreeNode: OptiPNG')
  {
    $Text = "OptiPNG by cosmin and rctruta"
    $Text += "{0}{0}"
    $Text += "http://optipng.sourceforge.net/"
    $Text += "{0}{0}"
    $Text += "Description:"
    $Text += "{0}{0}"
    $Text += "OptiPNG is a PNG optimizer that recompresses image files to a smaller size, without losing any information. This program also converts external formats (BMP, GIF, PNM and TIFF) "
    $Text += "to optimized PNG, and performs PNG integrity checks and corrections."
    $Text += "{0}{0}"
    $Text += "Why it's needed:"
    $Text += "{0}{0}"
    $Text += "While it's not necessarily 'needed', this is a great program that can reduce the file size of PNG files and still keep 100% quality. The script will work fine without it, but "
    $Text += "any options that use OptiPNG will not be able to function."
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("OptiPNG")
    $HelpDescription.SelectionFont = $FontSize13
    $HelpDescription.Find("Description:")
    $HelpDescription.SelectionFont = $FontSize11
    $HelpDescription.Find("Why it's needed:")
    $HelpDescription.SelectionFont = $FontSize11
  }
  elseif ($SelectedNode -eq 'TreeNode: xBRZ ScalerTest')
  {
    $Text = "xBRZ ScalerTest by Zenju"
    $Text += "{0}{0}"
    $Text += "https://sourceforge.net/projects/xbrz/"
    $Text += "{0}{0}"
    $Text += "Description:"
    $Text += "{0}{0}"
    $Text += "xBRZ is a high-quality image upscaling filter for creating beautiful HD representations from low-resolution images."
    $Text += "{0}{0}"
    $Text += "Why it's needed:"
    $Text += "{0}{0}"
    $Text += "This tool is required to apply the xBRZ upscaling filter when using the option 'Apply Upscaling Filter to All Textures'.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("xBRZ ScalerTest")
    $HelpDescription.SelectionFont = $FontSize13
    $HelpDescription.Find("Description:")
    $HelpDescription.SelectionFont = $FontSize11
    $HelpDescription.Find("Why it's needed:")
    $HelpDescription.SelectionFont = $FontSize11
  }
  elseif ($SelectedNode -eq 'TreeNode: Waifu2x')
  {
    $Text = "Waifu2x by nagadomi, -Caffe by lltcggie, -CPP by WL-Amigo/tanakamura"
    $Text += "{0}{0}"
    $Text += "https://github.com/lltcggie/waifu2x-caffe/releases {0}"
    $Text += "https://github.com/tanakamura/waifu2x-converter-cpp "
    $Text += "{0}{0}"
    $Text += "Description:"
    $Text += "{0}{0}"
    $Text += "Image Super-Resolution for Anime-style art using Deep Convolutional Neural Networks. And it supports photo."
    $Text += "{0}{0}"
    $Text += "Why it's needed:"
    $Text += "{0}{0}"
    $Text += "This tool is required to apply the Waifu2x upscaling filter when using the option 'Apply Upscaling Filter to All Textures'. Waifu2x-Caffe is most likely the better choice if "
    $Text += "the target system has a nvidia GPU. Waifu2x-CPP is preferable for AMD graphics card because they do not support CUDA, and CPP does support OpenCL which can speed up the upscaling "
    $Text += "process significantly. It should be noted that Waifu2x-CPP does have a higher failure rate at preserving transparency if images have few colors."
    $Text += "{0}{0}"
    $Text += "Although Waifu2x was designed to upscale anime art, it has proven to be extremely good at upscaling various game textures as well.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Waifu2x")
    $HelpDescription.SelectionFont = $FontSize13
    $HelpDescription.Find("-Caffe")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("-CPP")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Description:")
    $HelpDescription.SelectionFont = $FontSize11
    $HelpDescription.Find("Why it's needed:")
    $HelpDescription.SelectionFont = $FontSize11
  }
  elseif ($SelectedNode -eq 'TreeNode: Main Window')
  {
    $Text = "Main Window"
    $Text += "{0}{0}"
    $Text += "The main window is the first GUI window that shows up when the script is loaded. Here the 'Texture' and 'Output' paths can be selected, the operation to be performed "
    $Text += "which is selected through a 'Standard' or 'Advanced' option, and a configuration window for the selected operation. There are also buttons to 'Start' the operation, open "
    $Text += "the 'Options' panel, open this 'Help' document, and 'Exit' the script."
    $Text += "{0}{0}"
    $Text += "Control Key Modifier"
    $Text += "{0}{0}"
    $Text += 'Holding the Control key and pressing Start opens up a new mode called "Process Selected" which allows manually selecting a group of textures to process which temporarily '
    $Text += 'bypasses the "Texture Path". More on this mode can be found in the corresponding help topic in this section.'
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Main Window")
    $HelpDescription.SelectionFont = $FontSize13
    $HelpDescription.Find("Control Key Modifier")
    $HelpDescription.SelectionFont = $FontSize11
  }
  elseif ($SelectedNode -eq 'TreeNode: Texture Path')
  {
    $Text = "Texture Path"
    $Text += "{0}{0}"
    $Text += "This is the path to the folder that contains the textures to run through this script. This should usually be a folder that contains textures for Dolphin emulator, "
    $Text += "named to the disc's GameID (or the 3-digit equivalent). This folder can contain any number of images, as well as sub-folders containing images, as the script will recursively "
    $Text += "search though all folders found in this path. Any paths/folders that contain the ~ character will be skipped."
    $Text += "{0}{0}"
    $Text += 'Any image can be processed if the option "Allow All Images" is enabled. This option bypasses the check for Dolphin textures by skipping the search for the "tex1" prefix, and allows '
    $Text += 'this tool to work on any image that is in PNG, DDS, or JPG format.'
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Texture Path")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: Output Path')
  {
    $Text = "Output Path"
    $Text += "{0}{0}"
    $Text += "Where Custom Texture Tool PS will output all generated images. When selecting the Texture Path, this will default to the same folder, but can be changed to anywhere. "
    $Text += "{0}{0}"
    $Text += "Selecting this folder will always append a '\~CTT_Generated' folder, which is where all the various output folders will be found after running one of the script's options. The reason "
    $Text += "this folder is forced is to create an output path with the ~ character, which tells the script to skip processing textures found within it."
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Output Path")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: Process Selected')
  {
    $Text = "Process Selected"
    $Text += "{0}{0}"
    $Text += "This is a hidden option that allows processing a texture (or group of textures) that are manually selected by the user. It will bypass the 'Texture Path' for the current run. "
    $Text += "To access this hidden option, simply highlight the desired 'Standard' option and hold the 'Control' key when pressing the 'Start' button."
    $Text += "{0}{0}"
    $Text += "Textures can be added to the array by simply dragging and dropping them onto the window or by clicking the window and manually adding them through the file browser. "
    $Text += "It only supports PNG, DDS, and JPG images. When two or more images are added to the array, the left and right 'Arrow' buttons can navigate through the list. This "
    $Text += "feature does have its limitations and will not work correctly with most 'Advanced' options."
    $Text += "{0}{0}"
    $Text += "By default, textures will be created in the 'Output Path'. This can temporarily be changed on this option's window to output the textures to a different "
    $Text += "folder. This only changes the Output Path for the current run, and resets it back to its previous value when textures are processed or when the window is closed."
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Process Selected")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: Standard Options')
  {
    $Text = "Standard Options"
    $Text += "{0}{0}"
    $Text += "These can also be considered the 'Main' functions of this script. All standard options will output textures to wherever the 'Output Path' was selected, within the folder '\~CTT_Generated'. "
    $Text += "{0}{0}"
    $Text += "Standard options usually do not modify the texture pack directly, with the exception of the 'In-Place' options when using the 'Optimize PNG Textures "
    $Text += "With OptiPNG' or 'Create Material Maps With Ishiiruka Tool' functions.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Standard Options")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: Scan Dolphin Textures For Issues')
  {
    $Text = "Scan Dolphin Textures For Issues"
    $Text += "{0}{0}"
    $Text += "Scans textures for issues and offers the ability to repair any 'broken' textures that are found. Several options are available to configure which issues "
    $Text += "are found and how repaired textures will be generated. Detailed information about these options can be found by hovering the mouse over them which displays "
    $Text += "a tooltip. Below is a list of all issues that can be found when scanning."
    $Text += "{0}{0}"
    $Text += "NotHD Texture: A texture with the original dimensions or lower.{0}"
    $Text += "Duplicate Texture: Multiple textures that contain the same name.{0}"
    $Text += "Dolphin Duplicate: Dolphin named duplicates with .1, .2, etc. suffixes.{0}"
    $Text += "Uneven Scale: Width and height were not scaled with the same factor.{0}"
    $Text += "Non-Integer Scale: The custom texture width or height was not scaled with an integer scale and contains a decimal value.{0}"
    $Text += "Bad Aspect Ratio: Original and custom texture contain a different aspect ratio.{0}"
    $Text += "MipMaps Missing: Detects any missing mipmap levels for mipmap [m] textures and lists the number of them missing.{0}"
    $Text += "MipMaps Bad Scale: Detects bad mipmap scales for [m] textures and lists the number of mipmaps with bad scaling values found.{0}"
    $Text += "Material Textures: Texture contains material textures (bump/spec/lum/nrm). Repairing the texture will create a material map.{0}"
    $Text += "Bad DDS Dimensions: When DDS texture dimensions do not match the best possible dimensions calculated from the original dimensions."
    $Text += "{0}{0}"
    $Text += "Several folders can be created when using this option to easily identify which textures have the issue in the pack, or if they were repaired."
    $Text += "{0}{0}"
    $Text += "BrokenTextures: Textures that are found with issues and were not repaired.{0}"
    $Text += "RepairedTextures: Textures that are found with issues but were repaired.{0}"
    $Text += "NotHDTextures: Textures that have the original dimensions or lower.{0}"
    $Text += "DuplicateTextures: Textures found that have the same name as other textures.{0}"
    $Text += "DolphinDuplicates: Textures found with the '.#' suffix appended by Dolphin.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Scan Dolphin Textures For Issues")
    $HelpDescription.SelectionFont = $FontSize13
    $HelpDescription.Find("NotHD Texture:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Dolphin Duplicate:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Duplicate Texture:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Uneven Scale:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Non-Integer Scale:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Bad Aspect Ratio:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("MipMaps Missing:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("MipMaps Bad Scale:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Material Textures:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Bad DDS Dimensions:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("BrokenTextures:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("RepairedTextures:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("NotHDTextures:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("DuplicateTextures:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("DolphinDuplicates:")
    $HelpDescription.SelectionFont = $FontSize10
  }
  elseif ($SelectedNode -eq 'TreeNode: Convert Textures to Another Format')
  {
    $Text = "Convert Textures to Another Format"
    $Text += "{0}{0}"
    $Text += "This option performs a 1:1 conversion of all textures to the chosen format. There are three formats to pick from: PNG, DDS, and JPG."
    $Text += "{0}{0}"
    $Text += "PNG textures are a compressed format that have pixel perfect quality. When converting any image to PNG, the representation of pixels will not change. PNG textures are best used for archival "
    $Text += "purposes, as it is not an optimized format for GPU processing. Very large PNG textures, or PNG textures that are accessed by the game often, can create noticeable stutter when used in texture "
    $Text += "packs because of the amount of time it takes to decode the images on the GPU. Dolphin has options (such as prefetch) to attempt to remedy this, but it is still not as fast as DDS."
    $Text += "{0}{0}"
    $Text += "JPG textures are not suggested for texture packs. Like PNG they are slow to decode, and quality is permanently lost when converting to JPG. There was a time when JPG may have been useful as textures, "
    $Text += "but now days DDS is a far better choice. This script is not limited to textures, and can work with any images, and JPG is a common format when posting images online. This is the only reason I keep the "
    $Text += "JPG option around. There are times I want to mass convert a bunch of PNG images to JPG to use on the internet."
    $Text += "{0}{0}"
    $Text += "DDS textures can be created with 3 types of block compression: DXT1 (BC1), DXT5 (BC3), and BC7. They can also be created as uncompressed ARGB32. The DDS format can be chosen on the Options menu "
    $Text += 'which is labelled "DDS Compression". DDS descriptions will be broken up into four categories below. '
    $Text += "{0}{0}"
    $Text += "DDS DXT1 textures are the most efficient, but also have the lowest quality. They are effectively half the file size and require half the amount of VRAM as DXT5 textures. They only support 1-bit alpha, so "
    $Text += 'they are not very useful for most images that contain transparency. Textures will only be created with DXT1 compression if they are opaque, and if the "DXT1/DXT5" option is selected as the "DDS Compression".'
    $Text += "{0}{0}"
    $Text += "DDS DXT5 textures require twice as much disk space and VRAM as DXT1, yield slightly higher quality, and have much better support for alpha channels. DXT5 used to be the number one choice for most "
    $Text += 'textures during the D3D9 era, but it has been succeeded by BC7 which was introduced in D3D11. Textures with transparency will be created with DXT5 if "DXT1/DXT5" is selected as the "DDS Compression '
    $Text += 'Format". All textures will be created with "DXT5" if it is selected as the "DDS Compression".'
    $Text += "{0}{0}"
    $Text += "DDS BC7 textures require the same amount of resources as DXT5 but provide much higher quality. BC7 is a newer format that was introduced with DirectX 11. This means BC7 requires D3D11 and/or OpenGL4 compatible "
    $Text += "GPUs. This includes the Nvidia GTX 400 series and newer, Intel 7th generation graphics and newer (depending on drivers), and AMD Radeon HD 5000 series and newer. Anything older and BC7 textures will fail to load "
    $Text += 'in Dolphin. All textures will be created with "BC7" if it is selected as the "DDS Compression".'
    $Text += "{0}{0}"
    $Text += "DDS ARGB32 textures have the absolute best quality because they are uncompressed and lossless, but they require 4x the amount of disk space and VRAM as DXT5 and BC7. To put this into perspective, an 8192x8192 texture "
    $Text += "compressed with BC7 will require 64MB of disk space and VRAM, while an uncompressed texture with the same dimensions will require 256MB. Images should only be created as an uncompressed DDS texture in situations "
    $Text += "where quality is the utmost importance (such as fonts and UI textures). It should not be used for environment textures, as the pack will be enormous in filesize with over the top VRAM requirements. All textures will "
    $Text += 'be created as uncompressed DDS if "ARGB32" is selected as the "DDS Compression".'
    $Text += "{0}{0}"
    $Text += "The user may choose to auto-repair textures by checking the Auto-Repair Dimensions check box. This will ensure the texture has the most accurate dimensions, but there is "
    $Text += "the possibility it could screw up the dimensions if textures were purposely created with a bad integer scale. This option is not suggested for textures with very low scaling "
    $Text += "values even if it's not an integer scale. For example, if the texture is upscaled with a value of 1.80, there is a chance CTT-PS will ignore the decimal and use the whole number '1'. If this "
    $Text += "happens, the texture will end up with the original dimensions, meaning the dimensions it was dumped with. Scale-Fix Threshold can round the value up; more information can be found on the options tool tip."
    $Text += "{0}{0}"
    $Text += "The Copy Non-Textures option does exactly what it says, and copies any files that the script did not identify as a texture into the newly generated pack. This holds true for images that "
    $Text += "don't contain the 'tex1' prefix, as well as any text documents, script files, project files, basically anything that is not a Dolphin texture. If 'Allow All Images' is enabled, images "
    $Text += "that are not textures will be treated by the script as textures, so this is something to be aware of."
    $Text += "{0}{0}"
    $Text += "Textures generated with this option are output to a ConvertedTextures folder followed by the chosen file extension. After the rescaling process is finished, this "
    $Text += "folder can safely be renamed to the 3-digit GameID and used as a Dolphin texture pack.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Convert Textures to Another Format")
    $HelpDescription.SelectionFont = $FontSize13
    $HelpDescription.Find("PNG textures")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("JPG textures")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("DDS textures")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("DDS DXT1 textures")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("DDS DXT5 textures")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("DDS BC7 textures")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("DDS ARGB32 textures")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Copy Non-Textures")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Auto-Repair Dimensions")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("ConvertedTextures")
    $HelpDescription.SelectionFont = $FontSize10
  }
  elseif ($SelectedNode -eq 'TreeNode: Rescale Textures With New Scaling Factor')
  {
    $Text = "Rescale Textures With New Scaling Factor"
    $Text += "{0}{0}"
    $Text += "This option can rescale all textures with new dimensions, that are calculated from multiplying the 'Rescale Factor' by the texture's original dimensions. This means that this option completely "
    $Text += "ignores the 'current' dimensions of the custom texture, as they have no use in this case. Textures can be created as PNG, DDS, or JPG (see 'Convert Textures to Another Format' topic for more info)."
    $Text += "{0}{0}"
    $Text += "Textures should almost always be rescaled with an integer value such as 2, 3, 4, etc. Decimals are allowed in the Rescale Factor, but are not suggested. Dolphin prefers to see textures upscaled "
    $Text += "with an integer upscale, using decimal values can slightly reduce performance. For non-Dolphin texture packs, the only available dimensions are the 'current' dimensions and not the 'original' "
    $Text += "dimensions. This means that this option will not work the same as it does with Dolphin textures as the original dimensions are faked to the current dimensions. Since the original dimensions are "
    $Text += "unknown, all texture dimensions will be calculated from multiplying the 'Rescale Factor' by the texture's current dimension. "
    $Text += "{0}{0}"
    $Text += "Enabling the option 'Manual Rescale' changes how this option works. When enabled, the Rescale Factor acts as a default scaling value and a prompt appears for each texture to rescale "
    $Text += "them individually from 1-100. If 0 is entered as the scale, the texture is effectively skipped. It is not suggested to use Manual Rescale on an entire texture pack, as it could take "
    $Text += "a very long time to manually rescale each texture individually. This option is most useful to rescale a handful of textures at different scales."
    $Text += "{0}{0}"
    $Text += "The 'Copy Non-Textures' option does exactly what it says, and copies any files that the script did not deem a texture into the newly generated pack. This holds true for images that "
    $Text += "don't contain the 'tex1' prefix, as well as any text documents, script files, project files, basically anything that is not a Dolphin texture. If 'Allow All Images' is enabled, images "
    $Text += "that are not textures will be treated by the script as textures, so this is something to take notice of."
    $Text += "{0}{0}"
    $Text += "Textures generated with this option are output to a 'RescaledTextures' folder followed by the chosen file extension. After the rescaling process is finished, this folder can safely "
    $Text += "be renamed to the 3-digit GameID and used as a Dolphin texture pack.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Rescale Textures With New Scaling Factor")
    $HelpDescription.SelectionFont = $FontSize13
    $HelpDescription.Find("'RescaledTextures'")
    $HelpDescription.SelectionFont = $FontSize10
  }
  elseif ($SelectedNode -eq 'TreeNode: Add Identifying Watermark to All Textures')
  {
    $Text = "Add Identifying Watermark to All Textures"
    $Text += "{0}{0}"
    $Text += "Generates a watermark in the center of all textures that displays the texture name. The purpose of this option is to "
    $Text += "be able to easily identify where textures are located when loaded into a game. All textures will be created as PNG "
    $Text += "images with a minimum width of 256 pixels so the text is easily readable, and several options are available to configure "
    $Text += "the output. This option works with all supported formats (PNG/DDS/JPG)."
    $Text += "{0}{0}"
    $Text += "Note that DDS textures created with Ishiiruka Tool will require a valid path to Ishiiruka Tool to successfully create "
    $Text += "the watermark. If Ishiiruka Tool is not found, the texture will be generated as a black image that contains the watermark. "
    $Text += "This is still useful as it will still notify where the texture is in-game when loaded into Dolphin. The same holds true for "
    $Text += "DDS BC7 textures. TexConv is required to generate the watermark, and if it's not found, a black image will be created instead."
    $Text += "{0}{0}"
    $Text += "Textures generated with this option are output to a 'WatermarkTextures' folder.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Add Identifying Watermark to All Textures")
    $HelpDescription.SelectionFont = $FontSize13
    $HelpDescription.Find("'WatermarkTextures'")
    $HelpDescription.SelectionFont = $FontSize10
  }
  elseif ($SelectedNode -eq 'TreeNode: Create Material Maps With Ishiiruka Tool')
  {
    $Text = "Create Material Maps With Ishiiruka Tool"
    $Text += "{0}{0}"
    $Text += "Requires a valid path to Ishiiruka Tool which can be set in the Options menu."
    $Text += "{0}{0}"
    $Text += "Finds textures that have accompanying material textures (bump/spec/nrm/lum) and generates a material map (mat) from them. "
    $Text += "At this time, material maps are only usable by Dolphin Ishiiruka. These textures are capable of adding further graphical "
    $Text += "enhancements to the in-game textures such as bump map displacement using the bumpmap and normal map textures, and additional "
    $Text += "lighting effects using the specularity and luminance materials."
    $Text += "{0}{0}"
    $Text += "Older versions of Ishiiruka Tool generated the combined material as a normal map (nrm), but newer versions now generate the "
    $Text += "result with a new format (mat). I can only assume this is so Ishiiruka (nrms) were not confused with standard (nrms). It is "
    $Text += "important to always use the latest version of Ishiiruka Tool with this script as it relies on its behavior. Younger iterations "
    $Text += "of the tool suffer from bugs and some features may not be compatible. "
    $Text += "{0}{0}"
    $Text += "It is not required to use this option to generate material maps from material textures. Using any option that creates textures "
    $Text += "such as Scan + Repair, Convert, and Rescale will also generate material maps from any materials found. These options may be "
    $Text += "even better since it creates a full pack and they preserve the original materials in the base pack you are generating from. "
    $Text += "{0}{0}"
    $Text += "Textures generated with this option are output to a 'MaterialMaps' folder. It is also possible to generate material maps "
    $Text += "directly in the pack using the 'Create Materials In-Place' option. Do note that this will destroy the original materials! "
    $Text += "I do not suggest the in-place option because I believe in backups.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Create Material Maps With Ishiiruka Tool")
    $HelpDescription.SelectionFont = $FontSize13
    $HelpDescription.Find("'MaterialMaps'")
    $HelpDescription.SelectionFont = $FontSize10
  }
  elseif ($SelectedNode -eq 'TreeNode: Optimize PNG Textures With OptiPNG')
  {
    $Text = "Optimize PNG Textures With OptiPNG"
    $Text += "{0}{0}"
    $Text += "Requires a valid path to OptiPNG which can be set in the Options menu."
    $Text += "{0}{0}"
    $Text += "OptiPNG attempts to recompresses PNG files in order to shrink their file size by running a number of different tests "
    $Text += "and going with the best results. This script sets the number of OptiPNG tests to 3 by default, but can be configured "
    $Text += "with the corresponding option. There is a limit of 1-20 tests, as each test will significantly increase the time it "
    $Text += "takes to optimize a texture. It is not suggested to go above 5 tests at the most unless you want to run it for days."
    $Text += "{0}{0}"
    $Text += "Textures generated with this option are output to a 'OptimizedTextures' folder. Textures may also be created 'In-Place' "
    $Text += "which overwrites the unoptimized texture within the texture pack itself."
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Optimize PNG Textures With OptiPNG")
    $HelpDescription.SelectionFont = $FontSize13
    $HelpDescription.Find("'OptimizedTextures'")
    $HelpDescription.SelectionFont = $FontSize10
  }
  elseif ($SelectedNode -eq 'TreeNode: Apply Upscaling Filter to All Textures')
  {
    $Text = "Apply Upscaling Filter to All Textures"
    $Text += "{0}{0}"
    $Text += "This option allows applying an upscaling filter to all textures. The output size of the filtered texture is calculated by "
    $Text += "multiplying the current width/height of the texture by the entered 'Upscale Factor'. Several filters are available, and most "
    $Text += "of them are applied with ImageMagick. xBRZ requires the xBRZ ScalerTest, and Waifu2x requires either Caffe or CPP."
    $Text += "{0}{0}"
    $Text += "The resulting filtered texture dimensions can not exceed 32768x32768, which is insanely large and I do not suggest trying to create "
    $Text += "textures this big (I don't even know if it will work). If the max is exceeded, the script will automatically lower the Upscale Factor "
    $Text += "by 1 for the current texture and try again. It will keep trying to find a lower value until it reaches 2, where it will then give up "
    $Text += "if 2x still yields dimensions above 32768x32768. This means the lowest resolution a texture can have is 16384x16384 if any filter "
    $Text += "is going to be applied."
    $Text += "{0}{0}"
    $Text += "One great feature that this script has is the 'Seamless Method'. This tiles a texture 9 times in a 3x3 grid, crops 75% "
    $Text += "percent of the outer 8 tiles, applies the upscaling filter, and then crops whatever remains of the outer 8 tiles. This "
    $Text += "gives the upscaling filter neighboring pixels around the texture edges to work with so the resulting texture does not "
    $Text += "have visible seams when tiled in-game. This is obviously only useful for seamless textures, and it adds processing time, "
    $Text += "so when to apply this method and how much of the outer tiles are cropped before processing is configurable."
    $Text += "{0}{0}"
    $Text += "It should be noted that the Seamless Method does not break non-seamless textures. By default the method is set to 'Opaque' "
    $Text += "which means the Seamless Method is only applied to textures that don't have transparent pixels. The vast majority of seamless "
    $Text += "textures are used in game environments such as floors, walls, and skies. But this is not always true, so the option 'All' is "
    $Text += "available to force the Seamless Method on all textures even if they contain transparent pixels. It's also possible to disable "
    $Text += "the Seamless Method altogether if you are absolutely sure the textures you are upscaling are not seamless."
    $Text += "{0}{0}"
    $Text += "Waifu2x is unique in that it provides additional options. 'Conversion Mode' controls whether the texture is upscaled, denoised, "
    $Text += "or both. When 'Scale' is not present, the Upscale Factor is ignored. 'Noise Reduction' controls the amount of, umm, noise reduction. "
    $Text += "When using Waifu2x-Caffe, the maximum value is 3, but with Waifu2x-CPP, the maximum value is 2. 'Disable GPU' uses the host CPU "
    $Text += "rather than the GPU. This can be useful if the user wants to use Caffe with an AMD card, because Caffe only supports nvidia CUDA. "
    $Text += "Waifu2x-CPP offers the additional option 'Enable OpenCL' which allows AMD users to use the GPU, which is still not nearly as fast "
    $Text += "as CUDA, but is still much faster than using the CPU. "
    $Text += "{0}{0}"
    $Text += "Depending on your CPU, using 'Disable GPU' can be SLOW. Case in point, if your GPU is made by nvidia, use Waifu2x-Caffe. If your GPU "
    $Text += "is made by AMD, use Waifu2x-CPP and check 'Enable OpenCL'. The only time Disable GPU is useful is when using Caffe with an AMD card because "
    $Text += "Waifu2x-CPP is just not as developed as CPP. Don't get me wrong, CPP is great in 99% of cases, but it has the potential to ignore the "
    $Text += "texture's transparency and output it as black. This is 100% guaranteed when working on grayscale images, which has been fixed in Caffe."
    $Text += "{0}{0}"
    $Text += "Textures generated with this option are output to a FilteredTextures folder followed by the chosen filter.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Apply Upscaling Filter to All Textures")
    $HelpDescription.SelectionFont = $FontSize13
    $HelpDescription.Find("FilteredTextures")
    $HelpDescription.SelectionFont = $FontSize10
  }
  elseif ($SelectedNode -eq 'TreeNode: Advanced Options')
  {
    $Text = "Advanced Options"
    $Text += "{0}{0}"
    $Text += "Most advanced options modify the texture pack directly, so caution should be used when using them. It is highly suggested to "
    $Text += "create a backup of your texture pack before using these options in case you do not get the desired effect! "
    $Text += "{0}{0}"
    $Text += "The options 'Combine Multiple Textures' and 'Split Combined Multi-Texture' are the exception to the rule as they output "
    $Text += "generated textures to the selected 'Output Path'.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Advanced Options")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: Generate New MipMaps')
  {
    $Text = "Generate New MipMaps"
    $Text += "{0}{0}"
    $Text += "This option generates new mipmaps within the texture pack itself. Dynamic mipmaps are preserved unless 'Force New Mipmaps' is "
    $Text += "ticked on the options menu. Care must be taken with this option as textures with incorrect dimensions will be created with incorrect mipmaps. If in "
    $Text += "doubt, use 'Scan Dolphin Textures For Issues' and check 'Auto-Repair' to generate mipmaps for textures that are missing them. The new textures with "
    $Text += 'generated mipmaps can then be found in the "RepairedTextures" folder, and can be merged into the main pack. Alternatively, converting packs or rescaling '
    $Text += "them will automatically generate mipmaps for all textures in the resulting pack."
    $Text += "{0}{0}"
    $Text += "This option is only useful as a shortcut to creating new mipmaps when it is certain all textures have the correct dimensions.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Generate New MipMaps")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: Remove Invalid MipMaps')
  {
    $Text = "Remove Invalid MipMaps"
    $Text += "{0}{0}"
    $Text += "Scans a texture pack for textures that contain external mipmap levels that are not actually a mipmap [m] texture and deletes them. "
    $Text += "This option can also detect invalid internal mipmaps that are stored within DDS textures and remove those as well."
    $Text += "{0}{0}"
    $Text += "Example: tex1_32x32_d0f9034aa0ff4873_14 is not a MipMap texture, but contains external MipMap levels..."
    $Text += "{0}{0}"
    $Text += "tex1_32x32_d0f9034aa0ff4873_14_mip1{0}"
    $Text += "tex1_32x32_d0f9034aa0ff4873_14_mip2{0}"
    $Text += "tex1_32x32_d0f9034aa0ff4873_14_mip3"
    $Text += "{0}{0}"
    $Text += "Because this is not a MipMap texture, these MipMap levels will be removed. If it were a mipmap texture, the name would contain "
    $Text += "an [m], as in the example:"
    $Text += "{0}{0}"
    $Text += "tex1_32x32_m_d0f9034aa0ff4873_14{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Remove Invalid MipMaps")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: Extract DDS Internal MipMaps')
  {
    $Text = "Extract DDS Internal MipMaps"
    $Text += "{0}{0}"
    $Text += "Finds internal DDS mipmap textures and extracts their mipmaps into the texture pack. There really isn't much more to it than that. "
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Extract DDS Internal MipMaps")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: Remove Alpha Channel From Opaque Textures')
  {
    $Text = "Remove Alpha Channel From Opaque Textures"
    $Text += "{0}{0}"
    $Text += "Occasionally texture artists will create a fully opaque texture but mistakenly include an alpha channel. This adds "
    $Text += "unnecessary file size to the texture because an alpha channel is not required if there are no transparent pixels. "
    $Text += "This option will strip the alpha channel from the texture if there are no transparent pixels, reducing file size."
    $Text += "{0}{0}"
    $Text += "While this option works on both PNG and DDS textures, it is probably most useful on PNG textures. When using this "
    $Text += "script to convert to DDS using any option, the resulting texture already has its alpha channel removed if does not "
    $Text += "contain any transparent pixels.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Remove Alpha Channel From Opaque Textures")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: Combine Multiple Textures')
  {
    $Text = "Combine Multiple Textures"
    $Text += "{0}{0}"
    $Text += "Allows combining multiple textures into a single texture. This option is useful if the game has backgrounds or other "
    $Text += "types of textures that are composed of multiple textures in a grid. The grid in this option is defined by the number "
    $Text += "of rows and columns that are entered, so the total number of textures can be calculated by multiplying the number of "
    $Text += "rows * columns."
    $Text += "{0}{0}"
    $Text += "Using this option to combine textures will also generate a (.ctt) file along with the texture that can be used in the "
    $Text += "option below this one to resplit the texture and rename each individual texture back to their original names, even if "
    $Text += "it was retextured with different dimensions.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Combine Multiple Textures")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: Split Combined Multi-Texture')
  {
    $Text = "Split Combined Multi-Texture"
    $Text += "{0}{0}"
    $Text += "This option can split large multi-textures into multiple smaller textures. The number of images created is determined "
    $Text += "by the number of rows and columns entered, and the dimensions are also calculated from these values. Width is calculated "
    $Text += "by dividing the texture's width by the number of columns, and height is calculated from dividing the textures height "
    $Text += "by the number of rows."
    $Text += "{0}{0}"
    $Text += "Each new texture that is created from the chosen texture will be named from that texture unless a (.ctt) file generated "
    $Text += "from 'Combine Multiple Textures' is selected. Do note that a (.ctt) file is not necessary to split textures.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Split Combined Multi-Texture")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: Basic Image Viewer')
  {
    $Text = "Basic Image Viewer"
    $Text += "{0}{0}"
    $Text += "A simple image viewer which allows viewing various image formats, although there is very little use for this outside of uncompressed "
    $Text += "and BC7 DDS textures. This viewer is very slow when decoding images because the script does not have a built-in method to decode DDS "
    $Text += "files. Instead, the image and all mipmaps are converted to PNG, which is then displayed in the viewer. This is highly "
    $Text += "inefficient, but it's the best I can do. Hopefully better support for viewing DDS images eventually surfaces."
    $Text += "{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Basic Image Viewer")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: Options Menu')
  {
    $Text = "Options Menu"
    $Text += "{0}{0}"
    $Text += "The options panel can be opened simply by pressing the 'Options' button found on the main window. Options are broken into "
    $Text += "three categories: Texture Options, MipMap Options, and Preferences. Paths to external tools can also be configured here "
    $Text += "by pressing the 'Configure Paths' button."
    $Text += "{0}{0}"
    $Text += "When the script is closed, all changes that were made to any options are stored within the CTT-PS (.ps1) file itself. "
    $Text += "In short, the script will update itself with the new values. Because there is no external database file containing these "
    $Text += "settings, it is possible to import these stored options from another version of CTT-PS using the 'Import Stored Options' "
    $Text += "feature. This exists so any personal tweaks can be saved from previous versions of the script and not have to be set "
    $Text += "all over again."
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Options Menu")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: Texture Options')
  {
    $Text = "Texture Options"
    $Text += "{0}{0}"
    $Text += "These options affect the way textures are generated when performing almost any operation. More on each individual option can "
    $Text += "be found in their respective help topics below."
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Texture Options")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: Allow All Images')
  {
    $Text = "Allow All Images"
    $Text += "{0}{0}"
    $Text += "When CTT-PS finds an image, it verifies that the discovered image is a Dolphin texture by looking for the 'tex1' prefix "
    $Text += "within the texture's name. This allows a way for the script to separate Dolphin textures from all other image files. "
    $Text += "{0}{0}"
    $Text += "This is important because the pack may contain preview screenshots that the user wishes to copy into the new pack using "
    $Text += "the 'Copy Non-Textures' option when converting or rescaling textures. It's also important to know which images are Dolphin "
    $Text += "textures so that the original dimensions can be retrieved, and it can be identified whether or not it is a mipmap texture."
    $Text += "{0}{0}"
    $Text += "Enabling this option allows all images to bypass the script's verification process whether it contains 'tex1' or not. Dolphin "
    $Text += "textures are still identified as Dolphin textures, but non-Dolphin images will now be able to be processed by almost all Standard "
    $Text += "Options. Scanning these textures will not work because non-Dolphin images will always pass all checks and fail the NotHD check "
    $Text += "because the 'original' dimensions are faked by setting them to the 'current' dimensions."
    $Text += "{0}{0}"
    $Text += "Enabling this option works well enough that the script can be used for just about any texture project whether it be for "
    $Text += "Dolphin or someone's favorite PC game. Textures can be converted to other formats, optimized with OptiPNG, watermarks can "
    $Text += "be generated, and the various upscaling filters can be applied.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Allow All Images")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: Force Create MipMaps')
  {
    $Text = "Force Create MipMaps"
    $Text += "{0}{0}"
    $Text += "This option is disabled unless 'Allow All Images' is enabled. This allows creating internal DDS mipmaps for textures that "
    $Text += 'are not Dolphin textures (images without the "tex1" prefix). It exists so this tool can work with other texture projects '
    $Text += "outside of Dolphin texture modding, such as creating a texture pack PC games."
    $Text += "{0}{0}"
    $Text += "Almost all DDS creation software supplies this option, wich made this tool a poor choice (until now) for creating DDS textures"
    $Text += "outside of Dolphin texture packs. Before this option it was not possible to generate mipmaps for non-Dolphin textures.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Force Create MipMaps")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: DDS Creation Tool')
  {
    $Text = "DDS Creation Tool"
    $Text += "{0}{0}"
    $Text += "Allows selecting which program to use when creating DDS textures. A program will not show up on the list until the path to the "
    $Text += 'program is set. This can be accomplished by selecting "Add Tool..." and locating a '
    $Text += "program's (exe) file, or by adding the path in "
    $Text += "the Options menu by clicking the Configure Paths button and setting the tool's path."
    $Text += "{0}{0}"
    $Text += "Microsoft TexConv: Creates the lowest quality textures but is much faster than the others.{0}"
    $Text += "Compressonator: Creates the highest quality DXT1, DXT5, and BC7 textures.{0}"
    $Text += "DDS Utilities: Creates nice quality DXT1 and DXT5 textures, higher quality than TexConv.{0}"
    $Text += "ImageMagick: Creates the lowest quality textures, never reccommended (but it works)."
    $Text += "{0}{0}"
    $Text += "If confused on which program to use, I suggest all of them. If a program fails to create a texture, it will fall back to another one and continue to do so until the image is created."
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("DDS Creation Tool")
    $HelpDescription.SelectionFont = $FontSize13
    $HelpDescription.Find("DDS Utilities:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Compressonator:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Microsoft TexConv:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("ImageMagick:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Configure Paths")
    $HelpDescription.SelectionFont = $FontSize10
  }
  elseif ($SelectedNode -eq 'TreeNode: DDS Compression')
  {
    $Text = "DDS Compression"
    $Text += "{0}{0}"
    $Text += 'This option tells the script which type of block compression to use when creating DDS texures. For more DDS information, reference the section:{0}'
    $Text += 'Main Window \ Standard Options \ Convert Textures to Another Format. '
    $Text += "{0}{0}"
    $Text += "When using DXT1/DXT5, opaque images are created with DXT1, and images with transparency are created with DXT5. DXT1 is not very good "
    $Text += "at handling alpha channels (it only supports 1-bit alpha), but the quality is usually good enough for opaque images. DXT1 consumes half the resources "
    $Text += "that DXT5 does, including disk space and VRAM. DXT5 has slightly higher quality, and has full alpha support, so it is chosen for images with transparency."
    $Text += "{0}{0}"
    $Text += "The DXT5 option forces all textures to use DXT5 compression, even if the image does not have transparency. DXT5 textures are twice the size "
    $Text += "of DXT1 textures and consume twice as much VRAM, but can also provide slightly higher quality depending on the tool used."
    $Text += "{0}{0}"
    $Text += "BC7 compression yields much higher quality than DXT5, while consuming the same amount of resources, and can only be created with TexConv or "
    $Text += "Compressonator. BC7 requires D3D11 and/or OpenGL4 compatible GPUs. This includes the Nvidia GTX 400 series and newer, Intel 7th generation "
    $Text += "graphics and newer (depending on drivers), and AMD Radeon HD 5000 series and newer. Anything older and BC7 textures will fail to load in Dolphin."
    $Text += "{0}{0}"
    $Text += "ARGB32 is an uncompressed format and has the highest possible quality, but takes 4x the amount of resources. This includes "
    $Text += "requiring 4x as much disc space, as well as consuming 4x as much VRAM. It is not suggested to create very large packs using only uncompressed "
    $Text += "textures. They should only be created for smaller textures where detail is crucial such as UI textures. Uncompressed textures do not have the same "
    $Text += "limitations as BC7. They have existed since the D3D9 era, so they should work on any computer system that can actually run Dolphin."
    $Text += "{0}{0}"
    $Text += "Last is the User Defined option. This allows setting a flag in the texture name, or the path to the texture to force the compression type. Assigning "
    $Text += "a flag to a folder full of textures will compress all textures in that folder with the type of compression that the flag references. This is the list of "
    $Text += "available flags: "
    $Text += "{0}{0}"
    $Text += "_DXTC (or _DXTN): Works exactly like the DXT1/DXT5 option.{0}"
    $Text += "_DXT5 (or _BC3): Creates textures using DXT5 compression.{0}"
    $Text += "_BC7: Creates textures using BC7 compression.{0}"
    $Text += "_ARGB32: Creates uncompressed DDS textures."
    $Text += "{0}{0}"
    $Text += "Example: Convert all images in the path to BC7.{0}" 
    $Text += "C:\Textures\Environment_BC7\{0}"
    $Text += "C:\Textures\_BC7\Environment\{0}"
    $Text += "C:\Textures\Environ_BC7ment\"
    $Text += "{0}{0}"
    $Text += "Example: Convert specific image to DXT5.{0}" 
    $Text += "C:\Textures\Environment\tex1_256x256_892a399244b8359e_2_BC3.png{0}"
    $Text += "C:\Textures\Environment\tex1_256x256_892a399244b8359e_2_DXT5.png"
    $Text += "{0}{0}"
    $Text += "It is important to note that the flag must have an underscore before it, or the script will not find it. If a flag is not found in the texture's path, "
    $Text += "the fallback compression type set will be used instead. Again, the flag can be present in either the texture name, or the path to the texture.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("DDS Compression")
    $HelpDescription.SelectionFont = $FontSize13
    $HelpDescription.Find("Main Window \ Standard Options \ Convert Textures to Another Format")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("DXT1/DXT5")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("DXT5 option")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("BC7 compression")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("ARGB32")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("User Defined")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("_DXTC")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("_DXTN")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("_DXT5")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("_BC3")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("_BC7")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("_ARGB32")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Example: Convert all images in the path to BC7.")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Example: Convert specific image to DXT5.")
    $HelpDescription.SelectionFont = $FontSize10
  }
  elseif ($SelectedNode -eq 'TreeNode: Flag Removal')
  {
    $Text = "Flag Removal"
    $Text += "{0}{0}"
    $Text += "See the DDS Compression section above for more information about flags."
    $Text += "{0}{0}"
    $Text += "Flags can now be automatically removed from all folders and textures with the Flag Removal setting. Flags are removed immediately from a texture after they "
    $Text += "are converted. They are not removed from folder names until all textures have been converted."
    $Text += "{0}{0}"
    $Text += "There are three different settings for Flag Removal:"
    $Text += "{0}{0}"
    $Text += "New & Base - Removes user defined flags from both the base pack and the generated pack. Flags set by the user are a one off, meaning after converting, they are gone forever.{0}"
    $Text += "New Pack - Only removes flags from the generated pack. The base pack will keep the flags for a future run. This can be useful for making multiple packs or updating frequently.{0}"
    $Text += "None - Keep the flags in both packs, even the generated pack. I really do not suggest using this option at all."
    $Text += "{0}{0}"
    $Text += "Not the best choice for names, but I'm seriously running out of space on the UI and I really don't feel like making any big adjustments.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Flag Removal")
    $HelpDescription.SelectionFont = $FontSize13
    $HelpDescription.Find("DDS Compression")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("New & Base - ")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("New Pack - ")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("None - ")
    $HelpDescription.SelectionFont = $FontSize10 
  }
  elseif ($SelectedNode -eq 'TreeNode: DDS Fallback')
  {
    $Text = "DDS Fallback"
    $Text += "{0}{0}"
    $Text += "This option works just like DDS Compression, and is only used when set to User Defined. There really isn't much to explain about this one. If a texture path "
    $Text += "does not contain any flags, this is the type of compresion the texture will be created with."
    $Text += "{0}{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("DDS Fallback")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: MipMap Options')
  {
    $Text = "MipMap Options"
    $Text += "{0}{0}"
    $Text += "These options control the output of mipmaps when performing any operation on Dolphin textures. They do not affect generating mipmaps "
    $Text += 'for DDS images that pass validation when using "Allow All Images". To generate mipmaps for non-Dolphin textures, enable the option '
    $Text += 'Force Create MipMaps that are found above the MipMap Options within the Texture Options.'
    $Text += "{0}{0}"
    $Text += "Mipmap textures from Dolphin can be identified by their name, a flag with the letter 'm' will be present following the dimensions. "
    $Text += "{0}{0}"
    $Text += "Example: tex1_32x32_m_692d3f5c7b601717_14.png."
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("MipMap Options")
    $HelpDescription.SelectionFont = $FontSize13
    $HelpDescription.Find("Force Create MipMaps")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Example:")
    $HelpDescription.SelectionFont = $FontSize10
  }
  elseif ($SelectedNode -eq 'TreeNode: Force New MipMaps')
  {
    $Text = "Force New MipMaps"
    $Text += "{0}{0}"
    $Text += "Whenever mipmaps are generated, the script will attempt to use mipmaps that are provided with the texture pack as a base to "
    $Text += 'generate the new mipmaps from. This allows users to provide their own custom mipmaps to create "dynamic mipmaps", which means '
    $Text += 'using different images on descending layers. Dynamic mipmaps can provide effects that are not attainable through a single texture. '
    $Text += '{0}{0}'
    $Text += 'This option can override this functionality and force generating new mipmaps from the top mipmap layer (the base texture). This '
    $Text += 'can actually result in higher quality mipmaps since all mipmaps are regenerated from the largest possible image, but dynamic '
    $Text += "mipmaps will be lost in the process. Few packs use dynamic mipmaps, as of now only the Xenoblade Chronicles pack and hypatia's "
    $Text += "The Legend of Zelda: The Wind Waker pack make use of them."
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Force New MipMaps")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: Create From Top Level')
  {
    $Text = "Create From Top Level"
    $Text += "{0}{0}"
    $Text += "Starting with v23.0 of this script, when lower mipmap levels are created, but the pack does not provide these mipmaps, the script "
    $Text += "will attempt to use the lowest mipmap level provided as a base to generate the missing mipmaps. For example, a newly generated texture "
    $Text += "requires 10 mipmap levels, but the pack only provides levels 1-5. The script will use level 5 as a base to generate levels 6-10. This "
    $Text += "ensures that the last levels keep the visual continuity of the mipmap chain."
    $Text += "{0}{0}"
    $Text += "This option instead forces using the top level (base texture) to generate missing mipmap levels. Using the example above, mipmap levels "
    $Text += "1-5 will be generated from the mipmaps provided with the pack, but levels 6-10 will be generated from the top level. This should only be "
    $Text += "used in special case scenarios, as it can break the intended effect provided by dynamic mipmaps. "
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Create From Top Level")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: External DDS MipMaps')
  {
    $Text = "External DDS MipMaps"
    $Text += "{0}{0}"
    $Text += "When DDS mipmap textures are created, this option creates them externally from the texture. Dolphin supports both external mipmaps "
    $Text += "and internal mipmaps. External mipmaps each have their own texture file, with the suffix '_mip#' (# = level) in their name. Internal mipmaps "
    $Text += "are built into the base texture, and are only supported by the DDS format."
    $Text += "{0}{0}"
    $Text += "Starting with Dolphin v5.0-3506, support has been added for DDS internal mipamps. Ishiiruka has also supported them for some time now. It is "
    $Text += "suggested to create DDS textures with internal mipmaps from this point on, although external is still provided for preference."
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("External DDS MipMaps")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: Max MipMap Levels')
  {
    $Text = "Max MipMap Levels"
    $Text += "{0}{0}"
    $Text += "Forces the number of mipmap levels generated when creating textures. This option affects all output formats (PNG, DDS, JPG). By default, mipmaps "
    $Text += "will be generated down to 1x1 dimensions, but this option can override that behavior and limit the number of levels to the value entered. For "
    $Text += "example, if a value of '2' is set, then a 1024x1024 texture will only have two mipmaps generated: one at 512x512, and another at 256x256."
    $Text += "{0}{0}"
    $Text += "This option should NOT be used in most cases. It exists to limit the number of mipmaps for textures where you only want so many levels available "
    $Text += "for complete control over the texture's distance from the camera. This is a very rare case where too many mipmap levels can actually be a decrease "
    $Text += "in perceivable quality."
    $Text += "{0}{0}"
    $Text += "It should be noted that Compressonator has a bug that does not allow generating a single internal DDS mipmap. So setting the max level to 1 and "
    $Text += "generating a DDS texture will not create the texture with a single internal mipmap. This can be worked around in two ways: supply a single custom "
    $Text += "mipmap (texturename_mip1) with the texture (or multiple mipmaps), or use another program such as TexConv or DDS Utilities."
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Max MipMap Levels")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: Preferences')
  {
    $Text = "Preferences"
    $Text += "{0}{0}"
    $Text += "These options configure aspects of Custom Texture Tool PS, PowerShell, and the GUI. They do not affect texture generation in any way. Most of "
    $Text += "the options explain themselves, and they have tooltips that goes into more details, so they won't be explained much in this help document."
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Preferences")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: Create a log file of all textures processed')
  {
    $Text = "Create a log file of all textures processed"
    $Text += "{0}{0}"
    $Text += "This option does exactly what it says. It's not suggested to disable the log file when running the 'Scan Dolphin Textures For Issues' "
    $Text += "option as it relies on the log file to create a list of issues. The issues that are found will still be printed to the PowerShell "
    $Text += "console, but the console is not nearly as organized, nor is it a permanent list that can be referenced.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Create a log file of all textures processed")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: Allow opening PowerShell scripts with a double click')
  {
    $Text = "Allow opening PowerShell scripts with a double click"
    $Text += "{0}{0}"
    $Text += "Allows opening PowerShell scripts with a double click rather than having to right click it and selecting the 'Run with "
    $Text += "Powershell' option. Toggling this option makes a small change to the Windows registry value that controls how PowerShell "
    $Text += "scripts are launched. This option is 100% safe to use."
    $Text += "{0}{0}"
    $Text += "When the GUI is created when the script is launched, the value in the registry that controls how PowerShell scripts "
    $Text += "are executed is checked, and the GUI checkbox is created with the value's current state. When the checkbox is toggled, the "
    $Text += "registry state is checked once again. Depending on the state, a small registry script is generated into the TempFolder and is "
    $Text += "executed in 'Silent' mode so it does not interfere with the user. This generated script simply reverses the current state of "
    $Text += "the registry setting and is then removed from the TempFolder.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Allow opening PowerShell scripts with a double click")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: Save any changes made to all options on exit')
  {
    $Text = "Save any changes made to all options on exit"
    $Text += "{0}{0}"
    $Text += "When the script is closed, any options that were changed are saved to the script file itself. This feature can be disabled "
    $Text += "by unchecking this option so that changes are forgotten between runs.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Save any changes made to all options on exit")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: Disable forcing the GUI as the top-most window')
  {
    $Text = "Disable forcing the GUI as the top-most window"
    $Text += "{0}{0}"
    $Text += "This option determines whether or not CTT-PS GUI will stay over top of other windows even while it is not the active window.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Disable forcing the GUI as the top-most window")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: Always show the PowerShell console window')
  {
    $Text = "Always show the PowerShell console window"
    $Text += "{0}{0}"
    $Text += "Pretty self explanatory. When enabled, the PowerShell console is always visible. This is useful when running any option because "
    $Text += "the information from the last loop will remain visible until another option is ran or the script is closed. When disabled, it "
    $Text += "will hide the PowerShell console window while the GUI is visible, and only display it when a loop is in progress."
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Always show the PowerShell console window")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: Auto-center the PowerShell console on launch')
  {
    $Text = "Auto-center the PowerShell console on launch"
    $Text += "{0}{0}"
    $Text += "When the script is launched, it will attempt to force the PowerShell console to the center of the primary monitor. This is done "
    $Text += "by getting the pixel resolution of the screen, which is then divided in half to find the absolute center. This method will only "
    $Text += "work on PowerShell v3 and up. Windows 7 ships with PowerShell v2, so users with Windows 7 will have to manually update PowerShell "
    $Text += "to have this feature. There is no guarantee that the method used to set the position won't randomly break on some computers, so "
    $Text += "the option exists to disable it. "
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Auto-center the PowerShell console on launch")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: Disable the PowerShell console "X" Button')
  {
    $Text = 'Disable the PowerShell console "X" Button'
    $Text += "{0}{0}"
    $Text += ""
    $Text += "When the script is closed using the [x] button on the PowerShell console, the script will fail to update itself, and any changes "
    $Text += "that were made to any options are lost. This button is disabled by default to prevent this from happening, but if this effect is "
    $Text += "desired for some reason, it's possible to re-enable it by unchecking this option. "
    $Text += "{0}{0}"
    $Text += "Closing the script through all other conventional means will update all options properly. This includes using the GUI [x] button, "
    $Text += "the 'Exit' button, pressing the Alt+F4 combination, or pressing the Control+C combination while a loop is running. "
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find('Disable the PowerShell console "X" Button')
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: Enable additional PowerShell console colors')
  {
    $Text = "Enable additional PowerShell console colors"
    $Text += "{0}{0}"
    $Text += "Enables additional colors on the Powershell console when processing textures. The additional colors should help differentiate "
    $Text += "message headers from relevant output. If users don't like colors, this can be disabled."
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Enable additional PowerShell console colors")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: PowerShell Console Background Color')
  {
    $Text = "PowerShell Console Background Color"
    $Text += "{0}{0}"
    $Text += "Releases a deadly virus into the world that will transform most of the human race into brainless flesh-eating zombies, resulting "
    $Text += "in the beginning of the apocalypse. Err... wait, that option isn't exposed on the GUI. Anyway, this option changes the background "
    $Text += "color of the PowerShell console. PowerShell does not offer too many colors to choose from, but at least now it doesn't have to be "
    $Text += "dark magenta. It may be desired to disable 'additional PowerShell console colors' when using some background colors. "
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("PowerShell Console Background Color")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: Configure Paths')
  {
    $Text = "Configure Paths"
    $Text += "{0}{0}"
    $Text += "Pretty self-explanatory, these are the paths to the programs that this script requires. When configuring a path, "
    $Text += "the executable file must be selected to set the new location to the tool. It is also possible to paste the path to the "
    $Text += "executable in the text box, paste the path to the folder containing the executable, drag and drop the executable file "
    $Text += "onto the text box, or drag and drop the containing folder. When configuring the Waifu2x path from the GUI, a dropdown "
    $Text += "menu is available to select between the Caffe and CPP executables."
    $Text += "{0}{0}"
    $Text += "The exception to all of this is the 'Temp Folder'. This location is where CTT-PS will generate temporary textures. By "
    $Text += "default, this path is set to the user's 'AppData\Local\Temp' folder. It is possible some users may have trouble creating "
    $Text += "files here which is why the path is configurable. When the script is launched, this path is tested to see if it can be "
    $Text += "written to, and if it fails, CTT-PS will instead use the root of user's (C:\) drive."
    $Text += "{0}{0}"
    $Text += "No matter where the TempFolder is set to, it will go one directory deeper with a folder named 'CTT-PS_Temp'. This is to "
    $Text += "prevent destroying all files that are contained within this folder because CTT-PS completely wipes this folder out when "
    $Text += "it is done with it. I learned this the hard way in earlier versions of this script.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Configure Paths")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: Restore Defaults')
  {
    $Text = "Restore Defaults"
    $Text += "{0}{0}"
    $Text += "When CTT-PS is closed, the script file (.ps1) is updated to permanently store any options that were changed by the user. "
    $Text += "This option will reset the values of all options to their default values. It should be noted that this option does not "
    $Text += "reset any paths to external tools."
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Restore Defaults")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: Import Stored Options')
  {
    $Text = "Import Stored Options"
    $Text += "{0}{0}"
    $Text += "This option allows importing Stored Options from a previous version of Custom Texture Tool PS by simply selecting the script "
    $Text += "(.ps1) file. It should work on any version of the PowerShell versions of the script. This feature exists to retain option "
    $Text += "settings in future versions of this script, and not have to reset them every single time."
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Import Stored Options")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: Guides')
  {
    $Text = "Guides"
    $Text += "{0}{0}"
    $Text += "Okay I get it. This tool has way too many options for something as simple as creating images right? Well I can agree that "
    $Text += "maybe I went over the top in some cases, but I feel like every option included is necessary to personally tweak a texture "
    $Text += "pack to get the best possible results. And to be honest, this tool is still very limited, there is no replacing an artist's "
    $Text += "personal touch. There is only so much that can be done to automate the creation of art. "
    $Text += "{0}{0}"
    $Text += "These guides are aimed at some of the more general operations that most users will seek this tool for, such as creating DDS "
    $Text += "textures, rescaling textures, or creating material maps. Some guides may read more like a tutorial, while others are just a "
    $Text += "general information section. Hopefully the guides can help where the rest of this already bloated help section fails to.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Guides")
    $HelpDescription.SelectionFont = $FontSize13
  }
  elseif ($SelectedNode -eq 'TreeNode: Creating DDS Packs')
  {
    $Text = "Creating DDS Packs"
    $Text += "{0}{0}"
    $Text += "Because there is no way to create a tool to work perfectly with all Dolphin texture packs by default, there are a number "
    $Text += "of options available to tweak and try to get the best results. There are several programs that can generate DDS files from "
    $Text += "PNG/JPG files, but they do not offer enough options to fit all edge cases of Dolphin textures. This guide offers step-by-step "
    $Text += "instructions of how to convert a PNG/JPG pack to DDS. I can only assume ImageMagick and a DDS generating program is installed."
    $Text += "{0}{0}"
    $Text += "(1:) Set the 'Texture Path' field to the texture pack root folder.{0}"
    $Text += "(2:) (Optional) Set the 'Output Path' to wherever you want to create textures.{0}"
    $Text += "(3:) Choose the Standard Option 'Convert Textures to Another Format'.{0}"
    $Text += "(4:) Set the 'Output Format' to DDS.{0}"
    $Text += "(5:) Enter the first 3 digits of the GameID into the 'Auto-Rename Output' field.{0}"
    $Text += "(6:) Press the Start button to start converting.{0}"
    $Text += "(7:) Wait for the script to finish converting textures. This can take some time!{0}"
    $Text += "(8:) Find the new pack in the '~CTT_Generated' folder.{0}"
    $Text += "(9:) If this pack exists in 'C:\User\Documents\Dolphin Emulator\Load\Textures' then remove it and move in the newly "
    $Text += "generated/renamed pack."
    $Text += "{0}{0}"
    $Text += "DDS textures can be created with DXT1/DXT5, DXT5, or BC7 block compression. This can be configured in the Options menu under "
    $Text += "'Texture Options'. Going forward, it is highly suggested to use BC7 as it offers the highest quality. Creating and working with "
    $Text += "BC7 textures require a valid path set to TexConv in the 'Configure Paths' menu which is found on the Options menu."
    $Text += "{0}{0}"
    $Text += "Notice: Material map exists, but path to Ishiiruka Tool not found! {0}"
    $Text += "This means the texture pack was designed for Dolphin Ishiiruka, and requires Ishiiruka Tool to convert these textures. "
    $Text += "See the 'Quick Guide' help topic for a link and how to locate it within the script. Also see the 'Material Map Format' "
    $Text += "sub-section within the 'Global Options' section for more info. For example the Legend of Zelda: Twilight Princess 4K "
    $Text += "pack contains material map textures."
    $Text += "{0}{0}"
    $Text += "And what about this 'Auto-Repair Dimensions' option? {0}"
    $Text += "This is actually a very useful feature, and I would love to enable it by default but it has the potential to break some "
    $Text += "texture packs. In almost all cases, this option 'should' be enabled. This option can correct common mistakes made by texture "
    $Text += "artists such as not creating textures with an integer scale, or textures having slightly bad aspect ratios. It can break some "
    $Text += "texture packs if the custom textures are not much larger than the original textures, or if the aspect ratios are purposely "
    $Text += "distorted to achieve some effect. An example is the Tales of Symphonia pack.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Creating DDS Packs")
    $HelpDescription.SelectionFont = $FontSize13
    $HelpDescription.Find("Notice: Material map exists, but path to Ishiiruka Tool not found!")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Should I use the 'Force New MipMaps' option?")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("And what about this 'Auto-Repair Dimensions' option?")
    $HelpDescription.SelectionFont = $FontSize10
  }
  elseif ($SelectedNode -eq 'TreeNode: Rescaling Packs')
  {
    $Text = "Rescaling Packs"
    $Text += "{0}{0}"
    $Text += "This guide covers how to rescale all textures within a texture pack. In most cases, the purpose of doing this is to downscale "
    $Text += "a texture pack that contains very large textures, and the user's system struggles to keep solid frame rates or experiences a "
    $Text += "significant amount of 'stutter'. This option takes a 'Rescale Factor' which is then multiplied by the texture's original dimensions "
    $Text += "to calculate the new dimensions."
    $Text += "{0}{0}"
    $Text += "(1:) Set the 'Texture Path' field to the texture pack root folder.{0}"
    $Text += "(2:) (Optional) Set the 'Output Path' to wherever you want to create textures.{0}"
    $Text += "(3:) Choose the option 'Rescale Textures With New Scaling Factor'.{0}"
    $Text += "(4:) Set the 'Rescale Factor'. A value of 4 is fine for 1080p.{0}"
    $Text += "(5:) Set the 'Output Format' to DDS.{0}"
    $Text += "(6:) Set 'Rescale Condition' to Downscale so small textures are not upscaled.{0}"
    $Text += "(7:) Enter the first 3 digits of the GameID into the 'Auto-Rename Output' field.{0}"
    $Text += "(8:) Press the Start button to start rescaling.{0}"
    $Text += "(9:) Wait for the script to finish rescaling textures. This can take some time!"
    $Text += "(10:) Find the new pack in the '~CTT_Generated' folder.{0}"
    $Text += "(11:) If this pack exists in 'C:\User\Documents\Dolphin Emulator\Load\Textures' then remove it and move in the newly "
    $Text += "generated/renamed pack."
    $Text += "{0}{0}"
    $Text += "DDS textures can be created with DXT1/DXT5, DXT5, or BC7 block compression. This can be configured in the Options menu under "
    $Text += "'Texture Options'. Going forward, it is highly suggested to use BC7 as it offers the highest quality."
    $Text += "{0}{0}"
    $Text += "Notice: Material map exists, but path to Ishiiruka Tool not found! {0}"
    $Text += "This means the texture pack was designed for Dolphin Ishiiruka, and requires Ishiiruka Tool to convert these textures. "
    $Text += "See the 'Quick Guide' help topic for a link and how to locate it within the script. Also see the 'Material Map Format' "
    $Text += "sub-section within the 'Global Options' section for more info. For example the Legend of Zelda: Twilight Princess 4K "
    $Text += "pack contains material map textures."
    $Text += "{0}{0}"
    $Text += "What is this 'Manual Rescale' option? {0}"
    $Text += "For most users, this option has little to no use, and is geared towards texture artists. This allows rescaling a folder "
    $Text += "full of textures one by one, setting the 'Rescale Factor' individually for each texture. There may be very little value "
    $Text += "in this option, I myself have only found a use for it twice when working on the Xenoblade Chronicles texture pack when "
    $Text += "modifying BrunoFBK's textures and when working on some of my own textures.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Rescaling Packs")
    $HelpDescription.SelectionFont = $FontSize13
    $HelpDescription.Find("Notice: Material map exists, but path to Ishiiruka Tool not found!")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Should I use the 'Force New MipMaps' option?")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("What is this 'Manual Rescale' option?")
    $HelpDescription.SelectionFont = $FontSize10
  }
  elseif ($SelectedNode -eq 'TreeNode: MipMap Tutorial')
  {
    $Text = "MipMap Tutorial"
    $Text += "{0}{0}"
    $Text += "Mipmap textures are a collection of images that in most cases, represent the same image at a progressively lower resolution. It may be easier to "
    $Text += "view them as a cascade of progressively shrinking 'layers' with the top layer having the highest resolution, and the bottom layer having the "
    $Text += "lowest resolution. Each descending layer is half of the resolution of the previous layer, usually all the way down to a resolution of 1x1."
    $Text += "{0}{0}"
    $Text += "An example would be an image with the resolution of 64x64. This is the 'top layer'. The next layer down would contain a 32x32 version of the "
    $Text += "same image. Moving down one more layer reveals a 16x16 version of the same image. This cascade usually continues all the way down to the lowest "
    $Text += "layer which contains an image that is 1x1, but in some cases mipmap levels end at 8x8 or 4x4. It's up to the artist/developer."
    $Text += "{0}{0}"
    $Text += "Mipmaps serve several purposes. For one, they reduce hardware requirements when rendering a scene. Suppose the scene is of a field that uses a "
    $Text += "grass texture that is visible from the camera's base and extends all the way to the horizon. As the distance from the camera increases, the "
    $Text += "renderer can make use of these additional mipmap layers. Each descending layer means less pixels to sample when an actual screen pixel is "
    $Text += "calculated which reduces hardware requirements. "
    $Text += "{0}{0}"
    $Text += "In the same scenario as above, mipmaps provide a reduced level of detail which adds to the perception of 'realism'. The farther the grass is "
    $Text += "from the focal point, less detail should be apparent. As you gaze down the street, you will notice the amount of perceivable detail in the road "
    $Text += "decreases such as the granularity, cracks, pebbles, etc. The reduced image quality of additional mipmap layers makes for a more convincing "
    $Text += "reduction in the level of detail in 3-Dimensional world. "
    $Text += "{0}{0}"
    $Text += "Mipmaps come in many forms. Some of us in the Dolphin community have developed our own terminology for them to help distinguish between the "
    $Text += "different forms they come in, so these are not 'official' terms in any way. But basically, the 3 types of mipmaps that I will explain here "
    $Text += "have been dubbed: External Mipmaps, Internal MipMaps, and Dynamic MipMaps. "
    $Text += "{0}{0}"
    $Text += "External MipMaps: The PNG format can only store a single image, so the additional layers of mipmaps must come from additional images. If the "
    $Text += "image requires 12 additional layers of mipmaps, then the collection will entail of 13 images in total. The largest image is commonly referred "
    $Text += "to as the 'top layer' or 'top level', and the additional layers are commonly referred to as the 'lower levels' or 'lower layers'. External "
    $Text += "mipmaps are not limited to the PNG format. These can be found in any format such as DDS, TGA, JPG, BMP, etc. But for Dolphin, PNG and DDS are "
    $Text += "the most common."
    $Text += "{0}{0}"
    $Text += "Internal MipMaps: These types of mipmaps are exclusive to the DDS format. DDS textures are capable of storing all layers of mipmaps within a "
    $Text += "single DDS file. This has the advantage that it makes for a much more organized texture pack. Support for internal mipmaps has been added in "
    $Text += "Dolphin starting with v5.0-3506, and has been supported in Ishiiruka for a long time now. If a DDS pack is to be generated, then I personally "
    $Text += "suggest to create it using internal mipmaps. This script is also capable of generating 'dynamic' internal mipmaps."
    $Text += "{0}{0}"
    $Text += "Dynamic MipMaps: These types of mipmaps contain variations of the same image on descending layers, but are not necessarily the exact image. "
    $Text += "Texture artists make use of dynamic mipmaps to add additional effects through textures, usually lighting. It is not a common practice, but "
    $Text += "these textures do exist so they are worth mentioning because it is why this script does not force new mipmaps by default. As of now, only the "
    $Text += "Xenoblade Chronicles pack contains them. It might not be obvious, but dynamic mipmaps can be either external or internal.{0}"
    $Text += "{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("MipMap Tutorial")
    $HelpDescription.SelectionFont = $FontSize13
    $HelpDescription.Find("External MipMaps:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Internal MipMaps:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Dynamic MipMaps:")
    $HelpDescription.SelectionFont = $FontSize10
  }
  elseif ($SelectedNode -eq 'TreeNode: Creating MipMaps with CTT-PS')
  {
    $Text = "Creating MipMaps with CTT-PS"
    $Text += "{0}{0}"
    $Text += "So you may be asking yourself, how exactly does mipmap generation work in Custom Texture Tool PS? There are several ways this script handles mipmaps, and "
    $Text += "this section is dedicated to explaining them all."
    $Text += "{0}{0}"
    $Text += "Dolphin MipMap Handling"
    $Text += "{0}{0}"
    $Text += "For Dolphin textures, mipmaps are handled automatically for all mipmap textures, meaning textures with the [m] flag (such as tex1_64x64_m_0bd03e7ac65acbaf_14_mip1.png). "
    $Text += "When CTT-PS finds a mipmap texture when generating textures, and no mipmaps are provided, it will generate mipmaps for them using the top level as a base. If mipmaps "
    $Text += "are provided with the texture, the script will use those instead. If a mipmap chain is not complete, the script will use the last mipmap in the chain to generate any "
    $Text += "missing levels lower than that last mipmap. So if a texture needs 10 mipmaps, and only 7 are provided, mipmaps 8-10 will be generated from mipmap 7."
    $Text += "{0}{0}"
    $Text += "Custom MipMap Handling"
    $Text += "{0}{0}"
    $Text += "When working with non-Dolphin textures using the option Allow All Images, the script can not know which textures require mipmaps since they will most likely not have "
    $Text += "a flag in the file name. There are two ways to generate mipmaps for these textures. The first way is to enable the option Force Create MipMaps, which will forcefully "
    $Text += "create mipmaps for all textures generated. The second way is to simply provide at least one custom mipmap with the texture. For example, suppose a texture has the file "
    $Text += 'name "biznit.png". To generate mipmaps for this specific texture, provide one level named "biznit_mip1.png". This tells the script that this is a mipmap texture, and will '
    $Text += "generate the entire mipmap chain for it, even though only a single mipmap is provided. It is also possible to provide all mipmaps levels, and the script will use them all."
    $Text += "{0}{0}"
    $Text += "Controlling MipMap Chains"
    $Text += "{0}{0}"
    $Text += "There are a number of options that can be used to alter the output of the mipmap chain. First a recap of how mipmap handling works by default. Mipmaps are handled automatically " 
    $Text += "for Dolphin textures, and must be manually identified for non-Dolphin textures. If mipmaps are not provided with the texture, mipmaps will be generated from the base texture. "
    $Text += "If mipmaps are provided, the script will use them to generate new mipmaps. If a provided mipmap chain is incomplete, the script will use the lowest mipmap in the chain to generate "
    $Text += "the remaining levels."
    $Text += "{0}{0}"
    $Text += "The first option to manipulate how mipmaps are generated is Force New MipMaps. This tells the script to ignore mipmaps provided with the pack, and generate new ones from the base "
    $Text += "textures. This can be used by users who don't like the effects of dynamic mipmaps, meaning different images on descending layers. "
    $Text += "{0}{0}"
    $Text += "The next option Create From Top Level forces the "
    $Text += "script to use the base texture to generate mipmaps from, rather than use the lowest mipmap in the chain. Using the example from before, if a texture needs 10 mipmaps, and only "
    $Text += "7 are provided, mipmap levels 8-10 will be generated from the base texture and not mipmap 7."
    $Text += "{0}{0}"
    $Text += "Next up is External DDS MipMaps which creates all DDS mipmaps externally from the main texture "
    $Text += "rather than create them internally. This option has almost no use these days, but Dolphin can make use of external mipmaps."
    $Text += "{0}{0}"
    $Text += "Finally Max MipMap Levels controls how many levels are "
    $Text += "actually generated. In almost all cases, mipmaps should be generated down to 1x1 dimensions. But sometimes mipmaps are used for distance attenuation of sprites. A sprite does not "
    $Text += "look so good with very small dimensions, so by controlling the number of mipmaps, we can control the number of pixels used to represent the smallest image."
    $Text += "{0}{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Creating MipMaps with CTT-PS")
    $HelpDescription.SelectionFont = $FontSize13
    $HelpDescription.Find("Dolphin MipMap Handling")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Custom MipMap Handling")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Allow All Images")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Force Create MipMaps")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Controlling MipMap Chains")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Force New MipMaps")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Create From Top Level")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("External DDS MipMaps")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Max MipMap Levels")
    $HelpDescription.SelectionFont = $FontSize10
  }
  elseif ($SelectedNode -eq 'TreeNode: Ishiiruka Tool and Material Maps')
  {
    $Text = "Ishiiruka Tool and Material Maps"
    $Text += "{0}{0}"
    $Text += "A big thanks goes to Tino for supporting command line in his tool, and adding a few options that made integration into "
    $Text += "this script possible. I will categorize materials into two types: combined and uncombined. Uncombined materials can consist "
    $Text += "of a color texture, a normal map (.nrm), a bump map (.bump), a specularity map (.spec), and an emissive map (.lum). A combined "
    $Text += "material is a type of texture that is created with Ishiiruka Tool from the uncombined textures, also known as a material map. "
    $Text += "{0}{0}"
    $Text += "Combined materials can have one of two types of accompanying color textures: the standard format, or if it was generated with a "
    $Text += "(.lum) texture, the emissive data will be stored in the alpha channel and the texture will be named with (_lum) suffix."
    $Text += "{0}{0}"
    $Text += "The script must know where Ishiiruka Tool is located. If 'TextureEncoder.exe' is not found when the script finds material "
    $Text += "textures or combined material maps, a 'Notice' message will be displayed in the PowerShell console. The location of Ishiiruka "
    $Text += "Tool can be selected within the 'Options' panel."
    $Text += "{0}{0}"
    $Text += "To create a material map, a color texture, a bump map, and specularity map is required. The color texture is just your normal "
    $Text += "everyday texture that you wish to apply affects to with materials. If a normal map is not provided, it will be calculated from "
    $Text += "the bump map texture. The emissive texture is also optional, and is not required to generate a combined material. All material "
    $Text += "textures must be in the same folder, including the color texture because Ishiiruka Tool looks for them together. "
    $Text += "{0}{0}"
    $Text += "Combing Materials into a Material Map"
    $Text += "{0}{0}"
    $Text += "There are several options in this script that can create material maps from uncombined materials. Depending on the option selected "
    $Text += "depends on how and where the material map will be created."
    $Text += "{0}{0}"
    $Text += "(1.) Scan Dolphin Textures For Issues: The 'Attempt Repairs' checkbox must also be ticked. This option sees uncombined materials as "
    $Text += "an 'issue' that can be 'fixed' so it creates the material map. The materials from the source pack will remain in-tact, and "
    $Text += "the combined material map will be created in the 'RepairedTextures' output folder. "
    $Text += "{0}{0}"
    $Text += "(2.) Convert Textures to Another Format: The script will automatically create material maps from uncombined materials in the "
    $Text += "newly generated pack. The materials from the source pack will remain in-tact, and the combined material map will be created in "
    $Text += "the 'ConvertedTextures' output folder. "
    $Text += "{0}{0}"
    $Text += "(3.) Rescale Textures With New Scaling Factor: Like the convert textures option, it will create material maps from any uncombined "
    $Text += "materials that are found. Depending on the 'Rescale Factor' set, all material textures will be rescaled at the calculated "
    $Text += "resolution before being combined into a material map. The materials from the source pack will remain in-tact, and the "
    $Text += "combined material map will be created in the 'RescaledTextures' output folder. "
    $Text += "{0}{0}"
    $Text += "(4.) Create Material Maps With Ishiiruka Tool: This option exists if all you want to do is create material maps. This can be "
    $Text += "done directly with the Ishiiruka Tool GUI. Whether or not this tool is used or Ishiiruka Tool is used directly is a matter of "
    $Text += "personal preference. The Ishiiruka Tool GUI offers more options which are automated in Custom Texture Tool PS. The materials "
    $Text += "from the source folder will remain in-tact, and the combined material maps will be created in the 'MaterialMap' output folder. "
    $Text += "There also exists an option to create the materials 'in-place', but this option destroys the original materials. "
    $Text += "{0}{0}"
    $Text += "Working With Combined Material Maps"
    $Text += "{0}{0}"
    $Text += "There was a time when working with an already combined material map wasn't possible. Once the materials were combined that was "
    $Text += "it, there was nothing else that could be done with it. Image editors have no idea what it is. Thanks to Tino and my relentless "
    $Text += "(and most likely annoying) demands, it is now possible to work with already combined material maps using Ishiiruka Tool.  "
    $Text += "{0}{0}"
    $Text += "I have extended the capabilities by throwing in ImageMagick and DDS Utilities which is capable of converting Ishiiruka DDS color "
    $Text += "textures into either PNG or a DDS format that most image editors will once again recognize. Combined materials in this script can"
    $Text += "be converted to other formats when asked, and rescaled with new dimensions using the rescaling option. Other than that, not much "
    $Text += "else can be done with them. Most other options will just ignore they exist. It is possible to generate watermarks on the color "
    $Text += "texture, but the material map will be discarded since watermarks are only used for identification. "
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Ishiiruka Tool and Material Maps")
    $HelpDescription.SelectionFont = $FontSize13
    $HelpDescription.Find("Combing Materials into a Material Map")
    $HelpDescription.SelectionFont = $FontSize12
    $HelpDescription.Find("Scan Dolphin Textures For Issues:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Convert Textures to Another Format:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Rescale Textures With New Scaling Factor:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Create Material Maps With Ishiiruka Tool:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Working With Combined Material Maps")
    $HelpDescription.SelectionFont = $FontSize12
  }
  elseif ($SelectedNode -eq 'TreeNode: Credits')
  {
    $Text = "Credits"
    $Text += "{0}{0}"
    $Text += "I like to give credit where credit is deserved. Truth is, even though I am the sole creator of this script, it would not have come this far without the "
    $Text += "testing and ideas of others that helped shape it into what it is today."
    $Text += "{0}{0}"
    $Text += "Bighead: The creator. Writes terrible code that kind of works.{0}"
    $Text += "Dolphin Devs: All of you are awesome for this emulator!{0}"
    $Text += "ImageMagick Team: ImageMagick is amazing and makes this script possible.{0}"
    $Text += "Nvidia: DDS Utilities is perfect, simple but useful features other programs lack.{0}"
    $Text += "degasus: Planted the initial idea for this script into my head.{0}"
    $Text += "frozenwings: Personally tested dozens of early versions until I started to get it.{0}"
    $Text += "Tino: Ishiiruka Tool command line support. Thanks Tino!{0}"
    $Text += "Zenju: Added command line to the xBRZ ScalerTest, without hesitation!{0}"
    $Text += "uncleiroh: Created the initial idea of putting watermarks on textures.{0}"
    $Text += "MeleeHD: Alerted me of uncleiroh's idea of watermarks.{0}"
    $Text += "StripTheSoul: Inadvertently gave me the idea to support OptiPNG.{0}"
    $Text += "masterotaku: Gave me the idea to implement upscaling filters.{0}"
    $Text += "TheCrach: Requested progress indication which led to the title bar progress.{0}"
    $Text += "CyberGlitch: Solely responsible for the idea behind the Seamless Method.{0}"
    $Text += "Admentus: Alerted and helped me test out an issue with decimals as commas.{0}"
    $Text += "DarthVitrial: Always reminded me to get ImageMagick v7 to work.{0}"
    $Text += "BennyAlex98: Idea for saving texture/output paths and waifu2x model select.{0}"
    $Text += "CTCaer: Motivated me to add the option to force DXT5 for DDS textures.{0}"
    $Text += "Dolphin Community: The feedback and testing is much appreciated and helped motivate me to improve it! Thanks to anyone I failed to mentioned.{0}"
    $Text += "CTT-PS Current Icon: http://icons.mysitemyway.com{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Credits")
    $HelpDescription.SelectionFont = $FontSize12
    $HelpDescription.Find("Bighead:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Dolphin Devs:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("ImageMagick Team:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Nvidia:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("degasus:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("frozenwings:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Tino:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Zenju:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("uncleiroh:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("MeleeHD:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("StripTheSoul:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("masterotaku:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("TheCrach:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("CyberGlitch:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Admentus:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("DarthVitrial:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("BennyAlex98:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("CTCaer:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("Dolphin Community:")
    $HelpDescription.SelectionFont = $FontSize10
    $HelpDescription.Find("CTT-PS Current Icon:")
    $HelpDescription.SelectionFont = $FontSize10
  }
  elseif ($SelectedNode -eq 'TreeNode: About')
  {
    $Text =  "Custom Texture Tool PS - The Beginning to the End"
    $Text += "{0}{0}"
    $Text += "Just want to say this first, it is not important to read this section. At all. This section exists only to tell the story of why this tool came to exist and the struggle "
    $Text += "that was involved in making it what it is today. If you don't care, then it's safe to just skip it completely and spend your time doing something far more productive."
    $Text += "{0}{0}"
    $Text += "But if you do care, then I have to say I'm touched. Grab yourself a drink and a snack, and get settled in because it's story time..."
    $Text += "{0}{0}"
    $Text += "In what seems like forever ago, this kind of started as a simple batch script to simply generate mipmaps. Basic stuff. I have written batch scripts before because I love to automate "
    $Text += "monotonous tasks, and I've also scripted custom scenarios in Blizzard games dating back to StarCraft/WarCraft III (anyone remember Hydra RaNcHeRz or Wintermaul Wars TE?). I have "
    $Text += "never attempted to learn a programming language so I've always been limited in what I can do, so I never attempted anything major. That is, until this script. If you can even call it 'major'."
    $Text += "{0}{0}"
    $Text += "So Dolphin emulator had this huge issue with the previous texture format when it came to paletted textures. If the texture lookup table changed, then the dumped texture hash "
    $Text += "(Name/ID) also changed. This wasn't a big problem for many games, but it was for Xenoblade Chronicles, and I was heavily invested in the texture pack. Many textures in that game dumped "
    $Text += "100s to even 1000s of times: meaning if you want that texture to be re-textured at all times, you must find every possible hash. One of my fellow contributors to the pack (frozenwings) "
    $Text += "who has evolved into a dear friend of mine made it his mission to find every possible hash for the Europe version of the game. After I got bored of making textures for awhile, I joined "
    $Text += "him in his quest and started dumping the USA version of the game. Nearly 100k textures later for both versions of the game, we realized that like Pokemon, its nearly impossible to "
    $Text += "catch them all."
    $Text += "{0}{0}"
    $Text += "So what does this have to do with this script? Well during that period I worked on a few batch scripts for us that made creating duplicates of those textures a much, much "
    $Text += "simpler task. My script would take a 'base' re-texture, search for all dumps within the folder with that base, and create clones of that base using the dumped names. After "
    $Text += "it was finished, all the dumps were deleted and we were left with a pile of re-textures ready to ship. I think by the end there ended up being near or over 120 base folders "
    $Text += "and often we would find ourselves filling each folder with 100s even 1000s of dumps to clone. By the end of it all, the pack size started climbing into the Gigabytes all the "
    $Text += "while nothing new was really being added. But a lot of good came from this, I did get much better at writing batch scripts and understanding a ton of new concepts."
    $Text += "{0}{0}"
    $Text += "Eventually after wishing upon a star for almost 2 years, degasus took notice and introduced the new texture format that finally eliminated the issue with duplicate paletted textures. We rejoiced "
    $Text += "and revered him as some kind of messiah for making our dreams come true and finally putting an end to our pain. This meant all the work we put into dumping ended up being for naught. "
    $Text += "But I do like to think it made a great example that there was something very wrong with Dolphin in the first place. I had very little to do with this new format outside of testing the "
    $Text += "shit out of it and making the suggestion to flag mipmap textures with an [m] so they can easily be identified. Because I had a lot of free time and actually understood enough that I "
    $Text += "felt I could educate others, I created a post on the forums that explained the new custom texture format, which now exists today as a sticky labelled 'Dolphin Custom Textures Info'. "
    $Text += "{0}{0}"
    $Text += "Some time into that thread, degasus says: @Bighead: As you like scripting, do you think it's worth to have a script which check all textures and warn if{0}"
    $Text += "- the upscaling factor isn't an integer{0}"
    $Text += "- the aspect ratio is changed{0}"
    $Text += "- mipmaps have wrong size{0}"
    $Text += "- mipmaps aren't complete{0}"
    $Text += "- ... "
    $Text += "{0}{0}"
    $Text += "So this is where this tool really began. At first I wasn't really all that confident that I was capable of doing even those simple tasks. The scripts I wrote for Xenoblade dealt more "
    $Text += "with loops and directories and creating copies rather than doing any real math or any actual analysis on image files. I really didn't know much about the specifics of image files in "
    $Text += "general and even today I'm still a noob compared to some of the far more talented people out there. But I did attempt it, and Custom Texture Tool the batch script was born. At first "
    $Text += "all it could do was analyze simple issues with textures and generate mipmaps since I had already written a script to do that using ImageMagick. The initial support for this was very "
    $Text += "basic, it had to delete all mipmaps before generating new ones. (Unfortunately, this basic code remained for a long time.) Next came a new loop to scan folders for textures and create "
    $Text += "a log file of all textures that were found. Simple enough. Actual error checking has to be done now which involves math, which is where batch fails because it can only work with integers, "
    $Text += "and decimals are required for many of the necessary calculations."
    $Text += "{0}{0}"
    $Text += "The first type of error checking was detecting non-integer scaling values for custom textures. The new texture format makes this very easy to calculate, since "
    $Text += "the original texture dimensions are stored in the dumped name and can be extracted. For example, tex1_24x24_0804541083813079_14 may be a texture "
    $Text += "scaled to 150x150, and knowing the original is 24x24, the scaling value can be found: (Custom Width/Original Width) for X scale, (Custom Height/Original Height) "
    $Text += "for Y scale. 150/24 gives the quotient of 6.25, which is not an integer scale and is detected as an issue. Since batch can not work with decimal values, the math "
    $Text += "ends up being 150x100/24 (multiply dividend by 100), which gives 625. The full decimal value can then be simulated by extracting the last two digits and concatenating "
    $Text += "what remains (6) with a period (.) and those last two digits (25). "
    $Text += "{0}{0}"
    $Text += "Next came checking textures for aspect ratio issues, which is again simple enough with the new custom texture format. The math is nearly identical, only this "
    $Text += "time its (Original or Custom Width/Height). Calculating this for both the original and the custom texture should end up with the same quotient. If they are not "
    $Text += "equal, then the textures have different aspect ratios and it's an issue. The same trickery (multiplying width x 100) is used to find the decimal value internally."
    $Text += "{0}{0}"
    $Text += "Soon I realized that just checking the scaling values was not enough, 5.00x6.00 would pass because they are both integer scales. So error checking for uneven "
    $Text += "scales was implemented. I thought this took care of all issues, until I started running it on multiple packs. Seeing textures with 1.00x1.00 means it is not an HD "
    $Text += "texture, so that was added as an issue. There can also be duplicate textures named from the texture converter in dolphin that have a suffix appended such as: "
    $Text += "tex1_24x24_0804541083813079_14.1 or .2, .3, etc. So count that in too, and while we're at it, copy the found duplicate textures into a folder named '~DuplicateTextures'."
    $Text += "{0}{0}"
    $Text += "Eventually came OptiPNG support. When two users named FreeEmulator and StripTheSoul were discussing this program on the Dolphin forums, and were looking for a batch solution, I figured "
    $Text += "why not add it to the script. This program optimizes the structure of PNG textures to help somewhat reduce their filesize losslessly. Seemed like a good feature, so I added it. The original "
    $Text += "code was awful as there was an entirely separate loop for it, but eventually it was written into the main loop."
    $Text += "{0}{0}"
    $Text += "After all that was done, I released it as v2.0 and figured, okay it's good enough. But OCD eventually takes over, and I thought nope, I can do more. Mipmaps "
    $Text += "had to be deleted before being generated, which is gross and I wanted a much better system. Eventually I completely reworked mipmap handling:{0}"
    $Text += "- Mipmap error checking: detect both missing mipmaps and and bad scales.{0}"
    $Text += "- Calculates what the mipmap dimensions should be.{0}"
    $Text += "- Calculates how many levels the mipmap texture should have.{0}"
    $Text += "- Find how many mipmap levels are actually in the texture folder.{0}"
    $Text += "- Use found mipmaps and generate missing mipmaps.{0}"
    $Text += "- Correctly scale mipmaps when converting textures to a fixed integer scale.{0}"
    $Text += "- Apply a sharpening filter to generated mipmaps.{0}"
    $Text += "- DDS: Combine all found mipmaps into a single texture with internal mipmaps.{0}"
    $Text += "{0}"
    $Text += "Speaking of DDS, along the way I also wanted to add support for that too. I worked on implementing both the new mipmap code and DDS support at the "
    $Text += "same time. It became a nightmare, and took over three weeks to get everything working properly because I'm a noob at this stuff (not constant work of "
    $Text += "course, but lots of time in those weeks). My first intentions were to use ImageMagick for everything and soon realized that it's not going to happen. "
    $Text += "ImageMagick DDS support was terrible and I could not accomplish anything that I wanted other than error checking. I then stumbled onto nvidia's DDS Utilities "
    $Text += "which had much more functionality than ImageMagick for the DDS format, and it allowed merging multiple images as mipmap layers. Everything I wanted. "
    $Text += "{0}{0}"
    $Text += "Actually getting everything to work the way I wanted to soon proved to be an arduous task. I have a good understanding of logic, but I am not a programmer, "
    $Text += "and doing this in batch started to seem hopeless. There were several issues to overcome. The first was that PNG images fed into DDS Utilities must have "
    $Text += "dimensions that are a multiple of 4, there is no auto correction. So, I had to do these calculations myself, and at the time I was really overthinking of how it "
    $Text += "should be done. The first solution I came up with, was to continually subtract 4 from the dimensions, until something less than 4 was hit (0-3). With that, I "
    $Text += "knew how much the texture was off by and could just add the differences to the texture dimensions. But this was SLOW, and you can get bunk dimensions! "
    $Text += "Rethinking it, I came up with a simpler solution: Dimension / 4, if it has decimal, add 1 to dimension. Test again, if fails, add 1 again. This means only a total of "
    $Text += "up to 3 loop iterations, as opposed to potentially 100's depending on the texture resolution. Now, I needed a PNG image with these new dimensions, so a "
    $Text += "temporary image must be generated. Now that it's created, make a DDS file and delete the temporary image. All of this is invisible to the user and happens in milliseconds. "
    $Text += "{0}{0}"
    $Text += "DDS can also have internal mipmaps, and while the master branch of Dolphin does not make use of them, Tino's Dolphin Ishiiruka can use them. Adding "
    $Text += "support for internal mipmaps was not an easy task, especially when trying to detect if a texture currently has them or not. Luckily nvidia tools has the "
    $Text += "'detach' command which can extract all mipmaps. Cool, calculate how many it should have, extract them, count them, and delete them. With the use of the "
    $Text += "'stitch' command, all mipmaps found in the texture pack can now be used as internal mipmaps when generating DDS textures. "
    $Text += "{0}{0}"
    $Text += "Now theres the issue with scaling DDS textures to a new integer scale, and detecting problems with scaling. Some scales will not line up, a texture with "
    $Text += "dimensions 25x26 for example, will not end up with multiple four dimensions using an integer scale of 7. It ends up as 175x182, which are not valid DDS "
    $Text += "dimensions. Using the formula mentioned before, the new DDS dimensions will end up as 176x184, but now the scale will be bad (7.04x7.07). There is "
    $Text += "nothing that can be done about that, so for DDS there are only checks that validate the dimensions (based on the closest width integer scale, 7 in this case), "
    $Text += "and not the actual scale or aspect ratio. "
    $Text += "{0}{0}"
    $Text += "The last obstacle was that textures with transparency should be compressed with DXT5, and textures without transparency should be compressed with DXT1. "
    $Text += "Luckily, ImageMagick contains functions that can test if a PNG or DDS texture has an alpha channel and whether or not it has any transparent pixels. In the batch "
    $Text += "versions of the script, I did not know how to make use of the transparency feature, so all textures with an alpha channel were compressed with DXT5. Of course since "
    $Text += "the PowerShell versions, this is no longer the case. "
    $Text += "{0}{0}"
    $Text += "I started to realize that Batch was far too limited, and I'm always striving for... something more. As mentioned before one of the biggest limitations of Batch is its "
    $Text += "inability to use decimals. Everything must be multiplied by 100 before doing the actual equations to simulate two decimal places. Another big roadblock I hit  "
    $Text += "was paths using ampersands (& symbol). In batch this means 'AND DO', so a folder named 'Bionis Leg & Colony 6' will be seen as: '...Bions Leg' AND DO "
    $Text += "'Colony 6', and batch will say 'WHAT!?' and the script will halt. Using quotes can circumvent this, but when passing a variable containing a path into a "
    $Text += "function as a parameter, the quotes are ignored within the function's actions and the same problem happens. Through experimentation I learned that "
    $Text += "surrounding the value within the function with even more quotes will fix this, but now the path has quotes in it that are not ignored, that need to be "
    $Text += "eliminated with further string manipulation. ARGH! There are many other small annoyances that I came across, but these two things were the biggest roadblocks to progress."
    $Text += "{0}{0}"
    $Text += "Okay so much of the past few paragraphs were copy and pasted from my previous story which was before the PS versions existed, so it's back to manually typing up this most "
    $Text += "likely pointless saga. So anyway, after realizing how weak batch was, I began to translate my code into PowerShell. It actually didn't take very long, maybe three weeks at "
    $Text += "the most. I really liked PowerShell because it was very similar to the scripting language used in WarCraft III. The first thing I did after getting it functional was testing "
    $Text += "the speed of the main loop because Batch loops were incredibly slow. The results were amazing! Analysing the PNG Paper Mario: TTYD pack was almost 5 times faster! The DDS "
    $Text += "pack didn't see the same gains unfortunately, but it was still about 40% faster. The reason is because I still have to rely on ImageMagick to analyze DDS textures, but PNG "
    $Text += "texture information can be retrieved using .NET which is much faster than ImageMagick. "
    $Text += "{0}{0}"
    $Text += "So CTT-PS was born and released. After v1.0, a user on the forums named 'MeleeHD' informed me of a method that another user 'uncleiroh' came up with that involved applying "
    $Text += "a watermark of the texture's name over the texture to easily identify it in-game. I thought this was a great idea, but the solution uncleiroh came up with was somewhat "
    $Text += "convoluted so I set out to see if I could do the same thing with ImageMagick and my script. It didn't take too long, and a new feature was born. Credits to those guys. "
    $Text += "{0}{0}"
    $Text += "After many bug fix versions and general quality of life changes later, Tino came up with a new kind of texture: the material map. This proved to be my next big conquest. Since I have a texture tool that is "
    $Text += "supposed to work with Dolphin textures, adding support for these textures was a top priority. I honestly did not understand much about them, the idea of bump, spec, and nrm "
    $Text += "textures was completely alien to me. And to make it even more complicating, Tino made a tool to combine these textures into a single texture. I attempted to find a way to also "
    $Text += "create these textures on my own, but I just didn't have the know-how. Then it struck me... Tino's tool can already do it, so why not ask him to support command line so his tool "
    $Text += "can also work with my tool? So I did just that, and he was very willing to offer his help and make modifications to his tool. I am still grateful to this day. After many weeks "
    $Text += "of bug testing and many failed implementations, we both eventually got everything right so working with material maps finally became a reality. "
    $Text += "{0}{0}"
    $Text += "Time passes and Dolphin forum goers continue to fill my head with ideas. For example, a Twilight Princess texture pack creator named 'Victor Rosa' had a bunch of mipmaps for "
    $Text += "textures that weren't actually mipmap textures in his pack. I wanted to create an option in my tool to delete these textures, but I did not want my script to actually modify "
    $Text += "texture packs directly. Thus, the 'Advanced Options' were born. A set of options that can specifically modify texture packs directly that are cast aside form the main options. "
    $Text += "Not long after I thought it would be nice to have an advanced option to directly generate new mipmaps. I know the texture pack author 'General_Han_Solo' used my very early "
    $Text += "mipmap generation scripts so I thought hey, if anybody will use this option maybe it will be him. "
    $Text += "{0}{0}"
    $Text += "It wasn't long after that another forum user 'masterotaku' asked if the script could apply a nearest neighbor (point) filter to all textures. The script did not have a feature "
    $Text += "to apply upscaling filters, so I thought why not. I then added support for several generic filters. Later, forum user 'Lumbeeslayer' asks for xBRZ support, so I contacted the "
    $Text += "xBRZ author 'Zenju' to see if he would add command line support to his ScalerTest application. As it turns out, everyone always seems willing to help so xBRZ support was added. "
    $Text += "Later yet, another forum user 'CyberGlitch' mentions the waifu2x filter and how amazing the results can be. So I eventually worked on implementing that as well. He also gave me "
    $Text += "the fantastic idea of what is now known in the script as the 'Seamless Method' when upscaling textures with filters. This method tiles a texture 9 times before applying the filter "
    $Text += "so the texture has adjacent pixels to work with, then the outer 8 tiles are cropped away and you are left with a perfectly seamless texture. "
    $Text += "{0}{0}"
    $Text += "After the upscaling filters, I realized there really isn't much left I can do image-wise. So I decided to implement some ideas that I've had since the beginning but did not have "
    $Text += "the necessary skills to accomplish. One such feature is the ability to combine multiple textures into a single texture, and then split them back up when the combined texture has "
    $Text += "been retextured. I honestly don't know how useful this can be outside of making a sliding puzzle or working on N64 VC games, but I thought nobody else has done this, so why not? "
    $Text += "{0}{0}"
    $Text += "So now I really was out of ideas, and it was time to tackle the final conquest, the one I dreamed about since working on the Batch script: a GUI. I knew it was possible for a long "
    $Text += "time, it was no mystery PowerShell can make use of .NET framework directly as I've already done it on several occasions. The script has had some GUI elements for quite some time, "
    $Text += "albeit very basic elements such as Open File dialogs and the like. But now it was time to make my dream a reality and learn about Windows Forms. Holy shit is there ever a ton of  "
    $Text += "information to process. Remember, I'm not a programmer, so all of this was extremely confusing at first. I've made GUI's in StarCraft 2 maps but this was about 80% more complicating. "
    $Text += "So for a few weeks I hacked away at it in secret, eventually made a reveal, then eventually released it. Sweet, a GUI and it works! Plus I was even able to keep 'Script Mode'. "
    $Text += "{0}{0}"
    $Text += "And that's the end of my story, and I'm most likely reaching the end of this tool. It has already evolved way beyond anything I ever thought I could create. I know it's nothing "
    $Text += "special, but to me personally it is. I have started countless projects over the years, but I have never once saw one through to the end; meaning, reaching a point where I can say "
    $Text += "'Yep, I did good. It's finally done.', nor felt that what I created could actually be useful to anyone. I'm somewhat proud of this tool, and it's gotten to a point where it can even "
    $Text += "reach beyond Dolphin textures with the option 'Allow All Images', meaning anyone could use it for their texture projects with any type of game."
    $Text += "{0}{0}"
    $Text += "If you actually read this far, I have to compliment you on your stamina to sit through and actually read all of this. Unless you just skipped to the end, can't say I blame you.{0}"
    $Text = [String]::Format($Text, [Environment]::NewLine)
    $HelpDescription.Text = $Text
    $HelpDescription.Find("Custom Texture Tool PS - The Beginning to the End")
    $HelpDescription.SelectionFont = $FontSize12
  }
}
#==============================================================================================================================================================================================
#  INITIALIZATION B: STUFF TO DO AFTER CREATING THE GUI
#==============================================================================================================================================================================================
# Test to see if ImageMagick is installed.
FindImageMagick

# Set all global variables to their default state. This most likely isn't necessary, but it can't hurt either.
ResetGlobalVars

# If the PowerShell X button is disabled then make it inactive.
PowershellButtonX -Disabled $DisablePSXButton

# Automatically hide the console window if the user wanted.
ShowPowerShellConsole -ShowConsole $AlwaysShowConsole

# The "Combine Multiple Textures" option stores selected textures in an 2-dimensional array. Initialize it now with an empty array.
CombineTextures_UpdateArray

# Show the dialog. The script will hang out here and not proceed until the dialog is closed.
$MainDialog.ShowDialog() | Out-Null

# Force closing the help dialog if it is visible so everything closes in sync.
if ($HelpDialog.Visible)
{
  $HelpDialog.Close()
}
# Either Windows 7 is painfully slow when updating options, or it's just my VM that's slow. 
# Whatever the case, just hide the PS console from the user until it properly shuts down.
ShowPowerShellConsole -ShowConsole $false

# Attempt to write all options that may have been changed to the script file.
StoreAllOptions

# Not likely needed since this is the end, but force it closed anyway.
Exit
